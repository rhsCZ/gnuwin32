#ifndef _WINX_BITS_TIMEX_H_
#define _WINX_BITS_TIMEX_H_

#if defined(_TIMEVAL_DEFINED) || defined(_STRUCT_TIMEVAL) 
# define _TIMEVAL_DEFINED 1
# define __TIMEVAL__ 1
# define _STRUCT_TIMEVAL     1
#endif /* _TIMEVAL_DEFINED */

#endif /*_WINX_BITS_TIMEX_H_*/
