#ifndef __WINX_WINSOCK2X_H__
#define __WINX_WINSOCK2X_H__
#ifdef __GW32__

#include <winx/winsockx.h>

#endif /* __GW32__ */

#endif /* __WINX_WINSOCK2X_H__ */
