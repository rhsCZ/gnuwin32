#ifndef __WINX_STDARGX_H__
#define __WINX_STDARGX_H__
#ifdef __GW32__

#endif /* __GW32__ */

#endif /* __WINX_STDARGX_H__ */
