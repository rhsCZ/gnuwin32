#ifndef __WINX_WINDOWSX_H__
#define __WINX_WINDOWSX_H__
#ifdef __GW32__

#define _WIN32_WINNT 0x0500

#endif /* __GW32__ */

#endif /* __WINX_WINDOWSX_H__ */
