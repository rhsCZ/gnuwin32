#ifdef __GW32__

#include <dirent.h>

#endif /* __GW32__ */
