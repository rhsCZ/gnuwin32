#ifndef __WINX_ASSERTX_H__
#define __WINX_ASSERTX_H__
#ifdef __GW32__


#endif /* __GW32__ */

#endif /* __WINX_ASSERTX_H__ */
