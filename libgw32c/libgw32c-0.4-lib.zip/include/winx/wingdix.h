#ifndef __WINX_WINGDIX_H__
#define __WINX_WINGDIX_H__
#ifdef __GW32__

/* Logcolorspace signature */

#define LCS_SIGNATURE           'PSOC'

#endif /* __GW32__ */

#endif /* __WINX_WINGDIX_H__ */
