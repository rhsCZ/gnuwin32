#ifndef __WINX_MALLOCX_H__
#define __WINX_MALLOCX_H__
#ifdef __GW32__

#define valloc malloc

#endif /* __GW32__ */

#endif /* __WINX_MALLOCX_H__ */
