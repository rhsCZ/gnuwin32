#ifndef __WINX_STDDEFX_H__
#define __WINX_STDDEFX_H__
#ifdef __GW32__

#define   _DEFUN(name, arglist, args)   name(args)
#define _AND	,
#define _CONST	const

#endif /* __GW32__ */

#endif /* __WINX_STDDEFX_H__ */
