#ifndef __WINX_SIGNALX_H__
#define __WINX_SIGNALX_H__
#ifdef __GW32__

#include <winx/sys/signalx.h>

#ifndef _SIGNAL_H
#define _SIGNAL_H
#endif

#endif /* __GW32__ */

#endif /* __WINX_SIGNALX_H__ */
