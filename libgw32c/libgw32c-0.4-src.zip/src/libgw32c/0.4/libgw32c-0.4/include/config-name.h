/* Generated automatically from config-name.in by configure. -*- C -*-
   Generated from $Id: config-name.in,v 1.1 1994/12/08 09:12:33 roland Exp $.

   This is used only by the generic `uname' function for systems with no real
   `uname' call.  If this data is not correct, it does not matter much.  */

#define UNAME_SYSNAME "win32"
#define UNAME_RELEASE "unknown"
#define UNAME_VERSION "unknown"
#define UNAME_MACHINE "i386-pc"
#define UNAME_PROCESSOR "unknown"
#define UNAME_DOMAINNAME "unknown"
