#define GEN_THIS	__GT_BIGFILE
#define tmpfile		tmpfile64
#include "tmpfile.c"
