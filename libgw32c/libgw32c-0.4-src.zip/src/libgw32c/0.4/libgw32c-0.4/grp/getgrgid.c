#include <stdlib.h>
#include <grp.h>

struct group * getgrgid (__gid_t gid) {
 return NULL;
}
