#include <stdlib.h>
#include <grp.h>

void setgrent (void) {}
