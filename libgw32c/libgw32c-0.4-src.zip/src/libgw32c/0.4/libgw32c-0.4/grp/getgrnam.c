#include <stdlib.h>
#include <grp.h>

struct group * getgrnam (const char *grp) {
  return NULL;
}
