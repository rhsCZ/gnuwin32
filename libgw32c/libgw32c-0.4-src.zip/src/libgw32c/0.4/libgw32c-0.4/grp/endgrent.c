#include <stdlib.h>
#include <grp.h>

void endgrent (void) {}
