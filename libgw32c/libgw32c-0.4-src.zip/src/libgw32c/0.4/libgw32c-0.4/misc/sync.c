void sync(void)
{
	_flushall();
}
