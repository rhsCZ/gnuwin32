unsigned int alarm(unsigned int seconds)
{
	return 0;
}

