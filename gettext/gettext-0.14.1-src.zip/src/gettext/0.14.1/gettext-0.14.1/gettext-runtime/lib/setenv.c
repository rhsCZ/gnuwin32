#include "../../gettext-tools/lib/setenv.c"
