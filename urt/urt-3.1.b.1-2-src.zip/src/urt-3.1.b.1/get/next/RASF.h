#import "Image.h"


// RASF.h
// 
// Written by Vince DeMarco 
// 	demarco@cpsc.ucalgary.ca
//
// This program is In the Public Domain. If you make any improvements to this
// program please let me know


@interface RASF:Image
{
}

- init;
- open:(char *)filename;
@end

