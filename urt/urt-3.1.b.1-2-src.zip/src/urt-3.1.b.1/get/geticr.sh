rlequant   $* | rletoppm | ppmtoicr
