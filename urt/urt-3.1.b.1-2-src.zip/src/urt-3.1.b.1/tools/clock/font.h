typedef struct {
    char type;
    int x, y;
} move_t;

