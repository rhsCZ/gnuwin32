/*
 * Definitions for Mac UI doodads
 */

extern Ptr PanicStash;

extern char * OldFilename( char *, char *, OSType );
extern char * NewFilename( char *, char * );
extern WindowPtr MakeWindow( int, int, char * );

extern void ErrorAlert( char * s );
extern void ToolboxError(char * msg, int num);
extern void MemoryError( char * s );

extern DialogPtr InitProgress();
extern void UpdateProgress( DialogPtr dlog, double fraction );
extern void DoneProgress( DialogPtr dlog );

extern void EventLoop();
extern void InitMac();
extern void CreateMenus();

extern void DoFileItem( short );

#define GrayRgn (*((RgnHandle *) 0x9ee))  /* Indulge.  Have a magic cookie. */

/*
 * Useful for checking results.  Redef for non-printf apps.
 */
#define CHECK( thing, msg ) { if (!(thing)) { ErrorAlert( msg ); return; }}

#define NIL 0L

typedef struct ImageWin {
	long tag;			/* Safety */
	WindowPtr win;		/* Mac Window */
	GWorldPtr gw;		/* Off-screen cache for it */
	char *	name;		/* Filename */
} ImageWin;