/*
 * Defs for routines to manipulate images and Pict files in 32bit QuickDraw.
 *
 * John Peterson, Apple.
 */
 
extern GWorldPtr LoadPicture( char * );
extern void SavePicture( GWorldPtr, char * );
extern void SetupPict();
extern void WritePictFile( char * );
extern void CopyGWtoWindow( GWorldPtr, WindowPtr );


