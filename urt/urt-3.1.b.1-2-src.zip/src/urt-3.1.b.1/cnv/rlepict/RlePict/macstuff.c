/*
 * This software is copyrighted as noted below.  It may be freely copied,
 * modified, and redistributed, provided that the copyright notice is 
 * preserved on all copies.
 * 
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely "as is".  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the 
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 */
/*
 * Generic mac UI doodads for the RLE converter
 *
 * John Peterson - Jan/Feb '91
 *
 * Copyright (c) 1991 John Peterson
 *
 */


#include <QDOffscreen.h>

#include "macstuff.h"
#include <Stdio.h>
#include <string.h>
#include <pascal.h>

static MenuHandle appleMenu, fileMenu, editMenu;

 
/*******************************************************************
 * 						F I L E N A M E   S T U F F 			   *
 *******************************************************************/

/*
 * Prompt for an existing filename using the StdFile dialogs
 * (i.e., for an "Open..." menu item).
 */
 
char *
OldFilename( prompt, filename, type )
char * prompt;
char * filename;
OSType type;
{
	static Point dlogWhere = { 70, 40 };
	short numTypes = (type == '????') ? -1 : 1;
	SFReply imgFile;
	char pprompt[200];
	
	strcpy( pprompt, prompt );
	CtoPstr( pprompt );
	SFGetFile( dlogWhere, pprompt, NULL, numTypes, &type, NULL, &imgFile );
	if (! imgFile.good)
	{
		filename = NULL;
		return( NULL );
	}

	SetVol( NULL, imgFile.vRefNum ); /* Go to the directory */
	PtoCstr( (char *) imgFile.fName );
	strcpy( filename, (char *)imgFile.fName );
	return( filename );
}

/*
 * Prompt for a new filename using the StdFile dialogs
 * (i.e., for an "Save As..." menu item).
 */
 
char *
NewFilename( prompt, filename )
char * prompt;
char * filename;
{
	static Point dlogWhere = { 70, 40 };
	SFReply imgFile;
	char pprompt[200];
	char pfname[200];
	
	strcpy( pfname, filename );
	CtoPstr( pfname );
	strcpy( pprompt, prompt );
	CtoPstr( pprompt );
	SFPutFile( dlogWhere, pprompt, pfname, NULL, &imgFile );
	if (! imgFile.good)
	{
		filename = NULL;
		return( NULL );
	}

	SetVol( NULL, imgFile.vRefNum ); /* Go to the directory */
	PtoCstr( (char *) imgFile.fName );
	strcpy( filename, (char *)imgFile.fName );
	return( filename );
}

/*******************************************************************
 * 						E R R O R   A L E R T S					   *
 *******************************************************************/

/*
 * Handle generic error messages.
 */
void 
ErrorAlert( char * s )
{
	char msg[255];
	char * p;
	
	strcpy( msg, s );
	/* Kill newlines */
	for (p = msg; *p; p++)
		if (*p == '\n') *p = ' ';
	CtoPstr( msg );
	ParamText( msg, NIL, NIL, NIL );
	Alert( 200, NIL );
}

/*
 * Memory errors are always fatal.  We can just happily exit - because
 * this program does no editing, no user data will be lost.
 */
void
MemoryError( char * s )
{
	DisposPtr( PanicStash );
	ErrorAlert( s );
	ExitToShell();
}

void
ToolboxError(char * msg, int num)
{
	char alertmsg[255];
	
	if (num)
	{
		sprintf( alertmsg, "%s (code=%d)", msg, num );
		ErrorAlert( alertmsg );
	}
}

/*******************************************************************
 * 						W I N D O W   C R E A T I O N			   *
 *******************************************************************/
 
/*
 * Find the "best" color screen (with the most colors)
 */
Boolean ColorScreen(best)
Rect * best;
{
	Rect r;
	GDHandle QDDev;
	Boolean mainScreen;
	int bestScreen = 0;
		
	QDDev = GetDeviceList();
	mainScreen = (*QDDev)->gdFlags & (1<<mainScrn); 
	while (QDDev)
	{
		if ((*((*QDDev)->gdPMap))->pixelSize >= bestScreen)
		{
			bestScreen = (*((*QDDev)->gdPMap))->pixelSize;
			*best = (*QDDev)->gdRect;
			mainScreen = (*QDDev)->gdFlags & (1<<mainScrn); 
		}
		QDDev = GetNextDevice( QDDev );
	}
	return( mainScreen );
}

/*
 * Create a window on the most colorful screen.
 */
WindowPtr 
MakeWindow(width, height, title)
int width, height;
char * title;
{
	Rect r, best;
	static int vOffset = 40, hOffset = 20, rowcount = 1;
	WindowPtr win;
	
	CtoPstr( title );
	(void) ColorScreen( &best ) ;
	SetRect( &r, hOffset, vOffset, hOffset+width, vOffset+height );
	OffsetRect( &r, best.left, best.top );
	win = (WindowPtr) NewCWindow( NULL, &r, title,
										  true, noGrowDocProc,
										  (Ptr) -1L, true, 0L );
	PtoCstr( title );	/* Munge it back... */
	
	/* Stagger the windows as they're opened */
	
	hOffset += 20;
	vOffset += 40;
	if (vOffset > 300)
	{
		rowcount++;
		vOffset = 40 + rowcount * 20;
		hOffset = rowcount * 20;
		if (hOffset > 500) hOffset = 20;
	}	  
	
	if (!win)
		MemoryError( "Couldn't create window - out of memory" );
	return win;
}

/*******************************************************************
 * 				P R O G R E S S   I N D I C A T O R				   *
 *******************************************************************/


DialogPtr InitProgress( short dlogID )
{
	DialogPtr progressDlog;
	progressDlog = GetNewDialog( dlogID, NULL, -1L );
	if (! progressDlog)
		MemoryError( "Couldn't load progress indicator" );
	DrawDialog( progressDlog );
	SetPort( progressDlog );
	return( progressDlog );
}

void UpdateProgress( DialogPtr dlog, double fraction )
{
	short type;
	Handle item;
	Rect r;
	
	GetDItem( dlog, 2, &type, &item, &r );
	FrameRect( &r );
	InsetRect( &r, 2, 2 );
	r.right = r.left + (r.right - r.left) * fraction;
	FillRect( &r, gray );
}

void DoneProgress( DialogPtr dlog )
{
	DisposDialog( dlog );
}

/*******************************************************************
 * 								M E N U S						   *
 *******************************************************************/

void 
CreateMenus()
{
	appleMenu = GetMenu( 100 );				/* Apple Menu */
	if (! appleMenu)
		MemoryError( "Missing Apple menu?" );
	AddResMenu( appleMenu, 'DRVR' );		/* Add all the desk accys */
	InsertMenu( appleMenu, 0 );
	
	fileMenu = GetMenu( 200 );
	if (! fileMenu)
		MemoryError( "Missing file menu?" );		
	InsertMenu( fileMenu, 0 );

	editMenu = GetMenu( 300 );
	if (! editMenu)
		MemoryError( "Missing edit menu?" );		
	InsertMenu( editMenu, 0 );
	DrawMenuBar();
}

static 
DoAppleItem (item)
	int	item;
{
	GrafPtr	curPort;
	Str255	str;
	Handle	h;

	if (item == 1)
	{
		Alert( 400, NIL );		/* Bring up the about box */
	}
	else
	{
		GetPort (&curPort);
		GetItem (appleMenu, item, str);		/* get DA name */
		SetResLoad (false);
		h = GetNamedResource ('DRVR', str);
		SetResLoad (true);
		if (h != NULL)
		{
			ResrvMem (SizeResource (h) + 0x1000);
			(void) OpenDeskAcc (str);			/* open it */
		}
		SetPort (curPort);
	}
}

/*******************************************************************
 * 							E V E N T   L O O P					   *
 *******************************************************************/

void
EventLoop()
{
	EventRecord event;
	long menuCode, part;
	WindowPtr hitWin, updateWin;
	ImageWin * imgWin;
	Rect r;
	static Boolean editMenuOn = false;
	
	do
	{
		menuCode = 0;
		
		if (GetNextEvent( mDownMask+mUpMask+keyDownMask+updateMask+activMask, &event))
		{
			if ((event.what == keyDown) && (event.modifiers & cmdKey))
			{
				menuCode = MenuKey( event.message & charCodeMask );
			}
				
			if ( (event.what == mouseDown) && (event.where.v < MBarHeight))
				menuCode = MenuSelect( event.where );

			if ( (event.what == mouseDown ))
			{
				part = FindWindow( event.where, &hitWin );
				switch (part)
				{
				case inSysWindow:
					SystemClick( &event, hitWin );
					break;
					
				case inGrow:
					/* Grow stuff goez here */
					break;
					
				case inGoAway:
					if (TrackGoAway( hitWin, event.where ))
					{
						imgWin = (ImageWin *) GetWRefCon( hitWin );
						if (imgWin->tag != 0xDEADBEEF)
						{
							ErrorAlert("Not my window!");
							break;
						}
						SetPort( thePort );		/* Avoid dangling port */
						DisposeWindow( hitWin );
						DisposeGWorld( imgWin->gw );
					}
					break;

					
				case inDrag:
					r = (*GrayRgn)->rgnBBox;
					InsetRect( &r, 4, 4 );		/* Keep it on screen */
					DragWindow( hitWin, event.where, &r );
					break;
					
				case inContent:
					SelectWindow( hitWin );
					/* maybe report RGB, or somesuch? */
					break;
					
				}
			}
			
			if (event.what == updateEvt)
			{
				/* window to be updated is in theEvent->message */
				updateWin = (WindowPtr) event.message;
				imgWin = (ImageWin *) GetWRefCon( updateWin );
				if (imgWin->tag != 0xDEADBEEF)
					ErrorAlert("Unidentified flying window...");
					
				BeginUpdate( updateWin );
				CopyGWtoWindow( imgWin->gw, updateWin );				
				EndUpdate( updateWin );
			}
			
			if (event.what == activateEvt)
			{
				updateWin = (WindowPtr) event.message;
				if ( (((WindowPeek)updateWin)->windowKind == userKind)
					&& (event.modifiers & activeFlag))
				{
					SetPort( updateWin );
					
					if (editMenuOn)
					{
						EnableItem( fileMenu, 0 );
						DisableItem( editMenu, 0 );
						DrawMenuBar();
						editMenuOn = false;
					}
				}
				if ( (! editMenuOn) && (((WindowPeek)FrontWindow())->windowKind != userKind))
				{
					EnableItem( editMenu, 0 );
					DisableItem( fileMenu, 0 );
					DrawMenuBar();
					editMenuOn = true;
				}
			}
		}
		
		if (menuCode >> 16L)
		{
			switch ( menuCode >> 16L )
			{
			case 100: 
				DoAppleItem( (short) (menuCode & 0xFFFF) );
				break;
				
			case 200:
				DoFileItem( (short) (menuCode & 0xFFFF) );
				break;

			default:
				ErrorAlert("Menu from outer space..." );
				break;
			}
		}

		HiliteMenu( 0 );
		SystemTask();
	} while(1);
}

/*******************************************************************
 * 						I N I T I A L I Z A T I O N				   *
 *******************************************************************/

/*
 * Check to make sure this Mac can run the program.
 */
static void 
CheckGoodMac()
{
	SysEnvRec env;
	
	SysEnvirons( 1, &env );
	if (env.systemVersion < 0x0605)
		MemoryError("Sorry - you must be running\rat least system 6.0.5 or later");
		
	if (! env.hasColorQD)
		MemoryError("Sorry - you must have a\rMacintosh with Color QuickDraw" );
		
	/*
	 * If the QD32 trap (AB04) is really the unimplemented trap (A89F),
	 * then QD32 isn't around.  This is from Bruce's "develop" article.
	 */
	if (NGetTrapAddress( 0xAB03, ToolTrap ) == NGetTrapAddress( 0xA89F, ToolTrap ))
		MemoryError("Sorry - 32 bit Color Quickdraw is not present");
}

/*
 * Startup / initialization
 */
 
void InitMac()
{
	MaxApplZone();
	FlushEvents( everyEvent - diskMask, 0 );
	InitGraf(&thePort);
	InitFonts();
	InitWindows();
	InitMenus();
	TEInit();
	InitDialogs( NIL );
	InitCursor();
	CheckGoodMac();
}
