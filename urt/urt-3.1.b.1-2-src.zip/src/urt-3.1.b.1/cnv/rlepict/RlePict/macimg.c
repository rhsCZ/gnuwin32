/*
 * This software is copyrighted as noted below.  It may be freely copied,
 * modified, and redistributed, provided that the copyright notice is 
 * preserved on all copies.
 * 
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely "as is".  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the 
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 */
/*
 * Routines to manipulate images and Pict files in 32bit QuickDraw.
 *
 * John Peterson, Jan-Feb '91
 *
 * Copyright (c) 1991 John Peterson
 */

#include <QDOffscreen.h>
#define srcDither 64	/* Undefined transfer mode... */

#include "macstuff.h"
#include "macimg.h"
#include <Stdio.h>
#include <string.h>
#include <pascal.h>

static PicHandle thePic;

/*******************************************************************
 * 						P I C T U R E   I / O					   *
 *******************************************************************/
 
/*
 * Start recording an image.  Note the call:
 *
 *		 CopyBits( (BitMap *) &(thePort->portBits), 
 *		    	   (BitMap *) &(thePort->portBits), 
 *		    	   &(thePort->portRect), 
 *		    	   &(thePort->portRect), srcCopy, NULL );
 * 
 * Records an image of the current port.  "thePort" can also be
 * a WindowPtr.  So to save an image file, do something like:
 *
 * 		SetupPict()
 *		// Do Quickdraw drawing commands (like the CopyBits above) here
 *		WritePictFile("Imagefile.PICT");
 *
 * See SavePicture() below...
 */
void
SetupPict()
{
	thePic = OpenPicture( &thePort->portRect );
}

/*
 * Write out the picture as a "PICT" file.  
 */
void
WritePictFile(fname)
char * fname;
{
	int i, err;
	Str255 volName;
	int curVolRefNum, refNum;
	long len;
	FInfo ftype;
	unsigned char nulls[512];
	char name[255];
	static char curname = 'A';
	
	ClosePicture();
	HLock( thePic );
	DrawPicture( thePic, &((*thePic)->picFrame) );	/* So it's visible */
	
	for (i = 0; i < 512; i++) nulls[i] = 0;
	
	err = GetVol( volName, &curVolRefNum );
	ToolboxError( "Error writing PICT file, can't get volume", err );
	
	/* If name is NULL, generate MacDraw II pictures for debugging
	 * (this was useful for another application - RlePict shouldn't do this!).
	 */
	
	if (! fname)
	{
		strcpy( name, "ZZpictX" );
		name[6] = curname++;
		err = Create( CtoPstr( name ), curVolRefNum, 'MDPL', 'PICT' );
	}
	else
	{
		strcpy( name, fname );
		err = Create( CtoPstr( name ), curVolRefNum, 'RAPP', 'PICT' );
		ToolboxError( "Error writing PICT file, can't create file", err );
	}

	/*
	 * The Apple convention is that the first 512 bytes of a
	 * PICT file are ignored (usually NULL's).
	 */
	err = FSOpen( name, curVolRefNum, &refNum );
	ToolboxError( "Error writing PICT file, can't open file", err );
	len = 512L;
	err = FSWrite( refNum, &len, nulls );
	ToolboxError( "Error writing PICT file, can't write header", err );
	
	len = GetHandleSize( thePic ); /* Don't use (*thePic)->picSize; it's only 16 bits! */
	err = FSWrite( refNum, &len, *thePic );
	ToolboxError( "Error writing PICT file, can't write data", err );
	err = FSClose( refNum );
	ToolboxError( "Error writing PICT file, can't close file", err );
	
	HUnlock( thePic );
	KillPicture( thePic );
}

/*
 * Load the Pict file "name" into a GWorld created by this routine.
 */
GWorldPtr LoadPicture(name)
char * name;
{
    GDHandle saveDevice;
    CGrafPtr savePort;
	OSErr err;
	Str255 volName;
	int curVolRefNum, refNum;
	char buf[512];
	long len;
	PicHandle qdpic;
    GWorldPtr mygw;

	err = GetVol( volName, &curVolRefNum );
	ToolboxError( "Error loading PICT file, can't set volume", err );
	err = FSOpen( CtoPstr( name ), curVolRefNum, &refNum );
	ToolboxError( "Error loading PICT file, can't set volume", err );
	err = GetEOF( refNum, &len );
	ToolboxError( "Error loading PICT file, can't get EOF", err );
	if (len <= 512)
	{
		ErrorAlert("Pict file is empty");
		err = FSClose( refNum );
		return NULL;
	}
	err = SetFPos( refNum, fsFromStart, 512L );
	ToolboxError( "Error loading PICT file, can't skip header", err );
	qdpic = (PicHandle) NewHandle( len - 512L );
	if (! qdpic)
		MemoryError( "Error loading PICT file, not enough memory" );
	HLock( qdpic );
	len -= 512L;
	err = FSRead( refNum, &len, (Ptr) (*qdpic) );
	ToolboxError( "Error loading PICT file, can't read data", err );
	err = FSClose( refNum );
	ToolboxError( "Error loading PICT file, can't close file", err );
    err = NewGWorld( &mygw, 32, &((*qdpic)->picFrame), NULL, NULL, 0 );
    if (err)
    	MemoryError( "Error loading PICT file, not enough memory" );
    if (! LockPixels( mygw->portPixMap ) )
    	MemoryError( "Can't lock pixels in memory" );
	GetGWorld( &savePort, &saveDevice );
    SetGWorld( mygw, NULL );
    EraseRect( &(mygw->portRect) );	
    DrawPicture( qdpic, &((*qdpic)->picFrame) );
    UnlockPixels( mygw->portPixMap );
    HUnlock( qdpic );
    DisposHandle( qdpic );
    SetGWorld( savePort, saveDevice );
    PtoCstr( name );		/* Leave name as we found it� */
    return( mygw );	
}

/*
 * Save a GWorld out to a Pict
 */
void SavePicture( gw, name )
GWorldPtr gw;
char * name;
{
    GDHandle saveDevice;
    CGrafPtr savePort;
    GWorldPtr tmpGW;
    QDErr err;
    
    /*
     * Creating the quickdraw picture requires making a copy
     * of the picture in memory.  This pre-flights the operation
     * so we know if it can succede
     */
     
    err = NewGWorld( &tmpGW, (*(gw->portPixMap))->pixelSize, &gw->portRect, NULL, NULL, 0 );
    if (err)
    	MemoryError( "Not enough memory to make a PICT file" );
    else
    	DisposeGWorld( tmpGW );

	GetGWorld( &savePort, &saveDevice );
	SetGWorld( (CGrafPtr) gw, NULL );
	if (! LockPixels( gw->portPixMap ) )
		MemoryError( "Can't lock pixels in memory" );
	thePic = OpenPicture( &gw->portRect );
	CopyBits( *gw->portPixMap, *gw->portPixMap, 
				&gw->portRect, &gw->portRect, srcCopy, NULL );
	WritePictFile( name );
	UnlockPixels( gw->portPixMap );
    SetGWorld( savePort, saveDevice );
}	


/* 
 * Copy an Offscreen gworld to an onscreen window
 */
void CopyGWtoWindow( gw, window )
GWorldPtr gw;
WindowPtr window;
{
	RGBColor savefg, savebg, c;
	Rect srcRect, dstRect;
	GrafPtr savePort;
	
	GetForeColor( &savefg );		/* Robert sez ya gotta do this */
	GetBackColor( &savebg );
	c.red = c.green = c.blue = 0;
	RGBForeColor( &c );
	c.red = c.green = c.blue = 0xFFFF;
	RGBBackColor( &c );
	GetPort( &savePort );
	SetPort( window );

	srcRect = (*(gw->portPixMap))->bounds;
	dstRect = window->portRect;

	if ( LockPixels( gw->portPixMap ))
	{
	    CopyBits( *gw->portPixMap, (BitMap *) &(window->portBits), 
	    		  &srcRect, &dstRect, srcDither, NULL );
    }
 	UnlockPixels( gw->portPixMap );
 	SetPort( savePort );
 	
	RGBForeColor( &savefg );
	RGBBackColor( &savebg );
}
