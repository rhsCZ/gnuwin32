#! /bin/sh
crop 0 324 509 707 | repos -p 0 0
