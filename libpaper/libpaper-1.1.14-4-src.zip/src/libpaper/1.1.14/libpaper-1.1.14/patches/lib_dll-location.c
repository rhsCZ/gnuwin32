/* Provide relocatable packages.
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Bruno Haible <bruno@clisp.org>, 2003.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.  */

#ifdef ENABLE_RELOCATABLE

#include <windows.h>
#include <stdio.h>

extern char *shared_library_fullname;

/* Determine the full pathname of the shared library when it is loaded.  */

BOOL WINAPI
DllMain (HINSTANCE module_handle, DWORD event, LPVOID reserved)
{
  (void) reserved;

  if (event == DLL_PROCESS_ATTACH)
    {
      /* The DLL is being loaded into an application's address range.  */
      static char location[MAX_PATH];
	  char *lastslash;

      if (!GetModuleFileName (module_handle, location, sizeof (location)))
     /* Shouldn't happen.  */
     return FALSE;

      if (!IS_PATH_WITH_DIR (location))
     /* Shouldn't happen.  */
     return FALSE;
//	 printf ("shared_library_fullname: %s\n", location); 
	 
//	  if ((lastslash = strrchr (location, '\\')))
//	  	*lastslash = '\0';
//	 printf ("lastslash: %s\n", lastslash+1); 
//	 printf ("shared_library_fullname: %s\n", location); 
	  shared_library_fullname = strdup (location);
    }

  return TRUE;
}

#endif /* ENABLE_RELOCATABLE */
