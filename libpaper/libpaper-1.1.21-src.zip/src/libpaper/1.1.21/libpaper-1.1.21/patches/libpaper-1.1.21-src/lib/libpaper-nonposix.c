#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

#if defined _WIN32 || defined __WIN32__
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
#endif

#include "libpaper-nonposix.h"

#define SetErrno(val) errno = val

static char *GetShortPath (const char *LongPath)
{
     char *ShortPath = NULL;
     DWORD len, res;
     
     len = GetShortPathName(LongPath, ShortPath, 0);
     if (!len) {
		SetErrno (EINVAL);
          return (char *) LongPath;
     }
     ShortPath = (char *) malloc (len + 1);
     if (!ShortPath) {
		SetErrno (EINVAL);
          return (char *) LongPath;
     }
     res = GetShortPathName(LongPath, ShortPath, len);
     if (!res) {
          free (ShortPath);
		SetErrno (EINVAL);
          return (char *) LongPath;
     }
     return ShortPath;
}

static char *UnixToWinPath (char *FileName)
{
	char *s = FileName;
	
	while (*s) {
		if (*s == '/')
			*s = '\\';
		*s++;
	}
	return FileName;
}

static char *WinToUnixPath (char *FileName)
{
	char *s = FileName;
	while (*s) {
		if (*s == '\\')
			*s = '/';
		*s++;
	}
	return FileName;
}

char *GetExecPath (char *ExecPath)
{
	int res;
	if (!ExecPath)
		ExecPath = (char *) malloc (MAX_PATH);
	res = GetModuleFileName (NULL, ExecPath, MAX_PATH);
	
	if (!res) {
		ExecPath = NULL;
		SetErrno (EINVAL);
	} else if (res > MAX_PATH) {
		ExecPath = NULL;
		SetErrno (ENAMETOOLONG);
	}		
	WinToUnixPath (ExecPath);
	return ExecPath;
}

static char *DirName (char *FileName)
{
	char *LastSlash;

	if ((LastSlash = strrchr (FileName, '/')) != NULL)
		*LastSlash = '\0';
	return FileName;
}

char *ParentName (char *FileName)
{
	char *LastSlash;

	WinToUnixPath (FileName);
//printf ("ParentName: FileName = %s\n", FileName);
	if ((LastSlash = strrchr (FileName, '/')) != NULL)
		*LastSlash = '\0';
//printf ("ParentName: FileName = %s\n", FileName);
	if ((LastSlash = strrchr (FileName, '/')) != NULL)
		*LastSlash = '\0';
//printf ("ParentName: FileName = %s\n", FileName);
	return FileName;
	return FileName;
}

static char *GetExecParent (char *ExecParent)
{
	ExecParent = GetExecPath (ExecParent);
	ParentName (ExecParent);
	return ExecParent;
}

/* return a malloced string equal to path with origparent replaced by currentparent */
char *relocate (const char *currentparent, const char *origparent, const char *path)
{
	char *relative_path, *relocated_path, *relocated_short_path;
	int relative_pathLen, OrigParentLen, CurrentParentLen;
	
//	printf ("path:                 %s\n", path);
//	printf ("OrigParent:          %s\n", origparent);
//	printf ("CurrentParent:          %s\n", currentparent);
	WinToUnixPath (origparent);
	WinToUnixPath (currentparent);
	OrigParentLen = strlen (origparent);
	CurrentParentLen = strlen (currentparent);
	relative_path = (char *) path + OrigParentLen;
//	printf ("relative_path:        %s\n", relative_path);
	relative_pathLen = strlen (relative_path);
	relocated_path = malloc (CurrentParentLen + relative_pathLen + 1);
	strcpy (relocated_path, currentparent);
	strcat (relocated_path, relative_path);
//	printf ("relocated_path:       %s\n", relocated_path);
	relocated_short_path = GetShortPath (relocated_path);
//	printf ("relocated_short_path: %s\n", relocated_short_path);
	if (relocated_short_path) {
		if (relocated_short_path != relocated_path)
			free (relocated_path);
		return relocated_short_path;
	} else
		return relocated_path;
}


char *relocatex (const char *installdir, const char *path)
{
	char *p, *ExecParent = NULL;

	ExecParent = GetExecParent (ExecParent);
	if (access (path, R_OK))
		p = relocate (ExecParent, installdir, path);
	else
		p = (char *) path;
//	printf ("relocatenx: %s\n", p);
	if (ExecParent)
		free (ExecParent);
	return p;
}

