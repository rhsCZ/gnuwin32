/* Provide relocatable packages.
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Bruno Haible <bruno@clisp.org>, 2003.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.  */

#include <windows.h>
#include <stdio.h>

#include "libpaper-nonposix.h"

char *shared_library_parent;

/* Determine the full pathname of the shared library when it is loaded.  */

BOOL WINAPI
DllMain (HINSTANCE module_handle, DWORD event, LPVOID reserved)
{
  (void) reserved;

  if (event == DLL_PROCESS_ATTACH)
    {
      /* The DLL is being loaded into an application's address range.  */
      static char location[MAX_PATH];

      if (!GetModuleFileName (module_handle, location, sizeof (location)))
     /* Shouldn't happen.  */
     return FALSE;

      if (!IS_PATH_WITH_DIR (location))
     /* Shouldn't happen.  */
     return FALSE;
	 
	shared_library_parent = strdup (location);
//	 printf ("shared_library_parent: %s\n", location); 
	ParentName (shared_library_parent);
//	 printf ("shared_library_parent: %s\n", location); 
    }

  return TRUE;
}
