/* Provide relocatable packages.
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Bruno Haible <bruno@clisp.org>, 2003.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.  */

#ifndef _RELOCATABLE_H
#define _RELOCATABLE_H
#ifndef __GW32__
# define relocate(path) (path)
# define relocaten2(name,installdir,path) (path)
# define relocatenx(name,installdir,path) (path)
# define relocate2(installdir,path) (path)
# define relocatex(installdir,path) (path)
#else /*  __GW32__ */
 
#ifdef __cplusplus
extern "C" {
#endif

/* When building a DLL, we must export some functions.  Note that because
   this is a private .h file, we don't need to use __declspec(dllimport)
   in any case.  */
#if defined _WIN32 && BUILDING_DLL
# define RELOCATABLE_DLL_EXPORTED __declspec(dllexport)
#else
# define RELOCATABLE_DLL_EXPORTED
#endif

/* Original installation prefix.  */
extern char *orig_prefix;
extern size_t orig_prefix_len;
/* Current installation prefix.  */
extern char *curr_prefix;
extern size_t curr_prefix_len;
extern char *set_orig_prefix (const char *orig_prefix_arg);
extern char *set_current_prefix (const char *ModuleName);
extern char *relocaten (const char *ModuleName, const char *path);
extern char *relocaten2 (const char *ModuleName, const char *installdir, const char *path);
extern char *relocatenx (const char *ModuleName, const char *installdir, const char *path);
extern char *relocate2 (const char *installdir, const char *path);
extern char *relocatex (const char *installdir, const char *path);
extern char *get_orig_prefix (void);
extern char *get_curr_prefix (void);
extern char *set_curr_prefix (const char *ModuleName);

#ifdef __cplusplus
}
#endif

#endif /*  __GW32__ */

#endif /* _RELOCATABLE_H */
