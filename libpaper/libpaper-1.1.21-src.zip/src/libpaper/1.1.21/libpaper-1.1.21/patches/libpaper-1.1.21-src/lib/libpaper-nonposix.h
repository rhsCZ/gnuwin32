#ifndef _NONPOSIX_H
#define _NONPOSIX_H 1

#include <errno.h>
#include <fcntl.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef PIPE_BUF
#define PIPE_BUF 0
#endif /* PIPE_BUF  */

#define __set_errno(val)  errno = val

#define _stat  _stati64
#define stat   _stati64
#define off_t  __int64

#if defined _WIN32 || defined __WIN32__ || defined __EMX__ \
	|| defined __DJGPP__ || defined __MSDOS__
  /* Win32, OS/2, DOS */
#define PATH_SEPARATOR						';'
#define DRIVE_SEPARATOR					':'
#define DIR_SEPARATOR						'\\'
#define DIR_SEPARATOR_STR					"\\"
#define ISSLASH(C)							((C) == '/' || (C) == '\\')
#define STRRSLASH(S,C)						\
	do {									\
		char *s1, s2;						\
		s1 = strrchr (S, '/');				\
		s2 = strrchr (S, '\\');				\
		if (s1 < s2)						\
			C = s2;							\
		else								\
			C = s1;							\
	} while (0)
#define HAS_DEVICE(P) 						\
    ((((P)[0] >= 'A' && (P)[0] <= 'Z') || ((P)[0] >= 'a' && (P)[0] <= 'z')) \
     && (P)[1] == DRIVE_SEPARATOR)
#define IS_PATH_WITH_DIR(P) \
    (strchr (P, '/') != NULL || strchr (P, '\\') != NULL || HAS_DEVICE (P))
#define FILESYSTEM_PREFIX_LEN(P) 			(HAS_DEVICE (P) ? 2 : 0)
#define GET_PROGRAM_NAME(progname,name)	\
   do {                                     \
     char *p, *my_program_name;             \
                                            \
     p = strrchr((name), DIR_SEP);          \
     if (p == NULL)                         \
       p = (name);                          \
     else                                   \
       p++;                                 \
                                            \
     my_program_name = strdup(p);           \
     p = strrchr(my_program_name, '.');     \
     if (p != NULL)                         \
       *p = '\0';                           \
                                            \
     progname = my_program_name;            \
   } while (0)
#define IS_ABSOLUTE(P)                     (IS_SLASH((P)[0]) || ((P)[0] && (P)[1] == DRIVE_SEPARATOR))
#define SET_BINARY(f)                      do {if (!isatty(f)) setmode(f,O_BINARY);} while (0)
#else /* WIN, EMX, DOS */
  /* Unix */
#define SET_BINARY(f)                      (void)0
#define HAS_DEVICE(P)                      (0)
#define IS_ABSOLUTE(P)                     ((P)[0] == '/')
#define PATH_SEPARATOR						':'
#define DIR_SEPARATOR						'/'
#define ISSLASH(C)							((C) == '/')
#define IS_PATH_WITH_DIR(P)				(strchr (P, DIR_SEPARATOR) != NULL)
#define FILESYSTEM_PREFIX_LEN(P)			0
#define GET_PROGRAM_NAME(progname,name)	do {(progname) = (name);} while (0)
#define STRRSLASH(S,C)						\
	do {									\
		char *s1;							\
		s1 = strrchr (S, '/');				\
		C = s1;								\
	} while (0)
#endif  /* WIN, EMX, DOS */

#define PATH_SEP							PATH_SEPARATOR
#define DIR_SEP								DIR_SEPARATOR
#define IS_SLASH(C)							ISSLASH(C)
#define ISDIRSEP(C) 						ISSLASH(C)
#define ISDIRSEPARATOR(c)					ISDIRSEP(c)
#define ISPATHSEPARATOR(c)					((c) == PATH_SEPARATOR)
#define ISDRIVESEP(c)						((c) == DRIVE_SEPARATOR)
#define ISUNCNAME(s) ((strlen(s) > 2) && ISDIRSEP(s[0]) && ISDIRSEP(s[1]))
#define ISFULLPATH(s) ((strlen(s) >= 2 && ISDRIVESEP(s[1])) || ISUNCNAME(s))
#define HAVE_DRIVE(P)						HAS_DEVICE(P)

extern inline int pipe (int pipedes[2])
{
     return _pipe(pipedes, 0, _O_BINARY | _O_NOINHERIT);
}


extern inline pid_t
wait (int *stat_loc)
{
     return _cwait (stat_loc, 0, 0);
}

extern inline int
fork ()
{
  __set_errno (ENOSYS);
  return -1;
}

#ifdef _WIN32
extern char *shared_library_parent;
char *ParentName (char *FileName);
char *relocate (const char *currentparent, const char *origparent, const char *path);
#else /*  _WIN32 */
# define relocate(name,installdir,path) (path)
#endif /*  _WIN32 */

#endif /* _NONPOSIX_H */
