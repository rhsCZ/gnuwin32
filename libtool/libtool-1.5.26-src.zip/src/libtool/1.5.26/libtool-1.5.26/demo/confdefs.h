#define PACKAGE_NAME "demo"
#define PACKAGE_TARNAME "demo"
#define PACKAGE_VERSION "1.0"
#define PACKAGE_STRING "demo 1.0"
#define PACKAGE_BUGREPORT "bug-libtool@gnu.org"
#define PACKAGE "demo"
#define VERSION "1.0"
#define STDC_HEADERS 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STRINGS_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#define HAVE_UNISTD_H 1
