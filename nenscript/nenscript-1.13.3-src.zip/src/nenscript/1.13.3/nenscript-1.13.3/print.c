
/*
 *   $Id: print.c,v 1.2 1992/10/02 01:02:32 craigs Exp $
 *
 *   This code was written by Craig Southeren whilst under contract
 *   to Computer Sciences of Australia, Systems Engineering Division.
 *   It has been kindly released by CSA into the public domain.
 *
 *   Neither CSA or me guarantee that this source code is fit for anything,
 *   so use it at your peril. I don't even work for CSA any more, so
 *   don't bother them about it. If you have any suggestions or comments
 *   (or money, cheques, free trips =8^) !!!!! ) please contact me
 *   care of geoffw@extro.ucc.oz.au
 *
 */

#include "machdep.h"
#include "defs.h"

#include "print.h"
#include "paper.h"
#include "postscri.h"
#include "main.h"

/********************************
  defines
 ********************************/
#define	PAGEBREAK	('L' - 0x40)


/********************************
  print_file
 ********************************/

void print_file (input, output, filename, line_numbers, dotmatrix)

FILE *input;
FILE *output;
char *filename;
int  line_numbers;
int  dotmatrix;

{
  char line[8192+1];
  char line1[8192+1];
  int touched = False;
  int gotnws = False;
  char *p,*p1,*wrp_start;
  long line_num = 1;
  char *buffer;
  int  bufflen;
  char line_num_buf[9];

  buffer  = line;
  bufflen = 8192;

  if (line_numbers) {
    buffer  += 8;
    bufflen -= 8;
    sprintf (line, "%7lu:", line_num);
  }

  StartDocument (output, filename);

  while (fgets (buffer, bufflen, input) != NULL) {

    /* remove the trailing newline from the line */
    buffer [strlen(buffer)-1] = 0;

    /* Search for page breaks anywhere on the line */
    for (p = buffer; *p && *p != PAGEBREAK; p++)
        ;
    if (dotmatrix && *p == PAGEBREAK) {
      /* cut the lines up around the page breaks
       * and print each seperately
       */
      if (line_numbers) {
        sprintf (line1, "%7lu:", line_num);
        wrp_start=line1 + strlen(line1);
      } else {
   line1[0]='\0';
        wrp_start=line1;
      }

      p1 = wrp_start;
      p = buffer;
      do {
        if (*p == PAGEBREAK || *p == '\0') {
          *p1='\0';
          if (gotnws) {
            WriteLine (output, line1);
            touched = True;
          }
          if (*p == PAGEBREAK)
            EndColumn (output);
          p1 = wrp_start;
          gotnws = False;
        } else {
          if (*p != ' ' && *p != '\t')
             gotnws = True;
          *p1++ = *p;
        }
      } while (*p++);
      line_num++;
    } else {
      /* if the line is a page break, then handle it */
      for (p = buffer; *p == ' ' || *p == '\t'; p++)
        ;
      if (*p == PAGEBREAK) {
        if (touched)
          EndColumn (output);
      } else {
        WriteLine (output, line);
        touched = True;
        line_num++;
      }
    }
    if (line_numbers)
      sprintf (line, "%7lu:", line_num);
  }

  EndDocument (output);
}
