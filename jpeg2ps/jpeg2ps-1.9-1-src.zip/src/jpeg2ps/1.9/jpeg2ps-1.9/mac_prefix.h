/*
 * Prefix file for CodeWarrior on the Mac.
 * This is a workaround for the silly fact that
 * CodeWarrior doesn't support any project-wide
 * preprocessor settings directly. Sigh.
 */
 
#define MAC
#define DROPUNIX
