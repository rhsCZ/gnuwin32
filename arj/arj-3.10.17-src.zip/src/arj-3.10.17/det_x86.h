/*
 * $Id: det_x86.h,v 1.1.1.1 2002/03/28 00:02:20 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * Prototypes of the functions located in DET_X86.ASM are declared here.
 *
 */

#ifndef DET_X86_INCLUDED
#define DET_X86_INCLUDED

/* Prototypes */

unsigned int detect_x86();

#endif

