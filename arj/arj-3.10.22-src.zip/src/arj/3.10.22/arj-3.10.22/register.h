/*
 * $Id: register.h,v 1.1.1.1 2002/03/28 00:03:24 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * REGISTER exported stubs are declared here.
 *
 */

#ifndef REGISTER_INCLUDED
#define REGISTER_INCLUDED

/* Prototypes */

void decrypt_regproc();
void encrypt_regproc();

#endif

