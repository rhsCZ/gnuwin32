/*
 * $Id: rearj.h,v 1.1.1.2 2002/03/28 00:03:19 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * This file contains declarations of functions exported from REARJ.
 *
 */

#ifndef REARJ_INCLUDED
#define REARJ_INCLUDED

/* Prototypes */

void pause_error(FMSG *msg);

#endif
