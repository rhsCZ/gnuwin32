/*
 * $Id: filemode.h,v 1.1.1.1 2002/03/28 00:02:55 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * This file declares references on data in FILEMODE.C
 *
 */

#ifndef FILEMODE_INCLUDED
#define FILEMODE_INCLUDED

extern char m_r[];
extern char m_rb[];
extern char m_rbp[];
extern char m_rp[];
extern char m_w[];
extern char m_wb[];
extern char m_wbp[];
extern char m_a[];
extern char m_abp[];

#endif
