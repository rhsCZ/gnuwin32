#include <config.h>
char const version_string[] = "(GNU diffutils) 2.8.1";
