/* Define this when you able to redeclare getpw functions */
#undef HAVE_GETPW_DECLS
