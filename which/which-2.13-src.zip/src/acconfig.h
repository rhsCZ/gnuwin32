/* Define if you need xmalloc() */
#undef NEED_XMALLOC
