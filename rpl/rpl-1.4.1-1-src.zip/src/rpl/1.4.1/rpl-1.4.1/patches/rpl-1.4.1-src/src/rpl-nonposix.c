#ifdef _WIN32

#include <errno.h>
#include <stddef.h>
#include <unistd.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include <windows.h>
#include "rpl-nonposix.h"

char *realpath (const char *name, char * resolved_name)
{
    char *rpath = NULL, *lpFilePart;
    int len, res;
    len = GetFullPathName(name, 0, rpath, &lpFilePart);
    if (len == 0) {
         errno = EINVAL;
         return NULL;
    }
    if (resolved_name == NULL)
		resolved_name = malloc(len);
    res = GetFullPathName(name, len, resolved_name, &lpFilePart);
    if (res == 0) {
         errno = EINVAL;
         return NULL;
    }
    return resolved_name;
}


int mkstemp(char *template)
{
	char *tmpfilename;
	
//	fprintf (stderr, "mkstemp: template = %s\n", template);
	tmpfilename = _mktemp (template);
//	fprintf (stderr, "mkstemp: tmpfilename = %s\n", tmpfilename);
	return _open (tmpfilename, _O_RDWR | _O_CREAT | _O_EXCL | _O_TRUNC | _O_BINARY, 
			_S_IREAD | _S_IWRITE);
}

#endif /* _WIN32 */
