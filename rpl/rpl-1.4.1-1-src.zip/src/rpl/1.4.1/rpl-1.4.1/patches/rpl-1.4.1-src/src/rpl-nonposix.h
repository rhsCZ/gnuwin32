#ifndef RPL_NONPOSIX_H_INCLUDED
#define RPL_NONPOSIX_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32

extern char *realpath (const char *name, char *resolvedname);
extern int mkstemp(char *template);

#endif /* _WIN32 */

#ifdef __cplusplus
}
#endif

#endif /* RPL_NONPOSIX_H_INCLUDED  */
