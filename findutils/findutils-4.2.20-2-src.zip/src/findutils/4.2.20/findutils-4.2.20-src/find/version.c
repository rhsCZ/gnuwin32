#include <config.h>
char *version_string = VERSION;

