/* Provide relocation for macro and font files.
   Copyright (C) 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.  */

/* made after the relocation in kpathsea and gettext */

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <stdio.h>
#include <limits.h>

#if defined _WIN32 || defined __WIN32__
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
# define DEFAULT_PATHEXT ".com;.exe;.bat;.cmd"
# define LEN_DEFAULT_PATHEXT sizeof (DEFAULT_PATHEXT)
#endif

#include "defs.h"
#include "nonposix.h"
#include "relocate.h"

#define INSTALLPATHLEN  (sizeof(INSTALLPATH) - 1)
#define DEBUG 0

extern char *program_name;

static char *curr_prefix = NULL; /* the prefix (parent directory) corresponding to the binary */
static size_t curr_prefix_len = 0;

/* return the directory part of a filename, or "." if no path separators */
char *xdirname (char *s)
{
  static const char dot[] = ".";

  if (!s)
    return NULL;
  // DIR_SEPS[] are possible directory separator characters, see nonposix.h
  // We want the rightmost separator of all possible ones.
  // Example: d:/foo\\bar.
  char *p = strrchr(s, DIR_SEPS[0]), *p1;
  const char *sep = &DIR_SEPS[1];
  
  while (*sep)
    {
      p1 = strrchr(s, *sep);
      if (p1 && (!p || p1 > p))
     p = p1;
      sep++;
    }
  if (p)
    *p = '\0';
  else
    s = (char *) dot;
  return s;
}

/* return the full path of NAME along the path PATHP
   adapted from search_path::open_file in searchpath.cpp
*/
char *searchpath (const char *name, const char *pathp)
{
  char *p, *path;
  if ((!name) || (!*name))
  	return NULL;
#if DEBUG
  fprintf(stderr, "searchpath: pathp: `%s'\n", pathp);
  fprintf(stderr, "searchpath: trying `%s'\n", name);
#endif
/* try first NAME as such; success if NAME is an absolute filename,
   or if NAME is found in the current directory
*/
  if (!access (name, F_OK)) {
    path = malloc (PATH_MAX);
    path = realpath (name, path);
#if DEBUG
    fprintf(stderr, "searchpath: found `%s'\n", path);
#endif
    return path;
  }

/* secondly, try the current directory */

/* now search along PATHP */
  unsigned namelen = strlen(name);
  p = (char *) pathp;
  for (;;) {
    char *end = strchr(p, PATH_SEP_CHAR);
    if (!end)
      end = strchr(p, '\0');
    int need_slash = end > p && strchr(DIR_SEPS, end[-1]) == 0;
    path = malloc(end - p + need_slash + namelen + 1);
    memcpy(path, p, end - p);
    if (need_slash)
      path[end - p] = '/';
    strcpy(path + (end - p) + need_slash, name);
#if DEBUG
    fprintf(stderr, "searchpath: trying `%s'\n", path);
#endif
	if (!access (path, F_OK)) {
#if DEBUG
      fprintf(stderr, "searchpath: found `%s'\n", name);
#endif
	return path;
	}
	free (path);
    if (*end == '\0')
      break;
    p = end + 1;
  }
  return NULL;
}

/* search NAME along PATHP with the elements of PATHEXT in turn added */
char *searchpathext (const char *name, const char *pathext, const char *pathp)
{
	char *ext, *namex, *tmpathext, *found = NULL;
  
	tmpathext = strdup (pathext); /* strtok modifies this string, so make a copy */
	if (!tmpathext)
		return NULL;
	ext = strtok (tmpathext, PATH_SEP);
	while (ext) {
		namex = (char *) malloc (strlen (name) + strlen (ext) + 1);
		if (!namex)
			return NULL;
		strcpy (namex, name);
		strcat (namex, ext);
		found = searchpath (namex, pathp);
		free (namex);
		if (found)
			 break;
		ext = strtok (NULL, PATH_SEP);
     }
     return found;
}

/* convert an MS path to a POSIX path */
char *msw2posixpath(char *path)
{
     char *s = path;
     while (*s) {
		if (*s == '\\')
		     *s = '/';
		*s++;
     }
     return path;
}

/* compute the current prefix */
char *
set_current_prefix (void)
{
	char *pathextstr;
	int len = 0;
	
	curr_prefix = malloc (MAX_PATH * sizeof (char));
	if (!curr_prefix)
		return NULL;
/* obtain the full path of the current binary;
   using GetModuleFileName on MS-Windows,
   and searching along PATH on other systems
*/
#ifdef _WIN32
	len = GetModuleFileName (NULL, curr_prefix, MAX_PATH);
	if (len)
		len = GetShortPathName (curr_prefix, curr_prefix, MAX_PATH);
#if DEBUG
	fprintf (stderr, "curr_prefix: %s\n", curr_prefix);
#endif /* DEBUG */
#else
	if (!len)
		curr_prefix = searchpath (program_name, getenv ("PATH"));
    if (!curr_prefix && !strchr (program_name, '.')) { /* try with extensions */
		pathextstr = strdup (getenv ("PATHEXT"));
		if (!pathextstr)
			pathextstr = DEFAULT_PATHEXT;
		curr_prefix = searchpathext (program_name, pathextstr,getenv ("PATH"));
	}
	if (!curr_prefix) {
		free (curr_prefix);
		curr_prefix = NULL;
		return NULL;
	}
#endif /* _WIN32 */
	msw2posixpath (curr_prefix);
#if DEBUG
	fprintf (stderr, "curr_prefix: %s\n", curr_prefix);
#endif /* DEBUG */
	curr_prefix = xdirname (curr_prefix);	/* directory of executable */
	curr_prefix = xdirname (curr_prefix);	/* parent directory of executable */
	curr_prefix_len = strlen (curr_prefix);
#if DEBUG
	fprintf (stderr, "curr_prefix: %s\n", curr_prefix);
	fprintf (stderr, "curr_prefix_len: %d\n", curr_prefix_len);
#endif /* DEBUG */
	return curr_prefix;
}

/* strip the installation prefix and replace it with the current installation prefix;
   return the relocated path
*/
char *relocatep (const char *path)
{
	char *relative_path, *relocated_path;
	int relative_path_len;
	
#if DEBUG
	fprintf (stderr, "relocatep: path = %s\n", path);
	fprintf (stderr, "relocatep: INSTALLPATH = %s\n", INSTALLPATH);
	fprintf (stderr, "relocatep: INSTALLPATHLEN = %d\n", INSTALLPATHLEN);
#endif /* DEBUG */
	if (!curr_prefix)
		set_current_prefix ();
	if (strncmp (INSTALLPATH, path, INSTALLPATHLEN))
		return strdup(path);
	relative_path = (char *) path + INSTALLPATHLEN;
	relative_path_len = strlen (relative_path);
	relocated_path = malloc (curr_prefix_len + relative_path_len + 1);
	strcpy (relocated_path, curr_prefix);
	strcat (relocated_path, relative_path);
#if DEBUG
	fprintf (stderr, "relocated_path: %s\n", relocated_path);
#endif /* DEBUG */
	return relocated_path;
}

/* return the original pathname if it exists; otherwise return the relocated path */
char *relocate (const char *path)
{
	char *p;

	if (access (path, F_OK))
		p = relocatep (path);
	else
		p = strdup(path);
#if DEBUG
	fprintf (stderr, "relocate: %s\n", p);
#endif /* DEBUG */
	return p;
}
