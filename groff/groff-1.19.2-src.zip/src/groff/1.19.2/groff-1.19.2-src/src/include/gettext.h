/* This is a dummy header file to make getopt compile without gettext
   support. */

#define gettext(s) s
