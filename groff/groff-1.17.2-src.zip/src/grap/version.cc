#include <string>
using namespace std;
string version="grap-1.20 compiled under CYGWIN_98-4.10 1.3.2(0.39/3/2)";
