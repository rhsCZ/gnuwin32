typedef union {
    int val;
    double num;
    string *String;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
    coordid *coordident;
} YYSTYPE;
#define	NUMBER	257
#define	START	258
#define	END	259
#define	IDENT	260
#define	COPY	261
#define	SEP	262
#define	STRING	263
#define	COORD_NAME	264
#define	SOLID	265
#define	INVIS	266
#define	DOTTED	267
#define	DASHED	268
#define	DRAW	269
#define	LPAREN	270
#define	RPAREN	271
#define	FUNC0	272
#define	FUNC1	273
#define	FUNC2	274
#define	COMMA	275
#define	LINE	276
#define	PLOT	277
#define	FROM	278
#define	TO	279
#define	AT	280
#define	NEXT	281
#define	FRAME	282
#define	LEFT	283
#define	RIGHT	284
#define	TOP	285
#define	BOTTOM	286
#define	UP	287
#define	DOWN	288
#define	HT	289
#define	WID	290
#define	IN	291
#define	OUT	292
#define	NONE	293
#define	TICKS	294
#define	OFF	295
#define	BY	296
#define	GRID	297
#define	LJUST	298
#define	RJUST	299
#define	ABOVE	300
#define	BELOW	301
#define	ALIGNED	302
#define	PLUS	303
#define	MINUS	304
#define	TIMES	305
#define	DIV	306
#define	CARAT	307
#define	EQUALS	308
#define	SIZE	309
#define	UNALIGNED	310
#define	LABEL	311
#define	RADIUS	312
#define	CIRCLE	313
#define	ARROW	314
#define	XDIM	315
#define	YDIM	316
#define	LOG_X	317
#define	LOG_Y	318
#define	LOG_LOG	319
#define	COORD	320
#define	TEXT	321
#define	DEFINE	322
#define	IF	323
#define	THEN	324
#define	ELSE	325
#define	EQ	326
#define	NEQ	327
#define	LT	328
#define	GT	329
#define	LTE	330
#define	GTE	331
#define	NOT	332
#define	OR	333
#define	AND	334
#define	FOR	335
#define	DO	336
#define	MACRO	337
#define	COPYTEXT	338
#define	THRU	339
#define	GRAPH	340
#define	REST	341
#define	PRINT	342
#define	PIC	343
#define	TROFF	344
#define	UNTIL	345
#define	COLOR	346
#define	SPRINTF	347
#define	SH	348
#define	BAR	349
#define	FILL	350
#define	FILLCOLOR	351
#define	BASE	352
#define	ON	353
#define	LHS	354


extern YYSTYPE yylval;
