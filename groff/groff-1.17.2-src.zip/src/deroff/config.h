/* config.h.  Generated automatically by configure.  */
/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if realloc(0,n) fails. */
/* #undef BROKEN_REALLOC */

/* Define if you have <nl_types.h>. */
/* #undef HAVE_NL_TYPES_H */

/* The version string. */
#define VERSION "1.6"
