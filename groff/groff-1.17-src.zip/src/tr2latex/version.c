/*
** tr2latex - troff to LaTeX converter
** $Id: version.c,v 2.2 1992/04/27 15:13:26 Christian_Engel Dist krischan $
** COPYRIGHT (C) 1987 Kamal Al-Yahya, 1991,1992 Christian Engel
*/

char version [] = "tr2latex ($Revision: 2.2 $$Date: 1992/04/27 15:13:26 $ by C. Engel)";
