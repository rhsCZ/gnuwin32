/*
** tr2latex - troff to LaTeX converter
** $Id: flip.h,v 2.2 1992/04/27 15:13:26 Christian_Engel Dist krischan $
** COPYRIGHT (C) 1987 Kamal Al-Yahya, 1991,1992 Christian Engel
**
** Module: flip.h
**
** This file contains the words that are placed the opposite way
** in troff and TeX. Is there any more?
*/

char *flip_list[] =
{
"bar",  "dot",   "dotdot",   "hat",    "tilde",   "under",     "vec"
};
