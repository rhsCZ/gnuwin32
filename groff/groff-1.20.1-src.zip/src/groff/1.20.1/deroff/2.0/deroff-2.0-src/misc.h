#ifndef MISC_H
#define MISC_H

#ifdef BROKEN_REALLOC
#define realloc(p,s) myrealloc(p,s)
#endif

#endif
