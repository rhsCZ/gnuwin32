/* Copyright (C) 1989, 1990, 1991, 1992 Free Software Foundation, Inc.
     Written by James Clark (jjc@jclark.com) */

#include <stdlib.h>

void 
fatal_error_exit()
{
  exit (EXIT_FAILURE);
}
