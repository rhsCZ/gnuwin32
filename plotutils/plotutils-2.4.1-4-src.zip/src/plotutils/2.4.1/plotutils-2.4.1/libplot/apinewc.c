/* This file is specific to libplot, rather than libplotter.  It defines
   the new (i.e., thread-safe) C API.  The new C API contains wrappers
   around the operations that may be applied to any Plotter object, plus
   two additional functions (pl_newpl_r, pl_deletepl_r) that are specific
   to libplot.

   pl_newpl_r/pl_deletepl_r construct and destroy Plotter instances.  Their
   names resemble the C++ operations `new' and `delete'.  When a new
   Plotter of any type is constructed, the appropriate `default_init'
   structure, which contains function pointers, is copied into it.  Then
   its `initialize' method is invoked.  Before the Plotter is destroyed,
   its `terminate' method is invoked similarly.

   The C API also includes the functions pl_newplparams/pl_deleteplparams,
   which create/destroy PlotterParams instances, and wrappers around the
   methods that may be applied to any PlotterParams object.  A pointer to a
   PlotterParams object is passed to pl_newpl_r().  It specifies the
   device-driver parameters of the Plotter that will be created. */

#include "sys-defines.h"
#include "extern.h"
#include "plot.h"		/* header file for C API */

/* Known Plotter types, indexed into by a short mnemonic case-insensitive
   string: "generic"=generic (i.e. base Plotter class), "bitmap"=bitmap,
   "meta"=metafile, "tek"=Tektronix, "regis"=ReGIS, "hpgl"=HP-GL/2,
   "pcl"=PCL 5, "fig"=xfig, "cgm"=CGM, "ps"=PS, "ai"="AI", "svg"=SVG,
   "gif"=GIF, "pnm"=PNM (i.e. PBM/PGM/PPM), "z"=PNG, "X"=X11,
   "Xdrawable"=X11Drawable.  */

typedef struct 
{
  const char *name;
  const Plotter *default_init;
}
Plotter_data;

/* Initializations for the function-pointer part of each type of Plotter.
   Each of the initializing structures listed here is defined in the
   corresponding ?_defplot.c file. */
static const Plotter_data _plotter_data[] = 
{
  {"generic", &_g_default_plotter},
  {"bitmap", &_b_default_plotter},
  {"meta", &_m_default_plotter},
  {"tek", &_t_default_plotter},
  {"regis", &_r_default_plotter},
  {"hpgl", &_h_default_plotter},
  {"pcl", &_q_default_plotter},
  {"fig", &_f_default_plotter},
  {"cgm", &_c_default_plotter},
  {"ps", &_p_default_plotter},
  {"ai", &_a_default_plotter},
  {"svg", &_s_default_plotter},
  {"gif", &_i_default_plotter},
  {"pnm", &_n_default_plotter},
#ifdef INCLUDE_PNG_SUPPORT
  {"png", &_z_default_plotter},
#endif
#ifndef X_DISPLAY_MISSING
  {"Xdrawable", &_x_default_plotter},
  {"X", &_y_default_plotter},
#endif /* not X_DISPLAY_MISSING */
  {(const char *)NULL, (const Plotter *)NULL}
};

/* forward references */
static bool _string_to_plotter_data ____P((const char *type, int *position));
static void _api_warning ____P((const char *msg));

/* These are two user-callable functions that are specific to the new
   (i.e., thread-safe) C binding: pl_newpl_r, pl_deletepl_r. */

Plotter *
#ifdef _HAVE_PROTOS
pl_newpl_r (const char *type, FILE *infile, FILE *outfile, FILE *errfile, const PlotterParams *plotter_params)
#else
pl_newpl_r (type, infile, outfile, errfile, plotter_params)
     const char *type;
     FILE *infile, *outfile, *errfile;
     const PlotterParams *plotter_params;
#endif
{
  bool found;
  int position;
  Plotter *_plotter;
  
  /* determine initialization for specified plotter type */
  found = _string_to_plotter_data (type, &position);
  if (!found)
    {
      _api_warning ("ignoring request to create plotter of unknown type");
      return NULL;
    }

  /* create Plotter, copy function pointers to it */
  _plotter = (Plotter *)_plot_xmalloc (sizeof(Plotter));
  memcpy (_plotter, _plotter_data[position].default_init, sizeof(Plotter));

  /* create PlotterData structure, install it in Plotter */
  _plotter->data = (plPlotterData *)_plot_xmalloc (sizeof(plPlotterData));

  /* copy parameters to it */
  _plotter->data->infp = infile;  
  _plotter->data->outfp = outfile;
  _plotter->data->errfp = errfile;
  _copy_params_to_plotter (_plotter, plotter_params);

  /* do any additional needed initializiations of the Plotter (e.g.,
     initialize data members of the PlotterData structure in a
     device-dependent way); also add the Plotter to the _plotters[] array */
  _plotter->initialize (_plotter);

  return _plotter;
}

/* utility function, used above; keys into table of Plotter types by a
   short mnemonic string */
static bool
#ifdef _HAVE_PROTOS
_string_to_plotter_data (const char *type, int *position)
#else
_string_to_plotter_data (type, position)
     const char *type;
     int *position;
#endif
{
  const Plotter_data *p = _plotter_data;
  bool found = false;
  int i = 0;
  
  /* search table of known plotter type mnemonics */
  while (p->name)
    {
      if (strcasecmp ((char *)type, (char *)p->name) == 0)
	{
	  found = true;
	  break;
	}
      p++;
      i++;
    }
  /* return pointer to plotter data through pointer */
  if (found)
    *position = i;
  return found;
}

int
#ifdef _HAVE_PROTOS
pl_deletepl_r (Plotter *_plotter)
#else
pl_deletepl_r (_plotter)
     Plotter *_plotter;
#endif
{
  if (_plotter == NULL)
    {
      _api_warning ("ignoring request to delete a null Plotter");
      return -1;
    }

  /* if luser left the Plotter open, close it */
  if (_plotter->data->open)
    _API_closepl (_plotter);

  /* Invoke an internal Plotter method before deletion.  At a minimum, this
     private `terminate' method, frees instance-specific copies of class
     parameters, and also removes the pointer to the Plotter instance from
     the _plotters[] array.

     Also, it writes any unwritten graphics to the Plotter's output stream.
     This is the case for PSPlotters in particular, which write graphics
     only when they are deleted.  For a PSPlotter, the terminate method
     emits the Plotter's pages of graphics to its output stream and then
     deallocates associated storage.  For an XPlotter, this method kills
     the forked-off processes that are maintaining its popped-up windows
     (if any), provided that the VANISH_ON_DELETE parameter is set.  */
  _plotter->terminate (_plotter);

  /* tear down the PlotterData structure */
  free (_plotter->data);

  /* tear down the Plotter itself */
  free (_plotter);

  return 0;
}


/* function used in this file to print warning messages */
static void
#ifdef _HAVE_PROTOS
_api_warning (const char *msg)
#else
_api_warning (msg)
     const char *msg;
#endif
{
  if (libplot_warning_handler != NULL)
    (*libplot_warning_handler)(msg);
  else
    fprintf (stderr, "libplot: %s\n", msg);
}


/* These are two user-callable functions that are specific to the new
   (i.e., thread-safe) C binding: pl_newplparams, pl_deleteplparams,
   pl_copyplparams. */

PlotterParams *
#ifdef _HAVE_PROTOS
pl_newplparams (void)
#else
pl_newplparams ()
#endif
{
  int i;
  PlotterParams *_plotter_params_p;
  
  /* create PlotterParams, copy function pointers to it */
  _plotter_params_p = (PlotterParams *)_plot_xmalloc (sizeof(PlotterParams));
  memcpy (_plotter_params_p, &_default_plotter_params, sizeof(PlotterParams));

  /* null out all parameters */
  for (i = 0; i < NUM_PLOTTER_PARAMETERS; i++)
    _plotter_params_p->plparams[i] = (voidptr_t)NULL;

  return _plotter_params_p;
}

int
#ifdef _HAVE_PROTOS
pl_deleteplparams (PlotterParams *_plotter_params_p)
#else
pl_deleteplparams (_plotter_params_p)
     PlotterParams *_plotter_params_p;
#endif
{
  int i;
  
  /* free all copied strings, and the structure itself */
  for (i = 0; i < NUM_PLOTTER_PARAMETERS; i++)
    if (_known_params[i].is_string && _plotter_params_p->plparams[i] != NULL)
      free (_plotter_params_p->plparams[i]);
  free (_plotter_params_p);

  return 0;
}

PlotterParams *
#ifdef _HAVE_PROTOS
pl_copyplparams (const PlotterParams *_plotter_params_p)
#else
pl_copyplparams (_plotter_params_p)
     const PlotterParams *_plotter_params_p;
#endif
{
  int i;
  PlotterParams *new_plotter_params_p;
  
  /* create PlotterParams, copy function pointers to it */
  new_plotter_params_p = (PlotterParams *)_plot_xmalloc (sizeof(PlotterParams));
  memcpy (new_plotter_params_p, &_default_plotter_params, sizeof(PlotterParams));

  /* copy all parameters */
  for (i = 0; i < NUM_PLOTTER_PARAMETERS; i++)
    new_plotter_params_p->plparams[i] = _plotter_params_p->plparams[i];

  return new_plotter_params_p;
}

/* The following are C wrappers around the public functions in the
   PlotterParams class.  Together with the preceding functions, they are
   part of the new (i.e., thread-safe) C API. */

int
#ifdef _HAVE_PROTOS
pl_setplparam (PlotterParams *plotter_params, const char *parameter, voidptr_t value)
#else
pl_setplparam (plotter_params, parameter, value)
     PlotterParams *plotter_params;
     const char *parameter;
     voidptr_t value;
#endif
{
  return plotter_params->setplparam (plotter_params, parameter, value);
}

/* END OF WRAPPERS AROUND PLOTTERPARAMS METHODS */
