/* This file includes version information that is compiled into
   libplot/libplotter. */

#include "sys-defines.h"
#include "extern.h"

const char pl_libplot_ver[8] = PL_LIBPLOT_VER_STRING;
