#!/bin/sh
./re < $srcdir/tests
