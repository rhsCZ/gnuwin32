#!/bin/sh
./re -er < $srcdir/tests
