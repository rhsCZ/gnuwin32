#!/bin/sh
./re -el < $srcdir/tests
