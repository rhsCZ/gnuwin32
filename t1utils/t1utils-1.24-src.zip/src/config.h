/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */
/* Process this file with autoheader to produce config.h.in */
#ifndef CONFIG_H
#define CONFIG_H

/* Package and version */
#define PACKAGE "t1utils"
#define VERSION "1.24"


/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the <inttypes.h> header file.  */
/* #undef HAVE_INTTYPES_H */

/* Name of package */
#define PACKAGE "t1utils"

/* Version number of package */
#define VERSION "1.24"


#ifdef __cplusplus
extern "C" {
#endif

/* Prototype strerror() if we don't have it. */
#ifndef HAVE_STRERROR
char *strerror(int errno);
#endif

/* Get the [u]int*_t typedefs. */
/* #undef NEED_SYS_TYPES_H */
#ifdef NEED_SYS_TYPES_H
# include <sys/types.h>
#endif
/* #undef HAVE_INTTYPES_H */
#ifdef HAVE_INTTYPES_H
# include <inttypes.h>
#endif
#define uint16_t unsigned short
#define uint32_t unsigned int
#define int32_t int

#ifdef __cplusplus
}
/* Get rid of inline macro under C++ */
/* # undef inline */
#endif
#endif
