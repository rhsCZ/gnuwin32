#include <stdio.h>
#include <stdlib.h>
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include "wvexporter-priv.h"

void
wvPutBX (BX * item, U8 * page, U16 * pos)
{
}

void
wvPutBX6 (BX * item, U8 * page, U16 * pos)
{
}
