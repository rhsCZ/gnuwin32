/* getopt.h -- wrapper for gnulib getopt_.h.
   $Id: getopt.h,v 1.6 2004/09/14 12:36:00 karl Exp $
   Copyright (C) 2004 Free Software Foundation, Inc.

   Copying and distribution of this file, with or without modification,
   are permitted in any medium without royalty provided the copyright
   notice and this notice are preserved.
*/

#include "getopt_.h"
