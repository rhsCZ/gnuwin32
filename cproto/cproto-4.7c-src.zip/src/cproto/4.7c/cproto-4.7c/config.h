/* config.h.  Generated automatically by configure.  */
/* @configure_input@ */
/* $Id: config_h.in,v 4.2 1995/01/01 19:34:59 cthuang Exp $ */

#define CC_HAS_PROTOS 1
#define CPP "gcc -E"
#define CPP_DOES_ONLY_C_FILES 1
#define DOALLOC 10000
#define HAVE_GETOPT_H 1
#define HAVE_GETTIMEOFDAY 1
#define HAVE_LINK 1
#define HAVE_MEMORY_H 1
#define HAVE_MKTEMP 1
#define HAVE_POPEN_PROTOTYPE 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_STRSTR 1
#define HAVE_TMPFILE 1
#define HAVE_UNISTD_H 1
#define HAVE_UNLINK 1
#define OPT_LINTLIBRARY 1
#define STDC_HEADERS 1
#define TIME_WITH_SYS_TIME 1
#define YYTEXT_POINTER 1
