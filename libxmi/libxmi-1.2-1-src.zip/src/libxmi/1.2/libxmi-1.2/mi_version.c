/* This file includes version information that is compiled into libxmi. */

#include "sys-defines.h"
#include "extern.h"
#include "xmi.h"

const char mi_libxmi_ver[8] = MI_LIBXMI_VER_STRING;
