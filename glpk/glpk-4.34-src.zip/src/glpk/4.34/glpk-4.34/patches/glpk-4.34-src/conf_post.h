#ifdef _WIN32

#define __WOE__ 1

#define VC6_MT_DLL 1

#define MT 1

#endif /* _WIN32  */
