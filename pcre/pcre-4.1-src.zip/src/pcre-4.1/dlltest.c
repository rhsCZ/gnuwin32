#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef WIN32_LEAN_AND_MEAN
#include <stdlib.h>
#include <stdio.h>

int main()
{
	HMODULE dll;
	void *func;

	dll = LoadLibrary("./pcre.dll");
	if (dll == 0) {
		puts("could not load pcre.dll");
		exit(1);
	}

	func = GetProcAddress(dll, "pcre_info");
	if (func == 0) {
		puts("pcre_info not found");
		exit(2);
	}

	return 0;
}


