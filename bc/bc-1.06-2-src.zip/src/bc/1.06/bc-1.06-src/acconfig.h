/* PACKAGE name */
#undef PACKAGE

/* Package VERSION number */
#undef VERSION

/* VERSION number for DC target*/
#undef DC_VERSION

/* COPYRIGHT notice for DC target */
#undef DC_COPYRIGHT

/* COPYRIGHT notice for BC target */
#undef BC_COPYRIGHT

/* Define to use the readline library. */
#undef READLINE

/* Define to use the BSD libedit library. */
#undef LIBEDIT

/* Define to `size_t' if <sys/types.h> and <stddef.h> don't define.  */
#undef ptrdiff_t

