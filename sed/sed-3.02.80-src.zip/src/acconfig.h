/* PACKAGE name */
#undef PACKAGE

/* Package VERSION number */
#undef VERSION

/* Use lib/regex-gnu.h header (in preference to system's <regex.h>) */
#undef USE_REGEX_GNU_H

/* have the regexec() function */
#undef HAVE_REGEXEC

/* have the regnexec() function */
#undef HAVE_REGNEXEC

#undef LOCALEDIR

#undef ENABLE_NLS

#undef HAVE_CATGETS

#undef HAVE_GETTEXT

#undef HAVE_LC_MESSAGES

#undef HAVE_STPCPY

