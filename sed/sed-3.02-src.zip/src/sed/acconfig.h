/* PACKAGE name */
#undef PACKAGE

/* Package VERSION number */
#undef VERSION

/* Use lib/regex-gnu.h header (in preference to system's <regex.h>) */
#undef USE_REGEX_GNU_H

/* have the regexec() function */
#undef HAVE_REGEXEC

/* have the regnexec() function */
#undef HAVE_REGNEXEC
