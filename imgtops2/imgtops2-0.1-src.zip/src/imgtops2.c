/* imgtops2 - imgtops2.c
 *
 * Copyright (C) 2000      Doug Zongker
 *
 * Permission to use, copy, and distribute this software and its
 * documentation for any purpose with or without fee is hereby granted, 
 * provided that the above copyright notice appear in all copies and 
 * that both that copyright notice and this permission notice appear 
 * in supporting documentation.
 *
 * Permission to modify the software is granted, but not the right to
 * distribute the modified code.  Modifications are to be distributed 
 * as patches to released version.
 *  
 * This software is provided "as is" without express or implied warranty.
 * 
 *
 * AUTHOR
 *
 *   Doug Zongker
 * 
 * 
 * Send your comments, suggestions, or bug reports to 
 *      dougz@cs.washington.edu
 */

#include <stdio.h>
#include <stdlib.h>
#ifndef __sun__
#include <getopt.h>
#endif
#include <unistd.h>
#include <math.h>
#include <time.h>

/* variables for getopt() */
extern char* optarg;
extern int optind, opterr, optopt;

/* image types */
#define T_ERROR         0
#define T_PPM           1
#define T_PGM           2
#define T_JFIF          3
#define T_JFIF_YCBCR    4
#define T_JFIF_Y        5

#define FILEDATA_CHUNK   BUFSIZ

/* default printable areas. */
#ifdef DEFAULT_A4
/* default printable area for A4 page with 1-inch margins */
#define DEF_PS_OFFSETX  72
#define DEF_PS_OFFSETY  72
#define DEF_PS_SIZEX    451
#define DEF_PS_SIZEY    698
#else
/* default printable area for US letter page with 1-inch margins */
#define DEF_PS_OFFSETX  72
#define DEF_PS_OFFSETY  72
#define DEF_PS_SIZEX    468
#define DEF_PS_SIZEY    648
#endif

/* function prototypes. */
int parse_image( unsigned char* data, int size, int* width, int* height, int* type );
void postscript_start( FILE* fout, int width, int height, int type, char* inputfilename );
void postscript_data( FILE* fout, unsigned char* data, int length );
void postscript_finish( FILE* fout );

/* configuration variables. */
int turn_image_allowed = 0;
int precise_eps_file = 0;
int debug_mode = 0;
double ps_offsetx = DEF_PS_OFFSETX;
double ps_offsety = DEF_PS_OFFSETY;
double ps_sizex = DEF_PS_SIZEX;
double ps_sizey = DEF_PS_SIZEY;

/* program information. */
static char app_name[] = "imgtops2 v0.1";
static char rcs_id[] = "$Id: imgtops2.c,v 1.2 2000/01/20 18:24:04 dougz Exp $";

int main( int argc, char** argv )
{
    int i;
    FILE* fin = stdin;
    unsigned char* filedata = NULL;
    int filedata_size = 0;
    int filedata_alloc = 0;
    int header_skip;
    FILE* fout = stdout;
    int width, height, type;
    char* inputfilename = "(stdin)";
    char* endptr;
    
    while ( (i = getopt( argc, argv, "o:theds:c:" ) ) != EOF )
    {
	switch( i )
	{
	  case 'h':
	    fprintf( stderr, "usage: %s [options] [inputimage]\n", argv[0] );
	    fprintf( stderr, "  -o filename        specify output file (default stdout)\n" );
	    fprintf( stderr, "  -t                 turn image to fit\n" );
	    fprintf( stderr, "  -e                 produce precise EPS bounding box\n" );
	    fprintf( stderr, "  -c #,#             lower left corner of printable area (default %g,%g)\n", ps_offsetx, ps_offsety );
	    fprintf( stderr, "  -s #,#             printable area size (default %g,%g)\n", ps_sizex, ps_sizey );
	    fprintf( stderr, "  -d                 show image placement (for debugging)\n" );
	    fprintf( stderr, "  -h                 display this message\n" );
	    exit( 1 );
	    break;

	  case 'o':
	    fout = fopen( optarg, "wb" );
	    if ( fout == NULL )
	    {
		fprintf( stderr, "imgtops2: failed to open output file [%s]\n", optarg );
		exit( 1 );
	    }
	    break;

	  case 't':
	    turn_image_allowed = 1;
	    break;

	  case 'e':
	    precise_eps_file = 1;
	    break;

	  case 'c':
	    ps_offsetx = strtod( optarg, &endptr );
	    if ( *endptr != ',' )
	    {
		fprintf( stderr, "imgtops2: bad format argument to -c\n" );
		exit( 1 );
	    }
	    ps_offsety = strtod( endptr+1, NULL );
	    break;

	  case 's':
	    ps_sizex = strtod( optarg, &endptr );
	    if ( *endptr != ',' )
	    {
		fprintf( stderr, "imgtops2: bad format argument to -s\n" );
		exit( 1 );
	    }
	    ps_sizey = strtod( endptr+1, NULL );
	    fprintf( stderr, "size is %g,%g\n", ps_sizex, ps_sizey );
	    break;
	    
	  case 'd':
	    debug_mode = 1;
	    break;
	    
	  default:
	    fprintf( stderr, "imgtops2: unknown option \"-%c\"\n", optopt );
	    exit( 1 );
	    break;
	}
    }

    if ( optind == argc-1 )
    {
	fin = fopen( argv[optind], "rb" );
	if ( fin == NULL )
	{
	    fprintf( stderr, "imgtops2: failed to open input file [%s]\n", argv[optind] );
	    exit( 1 );
	}
	inputfilename = argv[optind];
    }
    else if ( optind < argc-1 )
    {
	fprintf( stderr, "imgtops2: too many arguments.\n" );
	exit( 1 );
    }

    /* read the input file into memory */
    
    do
    {
	if ( filedata_alloc < filedata_size + FILEDATA_CHUNK )
	{
	    filedata_alloc += FILEDATA_CHUNK;
	    filedata = (unsigned char*)realloc( filedata, filedata_alloc );
	    if ( filedata == NULL )
	    {
		fprintf( stderr, "imgtops2: failed to allocate memory for image.\n" );
		exit( 1 );
	    }
	}

	i = fread( filedata + filedata_size, 1, FILEDATA_CHUNK, fin );
	filedata_size += i;
    }
    while ( i == FILEDATA_CHUNK || !feof(fin) || ferror(fin) );
    fclose( fin );

    header_skip = parse_image( filedata, filedata_size, &width, &height, &type );
    if ( type == T_ERROR )
    {
	fprintf( stderr, "imgtops2: couldn't determine image format, or format not supported.\n" );
	exit( 1 );
    }

    postscript_start( fout, width, height, type, inputfilename );
    if ( ! debug_mode )
	postscript_data( fout, filedata + header_skip, filedata_size - header_skip );
    postscript_finish( fout );

    fclose( fout );

    return 0;
}

/* parse_image
 *
 *   given a blob of data, identify the image format (if supported)
 *   and extract the width and height of the image.
 *
 *   comments in the header of PPM/PGM files may be erased.
 */

int parse_image( unsigned char* data, int size, int* width, int* height, int* type )
{
    int i, j;
    int offset = 0;
    
    /* first, identify the image type */
    
    if ( data[0] == 0xff && data[1] == 0xd8 && data[2] == 0xff && data[3] == 0xe0 &&
	 data[6] == 'J' && data[7] == 'F' && data[8] == 'I' && data[9] == 'F' &&
	 data[10] == 0 )
    {
	/* defer finding out color vs. grayscale until later */
	*type = T_JFIF;
    }
    else if ( data[0] == 'P' && data[1] == '5' )
	*type = T_PGM;
    else if ( data[0] == 'P' && data[1] == '6' )
	*type = T_PPM;
    else
    {
	*type = T_ERROR;
	return 0;
    }

    *width = 0;
    *height = 0;
    
    /* now find the width and height */
    switch( *type )
    {
      case T_PGM:
      case T_PPM:
      {
	  int wstart, hstart, mstart, bitstart;
	  do
	  {
	      
	      sscanf( (char*)data, "P%*d %n%*s %n%*s %n%*s%n", &wstart, &hstart, &mstart, &bitstart );
	      j = 0;
	      if ( data[wstart] == '#' )
	      {
		  j = 1;
		  for ( i = wstart; data[i] != '\n'; ++i )
		      data[i] = ' ';
		  data[i] = ' ';
		  continue;
	      }
	      if ( data[hstart] == '#' )
	      {
		  j = 1;
		  for ( i = hstart; data[i] != '\n'; ++i )
		      data[i] = ' ';
		  data[i] = ' ';
		  continue;
	      }
	      if ( data[mstart] == '#' )
	      {
		  j = 1;
		  for ( i = mstart; data[i] != '\n'; ++i )
		      data[i] = ' ';
		  data[i] = ' ';
		  continue;
	      }
	  }
	  while ( j );
	  *width = atoi( (char*)data+wstart );
	  *height = atoi( (char*)data+hstart );
	  offset = bitstart+1;
      }
      break;

      case T_JFIF:
	i = 2;
	do
	{
	    unsigned short m, l;

	    m = (data[i] << 8) | data[i+1];
	    l = (data[i+2] << 8) | data[i+3];
	    if ( m == 0xffc0 || m == 0xffc2 )
	    {
		if ( m == 0xffc2 )
		    fprintf( stderr, "imgtops2:  input appears to be a progressive JPEG\n" );
		
		*height = (data[i+5] << 8) | data[i+6];
		*width = (data[i+7] << 8) | data[i+8];
		if ( data[i+9] == 3 )
		    *type = T_JFIF_YCBCR;
		else if ( data[i+9] == 1 )
		    *type = T_JFIF_Y;
		break;
	    }

	    i += l+2;
	}
	while( data[i] == 0xff );
	offset = 0;
	break;
    }

    if ( *type == T_JFIF )
    {
	/* if we didn't find an SOF marker, or there weren't 1 or 3
	   channels, then we don't know what to do with this JFIF
	   file. */
	*type = T_ERROR;
	return 0;
    }
    
    if ( *width == 0 || *height == 0 )
    {
	fprintf( stderr, "imgtops2: couldn't find width and height.\n" );
	exit( 1 );
    }

    return offset;
}

/* postscript_start
 *
 *    emit header.  determine correct position and orientation of
 * image, compute EPS bounding box.
 */

void postscript_start( FILE* fout, int width, int height, int type,
		       char* inputfilename )
{
    double noturnscale;
    double turnscale;
    double bb_left = 0, bb_right = 0, bb_top = 0, bb_bottom = 0;
    int ibb_left = 0, ibb_right = 0, ibb_top = 0, ibb_bottom = 0;
    char* buffer = NULL;

    buffer = (char*)malloc( 2048 );
    buffer[0] = 0;

    if ( precise_eps_file )
    {
	bb_left = 0;
	bb_right = width;
	bb_bottom = 0;
	bb_top = height;
	sprintf( buffer+strlen(buffer), "gsave\n" );
    }
    else
    {
	sprintf( buffer+strlen(buffer), "gsave %g %g translate\n",
		 ps_offsetx, ps_offsety );
	
	if ( debug_mode )
	{
	    /* draw a red box indicating the printable area. */
	    sprintf( buffer+strlen(buffer),
		     "gsave 1 0 0 setrgbcolor 0 0 moveto %g 0 lineto "
		     "%g %g lineto 0 %g lineto closepath stroke grestore\n",
		     ps_sizex, ps_sizex, ps_sizey, ps_sizey );
	}

	/* compute the largest scale factor that will keep the image
           in the printable area. */
	noturnscale = (double)ps_sizex / width;
	if ( (double)ps_sizey / height < noturnscale )
	    noturnscale = (double)ps_sizey / height;

	/* also compute the scale factor if the image is turned 90
           degrees. */
	turnscale = (double)ps_sizex / height;
	if ( (double)ps_sizey / width < turnscale )
	    turnscale = (double)ps_sizey / width;
	
	if ( turn_image_allowed && turnscale > noturnscale )
	{
	    /* if we're allowed to turn the image, and turning the
	       image allows for a larger scale factor, then turn the
	       image. */
	    
	    if ( (double)ps_sizex / height < (double)ps_sizey / width )
	    {
		/* fit height to page width and center vertically */
		sprintf( buffer+strlen(buffer),
			 "0 %g 2 div translate  %g %d div dup scale "
			 " 0 %d -2 div translate\n",
			 ps_sizey, ps_sizex, height, width );
		bb_left = ps_offsetx;
		bb_right = ps_offsetx + ps_sizex;
		bb_bottom = ps_offsety + (ps_sizey/2.0) + (width/2.0*turnscale);
		bb_top = ps_offsety + (ps_sizey/2.0) - (width/2.0*turnscale);
	    }
	    else
	    {
		/* fit width to page height and center horizontally */
		sprintf( buffer+strlen(buffer),
			 "%g 2 div 0 translate  %g %d div dup scale "
			 " %d -2 div 0 translate\n",
			 ps_sizex, ps_sizey, width, height );
		bb_left = ps_offsetx + (ps_sizex/2.0) - (height/2.0*turnscale);
		bb_right = ps_offsetx + (ps_sizex/2.0) + (height/2.0*turnscale);
		bb_bottom = ps_offsety;
		bb_top = ps_offsety + ps_sizey;
	    }
	    sprintf( buffer+strlen(buffer), "90 rotate 0 %d translate\n", -height );
	}
	else
	{
	    /* otherwise, leave the image upright. */
	    
	    if ( (double)ps_sizex / width < (double)ps_sizey / height )
	    {
		/* fit width and center vertically */
		sprintf( buffer+strlen(buffer),
			 "0 %g 2 div translate  %g %d div dup scale "
			 " 0 %d -2 div translate\n",
			 ps_sizey, ps_sizex, width, height );
		bb_left = ps_offsetx;
		bb_right = ps_offsetx + ps_sizex;
		bb_bottom = ps_offsety + (ps_sizey/2.0) - (height/2.0*noturnscale);
		bb_top = ps_offsety + (ps_sizey/2.0) + (height/2.0*noturnscale);
	    }
	    else
	    {
		/* fit height and center horizontally */
		sprintf( buffer+strlen(buffer),
			 "%g 2 div 0 translate  %g %d div dup scale "
			 " %d -2 div 0 translate\n",
			 ps_sizex, ps_sizey, height, width );
		bb_left = ps_offsetx + (ps_sizex/2.0) - (width/2.0*noturnscale);
		bb_right = ps_offsetx + (ps_sizex/2.0) + (width/2.0*noturnscale);
		bb_bottom = ps_offsety;
		bb_top = ps_offsety + ps_sizey;
	    }
	}
    }

    /* determine the integral bounding box. */
    ibb_left = floor( bb_left );
    ibb_right = ceil( bb_right );
    ibb_bottom = floor( bb_bottom );
    ibb_top = ceil( bb_top );

    /**
     ** once we have the bounding box, we can start writing to the
     ** output file.
     **/
    
    fprintf( fout, "%%!PS-Adobe-3.0 EPSF-3.0\n" );
    fprintf( fout, "%%%%BoundingBox: %d %d %d %d\n", ibb_left, ibb_bottom, ibb_right, ibb_top );
    fprintf( fout, "%%%%LanguageLevel: 2\n" );
    fprintf( fout, "%%%%Creator: %s (%s)\n", app_name, rcs_id );
    {
	time_t now = time(NULL);
	fprintf( fout, "%%%%CreationDate: %s", ctime(&now) );
    }
    fprintf( fout, "%%%%Title: %s\n\n", inputfilename );

    /* dump the postscript code we've accumulated. */
    fprintf( fout, buffer );
    free( buffer );

    /* adjust scale so that the image area is the unit square. */
    fprintf( fout, "%d %d scale\n", width, height );
    
    if ( debug_mode )
    {
	/* draw blue rectangle and triangle indicating the image
           boundary and orientation. */
	fprintf( fout, "gsave 0 0 1 setrgbcolor 0 setlinewidth\n" );
	fprintf( fout, "0 0 moveto 0 1 lineto 1 1 lineto 1 0 lineto closepath"
		 " 0.5 0.5 lineto 1 0 lineto stroke grestore\n" );
	
	/* undo the centering transformations to draw the bbox in
           default coordinates. */
	fprintf( fout, "grestore\n" );

	/* draw green rectangle indicating bounding box. */
	fprintf( fout, "gsave 0 0.7 0 setrgbcolor 0 setlinewidth\n" );
	fprintf( fout, "%d %d moveto %d %d lineto %d %d lineto %d %d lineto"
		 " closepath stroke grestore\n",
		 ibb_left, ibb_bottom, ibb_right, ibb_bottom,
		 ibb_right, ibb_top, ibb_left, ibb_top );
    }
    else
    {
	/* set PostScript color space as appropriate. */
	switch ( type )
	{
	  case T_PPM:
	  case T_JFIF_YCBCR:
	    fprintf( fout, "/DeviceRGB setcolorspace\n" );
	    break;
	    
	  case T_PGM:
	  case T_JFIF_Y:
	    fprintf( fout, "/DeviceGray setcolorspace\n" );
	    break;
	}

	/* emit the dictionary consumed by the image operator. */
	fprintf( fout, "<<\n  /ImageType 1\n  /Width %d /Height %d\n  "
		 "/BitsPerComponent 8\n  /ImageMatrix [%d 0 0 -%d 0 %d]\n",
		 width, height, width, height, height );
	switch( type )
	{
	  case T_PPM:
	    fprintf( fout, "  /Decode [0 1 0 1 0 1]\n" );
	    fprintf( fout, "  /DataSource currentfile "
		     "/ASCII85Decode filter\n" );
	    break;
	    
	  case T_PGM:
	    fprintf( fout, "  /Decode [0 1]\n" );
	    fprintf( fout, "  /DataSource currentfile "
		     "/ASCII85Decode filter\n" );
	    break;
	    
	  case T_JFIF_YCBCR:
	    fprintf( fout, "  /Decode [0 1 0 1 0 1]\n" );
	    fprintf( fout, "  /DataSource currentfile "
		     "/ASCII85Decode filter /DCTDecode filter\n" );
	    break;
	    
	  case T_JFIF_Y:
	    fprintf( fout, "  /Decode [0 1]\n" );
	    fprintf( fout, "  /DataSource currentfile "
		     "/ASCII85Decode filter /DCTDecode filter\n" );
	    break;
	}
	fprintf( fout, "\n>>\nimage\n\n" );
    }
}

/* postscript_data
 *
 *    encode a chunk of data using PostScript's ASCII85 method.
 */

void postscript_data( FILE* fout, unsigned char* data, int length )
{
    int i = 0;
    unsigned char c[5];
    unsigned int tuple;
    int count = 0;
    
    while ( i <= length-4 )
    {
	if ( data[i] == 0 && data[i+1] == 0 && data[i+2] == 0 && data[i+3] == 0 )
	    fputc( 'z', fout );
	else
	{
	    tuple = (data[i] << 24) | (data[i+1] << 16) | (data[i+2] << 8) | data[i+3];
	    c[4] = tuple % 85;
	    tuple /= 85;
	    c[3] = tuple % 85;
	    tuple /= 85;
	    c[2] = tuple % 85;
	    tuple /= 85;
	    c[1] = tuple % 85;
	    tuple /= 85;
	    c[0] = tuple;

	    fputc( c[0]+'!', fout );
	    fputc( c[1]+'!', fout );
	    fputc( c[2]+'!', fout );
	    fputc( c[3]+'!', fout );
	    fputc( c[4]+'!', fout );
	    count += 5;
	    if ( count > 240 )
	    {
		fputc( '\n', fout );
		count = 0;
	    }
	}
	i += 4;
    }
    if ( i < length )
    {
	tuple = (data[i] << 24) |
	    ( ((i+1<length) ? data[i+1] : 0 ) << 16 ) |
	    ( ((i+2<length) ? data[i+2] : 0 ) << 8 ) |
	    ( ((i+3<length) ? data[i+3] : 0 ) );
	
	c[4] = tuple % 85;
	tuple /= 85;
	c[3] = tuple % 85;
	tuple /= 85;
	c[2] = tuple % 85;
	tuple /= 85;
	c[1] = tuple % 85;
	tuple /= 85;
	c[0] = tuple;
	
	fputc( c[0]+'!', fout );
	if ( i+1 <= length )
	    fputc( c[1]+'!', fout );
	if ( i+2 <= length )
	    fputc( c[2]+'!', fout );
	if ( i+3 <= length )
	    fputc( c[3]+'!', fout );
    }
    
    fputc( '~', fout );
    fputc( '>', fout );
    fputc( '\n', fout );
}

/* postscript_finish
 *
 *    emit cleanup code following the image data.
 */

void postscript_finish( FILE* fout )
{
    if ( !debug_mode )
	fprintf( fout, "\ngrestore" );
    fprintf( fout, "\nshowpage\n" );
}

