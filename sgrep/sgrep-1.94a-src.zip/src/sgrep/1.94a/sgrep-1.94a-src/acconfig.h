/* The software package name from configure.in */
#undef PACKAGE

/* Version number from configure.in */
#undef VERSION

/* Are Assertions enables */
#undef ENABLE_ASSERTIONS

/* Is memory debugging enabled */
#undef MEMORY_DEBUG


