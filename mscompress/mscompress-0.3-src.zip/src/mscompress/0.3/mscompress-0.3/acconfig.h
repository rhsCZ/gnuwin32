/* Define hostname of the build host */
#undef BUILDHOST
