E e1.ed
1;/H/+d
w e1.o
EOT
