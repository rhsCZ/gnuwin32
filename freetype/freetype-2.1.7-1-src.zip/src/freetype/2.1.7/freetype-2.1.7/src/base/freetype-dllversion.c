/* See: http://msdn.microsoft.com/library/en-us/shellcc/platform/shell/programmersguide/versions.asp */
#include <shlwapi.h>

HRESULT DllGetVersion (DLLVERSIONINFO2 *pdvi)
{
	pdvi->info1.dwMajorVersion = 2;
	pdvi->info1.dwMinorVersion = 1;
	pdvi->info1.dwBuildNumber = 7;
	pdvi->info1.dwPlatformID = DLLVER_PLATFORM_WINDOWS;
	pdvi->ullVersion = MAKEDLLVERULL (2, 1, 7, 1505);
	return NOERROR;
}
