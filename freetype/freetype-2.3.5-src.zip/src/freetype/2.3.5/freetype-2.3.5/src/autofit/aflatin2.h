/***************************************************************************/
/*                                                                         */
/*  aflatin2.h                                                             */
/*                                                                         */
/*    Auto-fitter hinting routines for latin script (specification).       */
/*                                                                         */
/*  Copyright 2003, 2004, 2005, 2006, 2007 by                              */
/*  David Turner, Robert Wilhelm, and Werner Lemberg.                      */
/*                                                                         */
/*  This file is part of the FreeType project, and may only be used,       */
/*  modified, and distributed under the terms of the FreeType project      */
/*  license, LICENSE.TXT.  By continuing to use, modify, or distribute     */
/*  this file you indicate that you have read the license and              */
/*  understand and accept it fully.                                        */
/*                                                                         */
/***************************************************************************/


#ifndef __AFLATIN2_H__
#define __AFLATIN2_H__

#include "afhints.h"


FT_BEGIN_HEADER


  /* the latin-specific script class */

  FT_CALLBACK_TABLE const AF_ScriptClassRec
  af_latin2_script_class;

/* */

FT_END_HEADER

#endif /* __AFLATIN_H__ */


/* END */
