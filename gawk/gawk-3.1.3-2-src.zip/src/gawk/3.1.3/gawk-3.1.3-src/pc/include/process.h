#undef __STDC__
#include <process.h>
#define __STDC__ 1
