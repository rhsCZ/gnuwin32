#undef __STDC__
#include <stdlib.h>
#define __STDC__ 1
