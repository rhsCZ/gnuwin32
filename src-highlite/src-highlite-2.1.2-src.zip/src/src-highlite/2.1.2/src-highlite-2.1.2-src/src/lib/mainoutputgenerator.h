//
// C++ Interface: mainoutputgenerator
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef MAINOUTPUTGENERATOR_H
#define MAINOUTPUTGENERATOR_H

#include "outputgenerator.h"

extern OutputGenerator *outputgenerator;

#endif
