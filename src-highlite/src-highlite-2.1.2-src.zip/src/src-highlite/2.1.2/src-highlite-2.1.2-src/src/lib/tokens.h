#define COMMENT_T 400
#define CLASS_T 401
#define PUBLIC_T 402
#define EXTENDS_T 403
