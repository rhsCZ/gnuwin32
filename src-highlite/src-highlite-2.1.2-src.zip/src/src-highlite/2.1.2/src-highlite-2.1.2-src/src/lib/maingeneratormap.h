//
// C++ Interface: maingeneratormap
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef MAINGENERATORMAP_H
#define MAINGENERATORMAP_H

#include "generatormap.h"

extern GeneratorMap *generatormap;

#endif
