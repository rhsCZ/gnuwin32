#ifndef GLOBALOSTREAM_H
#define GLOBALOSTREAM_H

#include <iostream>

extern std::ostream* sout;

#endif // GLOBALOSTREAM_H
