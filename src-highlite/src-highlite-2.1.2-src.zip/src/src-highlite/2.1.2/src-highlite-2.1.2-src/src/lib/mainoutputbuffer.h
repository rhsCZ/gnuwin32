//
// C++ Interface: mainoutputbuffer
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef MAINOUTPUTBUFFER_H
#define MAINOUTPUTBUFFER_H

#include "outputbuffer.h"

extern OutputBuffer *outputbuffer;

#endif
