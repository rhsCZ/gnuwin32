//
// C++ Interface: defaults
//
// Description: 
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef DEFAULT_H
#define DEFAULT_H

// this should be passed by the compiler
#ifndef SOURCE_HIGHLIGHT_DATA_DIR
#define SOURCE_HIGHLIGHT_DATA_DIR "."
#endif

#endif
