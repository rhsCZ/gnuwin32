//
// C++ Implementation: outputbuffer
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "outputbuffer.h"

using namespace std;

OutputBuffer::OutputBuffer() :
  Base()
{
}


OutputBuffer::~OutputBuffer()
{
}

void
OutputBuffer::output_ln(const string &s)
{
  buffer << s;
  push_back(buffer.str());
  buffer.str("");
}

void
OutputBuffer::reset()
{
  clear();
  buffer.str("");
}

void
OutputBuffer::flush()
{
  string last = buffer.str();
  if (last.size())
    {
      push_back(last); // the last line without \n
      buffer.str("");
    }
}
