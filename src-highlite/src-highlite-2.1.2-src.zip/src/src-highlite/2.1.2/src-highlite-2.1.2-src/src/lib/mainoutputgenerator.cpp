//
// C++ Implementation: mainoutputgenerator
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "mainoutputgenerator.h"

OutputGenerator *outputgenerator = 0;

