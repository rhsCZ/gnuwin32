#ifndef CMDLINEARGS_H
#define CMDLINEARGS_H

#include "cmdline.h"

extern gengetopt_args_info args_info ;     // command line structure

#endif // CMDLINEARGS_H
