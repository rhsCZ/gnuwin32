#ifndef LINENUMDIGIT_H
#define LINENUMDIGIT_H

extern unsigned int line_num_digit; // num of digits to represent line number

#endif // LINENUMDIGIT_H
