//
// C++ Interface: parsetags
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef PARSETAGS_H
#define PARSETAGS_H

#include "tags.h"

Tags *parseTags(const std::string &path, const std::string &name) ;

#endif
