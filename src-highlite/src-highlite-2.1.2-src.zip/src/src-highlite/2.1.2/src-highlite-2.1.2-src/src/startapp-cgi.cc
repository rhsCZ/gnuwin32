#define BUILD_AS_CGI

#include "startapp.cc"
