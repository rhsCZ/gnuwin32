/*
  This is to demonstrate --debug-lang
  http://www.lorenzobettini.it
*/

package hello;

public class Hello {
	// just some greetings ;-)  /*
    int i = 10;
    System.out.println("Hello World!");
}
