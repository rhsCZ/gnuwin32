// Test for templates (probably won't compile with C++ :-)

#include "map"
#include <vector.h>
#include <algorithm>

int i = j<k && j>d

template <typename First,
          typename Second,
          typename CompareFirst = std::less<First>,
          typename CompareSecond = std::less<Second> >

Foo foo<class Test>
