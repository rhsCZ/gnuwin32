# some tests for comments # yep

=begin

This is rd Documentation

# foo

=end

print "Outside of the comment\n"
