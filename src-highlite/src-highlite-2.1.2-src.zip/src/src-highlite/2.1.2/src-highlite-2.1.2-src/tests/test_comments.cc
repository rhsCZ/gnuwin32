// some tests for comments

/* first /* second */ int i; */ int i;

/*   It is the same for Java and C++
 */

/*
  These are some comments with come nesting
  e.g. /* and
  let's see if it works!
*/

// since their // behaviour is /* almost the same 

*/

/* < & > // */
