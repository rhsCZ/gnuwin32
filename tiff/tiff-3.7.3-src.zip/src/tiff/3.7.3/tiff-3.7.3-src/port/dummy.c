/* $Id: dummy.c,v 1.1 2004/06/07 19:34:58 dron Exp $ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void
libport_dummy_function()
{
        return;
}

