#ifndef _RSK_STRTOLL_H
#define _RSK_STRTOLL_H

long long int strtoll(const char *nptr, char **endptr, int base);

#endif
