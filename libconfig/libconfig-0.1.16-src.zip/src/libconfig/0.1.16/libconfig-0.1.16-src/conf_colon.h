#ifndef LC_CONF_COLON_H
#define LC_CONF_COLON_H
#include "libconfig.h"
#include "libconfig_private.h"

int lc_process_conf_colon(const char *appname, const char *configfile);

#endif
