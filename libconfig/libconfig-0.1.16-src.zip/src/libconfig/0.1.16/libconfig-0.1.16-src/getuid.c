#include "getuid.h"

uid_t getuid(void) {
	return(0);
}
