#ifndef LC_CONF_XML_H
#define LC_CONF_XML_H
#include "libconfig.h"
#include "libconfig_private.h"

int lc_process_conf_xml(const char *appname, const char *configfile);

#endif
