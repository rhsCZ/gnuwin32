#ifndef LC_CONF_SPACE_H
#define LC_CONF_SPACE_H
#include "libconfig.h"
#include "libconfig_private.h"

int lc_process_conf_space(const char *appname, const char *configfile);

#endif
