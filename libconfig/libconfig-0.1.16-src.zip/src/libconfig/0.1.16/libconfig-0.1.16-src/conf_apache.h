#ifndef LC_CONF_APACHE_H
#define LC_CONF_APACHE_H
#include "libconfig.h"
#include "libconfig_private.h"

int lc_process_conf_apache(const char *appname, const char *configfile);

#endif
