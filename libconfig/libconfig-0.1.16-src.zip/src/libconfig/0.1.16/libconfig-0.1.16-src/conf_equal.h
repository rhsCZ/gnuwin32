#ifndef LC_CONF_EQUAL_H
#define LC_CONF_EQUAL_H
#include "libconfig.h"
#include "libconfig_private.h"

int lc_process_conf_equal(const char *appname, const char *configfile);

#endif
