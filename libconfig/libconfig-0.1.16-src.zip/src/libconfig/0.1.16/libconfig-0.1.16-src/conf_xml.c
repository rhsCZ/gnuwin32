#include "libconfig.h"
#include "libconfig_private.h"
#include "conf_xml.h"

int lc_process_conf_xml(const char *appname, const char *configfile) {
	return(-1);
}
