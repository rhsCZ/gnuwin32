#ifndef _LC_GETUID_H
#define _LC_GETUID_H

typedef int uid_t;

uid_t getuid(void);

#endif
