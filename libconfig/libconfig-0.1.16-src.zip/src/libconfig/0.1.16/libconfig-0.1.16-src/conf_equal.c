#include "libconfig.h"
#include "libconfig_private.h"
#include "conf_equal.h"

int lc_process_conf_equal(const char *appname, const char *configfile) {
	return(-1);
}
