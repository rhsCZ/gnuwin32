#! /bin/sh

# the next program must exit with error

if ./no_optgiven; then false; else true; fi
