#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
typedef union {
    char   *str;
    char    chr;
    int	    argtype;
    int	    boolean;
} yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	TOK_PACKAGE	257
# define	TOK_VERSION	258
# define	TOK_OPTION	259
# define	TOK_DEFGROUP	260
# define	TOK_GROUPOPTION	261
# define	TOK_YES	262
# define	TOK_NO	263
# define	TOK_ON	264
# define	TOK_OFF	265
# define	TOK_FLAG	266
# define	TOK_PURPOSE	267
# define	TOK_DEFAULT	268
# define	TOK_GROUP	269
# define	TOK_GROUPDESC	270
# define	TOK_MULTIPLE	271
# define	TOK_TYPESTR	272
# define	TOK_SECTION	273
# define	TOK_STRING	274
# define	TOK_MLSTRING	275
# define	TOK_CHAR	276
# define	TOK_ARGTYPE	277


extern YYSTYPE yylval;

#endif /* not BISON_Y_TAB_H */
