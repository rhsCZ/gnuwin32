// deal with namespace problems

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif // HAVE_CONFIG_H

#include <string>

#ifdef HAVE_NAMESPACES
using std::string;
#endif
