#! /bin/sh

# test values for options

$* ./test_values -s foo -S foo --string-values-no-short bar --multistring-values-no-short "foo" -S bar --multistring-values-no-short "foo","bar" -S bar,foo --multistring-values-no-short "bar" --multistring-values-no-short "bar","foo"