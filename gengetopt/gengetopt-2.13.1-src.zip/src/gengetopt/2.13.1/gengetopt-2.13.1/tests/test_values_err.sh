#! /bin/sh

# test values for options

if $* ./test_values -s fo ; then
       false;
else
       if $* ./test_values -S fooa ; then
                false;
       else
                if $* ./test_values --string-values-no-short fooa ; then
                        false;
                else
                        if $* ./test_values --multistring-values-no-short bar,fooa ; then false;
                        else true; fi 
                fi 
       fi 
fi