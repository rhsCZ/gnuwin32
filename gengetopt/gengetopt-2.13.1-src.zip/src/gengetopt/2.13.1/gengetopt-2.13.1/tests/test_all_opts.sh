#! /bin/sh

# the next program must exit with error

$* ./test_all_opts -r "foo" --opt-arg -o
$* ./test_all_opts -r "foo" --opt-arg="bar" -o"foobar"
if $* ./test_all_opts -r "foo"; then true; else false; fi
