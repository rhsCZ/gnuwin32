//
// C++ Interface: acceptedvalues
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef ACCEPTEDVALUES_H
#define ACCEPTEDVALUES_H

#include <list>
#include <set>
#include <string>

/**
the values that can be passed to an option

@author Lorenzo Bettini
*/
class AcceptedValues : protected std::list<std::string>
{
  private:
    typedef std::set<std::string> value_set;
    value_set values;
  
  public:
    void insert(const std::string &s);
    const std::string toString(bool escape = true) const;
    bool contains(const std::string &s) const;
};

#endif
