//
// C++ Interface: fileutils
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef FILEUTILS_H
#define FILEUTILS_H

#include <fstream>

using std::ofstream;

char *create_filename (char *name, char *ext);
ofstream *open_fstream (char *filename);

#endif
