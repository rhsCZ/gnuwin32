//
// C++ Interface: gm_utils
//
// Description:
//
//
// Author: Lorenzo Bettini <bettini@gnu.org>, (C) 2004
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifndef GM_UTILS_H
#define GM_UTILS_H

#include <string>

using std::string;

char *canonize_names(const char * name);
const string canonize_name(const string &name);
const string strip_path(const string &);
const string to_upper(const string &);

bool has_multiple_options_string();
bool has_multiple_options();
bool has_multiple_options_with_type();
bool has_required();
bool has_options();
bool has_values();

void wrap_cstr (string &wrapped, unsigned int from_column, unsigned int second_indent, const string &orig);

#endif
