#! /bin/sh

# the next program must not exit with error

if $* ../src/gengetopt.exe --show-help -i ../../gengetopt-2.20-src/tests/test_all_opts_cmd.ggo ; then 
        if $* ../src/gengetopt.exe --show-version -i ../../gengetopt-2.20-src/tests/test_all_opts_cmd.ggo ; then 
                if $* ../src/gengetopt.exe --show-help -i ../../gengetopt-2.20-src/tests/test_values_cmd.ggo ; then 
                        true;
                else
                        false;
                fi
        else
                false;
        fi
else 
        false; 
fi
