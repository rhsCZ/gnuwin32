#! /bin/sh

# the next program must exit with error

$* ./test_all_opts -r "foo" --opt-arg -o -l 150000000 -f 150.217 -u --file-save="test_all_opts.save" -F these are command line options without names
