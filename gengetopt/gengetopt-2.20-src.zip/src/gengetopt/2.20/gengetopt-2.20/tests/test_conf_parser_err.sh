#! /bin/sh

# the next program must exit with error

if $* ./test_conf_parser -r "bar" -i 100 -c ../../gengetopt-2.20-src/tests/test_conf_err.conf --opta "FOO"; then false; else true; fi
