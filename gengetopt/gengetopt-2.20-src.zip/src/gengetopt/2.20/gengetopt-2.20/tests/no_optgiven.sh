#! /bin/sh

# the next program must exit with error

if $* ./no_optgiven; 
then false; 
else 
        if $* ./no_optgiven2; then false;
        else true; fi
fi
