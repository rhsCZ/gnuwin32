#! /bin/sh

if $* ./test_conf_parser_ov3 -r "bar" --float 2.14 -i 100 -c ../../gengetopt-2.20-src/tests/test_conf2.conf; then true; else false; fi
