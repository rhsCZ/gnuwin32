#
# Configuration file for using the XML library in GNOME applications
#
XML_LIBDIR="-Lc:/progra~1/LibXml1/lib"
XML_LIBS="-lxml -lz  -Wl,-s -lwsock32 -liberty -lc"
XML_INCLUDEDIR="-Ic:/progra~1/LibXml1/include/gnome-xml"
MODULE_VERSION="xml-1.8.17"

