#ifndef __MINGW_H
#include <_mingw.h>
#endif

#if !defined(BUILD_DLL) && defined(__MINGW32__)
#define DLL_IMPORT __MINGW_IMPORT 
#else
#define DLL_IMPORT extern
#endif
