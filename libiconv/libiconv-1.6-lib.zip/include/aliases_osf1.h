  { "DEC-KANJI", ei_dec_kanji },
  { "DEC-HANYU", ei_dec_hanyu },
