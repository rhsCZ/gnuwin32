YOU MUST HAVE THE FOLLOWING LIBRARIES:

zlib
libpng
libtiff

Make sure you have the above libraries installed, then do
"make install" to compile and install fax2png. Type "fax2png"
with no arguments for a simple usage message. Type
"man fax2png" for an example and complete documentation.
Don't forget the -a option if you want attractive results!
  
