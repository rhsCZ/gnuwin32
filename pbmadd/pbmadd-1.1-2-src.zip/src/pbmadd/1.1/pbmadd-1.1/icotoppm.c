/* #includes */ /*{{{C}}}*//*{{{*/
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*}}}*/

int main(int argc, char *argv[])
{
  /* variables */ /*{{{*/
  struct
  {
    /* icon file header */
    char icoReserved[2];            /* Reserved, must be set to 0          */
    char icoResourceType[2];        /* Resource type, 1 for icon resources */
    char icoResourceCount[2];       /* Number of images in the file        */
    /* icon resource header */
    unsigned char Width;            /* Width in pixels                     */
    unsigned char Height;           /* Height in pixels                    */
    unsigned char ColorCount;       /* Number of colors                    */
    unsigned char Reserved1;
    char Reserved2[2];
    char Reserved3[2];
    unsigned char icoDIBSize[4];    /* Size in bytes of the pixel array    */
    unsigned char icoDIBOffset[4];  /* Offset of bitmap info header        */
    /* bitmap header */
    unsigned char biSize[4];
    unsigned char biWidth[4];
    unsigned char biHeight[4];
    unsigned char biPlanes[2];
    unsigned char biBitCount[2];
    unsigned char biCompression[4];
    unsigned char biSizeImage[4];
    unsigned char biXPelsPerMeter[4];
    unsigned char biYPelsPerMeter[4];
    unsigned char biClrUsed[4];
    unsigned char biClrImportant[4];
    unsigned char data[1];          /* colour map, bit map */
  } hdr;
  struct rgb
  {
    unsigned char rgbBlue;
    unsigned char rgbGreen;
    unsigned char rgbRed;
    unsigned char rgbReserved;
  };
  static struct rgb black={ 0,0,0,0 };
  struct rgb *colourtable=&black;
  unsigned char *colourbitmap,*monobitmap,*colour,*mono;
  int colours,bitsperpixel,colourbitmapsize,monobitmapsize;
  unsigned char bitmask;
  int i,j,k,line;
  unsigned int cd,md;
  static const char stdinname[]="(stdin)";
  FILE *ifp;
  const char *iname;
  /*}}}*/

  /* open input file */ /*{{{*/
  if (argc>=2)
  {
    iname=argv[1];
    if ((ifp=fopen(iname,"rb"))==(FILE*)0)
    {
      fprintf(stderr,"icotoppm: %s: opening failed: %s\n",iname,strerror(errno));
      exit(1);
    }
  }
  else
  {
    iname=stdinname;
    ifp=stdin;
  }
  /*}}}*/
  /* read header */ /*{{{*/
  if (fread(&hdr,sizeof(hdr)-1,1,ifp)!=1)
  {
    fprintf(stderr,"icotoppm: %s: failed to read header\n",iname);
    return 1;
  }
  /*}}}*/
  /* determine number of bits per pixel */ /*{{{*/
  if (hdr.ColorCount>0 && hdr.ColorCount<=2) { colours=hdr.ColorCount; bitsperpixel=1; bitmask=0x80; }
  else if (hdr.ColorCount>2 && hdr.ColorCount<=4) { colours=hdr.ColorCount; bitsperpixel=2; bitmask=0xc0; }
  else if (hdr.ColorCount>4 && hdr.ColorCount<=16) { colours=hdr.ColorCount; bitsperpixel=4; bitmask=0xf0; }
  else { colours=256; bitsperpixel=8; bitmask=0xff; }
  /*}}}*/
  /* determine number of bytes for bitmaps */ /*{{{*/
  colourbitmapsize=(((int)hdr.Width)*((int)hdr.Height)*bitsperpixel+7)/8;
  monobitmapsize=(((int)hdr.Width)*((int)hdr.Height)+7)/8;
  /*}}}*/
  /* sanity checks */ /*{{{*/
  if (hdr.icoReserved[0]||hdr.icoReserved[1])
  {
    fprintf(stderr,"icotoppm: %s: invalid icon file\n",iname);
    return(1);
  }
  if ((hdr.icoResourceCount[0]|(hdr.icoResourceCount[1]<<8))!=1)
  {
    fprintf(stderr,"icotoppm: %s: icon file contains %d icons, but multi-icon files are not supported.\n",iname,(hdr.icoResourceCount[0]|(hdr.icoResourceCount[1]<<8)));
    return(1);
  }
  if ((((unsigned int)hdr.icoDIBOffset[0])|(((unsigned int)hdr.icoDIBOffset[1])<<8)|(((unsigned int)hdr.icoDIBOffset[2])<<16)|(((unsigned int)hdr.icoDIBOffset[3])<<24))!=(((unsigned int)&(hdr.biSize[0]))-((unsigned int)&hdr)))
  {
    fprintf(stderr,"icotoppm: %s: bit map header does not start at expected position.\n",iname);
    return(1);
  }
  if (hdr.biCompression[0] || hdr.biCompression[1] || hdr.biCompression[2] || hdr.biCompression[3])
  {
    fprintf(stderr,"icotoppm: %s: Only RGB encoding supported.\n",iname);
    return(1);
  }
  /*}}}*/
  /* allocate and read colour table, rgb bit map and mono bit map */ /*{{{*/
  if ((colourtable=malloc(colours*sizeof(struct rgb)))==(void*)0)
  {
    fprintf(stderr,"icotoppm: %s: out of memory.\n",iname);
    return 1;
  }
  if ((colourbitmap=malloc(colourbitmapsize))==(void*)0 || (monobitmap=malloc(monobitmapsize))==(void*)0)
  {
    fprintf(stderr,"icotoppm: %s: out of memory.\n",iname);
    return 1;
  }
  if (fread(colourtable,colours*sizeof(struct rgb),1,ifp)!=1)
  {
    fprintf(stderr,"icotoppm: %s: reading colour map of size %d failed.\n",iname,colours);
    return 1;
  }
  if (fread(colourbitmap,colourbitmapsize,1,ifp)!=1)
  {
    fprintf(stderr,"icotoppm: %s: reading colour bit map failed.\n",iname);
    return 1;
  }
  if (fread(monobitmap,monobitmapsize,1,ifp)!=1)
  {
    fprintf(stderr,"icotoppm: %s: reading mono bit map failed.\n",iname);
    return 1;
  }
  /*}}}*/
  /* generate ppm file */ /*{{{*/
  printf("P3\n%d %d\n255\n",(int)hdr.Width,(int)hdr.Height);
  for (line=((int)hdr.Height)-1; line>=0; --line)
  {
    for
    (
      colour=colourbitmap+line*((((int)hdr.Width)*bitsperpixel+7)/8),cd=*colour,
      mono=monobitmap+line*((((int)hdr.Width)+7)/8),md=*mono,
      i=0,j=0,k=0;
      i<((int)hdr.Width);
      ++i
    )
    {
      struct rgb c;

      c=colourtable[(cd&bitmask)>>(8-bitsperpixel)];
      printf("%u ",md&0x80 ? 255 : (unsigned int)c.rgbRed);
      printf("%u ",md&0x80 ? 255 : (unsigned int)c.rgbGreen);
      printf("%u\n",md&0x80 ? 255 : (unsigned int)c.rgbBlue);
      cd<<=bitsperpixel;
      j+=bitsperpixel;
      md<<=1;
      ++k;
      if (j==8)
      {
        ++colour;
        cd=*colour;
        j=0;
      }
      if (k==8)
      {
        ++mono;
        md=*mono;
        k=0;
      }
    }
  }
  /*}}}*/
  /* close input file */ /*{{{*/
  if (iname!=stdinname) fclose(ifp);
  /*}}}*/
  return(0);
}
