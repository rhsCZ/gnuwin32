#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
  struct Colour { int r,g,b; } *colour,pixel;
  int colourSize=0,colourCapacity=32,n,i;

  if ((colour=malloc(sizeof(colour[0])*colourCapacity))==(struct Colour*)0)
  {
    fprintf(stderr,"rgbpalettetoppm: %s\n",strerror(errno));
    exit(1);
  }
  while ((n=scanf("%u %u %u\n",&pixel.r,&pixel.g,&pixel.b))!=EOF)
  {
    if (n==3)
    {
      if (colourSize==colourCapacity && (colour=realloc(colour,sizeof(colour[0])*(colourCapacity*=2)))==(struct Colour*)0)
      {
        fprintf(stderr,"rgbpalettetoppm: %s\n",strerror(errno));
        exit(1);
      }
      colour[colourSize++]=pixel;
    }
    else if (n==0) while ((n=getchar())!=EOF && n!='\n');
  }
  printf("P3\n%d 1\n255\n",colourSize);
  for (i=0; i<colourSize; ++i) printf("%d %d %d\n",colour[i].r,colour[i].g,colour[i].b);
  return 0;
}
