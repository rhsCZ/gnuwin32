#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define DIVERGE 5.6

static int darkest=15,brightest=63;
static int size;
static int userXSize=512,userYSize=512;
static unsigned char *pixel;

#define PIXEL(x,y) pixel[size*(x)+(y)]

int getuint(char *optarg, const char *msg) /*{{{C}}}*//*{{{*/
{
  char *end;
  int n;

  n=strtol(optarg,&end,10);
  if (end==optarg || n<0)
  {
    fprintf(stderr,msg);
    exit(EXIT_FAILURE);
  }
  return n;
}
/*}}}*/

int colour(float colour, float mf)
{
  int c;

  c=colour+(rand()/(float)RAND_MAX)*2.0*mf-mf+0.5;
  if (c>brightest) return brightest;
  else if (c<darkest) return darkest;
  else return c;
}

int main(int argc, char *argv[])
{
  int size_lg2;
  int c,i,j,k,n,nk,brightesto;
  char buf[30];
  float mf;

  /* parse options */ /*{{{*/
  while ((c=getopt(argc,argv,"x:y:h?"))!=EOF) switch (c)
  {
    case 'x':
    {
      userXSize=getuint(optarg,"pgmclouds: invalid x size\n");
      break;
    }
    case 'y':
    {
      userYSize=getuint(optarg,"pgmclouds: invalid y size\n");
      break;
    }
    default:
    {
      fprintf(stderr,"Usage: pgmclouds [-x width][-y height]\n");
      exit(EXIT_FAILURE);
    }
  }
  size=1;
  while (size<userXSize || size<userYSize) size<<=1;
  ++size;
  /*}}}*/
  /* allocate pixel buffer */ /*{{{*/
  if ((pixel=malloc(size*size))==(unsigned char*)0)
  {
    fprintf(stderr,"pbmclouds: can not allocate buffer: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  memset(pixel,0,size*size);
  /*}}}*/
  for (size_lg2=0,brightesto=size; brightesto>1; brightesto/=2) ++size_lg2;
  srand(time((time_t*)0));

  PIXEL(0,0)=colour((brightest-darkest)/2.0,DIVERGE);
  PIXEL(0,size)=colour((brightest-darkest)/2.0,DIVERGE);
  PIXEL(size,0)=colour((brightest-darkest)/2.0,DIVERGE);
  PIXEL(size,size)=colour((brightest-darkest)/2.0,DIVERGE);

  for (i=0,n=size; i<size_lg2; ++i,n>>=1)
  {
    if ((size_lg2-i-2)>7) mf=7*DIVERGE;
    else if ((size_lg2-i-2)<1) mf=DIVERGE;
    else mf=(size_lg2-i-2)*DIVERGE;
    for (j=0; j<(1<<i); ++j)
    {
      PIXEL(j*n+n/2,0)=colour
      ((
        ((unsigned int)PIXEL(j*n,0))
        +((unsigned int)PIXEL((j+1)*n,0))
      )/2.0,mf);
      PIXEL(j*n+n/2,size)=colour((((unsigned int)PIXEL(j*n,size))+((unsigned int)PIXEL((j+1)*n,size)))/2.0,mf);
      PIXEL(0,j*n+n/2)=colour((((unsigned int)PIXEL(0,j*n))+((unsigned int)PIXEL(0,(j+1)*n)))/2.0,mf);
      PIXEL(size,j*n+n/2)=colour((((unsigned int)PIXEL(size,j*n))+((unsigned int)PIXEL(size,(j+1)*n)))/2.0,mf);
    }
  }

  for (i=0,n=size; i<size_lg2; ++i,n>>=1)
  {
    if ((size_lg2-i-2)>7) mf=7*DIVERGE;
    else if ((size_lg2-i-2)<1) mf=DIVERGE;
    else mf=(size_lg2-i-2)*DIVERGE;
    for (k=0; k<(1<<i); ++k)
    {
      for (j=0; j<(1<<i); ++j)
      {
        PIXEL(j*n+n/2,k*n+n/2)=colour
        ((
          ((unsigned int)PIXEL(j*n,k*n))
          +((unsigned int)PIXEL(j*n,(k+1)*n))
          +((unsigned int)PIXEL((j+1)*n,k*n))
          +((unsigned int)PIXEL((j+1)*n,(k+1)*n))
        )/4.0,mf);
      }
    }
    for (k=0,nk=1; k<(1<<(i+1))-1; ++k,nk=!nk)
    {
      for (j=0; j<(1<<i)-nk; ++j)
      {
        PIXEL(j*n+n/2+nk*n/2,(k+1)*n/2)=colour
        ((
          ((unsigned int)PIXEL(j*n+n/2+nk*n/2,k*n/2))
          +((unsigned int)PIXEL((j+1)*n+nk*n/2,(k+1)*n/2))
          +((unsigned int)PIXEL(j*n+n/2+nk*n/2,(k+2)*n/2))
          +((unsigned int)PIXEL(j*n+nk*n/2,(k+1)*n/2))
        )/4.0,mf);
      }
    }
    nk=0;
  }

  for (k=0; k<2; ++k) for (i=0; i<size; ++i) for (j=0; j<size; ++j)
  {
    PIXEL(i,j)=
    (
      ((unsigned int)PIXEL(i,j))
      +((unsigned int)PIXEL(i+1,j))
      +((unsigned int)PIXEL(i,j+1))
      +((unsigned int)PIXEL(i+1,j+1))
    )/4.0+0.5;
  }

  /* write header */ /*{{{*/
  sprintf(buf,"P5\n%d %d\n%d\n",userXSize,userYSize,brightest+1);
  if (write(1,buf,strlen(buf))!=strlen(buf))
  {
    fprintf(stderr,"pgmclouds: failed to write header: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  /*}}}*/
  for (i=0; i<userYSize; ++i)
  {
    if (write(1,pixel+i*size,userXSize)!=userXSize)
    {
      fprintf(stderr,"pgmclouds: failed to write data: %s\n",strerror(errno));
      exit(EXIT_FAILURE);
    }
  }
  exit(0);
}
