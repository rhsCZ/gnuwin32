/* #includes */ /*{{{C}}}*//*{{{*/
#include <assert.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
/*}}}*/
/* #defines */ /*{{{*/
#define SEA 0
#define TOP (GRID/2)
#define XSPREAD 3
#define XOFFSET 20
#define YOFFSET 20
#define SEA_COLOUR (COLOURS/3)
#define BEACH_COLOUR (SEA_COLOUR+(COLOURS/10))
#define SHADE_HEIGHT_RATIO 0.4
#define COLOURS 255
#define GRID 512

#define P(x,y) p[(y)*(grid+1)+(x)]
#define PIXEL(x,y) pixel[(y)*xsize+(x)]
/*}}}*/

static unsigned char *pixel;
static int xsize,ysize;

static void area(int x1, int y1, int x2, int y2, int x3, int y3, int colour) /*{{{*/
{
  assert(x1>=0);
  assert(x1<xsize);
  assert(x2>=0);
  assert(x2<xsize);
  assert(x3>=0);
  assert(x3<xsize);
  assert(y1>=0);
  assert(y1<ysize);
  assert(y2>=0);
  assert(y2<ysize);
  assert(y3>=0);
  assert(y3<ysize);
  PIXEL(x1,y1)=colour;
  PIXEL(x2,y2)=colour;
  PIXEL(x3,y3)=colour;
  PIXEL((x1+x2)/2,(y1+y2)/2)=colour;
  PIXEL((x2+x3)/2,(y2+y3)/2)=colour;
  PIXEL((x3+x1)/2,(y3+y1)/2)=colour;
  PIXEL((x1+x2+x3)/3,(y1+y2+y3)/3)=colour;
}
/*}}}*/

int main(int argc, char *argv[])
{
  char buf[30];
  float *p;
  int grid=GRID,stepSize,i,j,min;
  float l1,l2,l3,laenge,ss,hh,v3;

  if ((p=malloc((grid+1)*(grid+1)*sizeof(int)))==(float*)0)
  {
    fprintf(stderr,"pgmmountains: can not allocate grid buffer: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  memset(p,0,(grid+1)*(grid+1)*sizeof(float));
  xsize=grid+2*XOFFSET;

  srand(time((time_t*)0));
  P(0,0)=10.0;
  P(grid/5,(grid*4)/5)=40.0;
  /* build mountains */ /*{{{*/
  l1=1;
  l2=0;
  l3=1;
  laenge=sqrt(l1*l1+l2*l2+l3*l3);
  l1=l1/laenge;
  l2=l2/laenge;
  l3=l3/laenge;
  for (stepSize=grid; stepSize>1; stepSize>>=1)
  {
    int w2=stepSize/2;

    for (j=0; j<grid; j+=stepSize) for (i=0; i<(grid-j); i+=stepSize)
    {
      P(i+w2,j)+=(P(i,j)+P(i+stepSize,j))/2.0+((rand()/(float)RAND_MAX)-0.5)*stepSize;
      P(j,i+w2)+=(P(j,i)+P(j,i+stepSize))/2.0+((rand()/(float)RAND_MAX)-0.5)*stepSize;
      P(grid-j-i-w2,i+w2)+=(P(grid-j-i,i)+P(grid-j-i-stepSize,i+stepSize))/2.0+((rand()/(float)RAND_MAX)-0.5)*stepSize;
    }
  }
  /*}}}*/
  /* draw graymap */ /*{{{*/
  for (min=grid,j=0; j<grid; ++j) for (i=0; i<(grid-j); ++i) if (j-P(i,j)<min) min=j-P(i,j);
  ysize=(-min+grid)/XSPREAD+2*YOFFSET;
  pixel=malloc(xsize*ysize);
  memset(pixel,0,xsize*ysize);

  ss=stepSize;
  hh=sqrt(0.75)*ss;
  v3=ss*hh;
  for (j=0; j<grid; j+=stepSize)
  {
    int a=j/2;
    int b=a+stepSize;
    int c=(j+stepSize)/2;
    int dd=c+stepSize;
    int ya=(j+stepSize-grid)/XSPREAD+ysize-YOFFSET;
    int yb=(j-grid)/XSPREAD+ysize-YOFFSET;

    for (i=0; i<(grid-j-stepSize); i+=stepSize)
    {
      float v1,v2,shade,height,p1,p2,p3;
      int colour;

      p1=P(i,j+stepSize); if (p1<SEA) p1=SEA;
      p2=P(i+stepSize,j); if (p2<SEA) p2=SEA;
      p3=P(i+stepSize,j+stepSize); if (p3<SEA) p3=SEA;
      if (p1==SEA && p2==SEA && p3==SEA) colour=SEA_COLOUR;
      else
      {
        height=(p1+p2+p3)/3.0/TOP;
        if (height>1.0) height=1.0;
        v1=10.0*-hh*(p3-p1);
        v2=10.0*ss*((p1+p3)/2.0-p2);
        shade=(l1*v1+l2*v2+l3*v3)/sqrt(v1*v1+v2*v2+v3*v3);
        if (shade<0.0) shade=0.0;
        colour=((SHADE_HEIGHT_RATIO*shade+(1.0-SHADE_HEIGHT_RATIO)*height)*(COLOURS-BEACH_COLOUR))+BEACH_COLOUR;
      }
      area
      (
        (int)((i+c)+XOFFSET),ya-(int)(p1/XSPREAD),
        (int)((i+b)+XOFFSET),yb-(int)(p2/XSPREAD),
        (int)((i+dd)+XOFFSET),ya-(int)(p3/XSPREAD),
        colour
      );
    }
    for (i=0; i<(grid-j); i+=stepSize)
    {
      float p0,p1,p2,v1,v2,shade,height;
      int colour;

      p0=P(i,j); if (p0<SEA) p0=SEA;
      p1=P(i,j+stepSize); if (p1<SEA) p1=SEA;
      p2=P(i+stepSize,j); if (p2<SEA) p2=SEA;
      if (p0==SEA && p1==SEA && p2==SEA) colour=SEA_COLOUR;
      else
      {
        height=(p0+p1+p2)/3.0/TOP;
        if (height>1.0) height=1.0;
        v1=10.0*-hh*(p2-p0);
        v2=10.0*ss*((p0+p2)/2-p1);
        shade=(l1*v1+l2*v2+l3*v3)/sqrt(v1*v1+v2*v2+v3*v3);
        if (shade<0.0) shade=0.0;
        colour=((SHADE_HEIGHT_RATIO*shade+(1.0-SHADE_HEIGHT_RATIO)*height)*(COLOURS-BEACH_COLOUR))+BEACH_COLOUR;
      }
      area
      (
        (int)((i+a)+XOFFSET),yb-(int)(p0/XSPREAD),
        (int)((i+b)+XOFFSET),yb-(int)(p2/XSPREAD),
        (int)((i+c)+XOFFSET),ya-(int)(p1/XSPREAD),
        colour
      );
    }
  }
  /*}}}*/
  /* write graymap */ /*{{{*/
  sprintf(buf,"P5\n%d %d\n%d\n",xsize,ysize,COLOURS);
  if (write(1,buf,strlen(buf))!=strlen(buf))
  {
    fprintf(stderr,"pgmmountains: failed to write header: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  write(1,pixel,xsize*ysize);
  /*}}}*/
  exit(EXIT_SUCCESS);
}
