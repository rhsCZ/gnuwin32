./pgmfract -p -0.5:0.0:1.5 > fractal1.pgm
./pgmfract -p -0.7660315:0.100861:0.0003 > fractal2.pgm
./pgmfract -p -1.252758:0.342541:0.007629 > fractal3.pgm
./pgmfract -p -0.368056:0.645833:0.097222 > fractal4.pgm
./pgmfract -p -0.17596915:1.08649105:0.0000004 > fractal5.pgm
./pgmfract -j -0.17596915:1.08649105 -p 0.0:0.0:0.01 > fractal6.pgm
./pgmfract -d 2000 -p -0.74567846:0.09998153:0.00012307 > fractal7.pgm
./pgmfract -d 2000 -j -0.74567846:0.09998153 -p 0.0:0.0:0.1 > fractal8.pgm
./pgmmountains > mountains.pgm
./pgmclouds > clouds.pgm
