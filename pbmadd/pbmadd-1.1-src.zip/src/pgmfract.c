/* #includes */ /*{{{C}}}*//*{{{*/
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
/*}}}*/
/* #defines */ /*{{{*/
#define SIZE   600
#define DEPTH  600
#define XPOS   0.0
#define YPOS   0.0
#define XYDIST 2.0
#define SHADES 64
/*}}}*/

int getuint(char *optarg, const char *msg) /*{{{*/
{
  char *end;
  int n;

  n=strtol(optarg,&end,10);
  if (end==optarg || n<0)
  {
    fprintf(stderr,msg);
    exit(EXIT_FAILURE);
  }
  return n;
}
/*}}}*/
int iterate(int maxdepth, double cx, double cy, double jcr, double jci) /*{{{*/
{
      int depth=0;
      register double xval=cx;
      register double yval=cy;
      double xsquare=xval*xval;
      double ysquare=yval*yval;
      do
      {
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=1; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=2; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=3; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=4; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=5; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=6; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=7; break; }
        yval=xval*yval*2.0+jci;
        xval=xsquare-ysquare+jcr;
        if (((xsquare=(xval*xval))+(ysquare=(yval*yval)))>=4.0) { depth+=8; break; }
        depth+=8;
      } while (depth<maxdepth);
  return depth;
}
/*}}}*/

int main(int argc, char *argv[])
{
  /* variables */ /*{{{*/
  int c,height=SIZE,width=SIZE,maxdepth=DEPTH,row,column,julia=0;
  double xPos=XPOS,yPos=YPOS,xyDistance=XYDIST,cx,cy,dx,dy,jcr=0.0,jci=0.0;
  char *buf;
  /*}}}*/

  /* parse options */ /*{{{*/
  while ((c=getopt(argc,argv,"s:d:p:j:h?"))!=EOF) switch (c)
  {
    case 's': width=getuint(optarg,"pgmfract: invalid width\n"); height=width; break;
    case 'd': maxdepth=getuint(optarg,"pgmfract: invalid depth\n"); break;
    case 'p':
    {
      char *end;
      xPos=strtod(optarg,&end);
      if (end!=optarg && *end)
      {
        optarg=end+1;
        yPos=strtod(optarg,&end);
        if (end!=optarg && *end)
        {
          optarg=end+1;
          xyDistance=strtod(optarg,&end);
          if (end!=optarg) break;
        }
      }
      fprintf(stderr,"pgmfract: invalid section\n");
      exit(EXIT_FAILURE);
    }
    case 'j':
    {
      char *end;
      julia=1;
      jcr=strtod(optarg,&end);
      if (end!=optarg && *end)
      {
        optarg=end+1;
        jci=strtod(optarg,&end);
        if (end!=optarg) break;
      }
      fprintf(stderr,"pgmfract: invalid constant\n");
      exit(EXIT_FAILURE);
    }
    default:
    {
      fprintf(stderr,"Usage: pgmfract [-s size][-d depth][-p xpos:ypos:distance][-j cr:ci]\n");
      exit(EXIT_FAILURE);
    }
  }
  /*}}}*/
  /* allocate output buffer */ /*{{{*/
  if ((buf=malloc(width<30 ? 30 : width))==(char*)0)
  {
    fprintf(stderr,"pbmfract: can not allocate buffer: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  /*}}}*/
  /* write header */ /*{{{*/
  sprintf(buf,"P5\n%d %d\n%d\n",width,height,SHADES-1);
  if (write(1,buf,strlen(buf))!=strlen(buf))
  {
    fprintf(stderr,"pgmfract: failed to write header: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  /*}}}*/

  dx=2.0*xyDistance/(double)width;
  dy=2.0*xyDistance/(double)height;
  for (cy=yPos+xyDistance,row=0; row<height; ++row,cy-=dy)
  {
    for (cx=xPos-xyDistance,column=0; column<width; ++column,cx+=dx)
    {
      int depth;

      if (julia) depth=iterate(maxdepth,cx,cy,jcr,jci);
      else depth=iterate(maxdepth,cx,cy,cx,cy);
      buf[column]=(depth>=maxdepth ? 0 : 1+depth%(SHADES-1));
    }
    if (write(1,buf,width)!=width)
    {
      fprintf(stderr,"pgmfract: failed to write data: %s\n",strerror(errno));
      exit(EXIT_FAILURE);
    }
  }
  exit(0);
}

