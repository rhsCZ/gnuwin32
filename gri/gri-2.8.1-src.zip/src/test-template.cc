#include <vector>
#include <algorithm>

template void std::reverse(std::vector<double>::iterator, std::vector<double>::iterator);

template void std::sort(std::vector<double>::iterator, std::vector<double>::iterator);
