#include "winsock.h"

int main() {

gethostname();

; return 0; }
