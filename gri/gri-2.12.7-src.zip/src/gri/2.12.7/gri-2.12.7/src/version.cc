// NB: number string must agree with line 1 of gri.cmd
char _gri_number[] = VERSION;	// set in Makefile
char _gri_release_time[] = "2003-Sep-04";
char _gri_date[] = "2003";
