// NB: number string must agree with line 1 of gri.cmd
char _gri_number[] = VERSION;	// set in Makefile
char _gri_release_time[] = "2004 Dec 13";
char _gri_date[] = "2004";
