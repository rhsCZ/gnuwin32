#if !defined(_debug_)

#define _debug_
#define DEBUG_CLIPPED 0x0001	/* `debug clipped values in draw commands' */

#endif				/* _debug_ */
