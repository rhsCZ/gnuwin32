// NB: number string must agree with line 1 of gri.cmd
char _gri_number[] = "2.8.0";
char _gri_release_time[] = "2001-jul-30";
char _gri_date[] = "2001";

// OLDER VERSIONS:
//
//  2.8.0       2001-Jul-30
//  2.6.1       2001-May-11
//  2.6.0       2001-Apr-01
//  2.5.5       2000-Jun-21
//  2.5.4       2000-Jun-01
//  2.5.3       2000-May-22
//  2.5.2       2000-May-20
//  2.5.1       2000-May-09
//  2.4.4       2000-May-07
//  2.4.3       2000-Apr-01
//  2.4.2       2000-Mar-25
//  2.4.1       2000-Jan-31
//  2.4.0=2.3.7 2000-Jan-05
//  2.4.0=2.3.7 2000-Jan-05
//  2.3.7       1999-Dec-14
//  2.3.6       1999-Dec-13
//  2.3.5       1999-Dec-12
//  2.2.6       1999-Nov-29
//  2.2.5       1999-Nov-10
