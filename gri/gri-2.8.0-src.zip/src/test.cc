#include <algorithm>
#include <vector.h>
#include <stdio.h>

void sub1();
void sub2();

int main(){
	sub1();
	sub2();
}

void sub1() {
	std::vector<double> s;
	for (int i = 0; i < 3; i++)
		s.push_back(0.1 * i); 
	reverse(s.begin(), s.end());
}

void sub2() {
	double s[3];
	for (int i = 0; i < 3; i++)
		s[i] = 0.11 * i;
	reverse(s, s + 3);
}
