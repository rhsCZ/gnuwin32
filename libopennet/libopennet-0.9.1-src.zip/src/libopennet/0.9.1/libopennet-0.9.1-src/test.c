#include "opennet.h"
#include "compat.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int main(int argc, char **argv) {
	NETFILE *fp;
	char buf[1024];
	int x;

	fp = fopen_net(argv[1], "r");

	while (1) {
		fgets_net(buf, sizeof(buf), fp);
		if (feof_net(fp)) {
			break;
		}

		printf("-- %s", buf);
	}

	return(0);
}
