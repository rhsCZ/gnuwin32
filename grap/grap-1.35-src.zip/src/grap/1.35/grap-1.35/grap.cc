/* A Bison parser, made by GNU Bison 1.875b.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     START = 259,
     END = 260,
     IDENT = 261,
     COPY = 262,
     SEP = 263,
     STRING = 264,
     COORD_NAME = 265,
     UNDEFINE = 266,
     SOLID = 267,
     INVIS = 268,
     DOTTED = 269,
     DASHED = 270,
     DRAW = 271,
     LPAREN = 272,
     RPAREN = 273,
     FUNC0 = 274,
     FUNC1 = 275,
     FUNC2 = 276,
     COMMA = 277,
     LINE = 278,
     PLOT = 279,
     FROM = 280,
     TO = 281,
     AT = 282,
     NEXT = 283,
     FRAME = 284,
     LEFT = 285,
     RIGHT = 286,
     TOP = 287,
     BOTTOM = 288,
     UP = 289,
     DOWN = 290,
     HT = 291,
     WID = 292,
     GRAP_IN = 293,
     GRAP_OUT = 294,
     NONE = 295,
     TICKS = 296,
     OFF = 297,
     BY = 298,
     GRID = 299,
     LJUST = 300,
     RJUST = 301,
     ABOVE = 302,
     BELOW = 303,
     ALIGNED = 304,
     PLUS = 305,
     MINUS = 306,
     TIMES = 307,
     DIV = 308,
     CARAT = 309,
     EQUALS = 310,
     GRAP_SIZE = 311,
     GRAP_UNALIGNED = 312,
     LABEL = 313,
     RADIUS = 314,
     CIRCLE = 315,
     ARROW = 316,
     XDIM = 317,
     YDIM = 318,
     LOG_X = 319,
     LOG_Y = 320,
     LOG_LOG = 321,
     GRAP_COORD = 322,
     GRAP_TEXT = 323,
     DEFINE = 324,
     IF = 325,
     THEN = 326,
     ELSE = 327,
     EQ = 328,
     NEQ = 329,
     LT = 330,
     GT = 331,
     LTE = 332,
     GTE = 333,
     NOT = 334,
     OR = 335,
     AND = 336,
     FOR = 337,
     DO = 338,
     MACRO = 339,
     COPYTEXT = 340,
     THRU = 341,
     GRAPH = 342,
     REST = 343,
     PRINT = 344,
     PIC = 345,
     TROFF = 346,
     UNTIL = 347,
     COLOR = 348,
     SPRINTF = 349,
     SH = 350,
     BAR = 351,
     FILL = 352,
     FILLCOLOR = 353,
     BASE = 354,
     ON = 355,
     LHS = 356,
     VFUNC1 = 357,
     CLIPPED = 358,
     UNCLIPPED = 359,
     THICKNESS = 360
   };
#endif
#define NUMBER 258
#define START 259
#define END 260
#define IDENT 261
#define COPY 262
#define SEP 263
#define STRING 264
#define COORD_NAME 265
#define UNDEFINE 266
#define SOLID 267
#define INVIS 268
#define DOTTED 269
#define DASHED 270
#define DRAW 271
#define LPAREN 272
#define RPAREN 273
#define FUNC0 274
#define FUNC1 275
#define FUNC2 276
#define COMMA 277
#define LINE 278
#define PLOT 279
#define FROM 280
#define TO 281
#define AT 282
#define NEXT 283
#define FRAME 284
#define LEFT 285
#define RIGHT 286
#define TOP 287
#define BOTTOM 288
#define UP 289
#define DOWN 290
#define HT 291
#define WID 292
#define GRAP_IN 293
#define GRAP_OUT 294
#define NONE 295
#define TICKS 296
#define OFF 297
#define BY 298
#define GRID 299
#define LJUST 300
#define RJUST 301
#define ABOVE 302
#define BELOW 303
#define ALIGNED 304
#define PLUS 305
#define MINUS 306
#define TIMES 307
#define DIV 308
#define CARAT 309
#define EQUALS 310
#define GRAP_SIZE 311
#define GRAP_UNALIGNED 312
#define LABEL 313
#define RADIUS 314
#define CIRCLE 315
#define ARROW 316
#define XDIM 317
#define YDIM 318
#define LOG_X 319
#define LOG_Y 320
#define LOG_LOG 321
#define GRAP_COORD 322
#define GRAP_TEXT 323
#define DEFINE 324
#define IF 325
#define THEN 326
#define ELSE 327
#define EQ 328
#define NEQ 329
#define LT 330
#define GT 331
#define LTE 332
#define GTE 333
#define NOT 334
#define OR 335
#define AND 336
#define FOR 337
#define DO 338
#define MACRO 339
#define COPYTEXT 340
#define THRU 341
#define GRAPH 342
#define REST 343
#define PRINT 344
#define PIC 345
#define TROFF 346
#define UNTIL 347
#define COLOR 348
#define SPRINTF 349
#define SH 350
#define BAR 351
#define FILL 352
#define FILLCOLOR 353
#define BASE 354
#define ON 355
#define LHS 356
#define VFUNC1 357
#define CLIPPED 358
#define UNCLIPPED 359
#define THICKNESS 360




/* Copy the first part of user declarations.  */
#line 2 "../grap-1.35-src/grap.y"

/* This code is (c) 1998-2001 Ted Faber (faber@lunabase.org) see the
   COPYRIGHT file for the full copyright and limitations of
   liabilities. */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <stdio.h>
#include <iostream>
#include <stack>
#include <math.h>
#ifdef STDC_HEADERS
#include <limits.h>
#else
// Best guess, really - limits should exist
#ifndef LONG_MAX
#define LONG_MAX        0x7fffffffL
#endif
#endif
#if defined(STDC_HEADERS) | defined(HAVE_STDLIB_H)
#include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "grap.h"
#include "grap_data.h"
#include "grap_draw.h"

doubleDictionary vars;
graph *the_graph =0;
lexStack lexstack;
macroDictionary macros;
stringSequence path;
bool first_line;
bool unaligned_default = false;	// Should strings be unaligned by default 
bool clip_default = true;	// Should strings be clipped by default 
extern bool do_sprintf;		// true if it's acceptable to parse sprintf

line* defline;
coord *defcoord;
string *graph_name;
string *graph_pos;
string *ps_param;
// number of lines in a number list (used in grap_parse.cc) 
int nlines;

// bison wants these defined....
int yyerror(char*);
int yylex();
void init_dict(); 

// defined in grap_lex.l
extern bool include_file(string *, bool =false, bool=true);
extern void lex_no_macro_expansion(); 
extern void lex_macro_expansion_ok(); 
extern void lex_begin_macro_text(); 
extern void lex_begin_rest_of_line();
extern void lex_no_coord();
extern void lex_coord_ok();
extern void lex_begin_copy( string*s=0);
extern int include_string(string *,struct for_descriptor *f=0,
			  grap_input i=GMACRO);
extern void lex_hunt_macro();
extern int yyparse(void);	// To shut yacc (vs. bison) up.
void draw_graph();
void init_graph();

// Parsing utilities in grap_parse.cc.  Locating them there reduces
// compilation time (this file was getting very large) and eliminates
// some code redundancy.
extern graph *initial_graph(); 
extern linedesc* combine_linedesc(linedesc *, linedesc*);
extern axis combine_logs(axis, axis);
extern void draw_statement(string *, linedesc *, DisplayString *);
extern void num_list(doublelist *);
extern double assignment_statement(string *, double);
extern stringlist *combine_strings(stringlist *, string *, strmod &);
extern void plot_statement(double, DisplayString *, point *); 
extern void next_statement(string *, point *, linedesc *);
extern ticklist *ticklist_elem(double, DisplayString *, ticklist *);
extern ticklist *tick_for(coord *, double, double, bydesc, DisplayString *);
extern void ticks_statement(sides, double, shiftlist *, ticklist *);
extern void grid_statement(sides, int, linedesc *, shiftlist *, ticklist *);
extern void line_statement(int, linedesc *, point *, point *, linedesc *);
extern axisdesc axis_description(axis, double, double );
extern void coord_statement(string *, axisdesc&, axisdesc&, axis);
extern void coord_statement(coord *, axisdesc&, axisdesc&, axis);
extern void for_statement(string *, double, double, bydesc, string *);
extern void process_frame(linedesc *, frame *, frame *);
extern void define_macro(string *, string*);
extern void bar_statement(coord *, sides, double, double, double,
		   double, linedesc *); 
void init_dict(); 

// adapters to return complex (complex-ish) functions
void grap_srandom(double x) { srandom(static_cast<unsigned int>(x)); }
double grap_random() {
    return static_cast<double>(random())/(static_cast<double>(LONG_MAX)+1e-6);
}
double grap_getpid() { return static_cast<double>(getpid());} 
double pow10(double x) { return pow(10,x); }
double toint(double x) { return static_cast<double>(int(x)); }
double grap_min(double a, double b) { return (a<b) ? a : b; } 
double grap_max(double a, double b) { return (a>b) ? a : b; } 
 
typedef void (*vfunction1)(double);
typedef double (*function0)();
typedef double (*function1)(double);
typedef double (*function2)(double, double);
// jump tables for dispatching internal functions
vfunction1 jtvf1[NVF1] = { grap_srandom };
function0 jtf0[NF0] = { grap_random, grap_getpid };
function1 jtf1[NF1] = { log10, pow10, toint, sin, cos, sqrt, exp, log };
function2 jtf2[NF2] = { atan2, grap_min, grap_max};


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 129 "../grap-1.35-src/grap.y"
typedef union YYSTYPE {
    int val;
    double num;
    string *String;
    DisplayString *ds;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    doublevec *double_vec;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 430 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 442 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   678

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  106
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  92
/* YYNRULES -- Number of rules. */
#define YYNRULES  225
/* YYNRULES -- Number of states. */
#define YYNSTATES  428

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   360

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     4,     7,     8,    13,    14,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
      41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    72,    74,    75,    77,
      78,    81,    83,    90,    92,    96,    97,    99,   100,   102,
     103,   106,   108,   110,   113,   116,   119,   122,   125,   128,
     130,   133,   134,   141,   144,   146,   149,   151,   154,   158,
     162,   166,   170,   174,   178,   181,   185,   190,   197,   201,
     203,   205,   207,   211,   213,   217,   221,   225,   229,   233,
     237,   241,   245,   248,   252,   256,   259,   261,   264,   268,
     274,   277,   278,   282,   287,   290,   293,   296,   299,   302,
     305,   308,   311,   315,   318,   322,   327,   334,   341,   344,
     347,   349,   352,   354,   356,   358,   360,   362,   365,   369,
     372,   376,   380,   384,   389,   394,   399,   404,   410,   416,
     419,   422,   425,   428,   430,   432,   433,   436,   439,   444,
     445,   448,   452,   456,   460,   464,   472,   474,   476,   479,
     480,   487,   491,   496,   502,   503,   506,   514,   522,   528,
     529,   532,   539,   541,   543,   552,   553,   558,   559,   564,
     567,   568,   570,   572,   574,   581,   582,   585,   587,   591,
     592,   599,   600,   601,   611,   612,   613,   620,   621,   626,
     627,   632,   633,   634,   638,   639,   647,   648,   660,   661,
     662,   669,   673,   675,   677,   678,   683,   686,   688,   690,
     693,   694,   697,   698,   705,   716
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     107,     0,    -1,    -1,   107,   108,    -1,    -1,     4,   109,
     110,     5,    -1,    -1,   110,   111,    -1,   132,    -1,   125,
      -1,   144,    -1,   123,    -1,   138,    -1,   137,    -1,   154,
      -1,   156,    -1,   157,    -1,   159,    -1,   196,    -1,   161,
      -1,   166,    -1,   168,    -1,   172,    -1,   175,    -1,   181,
      -1,   183,    -1,   185,    -1,   188,    -1,   177,    -1,   190,
      -1,   192,    -1,   197,    -1,     8,    -1,    25,    -1,    55,
      -1,    -1,    10,    -1,    -1,     6,    -1,    -1,   116,   135,
      -1,     9,    -1,    94,    17,     9,    22,   117,    18,    -1,
     128,    -1,   117,    22,   128,    -1,    -1,   128,    -1,    -1,
     122,    -1,    -1,   145,   120,    -1,    13,    -1,    12,    -1,
      14,   118,    -1,    15,   118,    -1,    93,   116,    -1,    97,
     118,    -1,    98,   116,    -1,   105,   118,    -1,   121,    -1,
     122,   121,    -1,    -1,    16,   124,   114,   119,   115,     8,
      -1,   127,     8,    -1,     3,    -1,    51,     3,    -1,   126,
      -1,   127,   126,    -1,   127,    22,   126,    -1,   128,    50,
     128,    -1,   128,    51,   128,    -1,   128,    52,   128,    -1,
     128,    53,   128,    -1,   128,    54,   128,    -1,    51,   128,
      -1,    19,    17,    18,    -1,    20,    17,   128,    18,    -1,
      21,    17,   128,    22,   128,    18,    -1,    17,   128,    18,
      -1,     6,    -1,     3,    -1,   128,    -1,    17,   130,    18,
      -1,   130,    -1,   129,    73,   129,    -1,   129,    74,   129,
      -1,   129,    75,   129,    -1,   129,    76,   129,    -1,   129,
      77,   129,    -1,   129,    78,   129,    -1,   129,    81,   129,
      -1,   129,    80,   129,    -1,    79,   129,    -1,   116,    73,
     116,    -1,   116,    74,   116,    -1,   128,     8,    -1,   132,
      -1,   101,   131,    -1,   128,    22,   128,    -1,    17,   128,
      22,   128,    18,    -1,   113,   133,    -1,    -1,   135,    56,
     128,    -1,   135,    56,    50,   128,    -1,   135,    45,    -1,
     135,    46,    -1,   135,    47,    -1,   135,    48,    -1,   135,
      49,    -1,   135,    57,    -1,   135,   103,    -1,   135,   104,
      -1,   135,    93,     9,    -1,   116,   135,    -1,   136,   116,
     135,    -1,   136,    27,   134,     8,    -1,    24,   128,   115,
      27,   134,     8,    -1,    28,   114,    27,   134,   119,     8,
      -1,    36,   128,    -1,    37,   128,    -1,   139,    -1,   140,
     139,    -1,    32,    -1,    33,    -1,    30,    -1,    31,    -1,
     140,    -1,   141,   122,    -1,   143,   141,   122,    -1,    29,
       8,    -1,    29,   122,     8,    -1,    29,   142,     8,    -1,
      29,   143,     8,    -1,    29,   142,   143,     8,    -1,    29,
     122,   143,     8,    -1,    29,   122,   142,     8,    -1,    29,
     142,   122,     8,    -1,    29,   122,   142,   143,     8,    -1,
      29,   142,   122,   143,     8,    -1,    34,   128,    -1,    35,
     128,    -1,    30,   128,    -1,    31,   128,    -1,    38,    -1,
      39,    -1,    -1,   146,   118,    -1,   128,   115,    -1,   148,
      22,   128,   115,    -1,    -1,    43,   128,    -1,    43,    50,
     128,    -1,    43,    52,   128,    -1,    43,    53,   128,    -1,
      27,   113,   148,    -1,   112,   113,   128,    26,   128,   149,
     115,    -1,   150,    -1,   151,    -1,   100,   114,    -1,    -1,
      41,   141,   147,   120,   152,     8,    -1,    41,    42,     8,
      -1,    41,   141,    42,     8,    -1,    41,   141,   147,   153,
       8,    -1,    -1,    41,    42,    -1,    44,   141,   155,   119,
     120,   152,     8,    -1,    44,   141,   155,   119,   120,   153,
       8,    -1,    58,   141,   136,   120,     8,    -1,    -1,    59,
     128,    -1,    60,    27,   134,   158,   119,     8,    -1,    23,
      -1,    61,    -1,   160,   119,    25,   134,    26,   134,   119,
       8,    -1,    -1,    62,   128,    22,   128,    -1,    -1,    63,
     128,    22,   128,    -1,   164,   165,    -1,    -1,    64,    -1,
      65,    -1,    66,    -1,    67,   114,   162,   163,   164,     8,
      -1,    -1,    92,   116,    -1,   116,    -1,     7,   116,     8,
      -1,    -1,     7,    92,   116,     8,   169,    85,    -1,    -1,
      -1,     7,   167,    86,   170,    84,   167,     8,   171,    85,
      -1,    -1,    -1,    69,   173,     6,   174,    68,     8,    -1,
      -1,    11,   176,     6,     8,    -1,    -1,    95,   178,    68,
       8,    -1,    -1,    -1,    72,   180,    68,    -1,    -1,    70,
     129,    71,   182,    68,   179,     8,    -1,    -1,    82,     6,
     112,   128,    26,   128,   149,    83,   184,    68,     8,    -1,
      -1,    -1,    87,   186,     6,   187,    88,     8,    -1,    89,
     189,     8,    -1,   116,    -1,   128,    -1,    -1,    90,   191,
      88,     8,    -1,    91,     8,    -1,    31,    -1,    34,    -1,
      99,   128,    -1,    -1,    37,   128,    -1,    -1,    96,   134,
      22,   134,   119,     8,    -1,    96,   113,   193,   128,    36,
     128,   195,   194,   119,     8,    -1,   102,    17,   128,    18,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   186,   186,   187,   191,   191,   205,   206,   210,   212,
     214,   220,   222,   224,   226,   228,   230,   232,   234,   236,
     238,   240,   242,   244,   246,   248,   250,   252,   254,   256,
     258,   260,   262,   266,   267,   270,   271,   276,   277,   282,
     283,   291,   293,   361,   366,   374,   375,   380,   381,   386,
     387,   396,   398,   400,   402,   404,   406,   408,   410,   415,
     417,   422,   422,   427,   432,   435,   440,   445,   450,   458,
     460,   462,   464,   466,   468,   470,   472,   474,   476,   478,
     491,   496,   498,   500,   505,   507,   509,   511,   513,   515,
     517,   519,   521,   523,   525,   530,   531,   535,   540,   542,
     546,   551,   558,   560,   562,   564,   566,   568,   570,   572,
     574,   576,   578,   583,   593,   598,   602,   607,   612,   618,
     627,   629,   640,   642,   644,   646,   651,   669,   674,   685,
     687,   689,   691,   693,   695,   697,   699,   701,   703,   708,
     710,   712,   714,   719,   721,   726,   727,   735,   737,   742,
     743,   749,   751,   753,   758,   767,   771,   773,   778,   794,
     800,   802,   807,   809,   817,   818,   823,   827,   838,   857,
     858,   863,   871,   873,   878,   883,   884,   888,   889,   894,
     897,   901,   903,   905,   911,   919,   920,   927,   942,   948,
     947,   969,   970,   969,  1052,  1053,  1052,  1058,  1058,  1066,
    1066,  1084,  1085,  1085,  1094,  1094,  1107,  1106,  1112,  1112,
    1112,  1139,  1143,  1148,  1155,  1155,  1159,  1164,  1166,  1170,
    1173,  1177,  1180,  1184,  1191,  1197
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NUMBER", "START", "END", "IDENT", "COPY", 
  "SEP", "STRING", "COORD_NAME", "UNDEFINE", "SOLID", "INVIS", "DOTTED", 
  "DASHED", "DRAW", "LPAREN", "RPAREN", "FUNC0", "FUNC1", "FUNC2", 
  "COMMA", "LINE", "PLOT", "FROM", "TO", "AT", "NEXT", "FRAME", "LEFT", 
  "RIGHT", "TOP", "BOTTOM", "UP", "DOWN", "HT", "WID", "GRAP_IN", 
  "GRAP_OUT", "NONE", "TICKS", "OFF", "BY", "GRID", "LJUST", "RJUST", 
  "ABOVE", "BELOW", "ALIGNED", "PLUS", "MINUS", "TIMES", "DIV", "CARAT", 
  "EQUALS", "GRAP_SIZE", "GRAP_UNALIGNED", "LABEL", "RADIUS", "CIRCLE", 
  "ARROW", "XDIM", "YDIM", "LOG_X", "LOG_Y", "LOG_LOG", "GRAP_COORD", 
  "GRAP_TEXT", "DEFINE", "IF", "THEN", "ELSE", "EQ", "NEQ", "LT", "GT", 
  "LTE", "GTE", "NOT", "OR", "AND", "FOR", "DO", "MACRO", "COPYTEXT", 
  "THRU", "GRAPH", "REST", "PRINT", "PIC", "TROFF", "UNTIL", "COLOR", 
  "SPRINTF", "SH", "BAR", "FILL", "FILLCOLOR", "BASE", "ON", "LHS", 
  "VFUNC1", "CLIPPED", "UNCLIPPED", "THICKNESS", "$accept", "graphs", 
  "graph", "@1", "prog", "statement", "from", "opt_coordname", 
  "opt_ident", "opt_display_string", "string", "expr_list", "opt_expr", 
  "opt_linedesc", "opt_shift", "linedesc_elem", "linedesc", 
  "draw_statement", "@2", "num_list", "num_line_elem", "num_line", "expr", 
  "lexpr", "pure_lexpr", "right_hand_side", "assignment_statement", 
  "coord_pair", "point", "strmod", "strlist", "plot_statement", 
  "next_statement", "size_elem", "size", "side", "final_size", "sides", 
  "frame_statement", "shift", "tickdir", "direction", "ticklist", 
  "by_clause", "tickat", "tickfor", "tickdesc", "autotick", 
  "ticks_statement", "opt_tick_off", "grid_statement", "label_statement", 
  "radius_spec", "circle_statement", "line_token", "line_statement", 
  "x_axis_desc", "y_axis_desc", "log_list", "log_desc", "coord_statement", 
  "until_clause", "copy_statement", "@3", "@4", "@5", "define_statement", 
  "@6", "@7", "undefine_statement", "@8", "sh_statement", "@9", 
  "else_clause", "@10", "if_statement", "@11", "for_statement", "@12", 
  "graph_statement", "@13", "@14", "print_statement", "print_param", 
  "pic_statement", "@15", "troff_line", "bar_dir", "bar_base", "opt_wid", 
  "bar_statement", "void_function", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   106,   107,   107,   109,   108,   110,   110,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   112,   112,   113,   113,   114,   114,   115,
     115,   116,   116,   117,   117,   118,   118,   119,   119,   120,
     120,   121,   121,   121,   121,   121,   121,   121,   121,   122,
     122,   124,   123,   125,   126,   126,   127,   127,   127,   128,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   129,   129,   129,   130,   130,   130,   130,   130,   130,
     130,   130,   130,   130,   130,   131,   131,   132,   133,   133,
     134,   135,   135,   135,   135,   135,   135,   135,   135,   135,
     135,   135,   135,   136,   136,   137,   137,   138,   139,   139,
     140,   140,   141,   141,   141,   141,   142,   143,   143,   144,
     144,   144,   144,   144,   144,   144,   144,   144,   144,   145,
     145,   145,   145,   146,   146,   147,   147,   148,   148,   149,
     149,   149,   149,   149,   150,   151,   152,   152,   153,   153,
     154,   154,   154,   154,   155,   155,   156,   156,   157,   158,
     158,   159,   160,   160,   161,   162,   162,   163,   163,   164,
     164,   165,   165,   165,   166,   167,   167,   167,   168,   169,
     168,   170,   171,   168,   173,   174,   172,   176,   175,   178,
     177,   179,   180,   179,   182,   181,   184,   183,   186,   187,
     185,   188,   189,   189,   191,   190,   192,   193,   193,   194,
     194,   195,   195,   196,   196,   197
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     0,     2,     0,     4,     0,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     1,     0,     1,     0,
       2,     1,     6,     1,     3,     0,     1,     0,     1,     0,
       2,     1,     1,     2,     2,     2,     2,     2,     2,     1,
       2,     0,     6,     2,     1,     2,     1,     2,     3,     3,
       3,     3,     3,     3,     2,     3,     4,     6,     3,     1,
       1,     1,     3,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     2,     3,     3,     2,     1,     2,     3,     5,
       2,     0,     3,     4,     2,     2,     2,     2,     2,     2,
       2,     2,     3,     2,     3,     4,     6,     6,     2,     2,
       1,     2,     1,     1,     1,     1,     1,     2,     3,     2,
       3,     3,     3,     4,     4,     4,     4,     5,     5,     2,
       2,     2,     2,     1,     1,     0,     2,     2,     4,     0,
       2,     3,     3,     3,     3,     7,     1,     1,     2,     0,
       6,     3,     4,     5,     0,     2,     7,     7,     5,     0,
       2,     6,     1,     1,     8,     0,     4,     0,     4,     2,
       0,     1,     1,     1,     6,     0,     2,     1,     3,     0,
       6,     0,     0,     9,     0,     0,     6,     0,     4,     0,
       4,     0,     0,     3,     0,     7,     0,    11,     0,     0,
       6,     3,     1,     1,     0,     4,     2,     1,     1,     2,
       0,     2,     0,     6,    10,     4
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       2,     0,     1,     4,     3,     6,     0,    64,     5,   185,
      32,    41,   197,    61,   172,     0,    37,     0,     0,     0,
       0,     0,     0,   173,    37,   194,     0,     0,   208,     0,
     214,     0,     0,   199,    35,     0,     0,     7,   101,    11,
       9,    66,     0,     8,     0,    13,    12,    10,    14,    15,
      16,    17,    47,    19,    20,    21,    22,    23,    28,    24,
      25,    26,    27,    29,    30,    18,    31,     0,   187,     0,
       0,    37,    80,    79,     0,     0,     0,     0,     0,    39,
      38,     0,   129,    52,    51,    45,    45,   124,   125,   122,
     123,     0,     0,     0,    45,     0,    45,    59,     0,   120,
     126,     0,     0,     0,     0,   145,   164,    65,     0,    35,
     175,     0,     0,     0,     0,    81,     0,    83,     0,     0,
     212,   213,     0,     0,   216,     0,     0,    36,     0,     0,
       0,    97,    96,     0,   113,    63,     0,    67,    35,   101,
       0,    48,   186,   188,   191,     0,    47,     0,     0,     0,
       0,    74,     0,     0,     0,     0,     0,     0,   101,    35,
      53,    46,    54,   118,   119,    55,    56,    57,    58,   130,
      60,     0,     0,   121,   127,   131,     0,     0,   132,     0,
     161,   143,   144,     0,    45,    49,     0,    47,    49,     0,
     169,     0,   177,   195,    81,     0,    83,    92,     0,     0,
     204,     0,     0,     0,     0,     0,     0,     0,     0,    33,
      34,     0,   209,   211,     0,     0,     0,     0,   217,   218,
       0,   100,     0,    35,    95,     0,   104,   105,   106,   107,
     108,     0,   109,     0,   110,   111,    68,     0,   114,    35,
     189,     0,   198,    39,    78,    75,     0,     0,    69,    70,
      71,    72,    73,    35,    40,    47,   135,     0,   134,   136,
       0,   133,   128,   162,   146,     0,     0,     0,     0,    37,
       0,    49,     0,   165,    49,     0,     0,    47,     0,     0,
     180,     0,    82,    93,    94,     0,    84,    85,    86,    87,
      88,    89,    91,    90,     0,     0,   215,     0,   200,     0,
       0,     0,    47,   225,     0,   102,   112,   115,     0,     0,
     185,     0,    76,     0,     0,     0,   137,   138,   141,   142,
     139,   140,   158,    35,    35,   156,   157,     0,    50,   163,
     159,   168,   170,     0,     0,     0,     0,     0,   201,     0,
       0,     0,    43,     0,    98,     0,     0,   103,    35,   190,
       0,   187,     0,    62,     0,   116,   117,     0,     0,   160,
       0,     0,   171,   176,     0,   184,   181,   182,   183,   179,
     196,   202,     0,   149,   210,    42,     0,     0,   222,   223,
      47,   186,   192,    77,    39,   154,     0,   166,   167,   178,
       0,   205,     0,     0,    44,    99,     0,   220,     0,     0,
     147,     0,     0,   203,     0,     0,     0,   150,   206,   221,
       0,    47,   174,   193,    39,   149,   151,   152,   153,     0,
     219,     0,   148,    39,     0,   224,   155,   207
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,     4,     5,     6,    37,   324,   189,    81,   157,
     114,   341,   160,   140,   270,    97,   141,    39,    71,    40,
      41,    42,   115,   116,   117,   131,    43,   221,   129,   134,
      44,    45,    46,    99,   100,   101,   102,   103,    47,   271,
     184,   185,   385,   393,   325,   326,   327,   272,    48,   187,
      49,    50,   277,    51,    52,    53,   192,   280,   336,   369,
      54,    69,    55,   309,   241,   399,    56,   111,   281,    57,
      70,    58,   126,   372,   390,    59,   285,    60,   419,    61,
     119,   295,    62,   122,    63,   123,    64,   222,   411,   397,
      65,    66
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -236
static const short yypact[] =
{
    -236,    82,  -236,  -236,  -236,  -236,   218,  -236,  -236,    24,
    -236,  -236,  -236,  -236,  -236,   193,    20,   325,   285,   171,
      32,   171,    15,  -236,    20,  -236,   432,    40,  -236,   188,
    -236,     7,    45,  -236,    62,     8,    67,  -236,  -236,  -236,
    -236,  -236,   144,  -236,    41,  -236,  -236,  -236,  -236,  -236,
    -236,  -236,    64,  -236,  -236,  -236,  -236,  -236,  -236,  -236,
    -236,  -236,  -236,  -236,  -236,  -236,  -236,    11,    91,    35,
     128,    20,  -236,  -236,   193,   120,   129,   139,   193,    42,
    -236,   145,  -236,  -236,  -236,   193,   193,  -236,  -236,  -236,
    -236,   193,   193,    11,   193,    11,   193,  -236,   374,  -236,
      12,    64,   401,   577,   163,   125,   133,  -236,    11,    62,
     115,   178,   432,   432,    -3,   624,   592,  -236,     9,   216,
    -236,   624,   222,   136,  -236,   223,   167,  -236,   512,   209,
     298,  -236,  -236,   193,   409,  -236,    18,  -236,    62,  -236,
     215,    64,   243,  -236,  -236,   244,    64,   220,   235,   193,
     193,  -236,   193,   193,   193,   193,   193,   231,  -236,    62,
    -236,   624,  -236,   624,   624,  -236,  -236,  -236,  -236,  -236,
    -236,   581,   590,  -236,    64,  -236,   412,   607,  -236,    64,
    -236,  -236,  -236,   252,   193,    23,   219,    64,    10,   278,
     204,   193,   201,  -236,   220,   506,   248,  -236,    11,    11,
    -236,   432,   432,   432,   432,   432,   432,   432,   432,  -236,
    -236,   193,  -236,  -236,   267,   255,   272,   193,  -236,  -236,
     503,  -236,   193,    62,  -236,   317,  -236,  -236,  -236,  -236,
    -236,   521,  -236,   274,  -236,  -236,  -236,   284,   409,    62,
    -236,   210,  -236,    11,  -236,  -236,   323,   508,    54,    54,
     242,   242,  -236,    62,   409,    64,  -236,   611,  -236,  -236,
     616,  -236,    64,  -236,  -236,   193,   193,   193,   193,    20,
     126,   155,   293,  -236,   155,   295,   193,    64,   514,   193,
    -236,   253,  -236,  -236,  -236,   254,  -236,  -236,  -236,  -236,
    -236,  -236,   578,   578,   543,   236,  -236,   193,  -236,   165,
     193,   580,    64,  -236,   193,   624,  -236,  -236,   299,   225,
      56,   303,  -236,   193,   318,   322,  -236,  -236,   624,   624,
     624,   624,  -236,    62,    62,  -236,  -236,   328,  -236,  -236,
     143,  -236,   624,   334,   193,   523,    48,   335,   259,   193,
     337,    97,   624,   193,   624,   193,   346,   624,    62,  -236,
      11,  -236,   351,  -236,   410,  -236,  -236,   193,   193,  -236,
     352,   355,  -236,   624,   193,  -236,  -236,  -236,  -236,  -236,
    -236,  -236,   356,   575,  -236,  -236,   193,   498,   608,  -236,
      64,  -236,  -236,  -236,    42,   344,   552,  -236,  -236,   624,
     304,  -236,   470,   296,   624,  -236,   193,   281,   375,   307,
    -236,   193,   193,  -236,   193,   193,   193,   624,  -236,   624,
     193,    64,  -236,  -236,    42,   575,   624,   624,   624,   316,
     624,   388,  -236,    11,   389,  -236,  -236,  -236
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -236,  -236,  -236,  -236,  -236,  -236,   280,   -33,   -19,  -235,
      -6,  -236,   -64,  -144,  -171,   -86,    -4,  -236,  -236,  -236,
     -26,  -236,   -11,   -76,   288,  -236,   366,  -236,   -99,   -92,
     294,  -236,  -236,   312,  -236,   -12,   305,    57,  -236,  -236,
    -236,  -236,  -236,     4,  -236,  -236,    99,   106,  -236,  -236,
    -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,
    -236,   111,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,
    -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,
    -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,  -236,
    -236,  -236
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -160
static const short yytable[] =
{
      38,   128,   243,    68,    79,   110,   105,   106,   311,   108,
     190,    72,   170,    98,    73,   124,   137,   275,   121,    11,
      11,     7,   162,   120,   130,    74,    80,    75,    76,    77,
     166,  -159,   168,    11,   209,   107,   195,   197,   139,   237,
     265,   266,   109,   274,   267,   268,   118,   238,    91,    92,
      11,    11,   146,   265,   266,   170,   365,   267,   268,    78,
     255,   142,   125,   147,   210,    11,   254,   151,   138,    20,
     198,   199,   127,   158,   161,   161,    83,    84,    85,    86,
     163,   164,     2,   161,   133,   161,     3,   165,   170,   167,
     170,   179,   152,   153,   154,   155,   156,   174,   176,   143,
     328,   194,    38,   330,    32,    32,   154,   155,   156,    35,
     236,   315,   366,   367,   368,   375,    67,   220,    32,   376,
     264,   144,   225,   269,   302,   286,   287,   288,   289,   290,
     291,   292,   293,   333,   145,    32,    32,   148,   246,   247,
     308,   248,   249,   250,   251,   252,   149,     7,   350,   400,
      32,   209,   135,   323,   314,   172,   150,    93,   346,   177,
     179,    94,    95,   181,   182,   179,   136,   183,   209,    96,
     323,   180,   159,   161,   186,   262,   170,   191,   220,   422,
     278,   210,   139,   244,   193,   265,   266,   343,   426,   267,
     268,    72,   283,   284,    73,    20,    72,    11,   210,    73,
     294,    87,    88,    89,    90,    74,   299,    75,    76,    77,
      74,   301,    75,    76,    77,   152,   153,   154,   155,   156,
     305,     7,   212,     8,   214,     9,    10,    11,   257,    12,
     213,   223,   215,   260,    13,   216,   398,   158,   244,    78,
     239,    14,    15,   269,    78,   179,    16,    17,   179,   380,
     322,   240,   242,   245,   318,   319,   320,   321,   253,    18,
     263,   273,    19,   276,   279,   332,   282,   421,   335,    20,
     152,   153,   154,   155,   156,   296,    21,   297,    22,    23,
     298,    72,    32,   306,    73,    24,   342,    25,    26,   344,
     357,   358,   307,   347,   310,   217,   156,    75,    76,    77,
      27,   329,   354,   331,   351,    28,   224,    29,    30,    31,
     349,   353,    32,    33,    34,    87,    88,    89,    90,    35,
      36,   337,   338,   363,   340,   348,   355,   104,   373,    78,
     356,   371,   377,    82,   378,   303,   359,    83,    84,    85,
      86,   312,   362,   370,   381,   374,   384,   386,   152,   153,
     154,   155,   156,   389,   379,    87,    88,    89,    90,   382,
     387,    91,    92,   388,   391,   394,   401,   152,   153,   154,
     155,   156,   403,   152,   153,   154,   155,   156,   158,   408,
     410,   407,   169,   412,   424,   409,    83,    84,    85,    86,
     414,   415,   413,   416,   417,   418,   425,   427,   211,   420,
     196,   132,   188,   171,    87,    88,    89,    90,   158,   175,
      91,    92,   173,    83,    84,    85,    86,   158,    93,   423,
     259,   352,    94,    95,    83,    84,    85,    86,   383,   360,
      96,    87,    88,    89,    90,    72,   361,     0,    73,     0,
       0,    11,    87,    88,    89,    90,     0,     0,     0,   112,
       0,    75,    76,    77,   226,   227,   228,   229,   230,     0,
     152,   153,   154,   155,   156,   231,   232,    93,     0,     0,
       0,    94,    95,    72,     0,     0,    73,     0,     0,    96,
       0,     0,     0,    78,     0,     0,     0,    74,     0,    75,
      76,    77,     0,     0,    93,     0,     0,     0,    94,    95,
       0,     0,   233,     0,     0,    93,    96,     0,     0,    94,
      95,   113,   234,   235,     0,    72,   395,    96,    73,     0,
     404,    78,   405,   406,    72,   300,    32,    73,     0,   217,
     313,    75,    76,    77,     0,     0,   334,     0,    74,     0,
      75,    76,    77,   218,     0,   364,   219,     0,   152,   153,
     154,   155,   156,   152,   153,   154,   155,   156,   152,   153,
     154,   155,   156,    78,   152,   153,   154,   155,   156,   339,
       0,   304,    78,   152,   153,   154,   155,   156,   402,   201,
     202,   203,   204,   205,   206,   178,   207,   208,     0,   256,
       0,     0,     0,   152,   153,   154,   155,   156,   258,     0,
       0,     0,   152,   153,   154,   155,   156,    87,    88,    89,
      90,    87,    88,    89,    90,   261,   345,     0,   392,   316,
      87,    88,    89,    90,   317,   152,   153,   154,   155,   156,
     152,   153,   154,   155,   156,     0,     0,    87,    88,    89,
      90,    87,    88,    89,    90,   396,    87,    88,    89,    90,
       0,   201,   202,   203,   204,   205,   206,     0,   152,   153,
     154,   155,   156,   200,     0,   201,   202,   203,   204,   205,
     206,     0,   207,   208,   152,   153,   154,   155,   156
};

static const short yycheck[] =
{
       6,    34,   146,     9,    15,    24,    18,    19,   243,    21,
     109,     3,    98,    17,     6,     8,    42,   188,    29,     9,
       9,     3,    86,    29,    35,    17,     6,    19,    20,    21,
      94,     8,    96,     9,    25,     3,   112,   113,    44,   138,
      30,    31,    27,   187,    34,    35,     6,   139,    36,    37,
       9,     9,    71,    30,    31,   141,     8,    34,    35,    51,
     159,    67,    17,    74,    55,     9,   158,    78,    27,    51,
      73,    74,    10,    79,    85,    86,    12,    13,    14,    15,
      91,    92,     0,    94,    17,    96,     4,    93,   174,    95,
     176,   103,    50,    51,    52,    53,    54,   101,   102,     8,
     271,   112,   108,   274,    94,    94,    52,    53,    54,   101,
     136,   255,    64,    65,    66,    18,    92,   128,    94,    22,
     184,    86,   133,   100,   223,   201,   202,   203,   204,   205,
     206,   207,   208,   277,     6,    94,    94,    17,   149,   150,
     239,   152,   153,   154,   155,   156,    17,     3,    92,   384,
      94,    25,     8,    27,   253,    98,    17,    93,   302,   102,
     172,    97,    98,    38,    39,   177,    22,    42,    25,   105,
      27,     8,    27,   184,    41,   179,   262,    62,   189,   414,
     191,    55,   188,    18,     6,    30,    31,    22,   423,    34,
      35,     3,   198,   199,     6,    51,     3,     9,    55,     6,
     211,    30,    31,    32,    33,    17,   217,    19,    20,    21,
      17,   222,    19,    20,    21,    50,    51,    52,    53,    54,
     231,     3,     6,     5,    88,     7,     8,     9,   171,    11,
       8,    22,     9,   176,    16,    68,   380,   243,    18,    51,
      25,    23,    24,   100,    51,   257,    28,    29,   260,   348,
     269,     8,     8,    18,   265,   266,   267,   268,    27,    41,
       8,    42,    44,    59,    63,   276,    18,   411,   279,    51,
      50,    51,    52,    53,    54,     8,    58,    22,    60,    61,
       8,     3,    94,     9,     6,    67,   297,    69,    70,   300,
     323,   324,     8,   304,    84,    17,    54,    19,    20,    21,
      82,     8,   313,     8,   310,    87,     8,    89,    90,    91,
      85,     8,    94,    95,    96,    30,    31,    32,    33,   101,
     102,    68,    68,   334,    88,    26,     8,    42,   339,    51,
       8,    72,   343,     8,   345,    18,     8,    12,    13,    14,
      15,    18,     8,     8,   350,     8,   357,   358,    50,    51,
      52,    53,    54,   364,     8,    30,    31,    32,    33,     8,
       8,    36,    37,     8,     8,   376,    22,    50,    51,    52,
      53,    54,    68,    50,    51,    52,    53,    54,   384,    83,
      99,   392,     8,     8,    68,   396,    12,    13,    14,    15,
     401,   402,    85,   404,   405,   406,     8,     8,   118,   410,
     112,    35,   108,    98,    30,    31,    32,    33,   414,     8,
      36,    37,   100,    12,    13,    14,    15,   423,    93,   415,
       8,   310,    97,    98,    12,    13,    14,    15,    18,   330,
     105,    30,    31,    32,    33,     3,   330,    -1,     6,    -1,
      -1,     9,    30,    31,    32,    33,    -1,    -1,    -1,    17,
      -1,    19,    20,    21,    45,    46,    47,    48,    49,    -1,
      50,    51,    52,    53,    54,    56,    57,    93,    -1,    -1,
      -1,    97,    98,     3,    -1,    -1,     6,    -1,    -1,   105,
      -1,    -1,    -1,    51,    -1,    -1,    -1,    17,    -1,    19,
      20,    21,    -1,    -1,    93,    -1,    -1,    -1,    97,    98,
      -1,    -1,    93,    -1,    -1,    93,   105,    -1,    -1,    97,
      98,    79,   103,   104,    -1,     3,    18,   105,     6,    -1,
      50,    51,    52,    53,     3,    22,    94,     6,    -1,    17,
      22,    19,    20,    21,    -1,    -1,    22,    -1,    17,    -1,
      19,    20,    21,    31,    -1,    22,    34,    -1,    50,    51,
      52,    53,    54,    50,    51,    52,    53,    54,    50,    51,
      52,    53,    54,    51,    50,    51,    52,    53,    54,    26,
      -1,    50,    51,    50,    51,    52,    53,    54,    26,    73,
      74,    75,    76,    77,    78,     8,    80,    81,    -1,     8,
      -1,    -1,    -1,    50,    51,    52,    53,    54,     8,    -1,
      -1,    -1,    50,    51,    52,    53,    54,    30,    31,    32,
      33,    30,    31,    32,    33,     8,    36,    -1,    43,     8,
      30,    31,    32,    33,     8,    50,    51,    52,    53,    54,
      50,    51,    52,    53,    54,    -1,    -1,    30,    31,    32,
      33,    30,    31,    32,    33,    37,    30,    31,    32,    33,
      -1,    73,    74,    75,    76,    77,    78,    -1,    50,    51,
      52,    53,    54,    71,    -1,    73,    74,    75,    76,    77,
      78,    -1,    80,    81,    50,    51,    52,    53,    54
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   107,     0,     4,   108,   109,   110,     3,     5,     7,
       8,     9,    11,    16,    23,    24,    28,    29,    41,    44,
      51,    58,    60,    61,    67,    69,    70,    82,    87,    89,
      90,    91,    94,    95,    96,   101,   102,   111,   116,   123,
     125,   126,   127,   132,   136,   137,   138,   144,   154,   156,
     157,   159,   160,   161,   166,   168,   172,   175,   177,   181,
     183,   185,   188,   190,   192,   196,   197,    92,   116,   167,
     176,   124,     3,     6,    17,    19,    20,    21,    51,   128,
       6,   114,     8,    12,    13,    14,    15,    30,    31,    32,
      33,    36,    37,    93,    97,    98,   105,   121,   122,   139,
     140,   141,   142,   143,    42,   141,   141,     3,   141,    27,
     114,   173,    17,    79,   116,   128,   129,   130,     6,   186,
     116,   128,   189,   191,     8,    17,   178,    10,   113,   134,
     128,   131,   132,    17,   135,     8,    22,   126,    27,   116,
     119,   122,   116,     8,    86,     6,   114,   128,    17,    17,
      17,   128,    50,    51,    52,    53,    54,   115,   116,    27,
     118,   128,   118,   128,   128,   116,   118,   116,   118,     8,
     121,   142,   143,   139,   122,     8,   122,   143,     8,   141,
       8,    38,    39,    42,   146,   147,    41,   155,   136,   113,
     134,    62,   162,     6,   128,   129,   130,   129,    73,    74,
      71,    73,    74,    75,    76,    77,    78,    80,    81,    25,
      55,   112,     6,     8,    88,     9,    68,    17,    31,    34,
     128,   133,   193,    22,     8,   128,    45,    46,    47,    48,
      49,    56,    57,    93,   103,   104,   126,   134,   135,    25,
       8,   170,     8,   119,    18,    18,   128,   128,   128,   128,
     128,   128,   128,    27,   135,   134,     8,   143,     8,     8,
     143,     8,   122,     8,   118,    30,    31,    34,    35,   100,
     120,   145,   153,    42,   119,   120,    59,   158,   128,    63,
     163,   174,    18,   116,   116,   182,   129,   129,   129,   129,
     129,   129,   129,   129,   128,   187,     8,    22,     8,   128,
      22,   128,   134,    18,    50,   128,     9,     8,   134,   169,
      84,   115,    18,    22,   134,   119,     8,     8,   128,   128,
     128,   128,   114,    27,   112,   150,   151,   152,   120,     8,
     120,     8,   128,   119,    22,   128,   164,    68,    68,    26,
      88,   117,   128,    22,   128,    36,   119,   128,    26,    85,
      92,   116,   167,     8,   128,     8,     8,   113,   113,     8,
     152,   153,     8,   128,    22,     8,    64,    65,    66,   165,
       8,    72,   179,   128,     8,    18,    22,   128,   128,     8,
     134,   116,     8,    18,   128,   148,   128,     8,     8,   128,
     180,     8,    43,   149,   128,    18,    37,   195,   119,   171,
     115,    22,    26,    68,    50,    52,    53,   128,    83,   128,
      99,   194,     8,    85,   128,   128,   128,   128,   128,   184,
     128,   119,   115,   149,    68,     8,   115,     8
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 191 "../grap-1.35-src/grap.y"
    {
                if ( !the_graph)
		    the_graph = initial_graph();
		the_graph->init();
		init_dict();
		first_line = true;
		the_graph->begin_block(yyvsp[0].String);
	    }
    break;

  case 5:
#line 199 "../grap-1.35-src/grap.y"
    {
		the_graph->draw(0);
		the_graph->end_block();
	    }
    break;

  case 6:
#line 205 "../grap-1.35-src/grap.y"
    { }
    break;

  case 7:
#line 207 "../grap-1.35-src/grap.y"
    { }
    break;

  case 8:
#line 211 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 9:
#line 213 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 10:
#line 215 "../grap-1.35-src/grap.y"
    {
		first_line = false;
		the_graph->queue_frame();
		the_graph->is_visible(true);
	    }
    break;

  case 11:
#line 221 "../grap-1.35-src/grap.y"
    { first_line = false; }
    break;

  case 12:
#line 223 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 13:
#line 225 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 14:
#line 227 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 15:
#line 229 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 16:
#line 231 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 17:
#line 233 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 18:
#line 235 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 19:
#line 237 "../grap-1.35-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 20:
#line 239 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 21:
#line 241 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 22:
#line 243 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 23:
#line 245 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 24:
#line 247 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 25:
#line 249 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 26:
#line 251 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 27:
#line 253 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 28:
#line 255 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 29:
#line 257 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 30:
#line 259 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 31:
#line 261 "../grap-1.35-src/grap.y"
    { first_line = false;}
    break;

  case 35:
#line 270 "../grap-1.35-src/grap.y"
    { yyval.coordptr= defcoord; }
    break;

  case 36:
#line 272 "../grap-1.35-src/grap.y"
    { yyval.coordptr= yyvsp[0].coordptr;}
    break;

  case 37:
#line 276 "../grap-1.35-src/grap.y"
    { yyval.String = 0; }
    break;

  case 38:
#line 278 "../grap-1.35-src/grap.y"
    { yyval.String = yyvsp[0].String; }
    break;

  case 39:
#line 282 "../grap-1.35-src/grap.y"
    { yyval.ds = 0; }
    break;

  case 40:
#line 284 "../grap-1.35-src/grap.y"
    {
		yyval.ds = new DisplayString(*yyvsp[-1].String, yyvsp[0].stringmod.just, yyvsp[0].stringmod.size, yyvsp[0].stringmod.rel, 
		    yyvsp[0].stringmod.clip, yyvsp[0].stringmod.color);
	    }
    break;

  case 41:
#line 292 "../grap-1.35-src/grap.y"
    { yyval.String = yyvsp[0].String; }
    break;

  case 42:
#line 294 "../grap-1.35-src/grap.y"
    {
		 if ( do_sprintf ) {
		     const int len = yyvsp[-3].String->length() < 128 ? 256 : 2*yyvsp[-3].String->length();
		     char *buf = new char[len];

		     // I really dislike this, but I dislike trying to do it
		     // incrementally more.
		     switch (yyvsp[-1].double_vec->size()) {
			case 0:
			    snprintf(buf, len, yyvsp[-3].String->c_str());
			    break;
			case 1:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0]);
			    break;
			case 2:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1]);
			    break;
			case 3:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2]);
			    break;
			case 4:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3]);
			    break;
			case 5:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4]);
			    break;
			case 6:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5]);
			    break;
			case 7:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6]);
			    break;
			case 8:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7]);
			    break;
			case 9:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7], (*yyvsp[-1].double_vec)[8]);
			    break;
			default:
			    cerr << "more that 10 arguments to sprintf.  " << 
				"Ignoring more than 10." << endl;
			case 10:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7], (*yyvsp[-1].double_vec)[8], (*yyvsp[-1].double_vec)[9]);
			    break;
		     }
		     delete yyvsp[-1].double_vec; delete yyvsp[-3].String;

		     yyval.String = new string(buf);
		     delete[] buf;
		 }
		 else yyval.String = yyvsp[-3].String;
	     }
    break;

  case 43:
#line 362 "../grap-1.35-src/grap.y"
    {
		yyval.double_vec = new doublevec;
		yyval.double_vec->push_back(yyvsp[0].num);
	    }
    break;

  case 44:
#line 367 "../grap-1.35-src/grap.y"
    {
		yyval.double_vec = yyvsp[-2].double_vec;
		yyval.double_vec->push_back(yyvsp[0].num);
	    }
    break;

  case 45:
#line 374 "../grap-1.35-src/grap.y"
    { yyval.num = 0; }
    break;

  case 46:
#line 376 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 47:
#line 380 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc; yyval.lined = 0;}
    break;

  case 48:
#line 382 "../grap-1.35-src/grap.y"
    {  yyval.lined = yyvsp[0].lined;}
    break;

  case 49:
#line 386 "../grap-1.35-src/grap.y"
    { yyval.shift_list = new shiftlist;}
    break;

  case 50:
#line 388 "../grap-1.35-src/grap.y"
    {
		yyval.shift_list = yyvsp[0].shift_list;
		yyval.shift_list->push_back(yyvsp[-1].shift);
	    }
    break;

  case 51:
#line 397 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(invis); }
    break;

  case 52:
#line 399 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(solid); }
    break;

  case 53:
#line 401 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(dotted, yyvsp[0].num); }
    break;

  case 54:
#line 403 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(dashed, yyvsp[0].num); }
    break;

  case 55:
#line 405 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(def, 0, yyvsp[0].String); }
    break;

  case 56:
#line 407 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(def, 0, 0, yyvsp[0].num); }
    break;

  case 57:
#line 409 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(def, 0, 0, 0, yyvsp[0].String); }
    break;

  case 58:
#line 411 "../grap-1.35-src/grap.y"
    { yyval.lined = new linedesc(def, 0, 0, 0, 0, yyvsp[0].num); }
    break;

  case 59:
#line 416 "../grap-1.35-src/grap.y"
    { yyval.lined = yyvsp[0].lined; }
    break;

  case 60:
#line 418 "../grap-1.35-src/grap.y"
    { yyval.lined = combine_linedesc(yyvsp[-1].lined, yyvsp[0].lined); }
    break;

  case 61:
#line 422 "../grap-1.35-src/grap.y"
    { lex_no_coord(); }
    break;

  case 62:
#line 423 "../grap-1.35-src/grap.y"
    { draw_statement(yyvsp[-3].String, yyvsp[-2].lined, yyvsp[-1].ds); lex_coord_ok(); }
    break;

  case 63:
#line 428 "../grap-1.35-src/grap.y"
    { num_list(yyvsp[-1].double_list); }
    break;

  case 64:
#line 433 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 65:
#line 436 "../grap-1.35-src/grap.y"
    { yyval.num = -yyvsp[0].num; }
    break;

  case 66:
#line 441 "../grap-1.35-src/grap.y"
    {
		yyval.double_list = new doublelist;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 67:
#line 446 "../grap-1.35-src/grap.y"
    {
		yyval.double_list = yyvsp[-1].double_list;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 68:
#line 451 "../grap-1.35-src/grap.y"
    {
		yyval.double_list = yyvsp[-2].double_list;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 69:
#line 459 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-2].num + yyvsp[0].num; }
    break;

  case 70:
#line 461 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-2].num - yyvsp[0].num; }
    break;

  case 71:
#line 463 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-2].num * yyvsp[0].num; }
    break;

  case 72:
#line 465 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-2].num / yyvsp[0].num; }
    break;

  case 73:
#line 467 "../grap-1.35-src/grap.y"
    { yyval.num = pow(yyvsp[-2].num,yyvsp[0].num);}
    break;

  case 74:
#line 469 "../grap-1.35-src/grap.y"
    { yyval.num = - yyvsp[0].num;}
    break;

  case 75:
#line 471 "../grap-1.35-src/grap.y"
    { yyval.num = ( yyvsp[-2].val >=0 && yyvsp[-2].val < NF0 ) ? jtf0[yyvsp[-2].val]() : 0; }
    break;

  case 76:
#line 473 "../grap-1.35-src/grap.y"
    { yyval.num = ( yyvsp[-3].val >=0 && yyvsp[-3].val < NF1 ) ? jtf1[yyvsp[-3].val](yyvsp[-1].num) : 0; }
    break;

  case 77:
#line 475 "../grap-1.35-src/grap.y"
    { yyval.num = ( yyvsp[-5].val >=0 && yyvsp[-5].val < NF2 ) ? jtf2[yyvsp[-5].val](yyvsp[-3].num, yyvsp[-1].num) : 0; }
    break;

  case 78:
#line 477 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 79:
#line 479 "../grap-1.35-src/grap.y"
    {
		doubleDictionary::iterator di;
		
		if ( (di = vars.find(*yyvsp[0].String)) != vars.end())
		    yyval.num = *(*di).second;
		else {
		    cerr << *yyvsp[0].String << " is uninitialized, using 0.0" << endl;
		    yyval.num = 0.0;
		}

		delete yyvsp[0].String;
	     }
    break;

  case 80:
#line 492 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 81:
#line 497 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 82:
#line 499 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 83:
#line 501 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 84:
#line 506 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num == yyvsp[0].num); }
    break;

  case 85:
#line 508 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num != yyvsp[0].num); }
    break;

  case 86:
#line 510 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num < yyvsp[0].num); }
    break;

  case 87:
#line 512 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num > yyvsp[0].num); }
    break;

  case 88:
#line 514 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num <= yyvsp[0].num); }
    break;

  case 89:
#line 516 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num >= yyvsp[0].num); }
    break;

  case 90:
#line 518 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num && yyvsp[0].num); }
    break;

  case 91:
#line 520 "../grap-1.35-src/grap.y"
    { yyval.num = (yyvsp[-2].num || yyvsp[0].num); }
    break;

  case 92:
#line 522 "../grap-1.35-src/grap.y"
    { yyval.num = ! ( (int) yyvsp[0].num); }
    break;

  case 93:
#line 524 "../grap-1.35-src/grap.y"
    { yyval.num = (*yyvsp[-2].String == *yyvsp[0].String); delete yyvsp[-2].String; delete yyvsp[0].String; }
    break;

  case 94:
#line 526 "../grap-1.35-src/grap.y"
    { yyval.num = (*yyvsp[-2].String != *yyvsp[0].String); delete yyvsp[-2].String; delete yyvsp[0].String; }
    break;

  case 95:
#line 530 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 96:
#line 531 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 97:
#line 536 "../grap-1.35-src/grap.y"
    { yyval.num = assignment_statement(yyvsp[-1].String, yyvsp[0].num);  }
    break;

  case 98:
#line 541 "../grap-1.35-src/grap.y"
    { yyval.pt = new point(yyvsp[-2].num, yyvsp[0].num, 0); }
    break;

  case 99:
#line 543 "../grap-1.35-src/grap.y"
    { yyval.pt = new point(yyvsp[-3].num, yyvsp[-1].num, 0); }
    break;

  case 100:
#line 547 "../grap-1.35-src/grap.y"
    { yyval.pt = new point(yyvsp[0].pt->x, yyvsp[0].pt->y, yyvsp[-1].coordptr); delete yyvsp[0].pt; }
    break;

  case 101:
#line 551 "../grap-1.35-src/grap.y"
    {
		yyval.stringmod.size = 0;
		yyval.stringmod.rel =0;
		yyval.stringmod.just = (unaligned_default) ? unaligned : 0;
		yyval.stringmod.clip = clip_default;
		yyval.stringmod.color = 0;
	    }
    break;

  case 102:
#line 559 "../grap-1.35-src/grap.y"
    { yyval.stringmod.size = yyvsp[0].num; yyval.stringmod.rel = (yyvsp[0].num<0); }
    break;

  case 103:
#line 561 "../grap-1.35-src/grap.y"
    { yyval.stringmod.size = yyvsp[0].num; yyval.stringmod.rel = 1; }
    break;

  case 104:
#line 563 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) ljust; }
    break;

  case 105:
#line 565 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) rjust; }
    break;

  case 106:
#line 567 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) above; }
    break;

  case 107:
#line 569 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) below; }
    break;

  case 108:
#line 571 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) aligned; }
    break;

  case 109:
#line 573 "../grap-1.35-src/grap.y"
    { yyval.stringmod.just |= (int) unaligned; }
    break;

  case 110:
#line 575 "../grap-1.35-src/grap.y"
    { yyval.stringmod.clip = true; }
    break;

  case 111:
#line 577 "../grap-1.35-src/grap.y"
    { yyval.stringmod.clip = false; }
    break;

  case 112:
#line 579 "../grap-1.35-src/grap.y"
    { yyval.stringmod.color = yyvsp[0].String; }
    break;

  case 113:
#line 584 "../grap-1.35-src/grap.y"
    {
		DisplayString *s;

		s = new DisplayString(*yyvsp[-1].String,yyvsp[0].stringmod.just,yyvsp[0].stringmod.size, yyvsp[0].stringmod.rel, 
		    yyvsp[0].stringmod.clip, yyvsp[0].stringmod.color);
		delete yyvsp[-1].String;
		yyval.string_list = new stringlist;
		yyval.string_list->push_back(s);
	    }
    break;

  case 114:
#line 594 "../grap-1.35-src/grap.y"
    { yyval.string_list = combine_strings(yyvsp[-2].string_list, yyvsp[-1].String, yyvsp[0].stringmod); }
    break;

  case 115:
#line 599 "../grap-1.35-src/grap.y"
    {
  		the_graph->new_plot(yyvsp[-3].string_list,yyvsp[-1].pt);
	    }
    break;

  case 116:
#line 603 "../grap-1.35-src/grap.y"
    { plot_statement(yyvsp[-4].num, yyvsp[-3].ds, yyvsp[-1].pt); }
    break;

  case 117:
#line 608 "../grap-1.35-src/grap.y"
    { next_statement(yyvsp[-4].String, yyvsp[-2].pt, yyvsp[-1].lined); }
    break;

  case 118:
#line 613 "../grap-1.35-src/grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->ht = yyvsp[0].num;
		yyval.frameptr->wid = 0;
	    }
    break;

  case 119:
#line 619 "../grap-1.35-src/grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->wid = yyvsp[0].num;
		yyval.frameptr->ht = 0;
	    }
    break;

  case 120:
#line 628 "../grap-1.35-src/grap.y"
    { yyval.frameptr = yyvsp[0].frameptr; }
    break;

  case 121:
#line 630 "../grap-1.35-src/grap.y"
    {
		yyval.frameptr = yyvsp[-1].frameptr;
		// Fill in non-default ht/wid
		
		if ( yyvsp[0].frameptr->ht != 0 ) yyval.frameptr->ht = yyvsp[0].frameptr->ht;
		if ( yyvsp[0].frameptr->wid != 0 ) yyval.frameptr->wid = yyvsp[0].frameptr->wid;
	    }
    break;

  case 122:
#line 641 "../grap-1.35-src/grap.y"
    { yyval.side = top_side;}
    break;

  case 123:
#line 643 "../grap-1.35-src/grap.y"
    { yyval.side= bottom_side;}
    break;

  case 124:
#line 645 "../grap-1.35-src/grap.y"
    { yyval.side = left_side;}
    break;

  case 125:
#line 647 "../grap-1.35-src/grap.y"
    { yyval.side = right_side; }
    break;

  case 126:
#line 652 "../grap-1.35-src/grap.y"
    {
		// This rule combines the explicit size settings with
		// the defaults. We create a new frame to have access
		// to the default sizes without needing to code them
		// explicitly (they're always implicit in a default
		// frame). N. B. that frames created by size (and
		// size_elem) use 0 to indicate no change to the ht or
		// wid.
		
		yyval.frameptr = new frame;

		if ( yyvsp[0].frameptr->ht != 0) yyval.frameptr->ht = yyvsp[0].frameptr->ht;
		if ( yyvsp[0].frameptr->wid != 0) yyval.frameptr->wid = yyvsp[0].frameptr->wid;
		delete yyvsp[0].frameptr;
	    }
    break;

  case 127:
#line 669 "../grap-1.35-src/grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->desc[yyvsp[-1].side] = *yyvsp[0].lined;
		delete yyvsp[0].lined;
	    }
    break;

  case 128:
#line 675 "../grap-1.35-src/grap.y"
    {
		if ( !yyvsp[-2].frameptr ) yyval.frameptr = new frame;
		else yyval.frameptr = yyvsp[-2].frameptr;
		
		yyval.frameptr->desc[yyvsp[-1].side] = *yyvsp[0].lined;
		delete yyvsp[0].lined;
	    }
    break;

  case 129:
#line 686 "../grap-1.35-src/grap.y"
    { process_frame(0, 0, 0); }
    break;

  case 130:
#line 688 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-1].lined, 0, 0); }
    break;

  case 131:
#line 690 "../grap-1.35-src/grap.y"
    { process_frame(0, yyvsp[-1].frameptr, 0); }
    break;

  case 132:
#line 692 "../grap-1.35-src/grap.y"
    { process_frame(0, 0, yyvsp[-1].frameptr); }
    break;

  case 133:
#line 694 "../grap-1.35-src/grap.y"
    { process_frame(0, yyvsp[-2].frameptr, yyvsp[-1].frameptr); }
    break;

  case 134:
#line 696 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-2].lined, 0, yyvsp[-1].frameptr); }
    break;

  case 135:
#line 698 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-2].lined, yyvsp[-1].frameptr, 0); }
    break;

  case 136:
#line 700 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-1].lined, yyvsp[-2].frameptr, 0); }
    break;

  case 137:
#line 702 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-3].lined, yyvsp[-2].frameptr, yyvsp[-1].frameptr);}
    break;

  case 138:
#line 704 "../grap-1.35-src/grap.y"
    { process_frame(yyvsp[-2].lined, yyvsp[-3].frameptr, yyvsp[-1].frameptr); }
    break;

  case 139:
#line 709 "../grap-1.35-src/grap.y"
    { yyval.shift = new shiftdesc(top_side, yyvsp[0].num); }
    break;

  case 140:
#line 711 "../grap-1.35-src/grap.y"
    { yyval.shift = new shiftdesc(bottom_side, yyvsp[0].num); }
    break;

  case 141:
#line 713 "../grap-1.35-src/grap.y"
    { yyval.shift = new shiftdesc(left_side, yyvsp[0].num); }
    break;

  case 142:
#line 715 "../grap-1.35-src/grap.y"
    { yyval.shift = new shiftdesc(right_side, yyvsp[0].num); }
    break;

  case 143:
#line 720 "../grap-1.35-src/grap.y"
    { yyval.val = -1; }
    break;

  case 144:
#line 722 "../grap-1.35-src/grap.y"
    { yyval.val = 1; }
    break;

  case 145:
#line 726 "../grap-1.35-src/grap.y"
    { yyval.num = 0.125; }
    break;

  case 146:
#line 728 "../grap-1.35-src/grap.y"
    {
		if ( yyvsp[0].num == 0 ) yyval.num = yyvsp[-1].val * 0.125;
		else yyval.num = yyvsp[-1].val * yyvsp[0].num;
	    }
    break;

  case 147:
#line 736 "../grap-1.35-src/grap.y"
    { yyval.tick_list = ticklist_elem(yyvsp[-1].num, yyvsp[0].ds, 0); }
    break;

  case 148:
#line 738 "../grap-1.35-src/grap.y"
    { yyval.tick_list = ticklist_elem(yyvsp[-1].num, yyvsp[0].ds, yyvsp[-3].tick_list); }
    break;

  case 149:
#line 742 "../grap-1.35-src/grap.y"
    { yyval.by.op = PLUS; yyval.by.expr = 1; }
    break;

  case 150:
#line 744 "../grap-1.35-src/grap.y"
    {
		yyval.by.op = PLUS;
		if ( yyvsp[0].num != 0.0 ) yyval.by.expr = yyvsp[0].num;
		else yyval.by.expr = 1;
	    }
    break;

  case 151:
#line 750 "../grap-1.35-src/grap.y"
    { yyval.by.op = PLUS; yyval.by.expr = yyvsp[0].num; }
    break;

  case 152:
#line 752 "../grap-1.35-src/grap.y"
    { yyval.by.op = TIMES; yyval.by.expr = yyvsp[0].num; }
    break;

  case 153:
#line 754 "../grap-1.35-src/grap.y"
    { yyval.by.op = DIV; yyval.by.expr = yyvsp[0].num; }
    break;

  case 154:
#line 759 "../grap-1.35-src/grap.y"
    {
		yyval.tick_list = yyvsp[0].tick_list;
		for (ticklist::iterator t= yyvsp[0].tick_list->begin(); t != yyvsp[0].tick_list->end(); t++)
		    (*t)->c = yyvsp[-1].coordptr;
	    }
    break;

  case 155:
#line 768 "../grap-1.35-src/grap.y"
    { yyval.tick_list = tick_for(yyvsp[-5].coordptr, yyvsp[-4].num, yyvsp[-2].num, yyvsp[-1].by, yyvsp[0].ds); }
    break;

  case 156:
#line 772 "../grap-1.35-src/grap.y"
    { yyval.tick_list = yyvsp[0].tick_list;}
    break;

  case 157:
#line 774 "../grap-1.35-src/grap.y"
    { yyval.tick_list= yyvsp[0].tick_list; }
    break;

  case 158:
#line 779 "../grap-1.35-src/grap.y"
    {
		coordinateDictionary::iterator ci;

		if ( yyvsp[0].String ) {
		    ci = the_graph->coords.find(*yyvsp[0].String);
		    if ( ci != the_graph->coords.end()) 
			yyval.coordptr = (*ci).second;
		    else {
			yyerror("Name must name a coordinate space");
		    }
		}
		else yyval.coordptr = 0;
		
	    }
    break;

  case 159:
#line 794 "../grap-1.35-src/grap.y"
    {
		yyval.coordptr = 0;
            }
    break;

  case 160:
#line 801 "../grap-1.35-src/grap.y"
    { ticks_statement(yyvsp[-4].side, yyvsp[-3].num, yyvsp[-2].shift_list, yyvsp[-1].tick_list); }
    break;

  case 161:
#line 803 "../grap-1.35-src/grap.y"
    {
		for ( int i = 0; i< 4; i++ )
		    the_graph->base->tickdef[i].size = 0;
	    }
    break;

  case 162:
#line 808 "../grap-1.35-src/grap.y"
    { the_graph->base->tickdef[yyvsp[-2].side].size = 0; }
    break;

  case 163:
#line 810 "../grap-1.35-src/grap.y"
    {
		the_graph->base->tickdef[yyvsp[-3].side].size = yyvsp[-2].num;
		if ( yyvsp[-1].coordptr ) the_graph->base->tickdef[yyvsp[-3].side].c = yyvsp[-1].coordptr;
	    }
    break;

  case 164:
#line 817 "../grap-1.35-src/grap.y"
    { yyval.val = 0; }
    break;

  case 165:
#line 819 "../grap-1.35-src/grap.y"
    { yyval.val = 1; }
    break;

  case 166:
#line 824 "../grap-1.35-src/grap.y"
    {
		grid_statement(yyvsp[-5].side, yyvsp[-4].val, yyvsp[-3].lined, yyvsp[-2].shift_list, yyvsp[-1].tick_list);
	    }
    break;

  case 167:
#line 828 "../grap-1.35-src/grap.y"
    {
		grid_statement(yyvsp[-5].side, yyvsp[-4].val, yyvsp[-3].lined, yyvsp[-2].shift_list, 0);
		// Because turning on a grid on a given side disables
		// automatic tick generation there, this is sets up
		// that side with the proper coordinates.
		if ( yyvsp[-1].coordptr ) the_graph->base->griddef[yyvsp[-5].side].c = yyvsp[-1].coordptr;
	    }
    break;

  case 168:
#line 839 "../grap-1.35-src/grap.y"
    {
		shiftdesc *sd;

		for (stringlist::iterator s = yyvsp[-2].string_list->begin(); s != yyvsp[-2].string_list->end(); s++)
		    if ( ! ((*s)->j & unaligned) ) (*s)->j |= aligned;
		
		the_graph->base->label[yyvsp[-3].side] = yyvsp[-2].string_list;

		// Copy the label shifts into the frame
		while (!yyvsp[-1].shift_list->empty() ) {
		    sd = yyvsp[-1].shift_list->front();
		    yyvsp[-1].shift_list->pop_front();
		    the_graph->base->lshift[yyvsp[-3].side]->push_back(sd);
		}
		delete yyvsp[-1].shift_list;
	    }
    break;

  case 169:
#line 857 "../grap-1.35-src/grap.y"
    { yyval.num = 0.025; }
    break;

  case 170:
#line 859 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 171:
#line 864 "../grap-1.35-src/grap.y"
    {
		the_graph->new_circle(yyvsp[-3].pt,yyvsp[-2].num,yyvsp[-1].lined);
		delete yyvsp[-3].pt; delete yyvsp[-1].lined;
	    }
    break;

  case 172:
#line 872 "../grap-1.35-src/grap.y"
    { yyval.val = 1; }
    break;

  case 173:
#line 874 "../grap-1.35-src/grap.y"
    { yyval.val = 0; }
    break;

  case 174:
#line 879 "../grap-1.35-src/grap.y"
    { line_statement(yyvsp[-7].val, yyvsp[-6].lined, yyvsp[-4].pt, yyvsp[-2].pt, yyvsp[-1].lined); }
    break;

  case 175:
#line 883 "../grap-1.35-src/grap.y"
    { yyval.axistype.which=none; }
    break;

  case 176:
#line 885 "../grap-1.35-src/grap.y"
    { yyval.axistype = axis_description(x_axis, yyvsp[-2].num, yyvsp[0].num); }
    break;

  case 177:
#line 888 "../grap-1.35-src/grap.y"
    { yyval.axistype.which=none; }
    break;

  case 178:
#line 890 "../grap-1.35-src/grap.y"
    { yyval.axistype = axis_description(y_axis, yyvsp[-2].num, yyvsp[0].num); }
    break;

  case 179:
#line 895 "../grap-1.35-src/grap.y"
    { yyval.axisname = combine_logs(yyvsp[-1].axisname, yyvsp[0].axisname); }
    break;

  case 180:
#line 897 "../grap-1.35-src/grap.y"
    { yyval.axisname = none; }
    break;

  case 181:
#line 902 "../grap-1.35-src/grap.y"
    { yyval.axisname = x_axis; }
    break;

  case 182:
#line 904 "../grap-1.35-src/grap.y"
    { yyval.axisname = y_axis; }
    break;

  case 183:
#line 906 "../grap-1.35-src/grap.y"
    { yyval.axisname = both; }
    break;

  case 184:
#line 912 "../grap-1.35-src/grap.y"
    {
		coord_statement(yyvsp[-4].String, yyvsp[-3].axistype, yyvsp[-2].axistype, yyvsp[-1].axisname);
		delete yyvsp[-4].String;
	    }
    break;

  case 185:
#line 919 "../grap-1.35-src/grap.y"
    { yyval.copyd = 0; }
    break;

  case 186:
#line 921 "../grap-1.35-src/grap.y"
    {
		unquote(yyvsp[0].String);
		yyval.copyd = new copydesc;
		yyval.copyd->t = copydesc::until;
		yyval.copyd->s = yyvsp[0].String;
	    }
    break;

  case 187:
#line 928 "../grap-1.35-src/grap.y"
    {
		unquote(yyvsp[0].String);
		yyval.copyd = new copydesc;
		yyval.copyd->t = copydesc::fname;
		yyval.copyd->s = yyvsp[0].String;
	    }
    break;

  case 188:
#line 943 "../grap-1.35-src/grap.y"
    {
		unquote(yyvsp[-1].String);
		if (!include_file(yyvsp[-1].String, false)) return 0;
	    }
    break;

  case 189:
#line 948 "../grap-1.35-src/grap.y"
    {
		unquote(yyvsp[-1].String);
		lex_begin_copy(yyvsp[-1].String);
	    }
    break;

  case 190:
#line 953 "../grap-1.35-src/grap.y"
    {
		string s="";
		while (yyvsp[0].line_list && !yyvsp[0].line_list->empty() ) {
		    string *ss;
		    ss = yyvsp[0].line_list->front();
		    yyvsp[0].line_list->pop_front();
		    if ( ss ) {
			s+= *ss;
			s+= '\n';
			delete ss;
			ss = 0;
		    }
		}
		include_string(&s, 0, GINTERNAL);
		delete yyvsp[0].line_list;
	    }
    break;

  case 191:
#line 969 "../grap-1.35-src/grap.y"
    { lex_hunt_macro(); }
    break;

  case 192:
#line 970 "../grap-1.35-src/grap.y"
    {
		copydesc *c = 0; // To shut the compiler up about uninit
		if ( yyvsp[-5].copyd && yyvsp[-1].copyd ) {
		    delete yyvsp[-5].copyd;
		    delete yyvsp[-1].copyd;
		    yyerror("Only specify 1 until or filename\n");
		}
		else c = (yyvsp[-5].copyd) ? yyvsp[-5].copyd : yyvsp[-1].copyd;
		// The else handles files with neither else clause, copying
		// text to the trailing .G2.  Fix from Bruce Lilly
		if ( c ) {
		    // lex_begin_copy takes command of the string that's
		    // passed to it, so don't delete it.  (I don't
		    // remember why I did that...)
		    if ( c->t == copydesc::until ) {
			lex_begin_copy(c->s);
			c->s = 0;
		    }
		    else {
			lex_begin_copy(0);
			include_file(c->s, false);
		    }
		    delete c;
		}
		else lex_begin_copy(0);
	    }
    break;

  case 193:
#line 997 "../grap-1.35-src/grap.y"
    {
		string *s;
		string *t;
		int lim;
		char end;
		stack<string *> st;

		while ( yyvsp[0].line_list && !yyvsp[0].line_list->empty() ) {
		    int i = 0;
		    t = new string;
		    
		    s = yyvsp[0].line_list->front();
		    yyvsp[0].line_list->pop_front();
		    lim = s->length();
		    
		    while ( i < lim ) {
			if ( (*s)[i] == ' ' || (*s)[i] == '\t' ) {
			    if ( t->length() ) {
				if ( yyvsp[-4].macro_val->add_arg(t)) 
				    t = new string;
			    }
			} else *t += (*s)[i];
			i++;
		    }
		    if ( t->length() ) yyvsp[-4].macro_val->add_arg(t);
		    else if (t) delete t;
		    t = yyvsp[-4].macro_val->invoke();
		    // "here" macros should end with a SEP.  If the
		    // user hasn't done so, we add a SEP for them.
		    // Even named macros should get a sep when they're
		    // copied through,

		    end = (*t)[t->length()-1];

		    if ( end != ';' && end != '\n' ) 
			*t += ';';
		    // Because include string stacks the strings, we stack them
		    // here and call include_string in reverse order to ensure
		    // correct ordered execution of multiple lines.
		    st.push(t);
		    delete s;
		}
		delete yyvsp[0].line_list;
		while ( !st.empty() ) {
		    include_string(st.top(), 0, GMACRO);
		    delete st.top();
		    st.pop();
	        }
		// don't delete defined macros
		if ( !yyvsp[-4].macro_val->name)
		    delete yyvsp[-4].macro_val;
	    }
    break;

  case 194:
#line 1052 "../grap-1.35-src/grap.y"
    { lex_no_coord(); lex_no_macro_expansion();}
    break;

  case 195:
#line 1053 "../grap-1.35-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 196:
#line 1054 "../grap-1.35-src/grap.y"
    { lex_macro_expansion_ok(); lex_coord_ok(); define_macro(yyvsp[-3].String, yyvsp[-1].String); }
    break;

  case 197:
#line 1058 "../grap-1.35-src/grap.y"
    { lex_no_coord(); lex_no_macro_expansion(); }
    break;

  case 198:
#line 1058 "../grap-1.35-src/grap.y"
    {
	    lex_coord_ok();
	    lex_macro_expansion_ok();
	    macros.erase(*yyvsp[-1].String);
	    delete yyvsp[-1].String;
	}
    break;

  case 199:
#line 1066 "../grap-1.35-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 200:
#line 1067 "../grap-1.35-src/grap.y"
    {
		int len = yyvsp[-1].String->length()+1 ;
		char *sys = new char [len];
		int i=0;

		// String to char*
		       
		while ((sys[i] = (*yyvsp[-1].String)[i]))
		    i++;

		delete yyvsp[-1].String;
		
		system(sys);
	    }
    break;

  case 201:
#line 1084 "../grap-1.35-src/grap.y"
    { yyval.String = 0; }
    break;

  case 202:
#line 1085 "../grap-1.35-src/grap.y"
    {lex_begin_macro_text(); }
    break;

  case 203:
#line 1086 "../grap-1.35-src/grap.y"
    {
		// force else clause to end with a SEP
		*yyvsp[0].String+= ';';
		yyval.String = yyvsp[0].String;
	    }
    break;

  case 204:
#line 1094 "../grap-1.35-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 205:
#line 1095 "../grap-1.35-src/grap.y"
    {
		// force all if blocks to be terminated by a SEP
		*yyvsp[-2].String += ';';
		if ( fabs(yyvsp[-5].num) > EPSILON ) include_string(yyvsp[-2].String,0,GINTERNAL);
		else if ( yyvsp[-1].String ) include_string(yyvsp[-1].String,0,GINTERNAL);
		delete yyvsp[-2].String;
		if ( yyvsp[-1].String) delete yyvsp[-1].String;
	    }
    break;

  case 206:
#line 1107 "../grap-1.35-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 207:
#line 1108 "../grap-1.35-src/grap.y"
    { for_statement(yyvsp[-9].String, yyvsp[-7].num, yyvsp[-5].num, yyvsp[-4].by, yyvsp[-1].String); }
    break;

  case 208:
#line 1112 "../grap-1.35-src/grap.y"
    { lex_no_coord(); }
    break;

  case 209:
#line 1112 "../grap-1.35-src/grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 210:
#line 1113 "../grap-1.35-src/grap.y"
    {
		if ( !first_line ) {
		    // Only draw the graph and clear its internals if
		    // it is visible.  This allows a user to declare
		    // things like coordinate spaces before the graph
		    // itself is named.  This is a compatibility
		    // feature for DWB grap.
		    if ( the_graph->is_visible() ) {
			the_graph->draw(0);
			the_graph->init(yyvsp[-3].String, yyvsp[-1].String);
			init_dict();
		    }
		    else
			the_graph->setname(yyvsp[-3].String);
		}
		else {
		    the_graph->init(yyvsp[-3].String, yyvsp[-1].String);
		    init_dict();
		}
		    
		if ( yyvsp[-3].String ) delete yyvsp[-3].String;
		if ( yyvsp[-1].String ) delete yyvsp[-1].String;
	    }
    break;

  case 212:
#line 1144 "../grap-1.35-src/grap.y"
    {
		unquote(yyvsp[0].String);
		cerr <<  *yyvsp[0].String << endl;
	    }
    break;

  case 213:
#line 1149 "../grap-1.35-src/grap.y"
    {
		cerr << yyvsp[0].num << endl;
	    }
    break;

  case 214:
#line 1155 "../grap-1.35-src/grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 215:
#line 1156 "../grap-1.35-src/grap.y"
    { the_graph->passthru_string(*yyvsp[-1].String); delete yyvsp[-1].String;}
    break;

  case 216:
#line 1160 "../grap-1.35-src/grap.y"
    { the_graph->passthru_string(*yyvsp[-1].String); delete yyvsp[-1].String;}
    break;

  case 217:
#line 1165 "../grap-1.35-src/grap.y"
    { yyval.side = right_side; }
    break;

  case 218:
#line 1167 "../grap-1.35-src/grap.y"
    { yyval.side = top_side; }
    break;

  case 219:
#line 1171 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 220:
#line 1173 "../grap-1.35-src/grap.y"
    { yyval.num = 0; }
    break;

  case 221:
#line 1178 "../grap-1.35-src/grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 222:
#line 1180 "../grap-1.35-src/grap.y"
    { yyval.num = 1; }
    break;

  case 223:
#line 1185 "../grap-1.35-src/grap.y"
    {
		// The point parsing has already autoscaled the
		// coordinate system to include those points.
		the_graph->new_box(yyvsp[-4].pt, yyvsp[-2].pt, yyvsp[-1].lined);
		delete yyvsp[-4].pt; delete yyvsp[-2].pt; delete yyvsp[-1].lined;
	    }
    break;

  case 224:
#line 1193 "../grap-1.35-src/grap.y"
    { bar_statement(yyvsp[-8].coordptr, yyvsp[-7].side, yyvsp[-6].num, yyvsp[-4].num, yyvsp[-3].num, yyvsp[-2].num, yyvsp[-1].lined); }
    break;

  case 225:
#line 1198 "../grap-1.35-src/grap.y"
    { if ( yyvsp[-3].val >=0 && yyvsp[-3].val < NVF1 ) jtvf1[yyvsp[-3].val](yyvsp[-1].num); }
    break;


    }

/* Line 999 of yacc.c.  */
#line 3274 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  const char* yyprefix;
	  char *yymsg;
	  int yyx;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 0;

	  yyprefix = ", expecting ";
	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		yysize += yystrlen (yyprefix) + yystrlen (yytname [yyx]);
		yycount += 1;
		if (yycount == 5)
		  {
		    yysize = 0;
		    break;
		  }
	      }
	  yysize += (sizeof ("syntax error, unexpected ")
		     + yystrlen (yytname[yytype]));
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yyprefix = ", expecting ";
		  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			yyp = yystpcpy (yyp, yyprefix);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yyprefix = " or ";
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1200 "../grap-1.35-src/grap.y"


