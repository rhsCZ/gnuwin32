/* config.h.  Generated automatically by configure.  */
#ifndef CONFIG_H
#define CONFIG_H
// This file is (c) 1998-2001 Ted Faber (faber@lunabase.org) see COPYRIGHT
// for the full copyright and limitations of liabilities.

// The following are set by configure

#define STDC_HEADERS 1
/* #undef HAVE_STDLIB_H */
#define HAVE_UNISTD_H 1
#define HAVE_HASH_MAP 1
/* #undef HAVE_SNPRINTF */
#define HAVE_RANDOM 1
#define HAVE_RAND 1
#define HAVE_STRDUP 1
#define HAVE_STRERROR 1
/* #undef SNPRINTF_DECLARED */
#define STRERROR_DECLARED 1
/* #undef RANDOM_DECLARED */
/* #undef OPTARG_DEFINED */
/* #undef SPRINTF_NOT_INT */

#define DEFINES "c:/progra~1/groff/share/grap/grap.defines" 

#endif
