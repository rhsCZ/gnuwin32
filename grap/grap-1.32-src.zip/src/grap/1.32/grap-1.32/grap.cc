/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     START = 259,
     END = 260,
     IDENT = 261,
     COPY = 262,
     SEP = 263,
     STRING = 264,
     COORD_NAME = 265,
     UNDEFINE = 266,
     SOLID = 267,
     INVIS = 268,
     DOTTED = 269,
     DASHED = 270,
     DRAW = 271,
     LPAREN = 272,
     RPAREN = 273,
     FUNC0 = 274,
     FUNC1 = 275,
     FUNC2 = 276,
     COMMA = 277,
     LINE = 278,
     PLOT = 279,
     FROM = 280,
     TO = 281,
     AT = 282,
     NEXT = 283,
     FRAME = 284,
     LEFT = 285,
     RIGHT = 286,
     TOP = 287,
     BOTTOM = 288,
     UP = 289,
     DOWN = 290,
     HT = 291,
     WID = 292,
     GRAP_IN = 293,
     GRAP_OUT = 294,
     NONE = 295,
     TICKS = 296,
     OFF = 297,
     BY = 298,
     GRID = 299,
     LJUST = 300,
     RJUST = 301,
     ABOVE = 302,
     BELOW = 303,
     ALIGNED = 304,
     PLUS = 305,
     MINUS = 306,
     TIMES = 307,
     DIV = 308,
     CARAT = 309,
     EQUALS = 310,
     GRAP_SIZE = 311,
     GRAP_UNALIGNED = 312,
     LABEL = 313,
     RADIUS = 314,
     CIRCLE = 315,
     ARROW = 316,
     XDIM = 317,
     YDIM = 318,
     LOG_X = 319,
     LOG_Y = 320,
     LOG_LOG = 321,
     GRAP_COORD = 322,
     GRAP_TEXT = 323,
     DEFINE = 324,
     IF = 325,
     THEN = 326,
     ELSE = 327,
     EQ = 328,
     NEQ = 329,
     LT = 330,
     GT = 331,
     LTE = 332,
     GTE = 333,
     NOT = 334,
     OR = 335,
     AND = 336,
     FOR = 337,
     DO = 338,
     MACRO = 339,
     COPYTEXT = 340,
     THRU = 341,
     GRAPH = 342,
     REST = 343,
     PRINT = 344,
     PIC = 345,
     TROFF = 346,
     UNTIL = 347,
     COLOR = 348,
     SPRINTF = 349,
     SH = 350,
     BAR = 351,
     FILL = 352,
     FILLCOLOR = 353,
     BASE = 354,
     ON = 355,
     LHS = 356,
     VFUNC1 = 357,
     CLIPPED = 358,
     UNCLIPPED = 359
   };
#endif
#define NUMBER 258
#define START 259
#define END 260
#define IDENT 261
#define COPY 262
#define SEP 263
#define STRING 264
#define COORD_NAME 265
#define UNDEFINE 266
#define SOLID 267
#define INVIS 268
#define DOTTED 269
#define DASHED 270
#define DRAW 271
#define LPAREN 272
#define RPAREN 273
#define FUNC0 274
#define FUNC1 275
#define FUNC2 276
#define COMMA 277
#define LINE 278
#define PLOT 279
#define FROM 280
#define TO 281
#define AT 282
#define NEXT 283
#define FRAME 284
#define LEFT 285
#define RIGHT 286
#define TOP 287
#define BOTTOM 288
#define UP 289
#define DOWN 290
#define HT 291
#define WID 292
#define GRAP_IN 293
#define GRAP_OUT 294
#define NONE 295
#define TICKS 296
#define OFF 297
#define BY 298
#define GRID 299
#define LJUST 300
#define RJUST 301
#define ABOVE 302
#define BELOW 303
#define ALIGNED 304
#define PLUS 305
#define MINUS 306
#define TIMES 307
#define DIV 308
#define CARAT 309
#define EQUALS 310
#define GRAP_SIZE 311
#define GRAP_UNALIGNED 312
#define LABEL 313
#define RADIUS 314
#define CIRCLE 315
#define ARROW 316
#define XDIM 317
#define YDIM 318
#define LOG_X 319
#define LOG_Y 320
#define LOG_LOG 321
#define GRAP_COORD 322
#define GRAP_TEXT 323
#define DEFINE 324
#define IF 325
#define THEN 326
#define ELSE 327
#define EQ 328
#define NEQ 329
#define LT 330
#define GT 331
#define LTE 332
#define GTE 333
#define NOT 334
#define OR 335
#define AND 336
#define FOR 337
#define DO 338
#define MACRO 339
#define COPYTEXT 340
#define THRU 341
#define GRAPH 342
#define REST 343
#define PRINT 344
#define PIC 345
#define TROFF 346
#define UNTIL 347
#define COLOR 348
#define SPRINTF 349
#define SH 350
#define BAR 351
#define FILL 352
#define FILLCOLOR 353
#define BASE 354
#define ON 355
#define LHS 356
#define VFUNC1 357
#define CLIPPED 358
#define UNCLIPPED 359




/* Copy the first part of user declarations.  */
#line 2 "grap.y"

/* This code is (c) 1998-2001 Ted Faber (faber@lunabase.org) see the
   COPYRIGHT file for the full copyright and limitations of
   liabilities. */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <stdio.h>
#include <iostream>
#include <stack>
#include <math.h>
#ifdef STDC_HEADERS
#include <limits.h>
#else
// Best guess, really - limits should exist
#ifndef LONG_MAX
#define LONG_MAX        0x7fffffffL
#endif
#endif
#if defined(STDC_HEADERS) | defined(HAVE_STDLIB_H)
#include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "grap.h"
#include "grap_data.h"
#include "grap_draw.h"

doubleDictionary vars;
graph *the_graph =0;
lexStack lexstack;
macroDictionary macros;
stringSequence path;
bool first_line;
bool unaligned_default = false;	// Should strings be unaligned by default 
bool clip_default = true;	// Should strings be clipped by default 
extern bool do_sprintf;		// true if it's acceptable to parse sprintf

line* defline;
coord *defcoord;
string *graph_name;
string *graph_pos;
string *ps_param;
// number of lines in a number list (used in grap_parse.cc) 
int nlines;

// bison wants these defined....
int yyerror(char*);
int yylex();
void init_dict(); 

// defined in grap_lex.l
extern bool include_file(string *, bool =false, bool=true);
extern void lex_no_macro_expansion(); 
extern void lex_macro_expansion_ok(); 
extern void lex_begin_macro_text(); 
extern void lex_begin_rest_of_line();
extern void lex_no_coord();
extern void lex_coord_ok();
extern void lex_begin_copy( string*s=0);
extern int include_string(string *,struct for_descriptor *f=0,
			  grap_input i=GMACRO);
extern void lex_hunt_macro();
extern int yyparse(void);	// To shut yacc (vs. bison) up.
void draw_graph();
void init_graph();

// Parsing utilities in grap_parse.cc.  Locating them there reduces
// compilation time (this file was getting very large) and eliminates
// some code redundancy.
extern graph *initial_graph(); 
extern linedesc* combine_linedesc(linedesc *, linedesc*);
extern axis combine_logs(axis, axis);
extern void draw_statement(string *, linedesc *, DisplayString *);
extern void num_list(doublelist *);
extern double assignment_statement(string *, double);
extern stringlist *combine_strings(stringlist *, string *, strmod &);
extern void plot_statement(double, DisplayString *, point *); 
extern void next_statement(string *, point *, linedesc *);
extern ticklist *ticklist_elem(double, DisplayString *, ticklist *);
extern ticklist *tick_for(coord *, double, double, bydesc, DisplayString *);
extern void ticks_statement(sides, double, shiftlist *, ticklist *);
extern void grid_statement(sides, int, linedesc *, shiftlist *, ticklist *);
extern void line_statement(int, linedesc *, point *, point *, linedesc *);
extern axisdesc axis_description(axis, double, double );
extern void coord_statement(string *, axisdesc&, axisdesc&, axis);
extern void coord_statement(coord *, axisdesc&, axisdesc&, axis);
extern void for_statement(string *, double, double, bydesc, string *);
extern void process_frame(linedesc *, frame *, frame *);
extern void define_macro(string *, string*);
extern void bar_statement(coord *, sides, double, double, double,
		   double, linedesc *); 
void init_dict(); 

// adapters to return complex (complex-ish) functions
void grap_srandom(double x) { srandom(static_cast<unsigned int>(x)); }
double grap_random() {
    return static_cast<double>(random())/(static_cast<double>(LONG_MAX)+1e-6);
}
double grap_getpid() { return static_cast<double>(getpid());} 
double pow10(double x) { return pow(10,x); }
double toint(double x) { return static_cast<double>(int(x)); }
double grap_min(double a, double b) { return (a<b) ? a : b; } 
double grap_max(double a, double b) { return (a>b) ? a : b; } 
 
typedef void (*vfunction1)(double);
typedef double (*function0)();
typedef double (*function1)(double);
typedef double (*function2)(double, double);
// jump tables for dispatching internal functions
vfunction1 jtvf1[NVF1] = { grap_srandom };
function0 jtf0[NF0] = { grap_random, grap_getpid };
function1 jtf1[NF1] = { log10, pow10, toint, sin, cos, sqrt, exp, log };
function2 jtf2[NF2] = { atan2, grap_min, grap_max};


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 129 "grap.y"
typedef union YYSTYPE {
    int val;
    double num;
    string *String;
    DisplayString *ds;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    doublevec *double_vec;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 427 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 439 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   686

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  105
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  92
/* YYNRULES -- Number of rules. */
#define YYNRULES  224
/* YYNRULES -- Number of states. */
#define YYNSTATES  426

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   359

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     4,     7,     8,    13,    14,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
      41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    72,    74,    75,    77,
      78,    81,    83,    90,    92,    96,    97,    99,   100,   102,
     103,   106,   108,   110,   113,   116,   119,   122,   125,   127,
     130,   131,   138,   141,   143,   146,   148,   151,   155,   159,
     163,   167,   171,   175,   178,   182,   187,   194,   198,   200,
     202,   204,   208,   210,   214,   218,   222,   226,   230,   234,
     238,   242,   245,   249,   253,   256,   258,   261,   265,   271,
     274,   275,   279,   284,   287,   290,   293,   296,   299,   302,
     305,   308,   312,   315,   319,   324,   331,   338,   341,   344,
     346,   349,   351,   353,   355,   357,   359,   362,   366,   369,
     373,   377,   381,   386,   391,   396,   401,   407,   413,   416,
     419,   422,   425,   427,   429,   430,   433,   436,   441,   442,
     445,   449,   453,   457,   461,   469,   471,   473,   476,   477,
     484,   488,   493,   499,   500,   503,   511,   519,   525,   526,
     529,   536,   538,   540,   549,   550,   555,   556,   561,   564,
     565,   567,   569,   571,   578,   579,   582,   584,   588,   589,
     596,   597,   598,   608,   609,   610,   617,   618,   623,   624,
     629,   630,   631,   635,   636,   644,   645,   657,   658,   659,
     666,   670,   672,   674,   675,   680,   683,   685,   687,   690,
     691,   694,   695,   702,   713
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     106,     0,    -1,    -1,   106,   107,    -1,    -1,     4,   108,
     109,     5,    -1,    -1,   109,   110,    -1,   131,    -1,   124,
      -1,   143,    -1,   122,    -1,   137,    -1,   136,    -1,   153,
      -1,   155,    -1,   156,    -1,   158,    -1,   195,    -1,   160,
      -1,   165,    -1,   167,    -1,   171,    -1,   174,    -1,   180,
      -1,   182,    -1,   184,    -1,   187,    -1,   176,    -1,   189,
      -1,   191,    -1,   196,    -1,     8,    -1,    25,    -1,    55,
      -1,    -1,    10,    -1,    -1,     6,    -1,    -1,   115,   134,
      -1,     9,    -1,    94,    17,     9,    22,   116,    18,    -1,
     127,    -1,   116,    22,   127,    -1,    -1,   127,    -1,    -1,
     121,    -1,    -1,   144,   119,    -1,    13,    -1,    12,    -1,
      14,   117,    -1,    15,   117,    -1,    93,   115,    -1,    97,
     117,    -1,    98,   115,    -1,   120,    -1,   121,   120,    -1,
      -1,    16,   123,   113,   118,   114,     8,    -1,   126,     8,
      -1,     3,    -1,    51,     3,    -1,   125,    -1,   126,   125,
      -1,   126,    22,   125,    -1,   127,    50,   127,    -1,   127,
      51,   127,    -1,   127,    52,   127,    -1,   127,    53,   127,
      -1,   127,    54,   127,    -1,    51,   127,    -1,    19,    17,
      18,    -1,    20,    17,   127,    18,    -1,    21,    17,   127,
      22,   127,    18,    -1,    17,   127,    18,    -1,     6,    -1,
       3,    -1,   127,    -1,    17,   129,    18,    -1,   129,    -1,
     128,    73,   128,    -1,   128,    74,   128,    -1,   128,    75,
     128,    -1,   128,    76,   128,    -1,   128,    77,   128,    -1,
     128,    78,   128,    -1,   128,    81,   128,    -1,   128,    80,
     128,    -1,    79,   128,    -1,   115,    73,   115,    -1,   115,
      74,   115,    -1,   127,     8,    -1,   131,    -1,   101,   130,
      -1,   127,    22,   127,    -1,    17,   127,    22,   127,    18,
      -1,   112,   132,    -1,    -1,   134,    56,   127,    -1,   134,
      56,    50,   127,    -1,   134,    45,    -1,   134,    46,    -1,
     134,    47,    -1,   134,    48,    -1,   134,    49,    -1,   134,
      57,    -1,   134,   103,    -1,   134,   104,    -1,   134,    93,
       9,    -1,   115,   134,    -1,   135,   115,   134,    -1,   135,
      27,   133,     8,    -1,    24,   127,   114,    27,   133,     8,
      -1,    28,   113,    27,   133,   118,     8,    -1,    36,   127,
      -1,    37,   127,    -1,   138,    -1,   139,   138,    -1,    32,
      -1,    33,    -1,    30,    -1,    31,    -1,   139,    -1,   140,
     121,    -1,   142,   140,   121,    -1,    29,     8,    -1,    29,
     121,     8,    -1,    29,   141,     8,    -1,    29,   142,     8,
      -1,    29,   141,   142,     8,    -1,    29,   121,   142,     8,
      -1,    29,   121,   141,     8,    -1,    29,   141,   121,     8,
      -1,    29,   121,   141,   142,     8,    -1,    29,   141,   121,
     142,     8,    -1,    34,   127,    -1,    35,   127,    -1,    30,
     127,    -1,    31,   127,    -1,    38,    -1,    39,    -1,    -1,
     145,   117,    -1,   127,   114,    -1,   147,    22,   127,   114,
      -1,    -1,    43,   127,    -1,    43,    50,   127,    -1,    43,
      52,   127,    -1,    43,    53,   127,    -1,    27,   112,   147,
      -1,   111,   112,   127,    26,   127,   148,   114,    -1,   149,
      -1,   150,    -1,   100,   113,    -1,    -1,    41,   140,   146,
     119,   151,     8,    -1,    41,    42,     8,    -1,    41,   140,
      42,     8,    -1,    41,   140,   146,   152,     8,    -1,    -1,
      41,    42,    -1,    44,   140,   154,   118,   119,   151,     8,
      -1,    44,   140,   154,   118,   119,   152,     8,    -1,    58,
     140,   135,   119,     8,    -1,    -1,    59,   127,    -1,    60,
      27,   133,   157,   118,     8,    -1,    23,    -1,    61,    -1,
     159,   118,    25,   133,    26,   133,   118,     8,    -1,    -1,
      62,   127,    22,   127,    -1,    -1,    63,   127,    22,   127,
      -1,   163,   164,    -1,    -1,    64,    -1,    65,    -1,    66,
      -1,    67,   113,   161,   162,   163,     8,    -1,    -1,    92,
     115,    -1,   115,    -1,     7,   115,     8,    -1,    -1,     7,
      92,   115,     8,   168,    85,    -1,    -1,    -1,     7,   166,
      86,   169,    84,   166,     8,   170,    85,    -1,    -1,    -1,
      69,   172,     6,   173,    68,     8,    -1,    -1,    11,   175,
       6,     8,    -1,    -1,    95,   177,    68,     8,    -1,    -1,
      -1,    72,   179,    68,    -1,    -1,    70,   128,    71,   181,
      68,   178,     8,    -1,    -1,    82,     6,   111,   127,    26,
     127,   148,    83,   183,    68,     8,    -1,    -1,    -1,    87,
     185,     6,   186,    88,     8,    -1,    89,   188,     8,    -1,
     115,    -1,   127,    -1,    -1,    90,   190,    88,     8,    -1,
      91,     8,    -1,    31,    -1,    34,    -1,    99,   127,    -1,
      -1,    37,   127,    -1,    -1,    96,   133,    22,   133,   118,
       8,    -1,    96,   112,   192,   127,    36,   127,   194,   193,
     118,     8,    -1,   102,    17,   127,    18,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   186,   186,   187,   191,   191,   205,   206,   210,   212,
     214,   220,   222,   224,   226,   228,   230,   232,   234,   236,
     238,   240,   242,   244,   246,   248,   250,   252,   254,   256,
     258,   260,   262,   266,   267,   270,   271,   276,   277,   282,
     283,   291,   293,   361,   366,   374,   375,   380,   381,   386,
     387,   396,   398,   400,   402,   404,   406,   408,   413,   415,
     420,   420,   425,   430,   433,   438,   443,   448,   456,   458,
     460,   462,   464,   466,   468,   470,   472,   474,   476,   489,
     494,   496,   498,   503,   505,   507,   509,   511,   513,   515,
     517,   519,   521,   523,   528,   529,   533,   538,   540,   544,
     549,   556,   558,   560,   562,   564,   566,   568,   570,   572,
     574,   576,   581,   591,   596,   600,   605,   610,   616,   625,
     627,   638,   640,   642,   644,   649,   667,   672,   683,   685,
     687,   689,   691,   693,   695,   697,   699,   701,   706,   708,
     710,   712,   717,   719,   724,   725,   733,   735,   740,   741,
     747,   749,   751,   756,   765,   769,   771,   776,   792,   798,
     800,   805,   807,   815,   816,   821,   825,   836,   855,   856,
     861,   869,   871,   876,   881,   882,   886,   887,   892,   895,
     899,   901,   903,   909,   917,   918,   925,   940,   946,   945,
     967,   968,   967,  1047,  1048,  1047,  1053,  1053,  1061,  1061,
    1079,  1080,  1080,  1089,  1089,  1102,  1101,  1107,  1107,  1107,
    1134,  1138,  1143,  1150,  1150,  1154,  1159,  1161,  1165,  1168,
    1172,  1175,  1179,  1186,  1192
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NUMBER", "START", "END", "IDENT", "COPY", 
  "SEP", "STRING", "COORD_NAME", "UNDEFINE", "SOLID", "INVIS", "DOTTED", 
  "DASHED", "DRAW", "LPAREN", "RPAREN", "FUNC0", "FUNC1", "FUNC2", 
  "COMMA", "LINE", "PLOT", "FROM", "TO", "AT", "NEXT", "FRAME", "LEFT", 
  "RIGHT", "TOP", "BOTTOM", "UP", "DOWN", "HT", "WID", "GRAP_IN", 
  "GRAP_OUT", "NONE", "TICKS", "OFF", "BY", "GRID", "LJUST", "RJUST", 
  "ABOVE", "BELOW", "ALIGNED", "PLUS", "MINUS", "TIMES", "DIV", "CARAT", 
  "EQUALS", "GRAP_SIZE", "GRAP_UNALIGNED", "LABEL", "RADIUS", "CIRCLE", 
  "ARROW", "XDIM", "YDIM", "LOG_X", "LOG_Y", "LOG_LOG", "GRAP_COORD", 
  "GRAP_TEXT", "DEFINE", "IF", "THEN", "ELSE", "EQ", "NEQ", "LT", "GT", 
  "LTE", "GTE", "NOT", "OR", "AND", "FOR", "DO", "MACRO", "COPYTEXT", 
  "THRU", "GRAPH", "REST", "PRINT", "PIC", "TROFF", "UNTIL", "COLOR", 
  "SPRINTF", "SH", "BAR", "FILL", "FILLCOLOR", "BASE", "ON", "LHS", 
  "VFUNC1", "CLIPPED", "UNCLIPPED", "$accept", "graphs", "graph", "@1", 
  "prog", "statement", "from", "opt_coordname", "opt_ident", 
  "opt_display_string", "string", "expr_list", "opt_expr", "opt_linedesc", 
  "opt_shift", "linedesc_elem", "linedesc", "draw_statement", "@2", 
  "num_list", "num_line_elem", "num_line", "expr", "lexpr", "pure_lexpr", 
  "right_hand_side", "assignment_statement", "coord_pair", "point", 
  "strmod", "strlist", "plot_statement", "next_statement", "size_elem", 
  "size", "side", "final_size", "sides", "frame_statement", "shift", 
  "tickdir", "direction", "ticklist", "by_clause", "tickat", "tickfor", 
  "tickdesc", "autotick", "ticks_statement", "opt_tick_off", 
  "grid_statement", "label_statement", "radius_spec", "circle_statement", 
  "line_token", "line_statement", "x_axis_desc", "y_axis_desc", 
  "log_list", "log_desc", "coord_statement", "until_clause", 
  "copy_statement", "@3", "@4", "@5", "define_statement", "@6", "@7", 
  "undefine_statement", "@8", "sh_statement", "@9", "else_clause", "@10", 
  "if_statement", "@11", "for_statement", "@12", "graph_statement", "@13", 
  "@14", "print_statement", "print_param", "pic_statement", "@15", 
  "troff_line", "bar_dir", "bar_base", "opt_wid", "bar_statement", 
  "void_function", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   105,   106,   106,   108,   107,   109,   109,   110,   110,
     110,   110,   110,   110,   110,   110,   110,   110,   110,   110,
     110,   110,   110,   110,   110,   110,   110,   110,   110,   110,
     110,   110,   110,   111,   111,   112,   112,   113,   113,   114,
     114,   115,   115,   116,   116,   117,   117,   118,   118,   119,
     119,   120,   120,   120,   120,   120,   120,   120,   121,   121,
     123,   122,   124,   125,   125,   126,   126,   126,   127,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   127,   127,
     128,   128,   128,   129,   129,   129,   129,   129,   129,   129,
     129,   129,   129,   129,   130,   130,   131,   132,   132,   133,
     134,   134,   134,   134,   134,   134,   134,   134,   134,   134,
     134,   134,   135,   135,   136,   136,   137,   138,   138,   139,
     139,   140,   140,   140,   140,   141,   142,   142,   143,   143,
     143,   143,   143,   143,   143,   143,   143,   143,   144,   144,
     144,   144,   145,   145,   146,   146,   147,   147,   148,   148,
     148,   148,   148,   149,   150,   151,   151,   152,   152,   153,
     153,   153,   153,   154,   154,   155,   155,   156,   157,   157,
     158,   159,   159,   160,   161,   161,   162,   162,   163,   163,
     164,   164,   164,   165,   166,   166,   166,   167,   168,   167,
     169,   170,   167,   172,   173,   171,   175,   174,   177,   176,
     178,   179,   178,   181,   180,   183,   182,   185,   186,   184,
     187,   188,   188,   190,   189,   191,   192,   192,   193,   193,
     194,   194,   195,   195,   196
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     0,     2,     0,     4,     0,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     1,     0,     1,     0,
       2,     1,     6,     1,     3,     0,     1,     0,     1,     0,
       2,     1,     1,     2,     2,     2,     2,     2,     1,     2,
       0,     6,     2,     1,     2,     1,     2,     3,     3,     3,
       3,     3,     3,     2,     3,     4,     6,     3,     1,     1,
       1,     3,     1,     3,     3,     3,     3,     3,     3,     3,
       3,     2,     3,     3,     2,     1,     2,     3,     5,     2,
       0,     3,     4,     2,     2,     2,     2,     2,     2,     2,
       2,     3,     2,     3,     4,     6,     6,     2,     2,     1,
       2,     1,     1,     1,     1,     1,     2,     3,     2,     3,
       3,     3,     4,     4,     4,     4,     5,     5,     2,     2,
       2,     2,     1,     1,     0,     2,     2,     4,     0,     2,
       3,     3,     3,     3,     7,     1,     1,     2,     0,     6,
       3,     4,     5,     0,     2,     7,     7,     5,     0,     2,
       6,     1,     1,     8,     0,     4,     0,     4,     2,     0,
       1,     1,     1,     6,     0,     2,     1,     3,     0,     6,
       0,     0,     9,     0,     0,     6,     0,     4,     0,     4,
       0,     0,     3,     0,     7,     0,    11,     0,     0,     6,
       3,     1,     1,     0,     4,     2,     1,     1,     2,     0,
       2,     0,     6,    10,     4
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       2,     0,     1,     4,     3,     6,     0,    63,     5,   184,
      32,    41,   196,    60,   171,     0,    37,     0,     0,     0,
       0,     0,     0,   172,    37,   193,     0,     0,   207,     0,
     213,     0,     0,   198,    35,     0,     0,     7,   100,    11,
       9,    65,     0,     8,     0,    13,    12,    10,    14,    15,
      16,    17,    47,    19,    20,    21,    22,    23,    28,    24,
      25,    26,    27,    29,    30,    18,    31,     0,   186,     0,
       0,    37,    79,    78,     0,     0,     0,     0,     0,    39,
      38,     0,   128,    52,    51,    45,    45,   123,   124,   121,
     122,     0,     0,     0,    45,     0,    58,     0,   119,   125,
       0,     0,     0,     0,   144,   163,    64,     0,    35,   174,
       0,     0,     0,     0,    80,     0,    82,     0,     0,   211,
     212,     0,     0,   215,     0,     0,    36,     0,     0,     0,
      96,    95,     0,   112,    62,     0,    66,    35,   100,     0,
      48,   185,   187,   190,     0,    47,     0,     0,     0,     0,
      73,     0,     0,     0,     0,     0,     0,   100,    35,    53,
      46,    54,   117,   118,    55,    56,    57,   129,    59,     0,
       0,   120,   126,   130,     0,     0,   131,     0,   160,   142,
     143,     0,    45,    49,     0,    47,    49,     0,   168,     0,
     176,   194,    80,     0,    82,    91,     0,     0,   203,     0,
       0,     0,     0,     0,     0,     0,     0,    33,    34,     0,
     208,   210,     0,     0,     0,     0,   216,   217,     0,    99,
       0,    35,    94,     0,   103,   104,   105,   106,   107,     0,
     108,     0,   109,   110,    67,     0,   113,    35,   188,     0,
     197,    39,    77,    74,     0,     0,    68,    69,    70,    71,
      72,    35,    40,    47,   134,     0,   133,   135,     0,   132,
     127,   161,   145,     0,     0,     0,     0,    37,     0,    49,
       0,   164,    49,     0,     0,    47,     0,     0,   179,     0,
      81,    92,    93,     0,    83,    84,    85,    86,    87,    88,
      90,    89,     0,     0,   214,     0,   199,     0,     0,     0,
      47,   224,     0,   101,   111,   114,     0,     0,   184,     0,
      75,     0,     0,     0,   136,   137,   140,   141,   138,   139,
     157,    35,    35,   155,   156,     0,    50,   162,   158,   167,
     169,     0,     0,     0,     0,     0,   200,     0,     0,     0,
      43,     0,    97,     0,     0,   102,    35,   189,     0,   186,
       0,    61,     0,   115,   116,     0,     0,   159,     0,     0,
     170,   175,     0,   183,   180,   181,   182,   178,   195,   201,
       0,   148,   209,    42,     0,     0,   221,   222,    47,   185,
     191,    76,    39,   153,     0,   165,   166,   177,     0,   204,
       0,     0,    44,    98,     0,   219,     0,     0,   146,     0,
       0,   202,     0,     0,     0,   149,   205,   220,     0,    47,
     173,   192,    39,   148,   150,   151,   152,     0,   218,     0,
     147,    39,     0,   223,   154,   206
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     1,     4,     5,     6,    37,   322,   187,    81,   156,
     113,   339,   159,   139,   268,    96,   140,    39,    71,    40,
      41,    42,   114,   115,   116,   130,    43,   219,   128,   133,
      44,    45,    46,    98,    99,   100,   101,   102,    47,   269,
     182,   183,   383,   391,   323,   324,   325,   270,    48,   185,
      49,    50,   275,    51,    52,    53,   190,   278,   334,   367,
      54,    69,    55,   307,   239,   397,    56,   110,   279,    57,
      70,    58,   125,   370,   388,    59,   283,    60,   417,    61,
     118,   293,    62,   121,    63,   122,    64,   220,   409,   395,
      65,    66
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -234
static const short yypact[] =
{
    -234,    29,  -234,  -234,  -234,  -234,   393,  -234,  -234,    13,
    -234,  -234,  -234,  -234,  -234,   516,    14,   262,   175,   408,
      23,   408,    64,  -234,    14,  -234,   145,    38,  -234,   164,
    -234,    84,    86,  -234,    96,    11,    93,  -234,  -234,  -234,
    -234,  -234,   211,  -234,    26,  -234,  -234,  -234,  -234,  -234,
    -234,  -234,   188,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,    10,   103,    32,
     109,    14,  -234,  -234,   516,   105,   115,   116,   516,   177,
    -234,   107,  -234,  -234,  -234,   516,   516,  -234,  -234,  -234,
    -234,   516,   516,    10,   516,    10,  -234,   335,  -234,    48,
     188,   434,   354,   138,   174,   111,  -234,    10,    96,    88,
     149,   145,   145,    -8,   632,   585,  -234,    15,   150,  -234,
     632,   160,    81,  -234,   168,   114,  -234,   495,   165,   253,
    -234,  -234,   516,   271,  -234,    31,  -234,    96,  -234,   170,
     188,   181,  -234,  -234,   189,   188,   360,   192,   516,   516,
    -234,   516,   516,   516,   516,   516,   172,  -234,    96,  -234,
     632,  -234,   632,   632,  -234,  -234,  -234,  -234,  -234,   579,
     595,  -234,   188,  -234,   478,   599,  -234,   188,  -234,  -234,
    -234,   203,   516,    17,   190,   188,    63,   522,   178,   516,
     171,  -234,   360,   594,   205,  -234,    10,    10,  -234,   145,
     145,   145,   145,   145,   145,   145,   145,  -234,  -234,   516,
    -234,  -234,   228,   218,   233,   516,  -234,  -234,     5,  -234,
     516,    96,  -234,   499,  -234,  -234,  -234,  -234,  -234,   319,
    -234,   235,  -234,  -234,  -234,   234,   271,    96,  -234,   163,
    -234,    10,  -234,  -234,   505,   373,    25,    25,   195,   195,
    -234,    96,   271,   188,  -234,   605,  -234,  -234,   609,  -234,
     188,  -234,  -234,   516,   516,   516,   516,    14,    16,   191,
     242,  -234,   191,   243,   516,   188,   532,   516,  -234,   196,
    -234,  -234,  -234,   197,  -234,  -234,  -234,  -234,  -234,  -234,
     603,   603,   543,   169,  -234,   516,  -234,   260,   516,   568,
     188,  -234,   516,   632,  -234,  -234,   230,   182,    67,   251,
    -234,   516,   252,   264,  -234,  -234,   632,   632,   632,   632,
    -234,    96,    96,  -234,  -234,   265,  -234,  -234,   120,  -234,
     632,   272,   516,   538,   128,   275,   207,   516,   282,    46,
     632,   516,   632,   516,   288,   632,    96,  -234,    10,  -234,
     289,  -234,   512,  -234,  -234,   516,   516,  -234,   293,   300,
    -234,   632,   516,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
     301,   601,  -234,  -234,   516,   527,   596,  -234,   188,  -234,
    -234,  -234,   177,   246,   548,  -234,  -234,   632,   247,  -234,
     452,   240,   632,  -234,   516,   225,   321,   248,  -234,   516,
     516,  -234,   516,   516,   516,   632,  -234,   632,   516,   188,
    -234,  -234,   177,   601,   632,   632,   632,   263,   632,   326,
    -234,    10,   327,  -234,  -234,  -234
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
    -234,  -234,  -234,  -234,  -234,  -234,   220,   -33,   -22,  -233,
      -6,  -234,   -73,  -140,  -170,   -86,    -5,  -234,  -234,  -234,
     -27,  -234,   -11,   -75,   241,  -234,   306,  -234,   -98,   -88,
     239,  -234,  -234,   254,  -234,   -12,   257,   -55,  -234,  -234,
    -234,  -234,  -234,   -57,  -234,  -234,    30,    33,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,    49,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,  -234,
    -234,  -234
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -159
static const short yytable[] =
{
      38,   127,   109,    68,    79,   241,   104,   105,   309,   107,
     188,   168,    97,   161,    72,   136,   273,    73,   120,    11,
      80,   165,    11,   119,   129,  -158,   106,   298,    74,     2,
      75,    76,    77,     3,     7,    11,   193,   195,   138,   235,
     207,   207,   170,   321,   117,   272,   175,   263,   264,   145,
     236,   265,   266,   137,   168,   151,   152,   153,   154,   155,
     253,   141,    78,   146,   373,   196,   197,   150,   374,   252,
     208,   208,    11,   157,   160,   160,    11,   153,   154,   155,
     162,   163,    20,   160,    91,    92,   168,   164,   168,   166,
     177,   108,   123,   263,   264,   172,   174,   265,   266,   326,
     192,    38,   328,   124,    32,    67,   126,    32,   234,   262,
     132,   142,    35,   313,   255,   144,   218,   267,   143,   258,
      32,   223,   147,   300,   284,   285,   286,   287,   288,   289,
     290,   291,   148,   149,   158,   331,   363,   244,   245,   306,
     246,   247,   248,   249,   250,   207,   178,   321,    72,   398,
     189,    73,   184,   312,    11,   191,   210,    32,   177,   348,
     344,    32,   111,   177,    75,    76,    77,    72,   211,   212,
      73,   160,   260,    11,   168,   208,   218,   213,   276,   420,
     138,    74,   214,    75,    76,    77,    11,   221,   424,   238,
     281,   282,   364,   365,   366,   237,    78,   240,   292,   251,
      83,    84,    85,    86,   297,    87,    88,    89,    90,   299,
     243,   261,   179,   180,     7,    78,   181,   103,   303,   134,
     267,   263,   264,   280,   112,   265,   266,   151,   152,   153,
     154,   155,   271,   135,   277,   157,   294,   274,   396,    32,
     295,   296,   305,   177,   304,   320,   177,   308,   378,   155,
     327,   329,   316,   317,   318,   319,   346,   338,    32,   351,
     353,   222,    20,   330,   335,   336,   333,   347,   399,   419,
      82,    32,   354,   357,    83,    84,    85,    86,   242,   369,
     360,    93,   341,   368,   340,    94,    95,   342,   355,   356,
     372,   345,    87,    88,    89,    90,   377,   380,    91,    92,
     352,   385,   349,   151,   152,   153,   154,   155,   386,   389,
     151,   152,   153,   154,   155,   401,   224,   225,   226,   227,
     228,   361,    72,   406,   408,    73,   371,   229,   230,   410,
     375,   422,   376,   411,   423,   425,    74,   209,    75,    76,
      77,   131,   379,   167,   382,   384,   186,    83,    84,    85,
      86,   387,   194,   171,   169,    93,   421,   350,   358,    94,
      95,   359,   176,   392,   231,    87,    88,    89,    90,   302,
      78,    91,    92,     0,   232,   233,   157,     0,   242,   405,
       0,     0,     0,   407,    87,    88,    89,    90,   412,   413,
       0,   414,   415,   416,     0,   311,     7,   418,     8,     0,
       9,    10,    11,     0,    12,     0,   157,     0,     0,    13,
     151,   152,   153,   154,   155,   157,    14,    15,     0,     0,
       0,    16,    17,   151,   152,   153,   154,   155,    93,     0,
       0,     0,    94,    95,    18,     0,     0,    19,    87,    88,
      89,    90,   173,     0,    20,     0,    83,    84,    85,    86,
       0,    21,     0,    22,    23,    72,     0,     0,    73,     0,
      24,     0,    25,    26,    87,    88,    89,    90,     0,    74,
       0,    75,    76,    77,     0,    27,     0,     0,     0,     0,
      28,     0,    29,    30,    31,     0,   257,    32,    33,    34,
      83,    84,    85,    86,    35,    36,     0,     0,    72,     0,
       0,    73,   402,    78,   403,   404,     0,     0,    87,    88,
      89,    90,   215,     0,    75,    76,    77,   301,     0,    72,
       0,     0,    73,   310,     0,    72,   216,    93,    73,   217,
     381,    94,    95,    74,     0,    75,    76,    77,     0,   215,
       0,    75,    76,    77,     0,   393,    78,     0,     0,   151,
     152,   153,   154,   155,   332,   151,   152,   153,   154,   155,
     362,     0,   151,   152,   153,   154,   155,    78,     0,   337,
       0,    93,     0,    78,   400,    94,    95,   151,   152,   153,
     154,   155,   151,   152,   153,   154,   155,   254,   151,   152,
     153,   154,   155,   151,   152,   153,   154,   155,   151,   152,
     153,   154,   155,   256,   343,     0,     0,   259,     0,    87,
      88,    89,    90,   314,     0,     0,     0,   315,   151,   152,
     153,   154,   155,     0,     0,    87,    88,    89,    90,    87,
      88,    89,    90,   394,     0,    87,    88,    89,    90,    87,
      88,    89,    90,     0,   390,     0,   151,   152,   153,   154,
     155,   151,   152,   153,   154,   155,   198,     0,   199,   200,
     201,   202,   203,   204,     0,   205,   206,   199,   200,   201,
     202,   203,   204,     0,   205,   206,   199,   200,   201,   202,
     203,   204,   151,   152,   153,   154,   155
};

static const short yycheck[] =
{
       6,    34,    24,     9,    15,   145,    18,    19,   241,    21,
     108,    97,    17,    86,     3,    42,   186,     6,    29,     9,
       6,    94,     9,    29,    35,     8,     3,    22,    17,     0,
      19,    20,    21,     4,     3,     9,   111,   112,    44,   137,
      25,    25,    97,    27,     6,   185,   101,    30,    31,    71,
     138,    34,    35,    27,   140,    50,    51,    52,    53,    54,
     158,    67,    51,    74,    18,    73,    74,    78,    22,   157,
      55,    55,     9,    79,    85,    86,     9,    52,    53,    54,
      91,    92,    51,    94,    36,    37,   172,    93,   174,    95,
     102,    27,     8,    30,    31,   100,   101,    34,    35,   269,
     111,   107,   272,    17,    94,    92,    10,    94,   135,   182,
      17,     8,   101,   253,   169,     6,   127,   100,    86,   174,
      94,   132,    17,   221,   199,   200,   201,   202,   203,   204,
     205,   206,    17,    17,    27,   275,     8,   148,   149,   237,
     151,   152,   153,   154,   155,    25,     8,    27,     3,   382,
      62,     6,    41,   251,     9,     6,     6,    94,   170,    92,
     300,    94,    17,   175,    19,    20,    21,     3,     8,    88,
       6,   182,   177,     9,   260,    55,   187,     9,   189,   412,
     186,    17,    68,    19,    20,    21,     9,    22,   421,     8,
     196,   197,    64,    65,    66,    25,    51,     8,   209,    27,
      12,    13,    14,    15,   215,    30,    31,    32,    33,   220,
      18,     8,    38,    39,     3,    51,    42,    42,   229,     8,
     100,    30,    31,    18,    79,    34,    35,    50,    51,    52,
      53,    54,    42,    22,    63,   241,     8,    59,   378,    94,
      22,     8,     8,   255,     9,   267,   258,    84,   346,    54,
       8,     8,   263,   264,   265,   266,    26,    88,    94,     8,
       8,     8,    51,   274,    68,    68,   277,    85,    22,   409,
       8,    94,     8,     8,    12,    13,    14,    15,    18,    72,
       8,    93,    22,     8,   295,    97,    98,   298,   321,   322,
       8,   302,    30,    31,    32,    33,     8,     8,    36,    37,
     311,     8,   308,    50,    51,    52,    53,    54,     8,     8,
      50,    51,    52,    53,    54,    68,    45,    46,    47,    48,
      49,   332,     3,    83,    99,     6,   337,    56,    57,     8,
     341,    68,   343,    85,     8,     8,    17,   117,    19,    20,
      21,    35,   348,     8,   355,   356,   107,    12,    13,    14,
      15,   362,   111,    99,    97,    93,   413,   308,   328,    97,
      98,   328,     8,   374,    93,    30,    31,    32,    33,    50,
      51,    36,    37,    -1,   103,   104,   382,    -1,    18,   390,
      -1,    -1,    -1,   394,    30,    31,    32,    33,   399,   400,
      -1,   402,   403,   404,    -1,    22,     3,   408,     5,    -1,
       7,     8,     9,    -1,    11,    -1,   412,    -1,    -1,    16,
      50,    51,    52,    53,    54,   421,    23,    24,    -1,    -1,
      -1,    28,    29,    50,    51,    52,    53,    54,    93,    -1,
      -1,    -1,    97,    98,    41,    -1,    -1,    44,    30,    31,
      32,    33,     8,    -1,    51,    -1,    12,    13,    14,    15,
      -1,    58,    -1,    60,    61,     3,    -1,    -1,     6,    -1,
      67,    -1,    69,    70,    30,    31,    32,    33,    -1,    17,
      -1,    19,    20,    21,    -1,    82,    -1,    -1,    -1,    -1,
      87,    -1,    89,    90,    91,    -1,     8,    94,    95,    96,
      12,    13,    14,    15,   101,   102,    -1,    -1,     3,    -1,
      -1,     6,    50,    51,    52,    53,    -1,    -1,    30,    31,
      32,    33,    17,    -1,    19,    20,    21,    18,    -1,     3,
      -1,    -1,     6,    18,    -1,     3,    31,    93,     6,    34,
      18,    97,    98,    17,    -1,    19,    20,    21,    -1,    17,
      -1,    19,    20,    21,    -1,    18,    51,    -1,    -1,    50,
      51,    52,    53,    54,    22,    50,    51,    52,    53,    54,
      22,    -1,    50,    51,    52,    53,    54,    51,    -1,    26,
      -1,    93,    -1,    51,    26,    97,    98,    50,    51,    52,
      53,    54,    50,    51,    52,    53,    54,     8,    50,    51,
      52,    53,    54,    50,    51,    52,    53,    54,    50,    51,
      52,    53,    54,     8,    36,    -1,    -1,     8,    -1,    30,
      31,    32,    33,     8,    -1,    -1,    -1,     8,    50,    51,
      52,    53,    54,    -1,    -1,    30,    31,    32,    33,    30,
      31,    32,    33,    37,    -1,    30,    31,    32,    33,    30,
      31,    32,    33,    -1,    43,    -1,    50,    51,    52,    53,
      54,    50,    51,    52,    53,    54,    71,    -1,    73,    74,
      75,    76,    77,    78,    -1,    80,    81,    73,    74,    75,
      76,    77,    78,    -1,    80,    81,    73,    74,    75,    76,
      77,    78,    50,    51,    52,    53,    54
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   106,     0,     4,   107,   108,   109,     3,     5,     7,
       8,     9,    11,    16,    23,    24,    28,    29,    41,    44,
      51,    58,    60,    61,    67,    69,    70,    82,    87,    89,
      90,    91,    94,    95,    96,   101,   102,   110,   115,   122,
     124,   125,   126,   131,   135,   136,   137,   143,   153,   155,
     156,   158,   159,   160,   165,   167,   171,   174,   176,   180,
     182,   184,   187,   189,   191,   195,   196,    92,   115,   166,
     175,   123,     3,     6,    17,    19,    20,    21,    51,   127,
       6,   113,     8,    12,    13,    14,    15,    30,    31,    32,
      33,    36,    37,    93,    97,    98,   120,   121,   138,   139,
     140,   141,   142,    42,   140,   140,     3,   140,    27,   113,
     172,    17,    79,   115,   127,   128,   129,     6,   185,   115,
     127,   188,   190,     8,    17,   177,    10,   112,   133,   127,
     130,   131,    17,   134,     8,    22,   125,    27,   115,   118,
     121,   115,     8,    86,     6,   113,   127,    17,    17,    17,
     127,    50,    51,    52,    53,    54,   114,   115,    27,   117,
     127,   117,   127,   127,   115,   117,   115,     8,   120,   141,
     142,   138,   121,     8,   121,   142,     8,   140,     8,    38,
      39,    42,   145,   146,    41,   154,   135,   112,   133,    62,
     161,     6,   127,   128,   129,   128,    73,    74,    71,    73,
      74,    75,    76,    77,    78,    80,    81,    25,    55,   111,
       6,     8,    88,     9,    68,    17,    31,    34,   127,   132,
     192,    22,     8,   127,    45,    46,    47,    48,    49,    56,
      57,    93,   103,   104,   125,   133,   134,    25,     8,   169,
       8,   118,    18,    18,   127,   127,   127,   127,   127,   127,
     127,    27,   134,   133,     8,   142,     8,     8,   142,     8,
     121,     8,   117,    30,    31,    34,    35,   100,   119,   144,
     152,    42,   118,   119,    59,   157,   127,    63,   162,   173,
      18,   115,   115,   181,   128,   128,   128,   128,   128,   128,
     128,   128,   127,   186,     8,    22,     8,   127,    22,   127,
     133,    18,    50,   127,     9,     8,   133,   168,    84,   114,
      18,    22,   133,   118,     8,     8,   127,   127,   127,   127,
     113,    27,   111,   149,   150,   151,   119,     8,   119,     8,
     127,   118,    22,   127,   163,    68,    68,    26,    88,   116,
     127,    22,   127,    36,   118,   127,    26,    85,    92,   115,
     166,     8,   127,     8,     8,   112,   112,     8,   151,   152,
       8,   127,    22,     8,    64,    65,    66,   164,     8,    72,
     178,   127,     8,    18,    22,   127,   127,     8,   133,   115,
       8,    18,   127,   147,   127,     8,     8,   127,   179,     8,
      43,   148,   127,    18,    37,   194,   118,   170,   114,    22,
      26,    68,    50,    52,    53,   127,    83,   127,    99,   193,
       8,    85,   127,   127,   127,   127,   127,   183,   127,   118,
     114,   148,    68,     8,   114,     8
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 191 "grap.y"
    {
                if ( !the_graph)
		    the_graph = initial_graph();
		the_graph->init();
		init_dict();
		first_line = true;
		the_graph->begin_block(yyvsp[0].String);
	    }
    break;

  case 5:
#line 199 "grap.y"
    {
		the_graph->draw(0);
		the_graph->end_block();
	    }
    break;

  case 6:
#line 205 "grap.y"
    { }
    break;

  case 7:
#line 207 "grap.y"
    { }
    break;

  case 8:
#line 211 "grap.y"
    { first_line = false;}
    break;

  case 9:
#line 213 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 10:
#line 215 "grap.y"
    {
		first_line = false;
		the_graph->queue_frame();
		the_graph->is_visible(true);
	    }
    break;

  case 11:
#line 221 "grap.y"
    { first_line = false; }
    break;

  case 12:
#line 223 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 13:
#line 225 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 14:
#line 227 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 15:
#line 229 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 16:
#line 231 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 17:
#line 233 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 18:
#line 235 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 19:
#line 237 "grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 20:
#line 239 "grap.y"
    { first_line = false;}
    break;

  case 21:
#line 241 "grap.y"
    { first_line = false;}
    break;

  case 22:
#line 243 "grap.y"
    { first_line = false;}
    break;

  case 23:
#line 245 "grap.y"
    { first_line = false;}
    break;

  case 24:
#line 247 "grap.y"
    { first_line = false;}
    break;

  case 25:
#line 249 "grap.y"
    { first_line = false;}
    break;

  case 26:
#line 251 "grap.y"
    { first_line = false;}
    break;

  case 27:
#line 253 "grap.y"
    { first_line = false;}
    break;

  case 28:
#line 255 "grap.y"
    { first_line = false;}
    break;

  case 29:
#line 257 "grap.y"
    { first_line = false;}
    break;

  case 30:
#line 259 "grap.y"
    { first_line = false;}
    break;

  case 31:
#line 261 "grap.y"
    { first_line = false;}
    break;

  case 35:
#line 270 "grap.y"
    { yyval.coordptr= defcoord; }
    break;

  case 36:
#line 272 "grap.y"
    { yyval.coordptr= yyvsp[0].coordptr;}
    break;

  case 37:
#line 276 "grap.y"
    { yyval.String = 0; }
    break;

  case 38:
#line 278 "grap.y"
    { yyval.String = yyvsp[0].String; }
    break;

  case 39:
#line 282 "grap.y"
    { yyval.ds = 0; }
    break;

  case 40:
#line 284 "grap.y"
    {
		yyval.ds = new DisplayString(*yyvsp[-1].String, yyvsp[0].stringmod.just, yyvsp[0].stringmod.size, yyvsp[0].stringmod.rel, 
		    yyvsp[0].stringmod.clip, yyvsp[0].stringmod.color);
	    }
    break;

  case 41:
#line 292 "grap.y"
    { yyval.String = yyvsp[0].String; }
    break;

  case 42:
#line 294 "grap.y"
    {
		 if ( do_sprintf ) {
		     const int len = yyvsp[-3].String->length() < 128 ? 256 : 2*yyvsp[-3].String->length();
		     char *buf = new char[len];

		     // I really dislike this, but I dislike trying to do it
		     // incrementally more.
		     switch (yyvsp[-1].double_vec->size()) {
			case 0:
			    snprintf(buf, len, yyvsp[-3].String->c_str());
			    break;
			case 1:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0]);
			    break;
			case 2:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1]);
			    break;
			case 3:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2]);
			    break;
			case 4:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3]);
			    break;
			case 5:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4]);
			    break;
			case 6:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5]);
			    break;
			case 7:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6]);
			    break;
			case 8:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7]);
			    break;
			case 9:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7], (*yyvsp[-1].double_vec)[8]);
			    break;
			default:
			    cerr << "more that 10 arguments to sprintf.  " << 
				"Ignoring more than 10." << endl;
			case 10:
			    snprintf(buf, len, yyvsp[-3].String->c_str(), (*yyvsp[-1].double_vec)[0], (*yyvsp[-1].double_vec)[1], 
				(*yyvsp[-1].double_vec)[2], (*yyvsp[-1].double_vec)[3], (*yyvsp[-1].double_vec)[4], (*yyvsp[-1].double_vec)[5], 
				(*yyvsp[-1].double_vec)[6], (*yyvsp[-1].double_vec)[7], (*yyvsp[-1].double_vec)[8], (*yyvsp[-1].double_vec)[9]);
			    break;
		     }
		     delete yyvsp[-1].double_vec; delete yyvsp[-3].String;

		     yyval.String = new string(buf);
		     delete[] buf;
		 }
		 else yyval.String = yyvsp[-3].String;
	     }
    break;

  case 43:
#line 362 "grap.y"
    {
		yyval.double_vec = new doublevec;
		yyval.double_vec->push_back(yyvsp[0].num);
	    }
    break;

  case 44:
#line 367 "grap.y"
    {
		yyval.double_vec = yyvsp[-2].double_vec;
		yyval.double_vec->push_back(yyvsp[0].num);
	    }
    break;

  case 45:
#line 374 "grap.y"
    { yyval.num = 0; }
    break;

  case 46:
#line 376 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 47:
#line 380 "grap.y"
    { yyval.lined = new linedesc; yyval.lined = 0;}
    break;

  case 48:
#line 382 "grap.y"
    {  yyval.lined = yyvsp[0].lined;}
    break;

  case 49:
#line 386 "grap.y"
    { yyval.shift_list = new shiftlist;}
    break;

  case 50:
#line 388 "grap.y"
    {
		yyval.shift_list = yyvsp[0].shift_list;
		yyval.shift_list->push_back(yyvsp[-1].shift);
	    }
    break;

  case 51:
#line 397 "grap.y"
    { yyval.lined = new linedesc(invis); }
    break;

  case 52:
#line 399 "grap.y"
    { yyval.lined = new linedesc(solid); }
    break;

  case 53:
#line 401 "grap.y"
    { yyval.lined = new linedesc(dotted, yyvsp[0].num); }
    break;

  case 54:
#line 403 "grap.y"
    { yyval.lined = new linedesc(dashed, yyvsp[0].num); }
    break;

  case 55:
#line 405 "grap.y"
    { yyval.lined = new linedesc(def, 0, yyvsp[0].String); }
    break;

  case 56:
#line 407 "grap.y"
    { yyval.lined = new linedesc(def, 0, 0, yyvsp[0].num); }
    break;

  case 57:
#line 409 "grap.y"
    { yyval.lined = new linedesc(def, 0, 0, 0, yyvsp[0].String); }
    break;

  case 58:
#line 414 "grap.y"
    { yyval.lined = yyvsp[0].lined; }
    break;

  case 59:
#line 416 "grap.y"
    { yyval.lined = combine_linedesc(yyvsp[-1].lined, yyvsp[0].lined); }
    break;

  case 60:
#line 420 "grap.y"
    { lex_no_coord(); }
    break;

  case 61:
#line 421 "grap.y"
    { draw_statement(yyvsp[-3].String, yyvsp[-2].lined, yyvsp[-1].ds); lex_coord_ok(); }
    break;

  case 62:
#line 426 "grap.y"
    { num_list(yyvsp[-1].double_list); }
    break;

  case 63:
#line 431 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 64:
#line 434 "grap.y"
    { yyval.num = -yyvsp[0].num; }
    break;

  case 65:
#line 439 "grap.y"
    {
		yyval.double_list = new doublelist;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 66:
#line 444 "grap.y"
    {
		yyval.double_list = yyvsp[-1].double_list;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 67:
#line 449 "grap.y"
    {
		yyval.double_list = yyvsp[-2].double_list;
		yyval.double_list->push_back(yyvsp[0].num);
	    }
    break;

  case 68:
#line 457 "grap.y"
    { yyval.num = yyvsp[-2].num + yyvsp[0].num; }
    break;

  case 69:
#line 459 "grap.y"
    { yyval.num = yyvsp[-2].num - yyvsp[0].num; }
    break;

  case 70:
#line 461 "grap.y"
    { yyval.num = yyvsp[-2].num * yyvsp[0].num; }
    break;

  case 71:
#line 463 "grap.y"
    { yyval.num = yyvsp[-2].num / yyvsp[0].num; }
    break;

  case 72:
#line 465 "grap.y"
    { yyval.num = pow(yyvsp[-2].num,yyvsp[0].num);}
    break;

  case 73:
#line 467 "grap.y"
    { yyval.num = - yyvsp[0].num;}
    break;

  case 74:
#line 469 "grap.y"
    { yyval.num = ( yyvsp[-2].val >=0 && yyvsp[-2].val < NF0 ) ? jtf0[yyvsp[-2].val]() : 0; }
    break;

  case 75:
#line 471 "grap.y"
    { yyval.num = ( yyvsp[-3].val >=0 && yyvsp[-3].val < NF1 ) ? jtf1[yyvsp[-3].val](yyvsp[-1].num) : 0; }
    break;

  case 76:
#line 473 "grap.y"
    { yyval.num = ( yyvsp[-5].val >=0 && yyvsp[-5].val < NF2 ) ? jtf2[yyvsp[-5].val](yyvsp[-3].num, yyvsp[-1].num) : 0; }
    break;

  case 77:
#line 475 "grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 78:
#line 477 "grap.y"
    {
		doubleDictionary::iterator di;
		
		if ( (di = vars.find(*yyvsp[0].String)) != vars.end())
		    yyval.num = *(*di).second;
		else {
		    cerr << *yyvsp[0].String << " is uninitialized, using 0.0" << endl;
		    yyval.num = 0.0;
		}

		delete yyvsp[0].String;
	     }
    break;

  case 79:
#line 490 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 80:
#line 495 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 81:
#line 497 "grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 82:
#line 499 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 83:
#line 504 "grap.y"
    { yyval.num = (yyvsp[-2].num == yyvsp[0].num); }
    break;

  case 84:
#line 506 "grap.y"
    { yyval.num = (yyvsp[-2].num != yyvsp[0].num); }
    break;

  case 85:
#line 508 "grap.y"
    { yyval.num = (yyvsp[-2].num < yyvsp[0].num); }
    break;

  case 86:
#line 510 "grap.y"
    { yyval.num = (yyvsp[-2].num > yyvsp[0].num); }
    break;

  case 87:
#line 512 "grap.y"
    { yyval.num = (yyvsp[-2].num <= yyvsp[0].num); }
    break;

  case 88:
#line 514 "grap.y"
    { yyval.num = (yyvsp[-2].num >= yyvsp[0].num); }
    break;

  case 89:
#line 516 "grap.y"
    { yyval.num = (yyvsp[-2].num && yyvsp[0].num); }
    break;

  case 90:
#line 518 "grap.y"
    { yyval.num = (yyvsp[-2].num || yyvsp[0].num); }
    break;

  case 91:
#line 520 "grap.y"
    { yyval.num = ! ( (int) yyvsp[0].num); }
    break;

  case 92:
#line 522 "grap.y"
    { yyval.num = (*yyvsp[-2].String == *yyvsp[0].String); delete yyvsp[-2].String; delete yyvsp[0].String; }
    break;

  case 93:
#line 524 "grap.y"
    { yyval.num = (*yyvsp[-2].String != *yyvsp[0].String); delete yyvsp[-2].String; delete yyvsp[0].String; }
    break;

  case 94:
#line 528 "grap.y"
    { yyval.num = yyvsp[-1].num; }
    break;

  case 95:
#line 529 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 96:
#line 534 "grap.y"
    { yyval.num = assignment_statement(yyvsp[-1].String, yyvsp[0].num);  }
    break;

  case 97:
#line 539 "grap.y"
    { yyval.pt = new point(yyvsp[-2].num, yyvsp[0].num, 0); }
    break;

  case 98:
#line 541 "grap.y"
    { yyval.pt = new point(yyvsp[-3].num, yyvsp[-1].num, 0); }
    break;

  case 99:
#line 545 "grap.y"
    { yyval.pt = new point(yyvsp[0].pt->x, yyvsp[0].pt->y, yyvsp[-1].coordptr); delete yyvsp[0].pt; }
    break;

  case 100:
#line 549 "grap.y"
    {
		yyval.stringmod.size = 0;
		yyval.stringmod.rel =0;
		yyval.stringmod.just = (unaligned_default) ? unaligned : 0;
		yyval.stringmod.clip = clip_default;
		yyval.stringmod.color = 0;
	    }
    break;

  case 101:
#line 557 "grap.y"
    { yyval.stringmod.size = yyvsp[0].num; yyval.stringmod.rel = (yyvsp[0].num<0); }
    break;

  case 102:
#line 559 "grap.y"
    { yyval.stringmod.size = yyvsp[0].num; yyval.stringmod.rel = 1; }
    break;

  case 103:
#line 561 "grap.y"
    { yyval.stringmod.just |= (int) ljust; }
    break;

  case 104:
#line 563 "grap.y"
    { yyval.stringmod.just |= (int) rjust; }
    break;

  case 105:
#line 565 "grap.y"
    { yyval.stringmod.just |= (int) above; }
    break;

  case 106:
#line 567 "grap.y"
    { yyval.stringmod.just |= (int) below; }
    break;

  case 107:
#line 569 "grap.y"
    { yyval.stringmod.just |= (int) aligned; }
    break;

  case 108:
#line 571 "grap.y"
    { yyval.stringmod.just |= (int) unaligned; }
    break;

  case 109:
#line 573 "grap.y"
    { yyval.stringmod.clip = true; }
    break;

  case 110:
#line 575 "grap.y"
    { yyval.stringmod.clip = false; }
    break;

  case 111:
#line 577 "grap.y"
    { yyval.stringmod.color = yyvsp[0].String; }
    break;

  case 112:
#line 582 "grap.y"
    {
		DisplayString *s;

		s = new DisplayString(*yyvsp[-1].String,yyvsp[0].stringmod.just,yyvsp[0].stringmod.size, yyvsp[0].stringmod.rel, 
		    yyvsp[0].stringmod.clip, yyvsp[0].stringmod.color);
		delete yyvsp[-1].String;
		yyval.string_list = new stringlist;
		yyval.string_list->push_back(s);
	    }
    break;

  case 113:
#line 592 "grap.y"
    { yyval.string_list = combine_strings(yyvsp[-2].string_list, yyvsp[-1].String, yyvsp[0].stringmod); }
    break;

  case 114:
#line 597 "grap.y"
    {
  		the_graph->new_plot(yyvsp[-3].string_list,yyvsp[-1].pt);
	    }
    break;

  case 115:
#line 601 "grap.y"
    { plot_statement(yyvsp[-4].num, yyvsp[-3].ds, yyvsp[-1].pt); }
    break;

  case 116:
#line 606 "grap.y"
    { next_statement(yyvsp[-4].String, yyvsp[-2].pt, yyvsp[-1].lined); }
    break;

  case 117:
#line 611 "grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->ht = yyvsp[0].num;
		yyval.frameptr->wid = 0;
	    }
    break;

  case 118:
#line 617 "grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->wid = yyvsp[0].num;
		yyval.frameptr->ht = 0;
	    }
    break;

  case 119:
#line 626 "grap.y"
    { yyval.frameptr = yyvsp[0].frameptr; }
    break;

  case 120:
#line 628 "grap.y"
    {
		yyval.frameptr = yyvsp[-1].frameptr;
		// Fill in non-default ht/wid
		
		if ( yyvsp[0].frameptr->ht != 0 ) yyval.frameptr->ht = yyvsp[0].frameptr->ht;
		if ( yyvsp[0].frameptr->wid != 0 ) yyval.frameptr->wid = yyvsp[0].frameptr->wid;
	    }
    break;

  case 121:
#line 639 "grap.y"
    { yyval.side = top_side;}
    break;

  case 122:
#line 641 "grap.y"
    { yyval.side= bottom_side;}
    break;

  case 123:
#line 643 "grap.y"
    { yyval.side = left_side;}
    break;

  case 124:
#line 645 "grap.y"
    { yyval.side = right_side; }
    break;

  case 125:
#line 650 "grap.y"
    {
		// This rule combines the explicit size settings with
		// the defaults. We create a new frame to have access
		// to the default sizes without needing to code them
		// explicitly (they're always implicit in a default
		// frame). N. B. that frames created by size (and
		// size_elem) use 0 to indicate no change to the ht or
		// wid.
		
		yyval.frameptr = new frame;

		if ( yyvsp[0].frameptr->ht != 0) yyval.frameptr->ht = yyvsp[0].frameptr->ht;
		if ( yyvsp[0].frameptr->wid != 0) yyval.frameptr->wid = yyvsp[0].frameptr->wid;
		delete yyvsp[0].frameptr;
	    }
    break;

  case 126:
#line 667 "grap.y"
    {
		yyval.frameptr = new frame;
		yyval.frameptr->desc[yyvsp[-1].side] = *yyvsp[0].lined;
		delete yyvsp[0].lined;
	    }
    break;

  case 127:
#line 673 "grap.y"
    {
		if ( !yyvsp[-2].frameptr ) yyval.frameptr = new frame;
		else yyval.frameptr = yyvsp[-2].frameptr;
		
		yyval.frameptr->desc[yyvsp[-1].side] = *yyvsp[0].lined;
		delete yyvsp[0].lined;
	    }
    break;

  case 128:
#line 684 "grap.y"
    { process_frame(0, 0, 0); }
    break;

  case 129:
#line 686 "grap.y"
    { process_frame(yyvsp[-1].lined, 0, 0); }
    break;

  case 130:
#line 688 "grap.y"
    { process_frame(0, yyvsp[-1].frameptr, 0); }
    break;

  case 131:
#line 690 "grap.y"
    { process_frame(0, 0, yyvsp[-1].frameptr); }
    break;

  case 132:
#line 692 "grap.y"
    { process_frame(0, yyvsp[-2].frameptr, yyvsp[-1].frameptr); }
    break;

  case 133:
#line 694 "grap.y"
    { process_frame(yyvsp[-2].lined, 0, yyvsp[-1].frameptr); }
    break;

  case 134:
#line 696 "grap.y"
    { process_frame(yyvsp[-2].lined, yyvsp[-1].frameptr, 0); }
    break;

  case 135:
#line 698 "grap.y"
    { process_frame(yyvsp[-1].lined, yyvsp[-2].frameptr, 0); }
    break;

  case 136:
#line 700 "grap.y"
    { process_frame(yyvsp[-3].lined, yyvsp[-2].frameptr, yyvsp[-1].frameptr);}
    break;

  case 137:
#line 702 "grap.y"
    { process_frame(yyvsp[-2].lined, yyvsp[-3].frameptr, yyvsp[-1].frameptr); }
    break;

  case 138:
#line 707 "grap.y"
    { yyval.shift = new shiftdesc(top_side, yyvsp[0].num); }
    break;

  case 139:
#line 709 "grap.y"
    { yyval.shift = new shiftdesc(bottom_side, yyvsp[0].num); }
    break;

  case 140:
#line 711 "grap.y"
    { yyval.shift = new shiftdesc(left_side, yyvsp[0].num); }
    break;

  case 141:
#line 713 "grap.y"
    { yyval.shift = new shiftdesc(right_side, yyvsp[0].num); }
    break;

  case 142:
#line 718 "grap.y"
    { yyval.val = -1; }
    break;

  case 143:
#line 720 "grap.y"
    { yyval.val = 1; }
    break;

  case 144:
#line 724 "grap.y"
    { yyval.num = 0.125; }
    break;

  case 145:
#line 726 "grap.y"
    {
		if ( yyvsp[0].num == 0 ) yyval.num = yyvsp[-1].val * 0.125;
		else yyval.num = yyvsp[-1].val * yyvsp[0].num;
	    }
    break;

  case 146:
#line 734 "grap.y"
    { yyval.tick_list = ticklist_elem(yyvsp[-1].num, yyvsp[0].ds, 0); }
    break;

  case 147:
#line 736 "grap.y"
    { yyval.tick_list = ticklist_elem(yyvsp[-1].num, yyvsp[0].ds, yyvsp[-3].tick_list); }
    break;

  case 148:
#line 740 "grap.y"
    { yyval.by.op = PLUS; yyval.by.expr = 1; }
    break;

  case 149:
#line 742 "grap.y"
    {
		yyval.by.op = PLUS;
		if ( yyvsp[0].num != 0.0 ) yyval.by.expr = yyvsp[0].num;
		else yyval.by.expr = 1;
	    }
    break;

  case 150:
#line 748 "grap.y"
    { yyval.by.op = PLUS; yyval.by.expr = yyvsp[0].num; }
    break;

  case 151:
#line 750 "grap.y"
    { yyval.by.op = TIMES; yyval.by.expr = yyvsp[0].num; }
    break;

  case 152:
#line 752 "grap.y"
    { yyval.by.op = DIV; yyval.by.expr = yyvsp[0].num; }
    break;

  case 153:
#line 757 "grap.y"
    {
		yyval.tick_list = yyvsp[0].tick_list;
		for (ticklist::iterator t= yyvsp[0].tick_list->begin(); t != yyvsp[0].tick_list->end(); t++)
		    (*t)->c = yyvsp[-1].coordptr;
	    }
    break;

  case 154:
#line 766 "grap.y"
    { yyval.tick_list = tick_for(yyvsp[-5].coordptr, yyvsp[-4].num, yyvsp[-2].num, yyvsp[-1].by, yyvsp[0].ds); }
    break;

  case 155:
#line 770 "grap.y"
    { yyval.tick_list = yyvsp[0].tick_list;}
    break;

  case 156:
#line 772 "grap.y"
    { yyval.tick_list= yyvsp[0].tick_list; }
    break;

  case 157:
#line 777 "grap.y"
    {
		coordinateDictionary::iterator ci;

		if ( yyvsp[0].String ) {
		    ci = the_graph->coords.find(*yyvsp[0].String);
		    if ( ci != the_graph->coords.end()) 
			yyval.coordptr = (*ci).second;
		    else {
			yyerror("Name must name a coordinate space");
		    }
		}
		else yyval.coordptr = 0;
		
	    }
    break;

  case 158:
#line 792 "grap.y"
    {
		yyval.coordptr = 0;
            }
    break;

  case 159:
#line 799 "grap.y"
    { ticks_statement(yyvsp[-4].side, yyvsp[-3].num, yyvsp[-2].shift_list, yyvsp[-1].tick_list); }
    break;

  case 160:
#line 801 "grap.y"
    {
		for ( int i = 0; i< 4; i++ )
		    the_graph->base->tickdef[i].size = 0;
	    }
    break;

  case 161:
#line 806 "grap.y"
    { the_graph->base->tickdef[yyvsp[-2].side].size = 0; }
    break;

  case 162:
#line 808 "grap.y"
    {
		the_graph->base->tickdef[yyvsp[-3].side].size = yyvsp[-2].num;
		if ( yyvsp[-1].coordptr ) the_graph->base->tickdef[yyvsp[-3].side].c = yyvsp[-1].coordptr;
	    }
    break;

  case 163:
#line 815 "grap.y"
    { yyval.val = 0; }
    break;

  case 164:
#line 817 "grap.y"
    { yyval.val = 1; }
    break;

  case 165:
#line 822 "grap.y"
    {
		grid_statement(yyvsp[-5].side, yyvsp[-4].val, yyvsp[-3].lined, yyvsp[-2].shift_list, yyvsp[-1].tick_list);
	    }
    break;

  case 166:
#line 826 "grap.y"
    {
		grid_statement(yyvsp[-5].side, yyvsp[-4].val, yyvsp[-3].lined, yyvsp[-2].shift_list, 0);
		// Because turning on a grid on a given side disables
		// automatic tick generation there, this is sets up
		// that side with the proper coordinates.
		if ( yyvsp[-1].coordptr ) the_graph->base->griddef[yyvsp[-5].side].c = yyvsp[-1].coordptr;
	    }
    break;

  case 167:
#line 837 "grap.y"
    {
		shiftdesc *sd;

		for (stringlist::iterator s = yyvsp[-2].string_list->begin(); s != yyvsp[-2].string_list->end(); s++)
		    if ( ! ((*s)->j & unaligned) ) (*s)->j |= aligned;
		
		the_graph->base->label[yyvsp[-3].side] = yyvsp[-2].string_list;

		// Copy the label shifts into the frame
		while (!yyvsp[-1].shift_list->empty() ) {
		    sd = yyvsp[-1].shift_list->front();
		    yyvsp[-1].shift_list->pop_front();
		    the_graph->base->lshift[yyvsp[-3].side]->push_back(sd);
		}
		delete yyvsp[-1].shift_list;
	    }
    break;

  case 168:
#line 855 "grap.y"
    { yyval.num = 0.025; }
    break;

  case 169:
#line 857 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 170:
#line 862 "grap.y"
    {
		the_graph->new_circle(yyvsp[-3].pt,yyvsp[-2].num,yyvsp[-1].lined);
		delete yyvsp[-3].pt; delete yyvsp[-1].lined;
	    }
    break;

  case 171:
#line 870 "grap.y"
    { yyval.val = 1; }
    break;

  case 172:
#line 872 "grap.y"
    { yyval.val = 0; }
    break;

  case 173:
#line 877 "grap.y"
    { line_statement(yyvsp[-7].val, yyvsp[-6].lined, yyvsp[-4].pt, yyvsp[-2].pt, yyvsp[-1].lined); }
    break;

  case 174:
#line 881 "grap.y"
    { yyval.axistype.which=none; }
    break;

  case 175:
#line 883 "grap.y"
    { yyval.axistype = axis_description(x_axis, yyvsp[-2].num, yyvsp[0].num); }
    break;

  case 176:
#line 886 "grap.y"
    { yyval.axistype.which=none; }
    break;

  case 177:
#line 888 "grap.y"
    { yyval.axistype = axis_description(y_axis, yyvsp[-2].num, yyvsp[0].num); }
    break;

  case 178:
#line 893 "grap.y"
    { yyval.axisname = combine_logs(yyvsp[-1].axisname, yyvsp[0].axisname); }
    break;

  case 179:
#line 895 "grap.y"
    { yyval.axisname = none; }
    break;

  case 180:
#line 900 "grap.y"
    { yyval.axisname = x_axis; }
    break;

  case 181:
#line 902 "grap.y"
    { yyval.axisname = y_axis; }
    break;

  case 182:
#line 904 "grap.y"
    { yyval.axisname = both; }
    break;

  case 183:
#line 910 "grap.y"
    {
		coord_statement(yyvsp[-4].String, yyvsp[-3].axistype, yyvsp[-2].axistype, yyvsp[-1].axisname);
		delete yyvsp[-4].String;
	    }
    break;

  case 184:
#line 917 "grap.y"
    { yyval.copyd = 0; }
    break;

  case 185:
#line 919 "grap.y"
    {
		unquote(yyvsp[0].String);
		yyval.copyd = new copydesc;
		yyval.copyd->t = copydesc::until;
		yyval.copyd->s = yyvsp[0].String;
	    }
    break;

  case 186:
#line 926 "grap.y"
    {
		unquote(yyvsp[0].String);
		yyval.copyd = new copydesc;
		yyval.copyd->t = copydesc::fname;
		yyval.copyd->s = yyvsp[0].String;
	    }
    break;

  case 187:
#line 941 "grap.y"
    {
		unquote(yyvsp[-1].String);
		if (!include_file(yyvsp[-1].String, false)) return 0;
	    }
    break;

  case 188:
#line 946 "grap.y"
    {
		unquote(yyvsp[-1].String);
		lex_begin_copy(yyvsp[-1].String);
	    }
    break;

  case 189:
#line 951 "grap.y"
    {
		string s="";
		while (yyvsp[0].line_list && !yyvsp[0].line_list->empty() ) {
		    string *ss;
		    ss = yyvsp[0].line_list->front();
		    yyvsp[0].line_list->pop_front();
		    if ( ss ) {
			s+= *ss;
			s+= '\n';
			delete ss;
			ss = 0;
		    }
		}
		include_string(&s, 0, GINTERNAL);
		delete yyvsp[0].line_list;
	    }
    break;

  case 190:
#line 967 "grap.y"
    { lex_hunt_macro(); }
    break;

  case 191:
#line 968 "grap.y"
    {
		copydesc *c = 0; // To shut the compiler up about uninit
		if ( yyvsp[-5].copyd && yyvsp[-1].copyd ) {
		    delete yyvsp[-5].copyd;
		    delete yyvsp[-1].copyd;
		    yyerror("Only specify 1 until or filename\n");
		}
		else c = (yyvsp[-5].copyd) ? yyvsp[-5].copyd : yyvsp[-1].copyd;
		if ( c ) {
		    // lex_begin_copy takes command of the string that's
		    // passed to it, so don't delete it.  (I don't
		    // remember why I did that...)
		    if ( c->t == copydesc::until ) {
			lex_begin_copy(c->s);
			c->s = 0;
		    }
		    else {
			lex_begin_copy(0);
			include_file(c->s, false);
		    }
		    delete c;
		}
	    }
    break;

  case 192:
#line 992 "grap.y"
    {
		string *s;
		string *t;
		int lim;
		char end;
		stack<string *> st;

		while ( yyvsp[0].line_list && !yyvsp[0].line_list->empty() ) {
		    int i = 0;
		    t = new string;
		    
		    s = yyvsp[0].line_list->front();
		    yyvsp[0].line_list->pop_front();
		    lim = s->length();
		    
		    while ( i < lim ) {
			if ( (*s)[i] == ' ' || (*s)[i] == '\t' ) {
			    if ( t->length() ) {
				if ( yyvsp[-4].macro_val->add_arg(t)) 
				    t = new string;
			    }
			} else *t += (*s)[i];
			i++;
		    }
		    if ( t->length() ) yyvsp[-4].macro_val->add_arg(t);
		    else if (t) delete t;
		    t = yyvsp[-4].macro_val->invoke();
		    // "here" macros should end with a SEP.  If the
		    // user hasn't done so, we add a SEP for them.
		    // Even named macros should get a sep when they're
		    // copied through,

		    end = (*t)[t->length()-1];

		    if ( end != ';' && end != '\n' ) 
			*t += ';';
		    // Because include string stacks the strings, we stack them
		    // here and call include_string in reverse order to ensure
		    // correct ordered execution of multiple lines.
		    st.push(t);
		    delete s;
		}
		delete yyvsp[0].line_list;
		while ( !st.empty() ) {
		    include_string(st.top(), 0, GMACRO);
		    delete st.top();
		    st.pop();
	        }
		// don't delete defined macros
		if ( !yyvsp[-4].macro_val->name)
		    delete yyvsp[-4].macro_val;
	    }
    break;

  case 193:
#line 1047 "grap.y"
    { lex_no_coord(); lex_no_macro_expansion();}
    break;

  case 194:
#line 1048 "grap.y"
    { lex_begin_macro_text(); }
    break;

  case 195:
#line 1049 "grap.y"
    { lex_macro_expansion_ok(); lex_coord_ok(); define_macro(yyvsp[-3].String, yyvsp[-1].String); }
    break;

  case 196:
#line 1053 "grap.y"
    { lex_no_coord(); lex_no_macro_expansion(); }
    break;

  case 197:
#line 1053 "grap.y"
    {
	    lex_coord_ok();
	    lex_macro_expansion_ok();
	    macros.erase(*yyvsp[-1].String);
	    delete yyvsp[-1].String;
	}
    break;

  case 198:
#line 1061 "grap.y"
    { lex_begin_macro_text(); }
    break;

  case 199:
#line 1062 "grap.y"
    {
		int len = yyvsp[-1].String->length()+1 ;
		char *sys = new char [len];
		int i=0;

		// String to char*
		       
		while ((sys[i] = (*yyvsp[-1].String)[i]))
		    i++;

		delete yyvsp[-1].String;
		
		system(sys);
	    }
    break;

  case 200:
#line 1079 "grap.y"
    { yyval.String = 0; }
    break;

  case 201:
#line 1080 "grap.y"
    {lex_begin_macro_text(); }
    break;

  case 202:
#line 1081 "grap.y"
    {
		// force else clause to end with a SEP
		*yyvsp[0].String+= ';';
		yyval.String = yyvsp[0].String;
	    }
    break;

  case 203:
#line 1089 "grap.y"
    { lex_begin_macro_text(); }
    break;

  case 204:
#line 1090 "grap.y"
    {
		// force all if blocks to be terminated by a SEP
		*yyvsp[-2].String += ';';
		if ( fabs(yyvsp[-5].num) > EPSILON ) include_string(yyvsp[-2].String,0,GINTERNAL);
		else if ( yyvsp[-1].String ) include_string(yyvsp[-1].String,0,GINTERNAL);
		delete yyvsp[-2].String;
		if ( yyvsp[-1].String) delete yyvsp[-1].String;
	    }
    break;

  case 205:
#line 1102 "grap.y"
    { lex_begin_macro_text(); }
    break;

  case 206:
#line 1103 "grap.y"
    { for_statement(yyvsp[-9].String, yyvsp[-7].num, yyvsp[-5].num, yyvsp[-4].by, yyvsp[-1].String); }
    break;

  case 207:
#line 1107 "grap.y"
    { lex_no_coord(); }
    break;

  case 208:
#line 1107 "grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 209:
#line 1108 "grap.y"
    {
		if ( !first_line ) {
		    // Only draw the graph and clear its internals if
		    // it is visible.  This allows a user to declare
		    // things like coordinate spaces before the graph
		    // itself is named.  This is a compatibility
		    // feature for DWB grap.
		    if ( the_graph->is_visible() ) {
			the_graph->draw(0);
			the_graph->init(yyvsp[-3].String, yyvsp[-1].String);
			init_dict();
		    }
		    else
			the_graph->setname(yyvsp[-3].String);
		}
		else {
		    the_graph->init(yyvsp[-3].String, yyvsp[-1].String);
		    init_dict();
		}
		    
		if ( yyvsp[-3].String ) delete yyvsp[-3].String;
		if ( yyvsp[-1].String ) delete yyvsp[-1].String;
	    }
    break;

  case 211:
#line 1139 "grap.y"
    {
		unquote(yyvsp[0].String);
		cerr <<  *yyvsp[0].String << endl;
	    }
    break;

  case 212:
#line 1144 "grap.y"
    {
		cerr << yyvsp[0].num << endl;
	    }
    break;

  case 213:
#line 1150 "grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 214:
#line 1151 "grap.y"
    { the_graph->passthru_string(*yyvsp[-1].String); delete yyvsp[-1].String;}
    break;

  case 215:
#line 1155 "grap.y"
    { the_graph->passthru_string(*yyvsp[-1].String); delete yyvsp[-1].String;}
    break;

  case 216:
#line 1160 "grap.y"
    { yyval.side = right_side; }
    break;

  case 217:
#line 1162 "grap.y"
    { yyval.side = top_side; }
    break;

  case 218:
#line 1166 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 219:
#line 1168 "grap.y"
    { yyval.num = 0; }
    break;

  case 220:
#line 1173 "grap.y"
    { yyval.num = yyvsp[0].num; }
    break;

  case 221:
#line 1175 "grap.y"
    { yyval.num = 1; }
    break;

  case 222:
#line 1180 "grap.y"
    {
		// The point parsing has already autoscaled the
		// coordinate system to include those points.
		the_graph->new_box(yyvsp[-4].pt, yyvsp[-2].pt, yyvsp[-1].lined);
		delete yyvsp[-4].pt; delete yyvsp[-2].pt; delete yyvsp[-1].lined;
	    }
    break;

  case 223:
#line 1188 "grap.y"
    { bar_statement(yyvsp[-8].coordptr, yyvsp[-7].side, yyvsp[-6].num, yyvsp[-4].num, yyvsp[-3].num, yyvsp[-2].num, yyvsp[-1].lined); }
    break;

  case 224:
#line 1193 "grap.y"
    { if ( yyvsp[-3].val >=0 && yyvsp[-3].val < NVF1 ) jtvf1[yyvsp[-3].val](yyvsp[-1].num); }
    break;


    }

/* Line 991 of yacc.c.  */
#line 3262 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab2;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:

  /* Suppress GCC warning that yyerrlab1 is unused when no action
     invokes YYERROR.  */
#if defined (__GNUC_MINOR__) && 2093 <= (__GNUC__ * 1000 + __GNUC_MINOR__)
//  __attribute__ ((__unused__))
#endif


  goto yyerrlab2;


/*---------------------------------------------------------------.
| yyerrlab2 -- pop states until the error token can be shifted.  |
`---------------------------------------------------------------*/
yyerrlab2:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1195 "grap.y"


