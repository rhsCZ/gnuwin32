#ifndef Y_TAB_H
# define Y_TAB_H

typedef union {
    int val;
    double num;
    string *String;
    DisplayString *ds;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    doublevec *double_vec;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
} YYSTYPE;
# define	NUMBER	257
# define	START	258
# define	END	259
# define	IDENT	260
# define	COPY	261
# define	SEP	262
# define	STRING	263
# define	COORD_NAME	264
# define	UNDEFINE	265
# define	SOLID	266
# define	INVIS	267
# define	DOTTED	268
# define	DASHED	269
# define	DRAW	270
# define	LPAREN	271
# define	RPAREN	272
# define	FUNC0	273
# define	FUNC1	274
# define	FUNC2	275
# define	COMMA	276
# define	LINE	277
# define	PLOT	278
# define	FROM	279
# define	TO	280
# define	AT	281
# define	NEXT	282
# define	FRAME	283
# define	LEFT	284
# define	RIGHT	285
# define	TOP	286
# define	BOTTOM	287
# define	UP	288
# define	DOWN	289
# define	HT	290
# define	WID	291
# define	IN	292
# define	OUT	293
# define	NONE	294
# define	TICKS	295
# define	OFF	296
# define	BY	297
# define	GRID	298
# define	LJUST	299
# define	RJUST	300
# define	ABOVE	301
# define	BELOW	302
# define	ALIGNED	303
# define	PLUS	304
# define	MINUS	305
# define	TIMES	306
# define	DIV	307
# define	CARAT	308
# define	EQUALS	309
# define	SIZE	310
# define	UNALIGNED	311
# define	LABEL	312
# define	RADIUS	313
# define	CIRCLE	314
# define	ARROW	315
# define	XDIM	316
# define	YDIM	317
# define	LOG_X	318
# define	LOG_Y	319
# define	LOG_LOG	320
# define	COORD	321
# define	TEXT	322
# define	DEFINE	323
# define	IF	324
# define	THEN	325
# define	ELSE	326
# define	EQ	327
# define	NEQ	328
# define	LT	329
# define	GT	330
# define	LTE	331
# define	GTE	332
# define	NOT	333
# define	OR	334
# define	AND	335
# define	FOR	336
# define	DO	337
# define	MACRO	338
# define	COPYTEXT	339
# define	THRU	340
# define	GRAPH	341
# define	REST	342
# define	PRINT	343
# define	PIC	344
# define	TROFF	345
# define	UNTIL	346
# define	COLOR	347
# define	SPRINTF	348
# define	SH	349
# define	BAR	350
# define	FILL	351
# define	FILLCOLOR	352
# define	BASE	353
# define	ON	354
# define	LHS	355
# define	VFUNC1	356


extern YYSTYPE yylval;

#endif /* not Y_TAB_H */
