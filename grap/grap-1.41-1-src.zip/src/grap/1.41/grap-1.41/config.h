/* config.h.  Generated from config.h.in by configure.  */
#ifndef CONFIG_H
#define CONFIG_H
// This file is (c) 1998-2001 Ted Faber (faber@lunabase.org) see COPYRIGHT
// for the full copyright and limitations of liabilities.

// The following are set by configure

#define STDC_HEADERS 1
/* #undef HAVE_STDLIB_H */
#define HAVE_UNISTD_H 1
/* #undef HAVE_HASH_MAP */
#define HAVE_EXT_HASH_MAP 1
/* #undef HAVE_UNORDERED_MAP */
#define HASH_SPACE __gnu_cxx
#define HAVE_LIMITS 1
#define HAVE_SNPRINTF 1
/* #undef HAVE_RANDOM */
#define HAVE_RAND 1
#define HAVE_STRDUP 1
#define HAVE_STRERROR 1
#define HAVE_ERRNO_H 1
#define SNPRINTF_DECLARED 1
#define STRERROR_DECLARED 1
/* #undef RANDOM_DECLARED */
#define RAND_DECLARED 1
/* #undef OPTARG_DEFINED */
/* #undef SPRINTF_NOT_INT */
/* #undef GRAP_SAFER */
#define PACKAGE_VERSION "1.41"
#define PACKAGE_BUGREPORT "faber@lunabase.org"
#define OS_VERSION "Microsoft Windows"
/* #undef LEX_HAS_YYUNPUT */

#define DEFINES "c:/progra~1/Grap/share/grap/grap.defines"
#define EXAMPLES_DIR "c:/progra~1/Grap/doc/examples"
#define DOCS_DIR "c:/progra~1/Grap/doc"

#endif
