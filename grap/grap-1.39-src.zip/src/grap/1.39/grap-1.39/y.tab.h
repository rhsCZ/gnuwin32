/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     START = 259,
     END = 260,
     IDENT = 261,
     COPY = 262,
     SEP = 263,
     STRING = 264,
     COORD_NAME = 265,
     UNDEFINE = 266,
     SOLID = 267,
     INVIS = 268,
     DOTTED = 269,
     DASHED = 270,
     DRAW = 271,
     LPAREN = 272,
     RPAREN = 273,
     FUNC0 = 274,
     FUNC1 = 275,
     FUNC2 = 276,
     COMMA = 277,
     LINE = 278,
     PLOT = 279,
     FROM = 280,
     TO = 281,
     AT = 282,
     NEXT = 283,
     FRAME = 284,
     LEFT = 285,
     RIGHT = 286,
     TOP = 287,
     BOTTOM = 288,
     UP = 289,
     DOWN = 290,
     HT = 291,
     WID = 292,
     GRAP_IN = 293,
     GRAP_OUT = 294,
     NONE = 295,
     TICKS = 296,
     OFF = 297,
     BY = 298,
     GRID = 299,
     LJUST = 300,
     RJUST = 301,
     ABOVE = 302,
     BELOW = 303,
     ALIGNED = 304,
     PLUS = 305,
     MINUS = 306,
     TIMES = 307,
     DIV = 308,
     CARAT = 309,
     EQUALS = 310,
     GRAP_SIZE = 311,
     GRAP_UNALIGNED = 312,
     LABEL = 313,
     RADIUS = 314,
     CIRCLE = 315,
     ARROW = 316,
     XDIM = 317,
     YDIM = 318,
     LOG_X = 319,
     LOG_Y = 320,
     LOG_LOG = 321,
     GRAP_COORD = 322,
     GRAP_TEXT = 323,
     DEFINE = 324,
     IF = 325,
     THEN = 326,
     ELSE = 327,
     EQ = 328,
     NEQ = 329,
     LT = 330,
     GT = 331,
     LTE = 332,
     GTE = 333,
     NOT = 334,
     OR = 335,
     AND = 336,
     FOR = 337,
     DO = 338,
     MACRO = 339,
     COPYTEXT = 340,
     THRU = 341,
     GRAPH = 342,
     REST = 343,
     PRINT = 344,
     PIC = 345,
     TROFF = 346,
     UNTIL = 347,
     COLOR = 348,
     SPRINTF = 349,
     SH = 350,
     BAR = 351,
     FILL = 352,
     FILLCOLOR = 353,
     BASE = 354,
     ON = 355,
     LHS = 356,
     VFUNC1 = 357,
     CLIPPED = 358,
     UNCLIPPED = 359,
     THICKNESS = 360
   };
#endif
/* Tokens.  */
#define NUMBER 258
#define START 259
#define END 260
#define IDENT 261
#define COPY 262
#define SEP 263
#define STRING 264
#define COORD_NAME 265
#define UNDEFINE 266
#define SOLID 267
#define INVIS 268
#define DOTTED 269
#define DASHED 270
#define DRAW 271
#define LPAREN 272
#define RPAREN 273
#define FUNC0 274
#define FUNC1 275
#define FUNC2 276
#define COMMA 277
#define LINE 278
#define PLOT 279
#define FROM 280
#define TO 281
#define AT 282
#define NEXT 283
#define FRAME 284
#define LEFT 285
#define RIGHT 286
#define TOP 287
#define BOTTOM 288
#define UP 289
#define DOWN 290
#define HT 291
#define WID 292
#define GRAP_IN 293
#define GRAP_OUT 294
#define NONE 295
#define TICKS 296
#define OFF 297
#define BY 298
#define GRID 299
#define LJUST 300
#define RJUST 301
#define ABOVE 302
#define BELOW 303
#define ALIGNED 304
#define PLUS 305
#define MINUS 306
#define TIMES 307
#define DIV 308
#define CARAT 309
#define EQUALS 310
#define GRAP_SIZE 311
#define GRAP_UNALIGNED 312
#define LABEL 313
#define RADIUS 314
#define CIRCLE 315
#define ARROW 316
#define XDIM 317
#define YDIM 318
#define LOG_X 319
#define LOG_Y 320
#define LOG_LOG 321
#define GRAP_COORD 322
#define GRAP_TEXT 323
#define DEFINE 324
#define IF 325
#define THEN 326
#define ELSE 327
#define EQ 328
#define NEQ 329
#define LT 330
#define GT 331
#define LTE 332
#define GTE 333
#define NOT 334
#define OR 335
#define AND 336
#define FOR 337
#define DO 338
#define MACRO 339
#define COPYTEXT 340
#define THRU 341
#define GRAPH 342
#define REST 343
#define PRINT 344
#define PIC 345
#define TROFF 346
#define UNTIL 347
#define COLOR 348
#define SPRINTF 349
#define SH 350
#define BAR 351
#define FILL 352
#define FILLCOLOR 353
#define BASE 354
#define ON 355
#define LHS 356
#define VFUNC1 357
#define CLIPPED 358
#define UNCLIPPED 359
#define THICKNESS 360




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 129 "../grap-1.39-src/grap.y"
typedef union YYSTYPE {
    int val;
    double num;
    string *String;
    DisplayString *ds;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    doublevec *double_vec;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
    bar_param *bar_p;
} YYSTYPE;
/* Line 1447 of yacc.c.  */
#line 275 "y.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



