/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NUMBER = 258,
     START = 259,
     END = 260,
     IDENT = 261,
     COPY = 262,
     SEP = 263,
     STRING = 264,
     COORD_NAME = 265,
     UNDEFINE = 266,
     SOLID = 267,
     INVIS = 268,
     DOTTED = 269,
     DASHED = 270,
     DRAW = 271,
     LPAREN = 272,
     RPAREN = 273,
     FUNC0 = 274,
     FUNC1 = 275,
     FUNC2 = 276,
     COMMA = 277,
     LINE = 278,
     PLOT = 279,
     FROM = 280,
     TO = 281,
     AT = 282,
     NEXT = 283,
     FRAME = 284,
     LEFT = 285,
     RIGHT = 286,
     TOP = 287,
     BOTTOM = 288,
     UP = 289,
     DOWN = 290,
     HT = 291,
     WID = 292,
     GRAP_IN = 293,
     GRAP_OUT = 294,
     NONE = 295,
     TICKS = 296,
     OFF = 297,
     BY = 298,
     GRID = 299,
     LJUST = 300,
     RJUST = 301,
     ABOVE = 302,
     BELOW = 303,
     ALIGNED = 304,
     PLUS = 305,
     MINUS = 306,
     TIMES = 307,
     DIV = 308,
     CARAT = 309,
     EQUALS = 310,
     GRAP_SIZE = 311,
     GRAP_UNALIGNED = 312,
     LABEL = 313,
     RADIUS = 314,
     CIRCLE = 315,
     ARROW = 316,
     XDIM = 317,
     YDIM = 318,
     LOG_X = 319,
     LOG_Y = 320,
     LOG_LOG = 321,
     GRAP_COORD = 322,
     GRAP_TEXT = 323,
     DEFINE = 324,
     IF = 325,
     THEN = 326,
     ELSE = 327,
     EQ = 328,
     NEQ = 329,
     LT = 330,
     GT = 331,
     LTE = 332,
     GTE = 333,
     NOT = 334,
     OR = 335,
     AND = 336,
     FOR = 337,
     DO = 338,
     MACRO = 339,
     COPYTEXT = 340,
     THRU = 341,
     GRAPH = 342,
     REST = 343,
     PRINT = 344,
     PIC = 345,
     TROFF = 346,
     UNTIL = 347,
     COLOR = 348,
     SPRINTF = 349,
     SH = 350,
     BAR = 351,
     FILL = 352,
     FILLCOLOR = 353,
     BASE = 354,
     ON = 355,
     LHS = 356,
     VFUNC1 = 357,
     CLIPPED = 358,
     UNCLIPPED = 359,
     THICKNESS = 360
   };
#endif
/* Tokens.  */
#define NUMBER 258
#define START 259
#define END 260
#define IDENT 261
#define COPY 262
#define SEP 263
#define STRING 264
#define COORD_NAME 265
#define UNDEFINE 266
#define SOLID 267
#define INVIS 268
#define DOTTED 269
#define DASHED 270
#define DRAW 271
#define LPAREN 272
#define RPAREN 273
#define FUNC0 274
#define FUNC1 275
#define FUNC2 276
#define COMMA 277
#define LINE 278
#define PLOT 279
#define FROM 280
#define TO 281
#define AT 282
#define NEXT 283
#define FRAME 284
#define LEFT 285
#define RIGHT 286
#define TOP 287
#define BOTTOM 288
#define UP 289
#define DOWN 290
#define HT 291
#define WID 292
#define GRAP_IN 293
#define GRAP_OUT 294
#define NONE 295
#define TICKS 296
#define OFF 297
#define BY 298
#define GRID 299
#define LJUST 300
#define RJUST 301
#define ABOVE 302
#define BELOW 303
#define ALIGNED 304
#define PLUS 305
#define MINUS 306
#define TIMES 307
#define DIV 308
#define CARAT 309
#define EQUALS 310
#define GRAP_SIZE 311
#define GRAP_UNALIGNED 312
#define LABEL 313
#define RADIUS 314
#define CIRCLE 315
#define ARROW 316
#define XDIM 317
#define YDIM 318
#define LOG_X 319
#define LOG_Y 320
#define LOG_LOG 321
#define GRAP_COORD 322
#define GRAP_TEXT 323
#define DEFINE 324
#define IF 325
#define THEN 326
#define ELSE 327
#define EQ 328
#define NEQ 329
#define LT 330
#define GT 331
#define LTE 332
#define GTE 333
#define NOT 334
#define OR 335
#define AND 336
#define FOR 337
#define DO 338
#define MACRO 339
#define COPYTEXT 340
#define THRU 341
#define GRAPH 342
#define REST 343
#define PRINT 344
#define PIC 345
#define TROFF 346
#define UNTIL 347
#define COLOR 348
#define SPRINTF 349
#define SH 350
#define BAR 351
#define FILL 352
#define FILLCOLOR 353
#define BASE 354
#define ON 355
#define LHS 356
#define VFUNC1 357
#define CLIPPED 358
#define UNCLIPPED 359
#define THICKNESS 360




/* Copy the first part of user declarations.  */
#line 2 "../grap-1.39-src/grap.y"

/* This code is (c) 1998-2001 Ted Faber (faber@lunabase.org) see the
   COPYRIGHT file for the full copyright and limitations of
   liabilities. */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <stdio.h>
#include <iostream>
#include <stack>
#include <math.h>
#ifdef STDC_HEADERS
#include <limits.h>
#else
// Best guess, really - limits should exist
#ifndef LONG_MAX
#define LONG_MAX        0x7fffffffL
#endif
#endif
#if defined(STDC_HEADERS) | defined(HAVE_STDLIB_H)
#include <stdlib.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "grap.h"
#include "grap_data.h"
#include "grap_draw.h"

doubleDictionary vars;
graph *the_graph =0;
lexStack lexstack;
macroDictionary macros;
stringSequence path;
bool first_line;
bool unaligned_default = false;	// Should strings be unaligned by default 
bool clip_default = true;	// Should strings be clipped by default 
extern bool do_sprintf;		// true if it's acceptable to parse sprintf

line* defline;
coord *defcoord;
string *graph_name;
string *graph_pos;
string *ps_param;
// number of lines in a number list (used in grap_parse.cc) 
int nlines;

// bison wants these defined....
int yyerror(char*);
int yylex();
void init_dict(); 

// defined in grap_lex.l
extern bool include_file(string *, bool =false, bool=true);
extern void lex_no_macro_expansion(); 
extern void lex_macro_expansion_ok(); 
extern void lex_begin_macro_text(); 
extern void lex_begin_rest_of_line();
extern void lex_no_coord();
extern void lex_coord_ok();
extern void lex_begin_copy( string*s=0);
extern int include_string(string *,struct for_descriptor *f=0,
			  grap_input i=GMACRO);
extern void lex_hunt_macro();
extern int yyparse(void);	// To shut yacc (vs. bison) up.
void draw_graph();
void init_graph();

// Parsing utilities in grap_parse.cc.  Locating them there reduces
// compilation time (this file was getting very large) and eliminates
// some code redundancy.
extern graph *initial_graph(); 
extern linedesc* combine_linedesc(linedesc *, linedesc*);
extern axis combine_logs(axis, axis);
extern void draw_statement(string *, linedesc *, DisplayString *);
extern void num_list(doublelist *);
extern double assignment_statement(string *, double);
extern stringlist *combine_strings(stringlist *, string *, strmod &);
extern void plot_statement(double, DisplayString *, point *); 
extern void next_statement(string *, point *, linedesc *);
extern ticklist *ticklist_elem(double, DisplayString *, ticklist *);
extern ticklist *tick_for(coord *, double, double, bydesc, DisplayString *);
extern void ticks_statement(sides, double, shiftlist *, ticklist *);
extern void grid_statement(sides, int, linedesc *, shiftlist *, ticklist *);
extern void line_statement(int, linedesc *, point *, point *, linedesc *);
extern axisdesc axis_description(axis, double, double );
extern void coord_statement(string *, axisdesc&, axisdesc&, axis);
extern void coord_statement(coord *, axisdesc&, axisdesc&, axis);
extern void for_statement(string *, double, double, bydesc, string *);
extern void process_frame(linedesc *, frame *, frame *);
extern void define_macro(string *, string*);
extern void bar_statement(coord *, sides, double, double, double,
		   double, linedesc *); 
void init_dict(); 

// adapters to return complex (complex-ish) functions
void grap_srandom(double x) { srandom(static_cast<unsigned int>(x)); }
double grap_random() {
    return static_cast<double>(random())/(static_cast<double>(LONG_MAX)+1e-6);
}
double grap_getpid() { return static_cast<double>(getpid());} 
double pow10(double x) { return pow(10,x); }
double toint(double x) { return static_cast<double>(int(x)); }
double grap_min(double a, double b) { return (a<b) ? a : b; } 
double grap_max(double a, double b) { return (a>b) ? a : b; } 
 
typedef void (*vfunction1)(double);
typedef double (*function0)();
typedef double (*function1)(double);
typedef double (*function2)(double, double);
// jump tables for dispatching internal functions
vfunction1 jtvf1[NVF1] = { grap_srandom };
function0 jtf0[NF0] = { grap_random, grap_getpid };
function1 jtf1[NF1] = { log10, pow10, toint, sin, cos, sqrt, exp, log };
function2 jtf2[NF2] = { atan2, grap_min, grap_max};


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 129 "../grap-1.39-src/grap.y"
typedef union YYSTYPE {
    int val;
    double num;
    string *String;
    DisplayString *ds;
    frame *frameptr;
    shiftdesc *shift;
    shiftlist *shift_list;
    point *pt;
    linedesc *lined;
    stringlist *string_list;
    linelist *line_list;
    ticklist *tick_list;
    doublelist *double_list;
    doublevec *double_vec;
    macro *macro_val;
    coord *coordptr;
    line *lineptr;
    sides side;
    bydesc by;
    axisdesc axistype;
    axis axisname;
    strmod stringmod;
    copydesc *copyd;
    bar_param *bar_p;
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 440 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 452 "y.tab.c"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE))			\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   719

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  106
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  92
/* YYNRULES -- Number of rules. */
#define YYNRULES  226
/* YYNRULES -- Number of states. */
#define YYNSTATES  429

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   360

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     4,     7,     8,    13,    14,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
      41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    72,    74,    75,    77,
      78,    81,    83,    90,    92,    96,    97,    99,   100,   102,
     103,   106,   108,   110,   113,   116,   119,   122,   125,   128,
     130,   133,   134,   141,   144,   146,   149,   151,   154,   158,
     162,   166,   170,   174,   178,   181,   185,   190,   197,   201,
     203,   205,   207,   211,   213,   217,   221,   225,   229,   233,
     237,   241,   245,   248,   252,   256,   259,   261,   264,   268,
     274,   277,   278,   282,   287,   290,   293,   296,   299,   302,
     305,   308,   311,   315,   318,   322,   327,   334,   341,   344,
     347,   349,   352,   354,   356,   358,   360,   362,   365,   369,
     372,   376,   380,   384,   389,   394,   399,   404,   410,   416,
     419,   422,   425,   428,   430,   432,   433,   436,   439,   444,
     445,   448,   452,   456,   460,   464,   472,   474,   476,   479,
     480,   487,   491,   496,   502,   503,   506,   514,   522,   528,
     529,   532,   539,   541,   543,   552,   553,   558,   559,   564,
     567,   568,   570,   572,   574,   581,   582,   585,   587,   591,
     592,   599,   600,   601,   611,   612,   613,   620,   621,   626,
     627,   632,   633,   634,   638,   639,   647,   648,   660,   661,
     662,   669,   673,   675,   677,   678,   683,   686,   688,   690,
     693,   696,   699,   701,   704,   711,   719
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     107,     0,    -1,    -1,   107,   108,    -1,    -1,     4,   109,
     110,     5,    -1,    -1,   110,   111,    -1,   132,    -1,   125,
      -1,   144,    -1,   123,    -1,   138,    -1,   137,    -1,   154,
      -1,   156,    -1,   157,    -1,   159,    -1,   196,    -1,   161,
      -1,   166,    -1,   168,    -1,   172,    -1,   175,    -1,   181,
      -1,   183,    -1,   185,    -1,   188,    -1,   177,    -1,   190,
      -1,   192,    -1,   197,    -1,     8,    -1,    25,    -1,    55,
      -1,    -1,    10,    -1,    -1,     6,    -1,    -1,   116,   135,
      -1,     9,    -1,    94,    17,     9,    22,   117,    18,    -1,
     128,    -1,   117,    22,   128,    -1,    -1,   128,    -1,    -1,
     122,    -1,    -1,   145,   120,    -1,    13,    -1,    12,    -1,
      14,   118,    -1,    15,   118,    -1,    93,   116,    -1,    97,
     118,    -1,    98,   116,    -1,   105,   118,    -1,   121,    -1,
     122,   121,    -1,    -1,    16,   124,   114,   119,   115,     8,
      -1,   127,     8,    -1,     3,    -1,    51,     3,    -1,   126,
      -1,   127,   126,    -1,   127,    22,   126,    -1,   128,    50,
     128,    -1,   128,    51,   128,    -1,   128,    52,   128,    -1,
     128,    53,   128,    -1,   128,    54,   128,    -1,    51,   128,
      -1,    19,    17,    18,    -1,    20,    17,   128,    18,    -1,
      21,    17,   128,    22,   128,    18,    -1,    17,   128,    18,
      -1,     6,    -1,     3,    -1,   128,    -1,    17,   130,    18,
      -1,   130,    -1,   129,    73,   129,    -1,   129,    74,   129,
      -1,   129,    75,   129,    -1,   129,    76,   129,    -1,   129,
      77,   129,    -1,   129,    78,   129,    -1,   129,    81,   129,
      -1,   129,    80,   129,    -1,    79,   129,    -1,   116,    73,
     116,    -1,   116,    74,   116,    -1,   128,     8,    -1,   132,
      -1,   101,   131,    -1,   128,    22,   128,    -1,    17,   128,
      22,   128,    18,    -1,   113,   133,    -1,    -1,   135,    56,
     128,    -1,   135,    56,    50,   128,    -1,   135,    45,    -1,
     135,    46,    -1,   135,    47,    -1,   135,    48,    -1,   135,
      49,    -1,   135,    57,    -1,   135,   103,    -1,   135,   104,
      -1,   135,    93,     9,    -1,   116,   135,    -1,   136,   116,
     135,    -1,   136,    27,   134,     8,    -1,    24,   118,   115,
      27,   134,     8,    -1,    28,   114,    27,   134,   119,     8,
      -1,    36,   128,    -1,    37,   128,    -1,   139,    -1,   140,
     139,    -1,    32,    -1,    33,    -1,    30,    -1,    31,    -1,
     140,    -1,   141,   122,    -1,   143,   141,   122,    -1,    29,
       8,    -1,    29,   122,     8,    -1,    29,   142,     8,    -1,
      29,   143,     8,    -1,    29,   142,   143,     8,    -1,    29,
     122,   143,     8,    -1,    29,   122,   142,     8,    -1,    29,
     142,   122,     8,    -1,    29,   122,   142,   143,     8,    -1,
      29,   142,   122,   143,     8,    -1,    34,   128,    -1,    35,
     128,    -1,    30,   128,    -1,    31,   128,    -1,    38,    -1,
      39,    -1,    -1,   146,   118,    -1,   128,   115,    -1,   148,
      22,   128,   115,    -1,    -1,    43,   128,    -1,    43,    50,
     128,    -1,    43,    52,   128,    -1,    43,    53,   128,    -1,
      27,   113,   148,    -1,   112,   113,   128,    26,   128,   149,
     115,    -1,   150,    -1,   151,    -1,   100,   114,    -1,    -1,
      41,   141,   147,   120,   152,     8,    -1,    41,    42,     8,
      -1,    41,   141,    42,     8,    -1,    41,   141,   147,   153,
       8,    -1,    -1,    41,    42,    -1,    44,   141,   155,   119,
     120,   152,     8,    -1,    44,   141,   155,   119,   120,   153,
       8,    -1,    58,   141,   136,   120,     8,    -1,    -1,    59,
     128,    -1,    60,    27,   134,   158,   119,     8,    -1,    23,
      -1,    61,    -1,   160,   119,    25,   134,    26,   134,   119,
       8,    -1,    -1,    62,   128,    22,   128,    -1,    -1,    63,
     128,    22,   128,    -1,   164,   165,    -1,    -1,    64,    -1,
      65,    -1,    66,    -1,    67,   114,   162,   163,   164,     8,
      -1,    -1,    92,   116,    -1,   116,    -1,     7,   116,     8,
      -1,    -1,     7,    92,   116,     8,   169,    85,    -1,    -1,
      -1,     7,   167,    86,   170,    84,   167,     8,   171,    85,
      -1,    -1,    -1,    69,   173,     6,   174,    68,     8,    -1,
      -1,    11,   176,     6,     8,    -1,    -1,    95,   178,    68,
       8,    -1,    -1,    -1,    72,   180,    68,    -1,    -1,    70,
     129,    71,   182,    68,   179,     8,    -1,    -1,    82,     6,
     112,   128,    26,   128,   149,    83,   184,    68,     8,    -1,
      -1,    -1,    87,   186,     6,   187,    88,     8,    -1,    89,
     189,     8,    -1,   116,    -1,   128,    -1,    -1,    90,   191,
      88,     8,    -1,    91,     8,    -1,    31,    -1,    34,    -1,
      36,   128,    -1,    37,   128,    -1,    99,   128,    -1,   194,
      -1,   195,   194,    -1,    96,   134,    22,   134,   119,     8,
      -1,    96,   113,   193,   128,   195,   119,     8,    -1,   102,
      17,   128,    18,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   188,   188,   189,   193,   193,   207,   208,   212,   214,
     216,   222,   224,   226,   228,   230,   232,   234,   236,   238,
     240,   242,   244,   246,   248,   250,   252,   254,   256,   258,
     260,   262,   264,   268,   269,   272,   273,   278,   279,   284,
     285,   293,   295,   363,   368,   376,   377,   382,   383,   388,
     389,   398,   400,   402,   404,   406,   408,   410,   412,   417,
     419,   424,   424,   429,   434,   437,   442,   447,   452,   460,
     462,   464,   466,   468,   470,   472,   474,   476,   478,   480,
     493,   498,   500,   502,   507,   509,   511,   513,   515,   517,
     519,   521,   523,   525,   527,   532,   533,   537,   542,   544,
     548,   553,   560,   562,   564,   566,   568,   570,   572,   574,
     576,   578,   580,   585,   595,   600,   604,   609,   614,   620,
     629,   631,   642,   644,   646,   648,   653,   671,   676,   702,
     704,   706,   708,   710,   712,   714,   716,   718,   720,   725,
     727,   729,   731,   736,   738,   743,   744,   752,   754,   759,
     760,   766,   768,   770,   775,   784,   788,   790,   795,   811,
     817,   819,   824,   826,   834,   835,   840,   844,   855,   874,
     875,   880,   888,   890,   895,   900,   901,   905,   906,   911,
     914,   918,   920,   922,   928,   936,   937,   944,   959,   965,
     964,   986,   987,   986,  1069,  1070,  1069,  1075,  1075,  1083,
    1083,  1101,  1102,  1102,  1111,  1111,  1125,  1124,  1130,  1130,
    1130,  1157,  1161,  1166,  1173,  1173,  1177,  1182,  1184,  1191,
    1192,  1193,  1197,  1198,  1213,  1220,  1234
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NUMBER", "START", "END", "IDENT",
  "COPY", "SEP", "STRING", "COORD_NAME", "UNDEFINE", "SOLID", "INVIS",
  "DOTTED", "DASHED", "DRAW", "LPAREN", "RPAREN", "FUNC0", "FUNC1",
  "FUNC2", "COMMA", "LINE", "PLOT", "FROM", "TO", "AT", "NEXT", "FRAME",
  "LEFT", "RIGHT", "TOP", "BOTTOM", "UP", "DOWN", "HT", "WID", "GRAP_IN",
  "GRAP_OUT", "NONE", "TICKS", "OFF", "BY", "GRID", "LJUST", "RJUST",
  "ABOVE", "BELOW", "ALIGNED", "PLUS", "MINUS", "TIMES", "DIV", "CARAT",
  "EQUALS", "GRAP_SIZE", "GRAP_UNALIGNED", "LABEL", "RADIUS", "CIRCLE",
  "ARROW", "XDIM", "YDIM", "LOG_X", "LOG_Y", "LOG_LOG", "GRAP_COORD",
  "GRAP_TEXT", "DEFINE", "IF", "THEN", "ELSE", "EQ", "NEQ", "LT", "GT",
  "LTE", "GTE", "NOT", "OR", "AND", "FOR", "DO", "MACRO", "COPYTEXT",
  "THRU", "GRAPH", "REST", "PRINT", "PIC", "TROFF", "UNTIL", "COLOR",
  "SPRINTF", "SH", "BAR", "FILL", "FILLCOLOR", "BASE", "ON", "LHS",
  "VFUNC1", "CLIPPED", "UNCLIPPED", "THICKNESS", "$accept", "graphs",
  "graph", "@1", "prog", "statement", "from", "opt_coordname", "opt_ident",
  "opt_display_string", "string", "expr_list", "opt_expr", "opt_linedesc",
  "opt_shift", "linedesc_elem", "linedesc", "draw_statement", "@2",
  "num_list", "num_line_elem", "num_line", "expr", "lexpr", "pure_lexpr",
  "right_hand_side", "assignment_statement", "coord_pair", "point",
  "strmod", "strlist", "plot_statement", "next_statement", "size_elem",
  "size", "side", "final_size", "sides", "frame_statement", "shift",
  "tickdir", "direction", "ticklist", "by_clause", "tickat", "tickfor",
  "tickdesc", "autotick", "ticks_statement", "opt_tick_off",
  "grid_statement", "label_statement", "radius_spec", "circle_statement",
  "line_token", "line_statement", "x_axis_desc", "y_axis_desc", "log_list",
  "log_desc", "coord_statement", "until_clause", "copy_statement", "@3",
  "@4", "@5", "define_statement", "@6", "@7", "undefine_statement", "@8",
  "sh_statement", "@9", "else_clause", "@10", "if_statement", "@11",
  "for_statement", "@12", "graph_statement", "@13", "@14",
  "print_statement", "print_param", "pic_statement", "@15", "troff_line",
  "bar_dir", "bar_param", "bar_params", "bar_statement", "void_function", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   106,   107,   107,   109,   108,   110,   110,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     111,   111,   111,   112,   112,   113,   113,   114,   114,   115,
     115,   116,   116,   117,   117,   118,   118,   119,   119,   120,
     120,   121,   121,   121,   121,   121,   121,   121,   121,   122,
     122,   124,   123,   125,   126,   126,   127,   127,   127,   128,
     128,   128,   128,   128,   128,   128,   128,   128,   128,   128,
     128,   129,   129,   129,   130,   130,   130,   130,   130,   130,
     130,   130,   130,   130,   130,   131,   131,   132,   133,   133,
     134,   135,   135,   135,   135,   135,   135,   135,   135,   135,
     135,   135,   135,   136,   136,   137,   137,   138,   139,   139,
     140,   140,   141,   141,   141,   141,   142,   143,   143,   144,
     144,   144,   144,   144,   144,   144,   144,   144,   144,   145,
     145,   145,   145,   146,   146,   147,   147,   148,   148,   149,
     149,   149,   149,   149,   150,   151,   152,   152,   153,   153,
     154,   154,   154,   154,   155,   155,   156,   156,   157,   158,
     158,   159,   160,   160,   161,   162,   162,   163,   163,   164,
     164,   165,   165,   165,   166,   167,   167,   167,   168,   169,
     168,   170,   171,   168,   173,   174,   172,   176,   175,   178,
     177,   179,   180,   179,   182,   181,   184,   183,   186,   187,
     185,   188,   189,   189,   191,   190,   192,   193,   193,   194,
     194,   194,   195,   195,   196,   196,   197
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     0,     2,     0,     4,     0,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     1,     0,     1,     0,
       2,     1,     6,     1,     3,     0,     1,     0,     1,     0,
       2,     1,     1,     2,     2,     2,     2,     2,     2,     1,
       2,     0,     6,     2,     1,     2,     1,     2,     3,     3,
       3,     3,     3,     3,     2,     3,     4,     6,     3,     1,
       1,     1,     3,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     2,     3,     3,     2,     1,     2,     3,     5,
       2,     0,     3,     4,     2,     2,     2,     2,     2,     2,
       2,     2,     3,     2,     3,     4,     6,     6,     2,     2,
       1,     2,     1,     1,     1,     1,     1,     2,     3,     2,
       3,     3,     3,     4,     4,     4,     4,     5,     5,     2,
       2,     2,     2,     1,     1,     0,     2,     2,     4,     0,
       2,     3,     3,     3,     3,     7,     1,     1,     2,     0,
       6,     3,     4,     5,     0,     2,     7,     7,     5,     0,
       2,     6,     1,     1,     8,     0,     4,     0,     4,     2,
       0,     1,     1,     1,     6,     0,     2,     1,     3,     0,
       6,     0,     0,     9,     0,     0,     6,     0,     4,     0,
       4,     0,     0,     3,     0,     7,     0,    11,     0,     0,
       6,     3,     1,     1,     0,     4,     2,     1,     1,     2,
       2,     2,     1,     2,     6,     7,     4
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       2,     0,     1,     4,     3,     6,     0,    64,     5,   185,
      32,    41,   197,    61,   172,    45,    37,     0,     0,     0,
       0,     0,     0,   173,    37,   194,     0,     0,   208,     0,
     214,     0,     0,   199,    35,     0,     0,     7,   101,    11,
       9,    66,     0,     8,     0,    13,    12,    10,    14,    15,
      16,    17,    47,    19,    20,    21,    22,    23,    28,    24,
      25,    26,    27,    29,    30,    18,    31,     0,   187,     0,
       0,    37,    80,    79,     0,     0,     0,     0,     0,    39,
      46,    38,     0,   129,    52,    51,    45,    45,   124,   125,
     122,   123,     0,     0,     0,    45,     0,    45,    59,     0,
     120,   126,     0,     0,     0,     0,   145,   164,    65,     0,
      35,   175,     0,     0,     0,     0,    81,     0,    83,     0,
       0,   212,   213,     0,     0,   216,     0,     0,    36,     0,
       0,     0,    97,    96,     0,   113,    63,     0,    67,    35,
     101,     0,    48,   186,   188,   191,     0,    47,     0,     0,
       0,     0,    74,     0,   101,     0,     0,     0,     0,     0,
      35,    53,    54,   118,   119,    55,    56,    57,    58,   130,
      60,     0,     0,   121,   127,   131,     0,     0,   132,     0,
     161,   143,   144,     0,    45,    49,     0,    47,    49,     0,
     169,     0,   177,   195,    81,     0,    83,    92,     0,     0,
     204,     0,     0,     0,     0,     0,     0,     0,     0,    33,
      34,     0,   209,   211,     0,     0,     0,     0,   217,   218,
       0,   100,     0,    35,    95,     0,   104,   105,   106,   107,
     108,     0,   109,     0,   110,   111,    68,     0,   114,    35,
     189,     0,   198,    39,    78,    75,     0,     0,    35,    40,
      69,    70,    71,    72,    73,    47,   135,     0,   134,   136,
       0,   133,   128,   162,   146,     0,     0,     0,     0,    37,
       0,    49,     0,   165,    49,     0,     0,    47,     0,     0,
     180,     0,    82,    93,    94,     0,    84,    85,    86,    87,
      88,    89,    91,    90,     0,     0,   215,     0,   200,     0,
       0,     0,    47,   226,     0,   102,   112,   115,     0,     0,
     185,     0,    76,     0,     0,     0,   137,   138,   141,   142,
     139,   140,   158,    35,    35,   156,   157,     0,    50,   163,
     159,   168,   170,     0,     0,     0,     0,     0,   201,     0,
       0,     0,    43,     0,    98,     0,     0,     0,   222,    47,
       0,   103,    35,   190,     0,   187,     0,    62,     0,   116,
     117,     0,     0,   160,     0,     0,   171,   176,     0,   184,
     181,   182,   183,   179,   196,   202,     0,   149,   210,    42,
       0,     0,   219,   220,   221,     0,   223,   224,    47,   186,
     192,    77,    39,   154,     0,   166,   167,   178,     0,   205,
       0,     0,    44,    99,   225,     0,     0,   147,     0,     0,
     203,     0,     0,     0,   150,   206,   174,   193,    39,   149,
     151,   152,   153,     0,   148,    39,     0,   155,   207
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     1,     4,     5,     6,    37,   324,   189,    82,   153,
     115,   341,    79,   141,   270,    98,   142,    39,    71,    40,
      41,    42,   116,   117,   118,   132,    43,   221,   130,   135,
      44,    45,    46,   100,   101,   102,   103,   104,    47,   271,
     184,   185,   393,   401,   325,   326,   327,   272,    48,   187,
      49,    50,   277,    51,    52,    53,   192,   280,   336,   373,
      54,    69,    55,   309,   241,   406,    56,   112,   281,    57,
      70,    58,   127,   376,   398,    59,   285,    60,   423,    61,
     120,   295,    62,   123,    63,   124,    64,   222,   348,   349,
      65,    66
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -232
static const short int yypact[] =
{
    -232,   158,  -232,  -232,  -232,  -232,   355,  -232,  -232,    49,
    -232,  -232,  -232,  -232,  -232,   507,    56,   396,   239,    21,
      25,    21,     9,  -232,    56,  -232,   478,    66,  -232,   497,
    -232,    79,    76,  -232,    89,    13,    84,  -232,  -232,  -232,
    -232,  -232,    17,  -232,     4,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,    28,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,    38,    99,    29,
     111,    56,  -232,  -232,   507,   105,   110,   140,   507,    38,
     665,  -232,   137,  -232,  -232,  -232,   507,   507,  -232,  -232,
    -232,  -232,   507,   507,    38,   507,    38,   507,  -232,   440,
    -232,    23,    28,    98,   606,   166,   146,   128,  -232,    38,
      89,   114,   175,   478,   478,   116,   665,   618,  -232,    30,
     180,  -232,   665,   191,   117,  -232,   195,   139,  -232,   543,
     199,   265,  -232,  -232,   507,   418,  -232,    26,  -232,    89,
    -232,   197,    28,   228,  -232,  -232,   230,    28,   102,   221,
     507,   507,  -232,   219,  -232,   507,   507,   507,   507,   507,
      89,  -232,  -232,   665,   665,  -232,  -232,  -232,  -232,  -232,
    -232,   625,   642,  -232,    28,  -232,   201,   646,  -232,    28,
    -232,  -232,  -232,   242,   507,   167,   209,    28,    74,   584,
     193,   507,   203,  -232,   102,   627,   235,  -232,    38,    38,
    -232,   478,   478,   478,   478,   478,   478,   478,   478,  -232,
    -232,   507,  -232,  -232,   250,   252,   256,   507,  -232,  -232,
     408,  -232,   507,    89,  -232,   323,  -232,  -232,  -232,  -232,
    -232,   576,  -232,   266,  -232,  -232,  -232,   274,   418,    89,
    -232,   204,  -232,    38,  -232,  -232,   490,   566,    89,   418,
     165,   165,   231,   231,  -232,    28,  -232,   651,  -232,  -232,
     655,  -232,    28,  -232,  -232,   507,   507,   507,   507,    56,
     -10,   136,   279,  -232,   136,   284,   507,    28,   578,   507,
    -232,   227,  -232,  -232,  -232,   232,  -232,  -232,  -232,  -232,
    -232,  -232,   636,   636,   341,   213,  -232,   507,  -232,   190,
     507,   260,    28,  -232,   507,   665,  -232,  -232,   277,   220,
      57,   299,  -232,   507,   300,   301,  -232,  -232,   665,   665,
     665,   665,  -232,    89,    89,  -232,  -232,   313,  -232,  -232,
      19,  -232,   665,   314,   507,   590,    14,   316,   253,   507,
     318,   161,   665,   507,   665,   507,   507,   507,  -232,   247,
     319,   665,    89,  -232,    38,  -232,   321,  -232,   516,  -232,
    -232,   507,   507,  -232,   322,   325,  -232,   665,   507,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,   329,   617,  -232,  -232,
     507,   557,   665,   665,   665,   330,  -232,  -232,    28,  -232,
    -232,  -232,   226,   309,   595,  -232,  -232,   665,   271,  -232,
     533,   259,   665,  -232,  -232,   335,   262,  -232,   507,   507,
    -232,   507,   507,   507,   665,  -232,  -232,  -232,   226,   617,
     665,   665,   665,   281,  -232,    38,   345,  -232,  -232
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -232,  -232,  -232,  -232,  -232,  -232,   236,   -33,   -22,  -231,
      -6,  -232,   -60,  -139,  -177,   -85,    -7,  -232,  -232,  -232,
     -37,  -232,   -11,    22,   241,  -232,   326,  -232,   -89,   -84,
     261,  -232,  -232,   255,  -232,   -12,   269,   -34,  -232,  -232,
    -232,  -232,  -232,   -54,  -232,  -232,    42,    50,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,    71,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,
    -232,  -232,  -232,  -232,  -232,  -232,  -232,  -232,    33,  -232,
    -232,  -232
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -160
static const short int yytable[] =
{
      38,   129,   111,    68,    80,   138,   106,   107,   243,   109,
      99,   275,   311,    11,   170,   209,    72,   323,   122,    73,
       7,   190,   369,   121,   131,   136,   161,   162,   108,     7,
      74,   139,    75,    76,    77,   166,   110,   168,   140,   137,
      84,    85,    86,    87,   209,   210,   323,    11,   274,   147,
     237,    88,    89,    90,    91,   209,   238,   170,    11,    92,
      93,   143,    81,   148,    78,   172,    11,   152,    20,   177,
     249,   255,   119,   154,   210,    80,    80,    20,   370,   371,
     372,   163,   164,    11,    80,   210,    80,   125,   165,   170,
     167,   170,   179,   126,   328,   174,   176,   330,    32,   128,
     236,   134,   194,    38,   265,   266,   175,   144,   267,   268,
      84,    85,    86,    87,    35,   145,   315,   146,   220,   269,
     244,    94,   149,   225,   264,    95,    96,   150,    88,    89,
      90,    91,    32,    97,   302,   195,   197,   257,   333,   246,
     247,    67,   260,    32,   250,   251,   252,   253,   254,   354,
     308,    32,   155,   156,   157,   158,   159,   151,     2,   314,
     179,   407,     3,   350,   160,   179,   265,   266,    32,   186,
     267,   268,   262,    80,   180,  -159,   191,   170,   220,   379,
     278,   193,   140,   380,   181,   182,   212,   424,   183,   198,
     199,    94,   283,   284,   427,    95,    96,   265,   266,   213,
     294,   267,   268,    97,   215,   214,   299,   216,   244,   259,
     385,   301,   343,    84,    85,    86,    87,   157,   158,   159,
     305,   223,   239,   286,   287,   288,   289,   290,   291,   292,
     293,    88,    89,    90,    91,    11,   240,   154,   242,   245,
     155,   156,   157,   158,   159,   179,   248,   322,   179,   405,
     263,   273,   276,   282,   318,   319,   320,   321,   296,    84,
      85,    86,    87,   388,   298,   332,   279,   269,   335,    88,
      89,    90,    91,   224,   297,   306,   155,   156,   157,   158,
     159,   105,   307,   345,   346,   159,   342,   329,   310,   344,
     361,   362,   331,   351,    94,   337,   345,   346,    95,    96,
     338,   340,   358,   352,   355,   353,    97,   357,   359,   360,
     155,   156,   157,   158,   159,   155,   156,   157,   158,   159,
      32,   363,   366,   367,   374,   375,   378,   387,   377,   390,
     395,   408,   381,   396,   382,   383,   384,   399,   404,   410,
      94,   303,   415,   416,    95,    96,   347,   417,   389,   426,
     392,   394,    97,   428,   196,   211,   173,   397,     7,   347,
       8,   133,     9,    10,    11,   425,    12,   339,   171,   402,
     188,    13,   364,   155,   156,   157,   158,   159,    14,    15,
     365,   356,   386,    16,    17,     0,   154,     0,     0,   414,
       0,   155,   156,   157,   158,   159,    18,   418,   419,    19,
     420,   421,   422,     0,    83,     0,    20,     0,    84,    85,
      86,    87,   154,    21,     0,    22,    23,     0,     0,   154,
       0,     0,    24,     0,    25,    26,    88,    89,    90,    91,
     300,     0,    92,    93,     0,     0,     0,    27,     0,     0,
       0,     0,    28,     0,    29,    30,    31,     0,   169,    32,
      33,    34,    84,    85,    86,    87,    35,    36,   155,   156,
     157,   158,   159,   226,   227,   228,   229,   230,     0,     0,
      88,    89,    90,    91,   231,   232,    92,    93,     0,     0,
       0,    72,     0,     0,    73,     0,     0,    11,     0,    94,
       0,     0,     0,    95,    96,   113,     0,    75,    76,    77,
      72,    97,     0,    73,     0,     0,    11,     0,   312,     0,
      72,   233,     0,    73,    74,     0,    75,    76,    77,     0,
       0,   234,   235,     0,    74,     0,    75,    76,    77,    78,
       0,     0,     0,    94,   391,     0,    72,    95,    96,    73,
     155,   156,   157,   158,   159,    97,    72,     0,    78,    73,
      74,     0,    75,    76,    77,     0,     0,   114,    78,     0,
     217,     0,    75,    76,    77,     0,   155,   156,   157,   158,
     159,     0,    32,     0,   218,   403,     0,   219,     0,    72,
       0,     0,    73,   411,    78,   412,   413,    72,   313,     0,
      73,    32,     0,    74,    78,    75,    76,    77,     0,     0,
     334,   217,     0,    75,    76,    77,     0,   155,   156,   157,
     158,   159,   368,     0,   178,     0,   155,   156,   157,   158,
     159,   409,     0,     0,     0,     0,   304,    78,   155,   156,
     157,   158,   159,   256,     0,    78,    88,    89,    90,    91,
     155,   156,   157,   158,   159,   155,   156,   157,   158,   159,
     258,     0,     0,     0,   261,    88,    89,    90,    91,   316,
     400,     0,     0,   317,     0,     0,     0,   155,   156,   157,
     158,   159,    88,    89,    90,    91,    88,    89,    90,    91,
       0,    88,    89,    90,    91,    88,    89,    90,    91,   200,
       0,   201,   202,   203,   204,   205,   206,     0,   207,   208,
     201,   202,   203,   204,   205,   206,     0,   207,   208,   201,
     202,   203,   204,   205,   206,   155,   156,   157,   158,   159
};

static const short int yycheck[] =
{
       6,    34,    24,     9,    15,    42,    18,    19,   147,    21,
      17,   188,   243,     9,    99,    25,     3,    27,    29,     6,
       3,   110,     8,    29,    35,     8,    86,    87,     3,     3,
      17,    27,    19,    20,    21,    95,    27,    97,    44,    22,
      12,    13,    14,    15,    25,    55,    27,     9,   187,    71,
     139,    30,    31,    32,    33,    25,   140,   142,     9,    36,
      37,    67,     6,    74,    51,    99,     9,    78,    51,   103,
     154,   160,     6,    79,    55,    86,    87,    51,    64,    65,
      66,    92,    93,     9,    95,    55,    97,     8,    94,   174,
      96,   176,   104,    17,   271,   102,   103,   274,    94,    10,
     137,    17,   113,   109,    30,    31,     8,     8,    34,    35,
      12,    13,    14,    15,   101,    86,   255,     6,   129,   100,
      18,    93,    17,   134,   184,    97,    98,    17,    30,    31,
      32,    33,    94,   105,   223,   113,   114,   171,   277,   150,
     151,    92,   176,    94,   155,   156,   157,   158,   159,    92,
     239,    94,    50,    51,    52,    53,    54,    17,     0,   248,
     172,   392,     4,   302,    27,   177,    30,    31,    94,    41,
      34,    35,   179,   184,     8,     8,    62,   262,   189,    18,
     191,     6,   188,    22,    38,    39,     6,   418,    42,    73,
      74,    93,   198,   199,   425,    97,    98,    30,    31,     8,
     211,    34,    35,   105,     9,    88,   217,    68,    18,     8,
     349,   222,    22,    12,    13,    14,    15,    52,    53,    54,
     231,    22,    25,   201,   202,   203,   204,   205,   206,   207,
     208,    30,    31,    32,    33,     9,     8,   243,     8,    18,
      50,    51,    52,    53,    54,   257,    27,   269,   260,   388,
       8,    42,    59,    18,   265,   266,   267,   268,     8,    12,
      13,    14,    15,   352,     8,   276,    63,   100,   279,    30,
      31,    32,    33,     8,    22,     9,    50,    51,    52,    53,
      54,    42,     8,    36,    37,    54,   297,     8,    84,   300,
     323,   324,     8,   304,    93,    68,    36,    37,    97,    98,
      68,    88,   313,    26,   310,    85,   105,     8,     8,     8,
      50,    51,    52,    53,    54,    50,    51,    52,    53,    54,
      94,     8,     8,   334,     8,    72,     8,     8,   339,     8,
       8,    22,   343,     8,   345,   346,   347,     8,     8,    68,
      93,    18,    83,     8,    97,    98,    99,    85,   354,    68,
     361,   362,   105,     8,   113,   119,   101,   368,     3,    99,
       5,    35,     7,     8,     9,   419,    11,    26,    99,   380,
     109,    16,   330,    50,    51,    52,    53,    54,    23,    24,
     330,   310,   349,    28,    29,    -1,   392,    -1,    -1,   400,
      -1,    50,    51,    52,    53,    54,    41,   408,   409,    44,
     411,   412,   413,    -1,     8,    -1,    51,    -1,    12,    13,
      14,    15,   418,    58,    -1,    60,    61,    -1,    -1,   425,
      -1,    -1,    67,    -1,    69,    70,    30,    31,    32,    33,
      22,    -1,    36,    37,    -1,    -1,    -1,    82,    -1,    -1,
      -1,    -1,    87,    -1,    89,    90,    91,    -1,     8,    94,
      95,    96,    12,    13,    14,    15,   101,   102,    50,    51,
      52,    53,    54,    45,    46,    47,    48,    49,    -1,    -1,
      30,    31,    32,    33,    56,    57,    36,    37,    -1,    -1,
      -1,     3,    -1,    -1,     6,    -1,    -1,     9,    -1,    93,
      -1,    -1,    -1,    97,    98,    17,    -1,    19,    20,    21,
       3,   105,    -1,     6,    -1,    -1,     9,    -1,    18,    -1,
       3,    93,    -1,     6,    17,    -1,    19,    20,    21,    -1,
      -1,   103,   104,    -1,    17,    -1,    19,    20,    21,    51,
      -1,    -1,    -1,    93,    18,    -1,     3,    97,    98,     6,
      50,    51,    52,    53,    54,   105,     3,    -1,    51,     6,
      17,    -1,    19,    20,    21,    -1,    -1,    79,    51,    -1,
      17,    -1,    19,    20,    21,    -1,    50,    51,    52,    53,
      54,    -1,    94,    -1,    31,    18,    -1,    34,    -1,     3,
      -1,    -1,     6,    50,    51,    52,    53,     3,    22,    -1,
       6,    94,    -1,    17,    51,    19,    20,    21,    -1,    -1,
      22,    17,    -1,    19,    20,    21,    -1,    50,    51,    52,
      53,    54,    22,    -1,     8,    -1,    50,    51,    52,    53,
      54,    26,    -1,    -1,    -1,    -1,    50,    51,    50,    51,
      52,    53,    54,     8,    -1,    51,    30,    31,    32,    33,
      50,    51,    52,    53,    54,    50,    51,    52,    53,    54,
       8,    -1,    -1,    -1,     8,    30,    31,    32,    33,     8,
      43,    -1,    -1,     8,    -1,    -1,    -1,    50,    51,    52,
      53,    54,    30,    31,    32,    33,    30,    31,    32,    33,
      -1,    30,    31,    32,    33,    30,    31,    32,    33,    71,
      -1,    73,    74,    75,    76,    77,    78,    -1,    80,    81,
      73,    74,    75,    76,    77,    78,    -1,    80,    81,    73,
      74,    75,    76,    77,    78,    50,    51,    52,    53,    54
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   107,     0,     4,   108,   109,   110,     3,     5,     7,
       8,     9,    11,    16,    23,    24,    28,    29,    41,    44,
      51,    58,    60,    61,    67,    69,    70,    82,    87,    89,
      90,    91,    94,    95,    96,   101,   102,   111,   116,   123,
     125,   126,   127,   132,   136,   137,   138,   144,   154,   156,
     157,   159,   160,   161,   166,   168,   172,   175,   177,   181,
     183,   185,   188,   190,   192,   196,   197,    92,   116,   167,
     176,   124,     3,     6,    17,    19,    20,    21,    51,   118,
     128,     6,   114,     8,    12,    13,    14,    15,    30,    31,
      32,    33,    36,    37,    93,    97,    98,   105,   121,   122,
     139,   140,   141,   142,   143,    42,   141,   141,     3,   141,
      27,   114,   173,    17,    79,   116,   128,   129,   130,     6,
     186,   116,   128,   189,   191,     8,    17,   178,    10,   113,
     134,   128,   131,   132,    17,   135,     8,    22,   126,    27,
     116,   119,   122,   116,     8,    86,     6,   114,   128,    17,
      17,    17,   128,   115,   116,    50,    51,    52,    53,    54,
      27,   118,   118,   128,   128,   116,   118,   116,   118,     8,
     121,   142,   143,   139,   122,     8,   122,   143,     8,   141,
       8,    38,    39,    42,   146,   147,    41,   155,   136,   113,
     134,    62,   162,     6,   128,   129,   130,   129,    73,    74,
      71,    73,    74,    75,    76,    77,    78,    80,    81,    25,
      55,   112,     6,     8,    88,     9,    68,    17,    31,    34,
     128,   133,   193,    22,     8,   128,    45,    46,    47,    48,
      49,    56,    57,    93,   103,   104,   126,   134,   135,    25,
       8,   170,     8,   119,    18,    18,   128,   128,    27,   135,
     128,   128,   128,   128,   128,   134,     8,   143,     8,     8,
     143,     8,   122,     8,   118,    30,    31,    34,    35,   100,
     120,   145,   153,    42,   119,   120,    59,   158,   128,    63,
     163,   174,    18,   116,   116,   182,   129,   129,   129,   129,
     129,   129,   129,   129,   128,   187,     8,    22,     8,   128,
      22,   128,   134,    18,    50,   128,     9,     8,   134,   169,
      84,   115,    18,    22,   134,   119,     8,     8,   128,   128,
     128,   128,   114,    27,   112,   150,   151,   152,   120,     8,
     120,     8,   128,   119,    22,   128,   164,    68,    68,    26,
      88,   117,   128,    22,   128,    36,    37,    99,   194,   195,
     119,   128,    26,    85,    92,   116,   167,     8,   128,     8,
       8,   113,   113,     8,   152,   153,     8,   128,    22,     8,
      64,    65,    66,   165,     8,    72,   179,   128,     8,    18,
      22,   128,   128,   128,   128,   119,   194,     8,   134,   116,
       8,    18,   128,   148,   128,     8,     8,   128,   180,     8,
      43,   149,   128,    18,     8,   119,   171,   115,    22,    26,
      68,    50,    52,    53,   128,    83,     8,    85,   128,   128,
     128,   128,   128,   184,   115,   149,    68,   115,     8
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);


# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()
    ;
#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 4:
#line 193 "../grap-1.39-src/grap.y"
    {
                if ( !the_graph)
		    the_graph = initial_graph();
		the_graph->init();
		init_dict();
		first_line = true;
		the_graph->begin_block((yyvsp[0].String));
	    }
    break;

  case 5:
#line 201 "../grap-1.39-src/grap.y"
    {
		the_graph->draw(0);
		the_graph->end_block();
	    }
    break;

  case 6:
#line 207 "../grap-1.39-src/grap.y"
    { }
    break;

  case 7:
#line 209 "../grap-1.39-src/grap.y"
    { }
    break;

  case 8:
#line 213 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 9:
#line 215 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 10:
#line 217 "../grap-1.39-src/grap.y"
    {
		first_line = false;
		the_graph->queue_frame();
		the_graph->is_visible(true);
	    }
    break;

  case 11:
#line 223 "../grap-1.39-src/grap.y"
    { first_line = false; }
    break;

  case 12:
#line 225 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 13:
#line 227 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 14:
#line 229 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 15:
#line 231 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 16:
#line 233 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 17:
#line 235 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 18:
#line 237 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 19:
#line 239 "../grap-1.39-src/grap.y"
    { first_line = false; the_graph->is_visible(true);}
    break;

  case 20:
#line 241 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 21:
#line 243 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 22:
#line 245 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 23:
#line 247 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 24:
#line 249 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 25:
#line 251 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 26:
#line 253 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 27:
#line 255 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 28:
#line 257 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 29:
#line 259 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 30:
#line 261 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 31:
#line 263 "../grap-1.39-src/grap.y"
    { first_line = false;}
    break;

  case 35:
#line 272 "../grap-1.39-src/grap.y"
    { (yyval.coordptr)= defcoord; }
    break;

  case 36:
#line 274 "../grap-1.39-src/grap.y"
    { (yyval.coordptr)= (yyvsp[0].coordptr);}
    break;

  case 37:
#line 278 "../grap-1.39-src/grap.y"
    { (yyval.String) = 0; }
    break;

  case 38:
#line 280 "../grap-1.39-src/grap.y"
    { (yyval.String) = (yyvsp[0].String); }
    break;

  case 39:
#line 284 "../grap-1.39-src/grap.y"
    { (yyval.ds) = 0; }
    break;

  case 40:
#line 286 "../grap-1.39-src/grap.y"
    {
		(yyval.ds) = new DisplayString(*(yyvsp[-1].String), (yyvsp[0].stringmod).just, (yyvsp[0].stringmod).size, (yyvsp[0].stringmod).rel, 
		    (yyvsp[0].stringmod).clip, (yyvsp[0].stringmod).color);
	    }
    break;

  case 41:
#line 294 "../grap-1.39-src/grap.y"
    { (yyval.String) = (yyvsp[0].String); }
    break;

  case 42:
#line 296 "../grap-1.39-src/grap.y"
    {
		 if ( do_sprintf ) {
		     const int len = (yyvsp[-3].String)->length() < 128 ? 256 : 2*(yyvsp[-3].String)->length();
		     char *buf = new char[len];

		     // I really dislike this, but I dislike trying to do it
		     // incrementally more.
		     switch ((yyvsp[-1].double_vec)->size()) {
			case 0:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str());
			    break;
			case 1:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0]);
			    break;
			case 2:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1]);
			    break;
			case 3:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2]);
			    break;
			case 4:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3]);
			    break;
			case 5:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4]);
			    break;
			case 6:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4], (*(yyvsp[-1].double_vec))[5]);
			    break;
			case 7:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4], (*(yyvsp[-1].double_vec))[5], 
				(*(yyvsp[-1].double_vec))[6]);
			    break;
			case 8:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4], (*(yyvsp[-1].double_vec))[5], 
				(*(yyvsp[-1].double_vec))[6], (*(yyvsp[-1].double_vec))[7]);
			    break;
			case 9:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4], (*(yyvsp[-1].double_vec))[5], 
				(*(yyvsp[-1].double_vec))[6], (*(yyvsp[-1].double_vec))[7], (*(yyvsp[-1].double_vec))[8]);
			    break;
			default:
			    cerr << "more that 10 arguments to sprintf.  " << 
				"Ignoring more than 10." << endl;
			case 10:
			    snprintf(buf, len, (yyvsp[-3].String)->c_str(), (*(yyvsp[-1].double_vec))[0], (*(yyvsp[-1].double_vec))[1], 
				(*(yyvsp[-1].double_vec))[2], (*(yyvsp[-1].double_vec))[3], (*(yyvsp[-1].double_vec))[4], (*(yyvsp[-1].double_vec))[5], 
				(*(yyvsp[-1].double_vec))[6], (*(yyvsp[-1].double_vec))[7], (*(yyvsp[-1].double_vec))[8], (*(yyvsp[-1].double_vec))[9]);
			    break;
		     }
		     delete (yyvsp[-1].double_vec); delete (yyvsp[-3].String);

		     (yyval.String) = new string(buf);
		     delete[] buf;
		 }
		 else (yyval.String) = (yyvsp[-3].String);
	     }
    break;

  case 43:
#line 364 "../grap-1.39-src/grap.y"
    {
		(yyval.double_vec) = new doublevec;
		(yyval.double_vec)->push_back((yyvsp[0].num));
	    }
    break;

  case 44:
#line 369 "../grap-1.39-src/grap.y"
    {
		(yyval.double_vec) = (yyvsp[-2].double_vec);
		(yyval.double_vec)->push_back((yyvsp[0].num));
	    }
    break;

  case 45:
#line 376 "../grap-1.39-src/grap.y"
    { (yyval.num) = 0; }
    break;

  case 46:
#line 378 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 47:
#line 382 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc; (yyval.lined) = 0;}
    break;

  case 48:
#line 384 "../grap-1.39-src/grap.y"
    {  (yyval.lined) = (yyvsp[0].lined);}
    break;

  case 49:
#line 388 "../grap-1.39-src/grap.y"
    { (yyval.shift_list) = new shiftlist;}
    break;

  case 50:
#line 390 "../grap-1.39-src/grap.y"
    {
		(yyval.shift_list) = (yyvsp[0].shift_list);
		(yyval.shift_list)->push_back((yyvsp[-1].shift));
	    }
    break;

  case 51:
#line 399 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(invis); }
    break;

  case 52:
#line 401 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(solid); }
    break;

  case 53:
#line 403 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(dotted, (yyvsp[0].num)); }
    break;

  case 54:
#line 405 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(dashed, (yyvsp[0].num)); }
    break;

  case 55:
#line 407 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(def, 0, (yyvsp[0].String)); }
    break;

  case 56:
#line 409 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(def, 0, 0, (yyvsp[0].num)); }
    break;

  case 57:
#line 411 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(def, 0, 0, 0, (yyvsp[0].String)); }
    break;

  case 58:
#line 413 "../grap-1.39-src/grap.y"
    { (yyval.lined) = new linedesc(def, 0, 0, 0, 0, (yyvsp[0].num)); }
    break;

  case 59:
#line 418 "../grap-1.39-src/grap.y"
    { (yyval.lined) = (yyvsp[0].lined); }
    break;

  case 60:
#line 420 "../grap-1.39-src/grap.y"
    { (yyval.lined) = combine_linedesc((yyvsp[-1].lined), (yyvsp[0].lined)); }
    break;

  case 61:
#line 424 "../grap-1.39-src/grap.y"
    { lex_no_coord(); }
    break;

  case 62:
#line 425 "../grap-1.39-src/grap.y"
    { draw_statement((yyvsp[-3].String), (yyvsp[-2].lined), (yyvsp[-1].ds)); lex_coord_ok(); }
    break;

  case 63:
#line 430 "../grap-1.39-src/grap.y"
    { num_list((yyvsp[-1].double_list)); }
    break;

  case 64:
#line 435 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 65:
#line 438 "../grap-1.39-src/grap.y"
    { (yyval.num) = -(yyvsp[0].num); }
    break;

  case 66:
#line 443 "../grap-1.39-src/grap.y"
    {
		(yyval.double_list) = new doublelist;
		(yyval.double_list)->push_back((yyvsp[0].num));
	    }
    break;

  case 67:
#line 448 "../grap-1.39-src/grap.y"
    {
		(yyval.double_list) = (yyvsp[-1].double_list);
		(yyval.double_list)->push_back((yyvsp[0].num));
	    }
    break;

  case 68:
#line 453 "../grap-1.39-src/grap.y"
    {
		(yyval.double_list) = (yyvsp[-2].double_list);
		(yyval.double_list)->push_back((yyvsp[0].num));
	    }
    break;

  case 69:
#line 461 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-2].num) + (yyvsp[0].num); }
    break;

  case 70:
#line 463 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-2].num) - (yyvsp[0].num); }
    break;

  case 71:
#line 465 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-2].num) * (yyvsp[0].num); }
    break;

  case 72:
#line 467 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-2].num) / (yyvsp[0].num); }
    break;

  case 73:
#line 469 "../grap-1.39-src/grap.y"
    { (yyval.num) = pow((yyvsp[-2].num),(yyvsp[0].num));}
    break;

  case 74:
#line 471 "../grap-1.39-src/grap.y"
    { (yyval.num) = - (yyvsp[0].num);}
    break;

  case 75:
#line 473 "../grap-1.39-src/grap.y"
    { (yyval.num) = ( (yyvsp[-2].val) >=0 && (yyvsp[-2].val) < NF0 ) ? jtf0[(yyvsp[-2].val)]() : 0; }
    break;

  case 76:
#line 475 "../grap-1.39-src/grap.y"
    { (yyval.num) = ( (yyvsp[-3].val) >=0 && (yyvsp[-3].val) < NF1 ) ? jtf1[(yyvsp[-3].val)]((yyvsp[-1].num)) : 0; }
    break;

  case 77:
#line 477 "../grap-1.39-src/grap.y"
    { (yyval.num) = ( (yyvsp[-5].val) >=0 && (yyvsp[-5].val) < NF2 ) ? jtf2[(yyvsp[-5].val)]((yyvsp[-3].num), (yyvsp[-1].num)) : 0; }
    break;

  case 78:
#line 479 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-1].num); }
    break;

  case 79:
#line 481 "../grap-1.39-src/grap.y"
    {
		doubleDictionary::iterator di;
		
		if ( (di = vars.find(*(yyvsp[0].String))) != vars.end())
		    (yyval.num) = *(*di).second;
		else {
		    cerr << *(yyvsp[0].String) << " is uninitialized, using 0.0" << endl;
		    (yyval.num) = 0.0;
		}

		delete (yyvsp[0].String);
	     }
    break;

  case 80:
#line 494 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 81:
#line 499 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 82:
#line 501 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-1].num); }
    break;

  case 83:
#line 503 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 84:
#line 508 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) == (yyvsp[0].num)); }
    break;

  case 85:
#line 510 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) != (yyvsp[0].num)); }
    break;

  case 86:
#line 512 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) < (yyvsp[0].num)); }
    break;

  case 87:
#line 514 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) > (yyvsp[0].num)); }
    break;

  case 88:
#line 516 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) <= (yyvsp[0].num)); }
    break;

  case 89:
#line 518 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) >= (yyvsp[0].num)); }
    break;

  case 90:
#line 520 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) && (yyvsp[0].num)); }
    break;

  case 91:
#line 522 "../grap-1.39-src/grap.y"
    { (yyval.num) = ((yyvsp[-2].num) || (yyvsp[0].num)); }
    break;

  case 92:
#line 524 "../grap-1.39-src/grap.y"
    { (yyval.num) = ! ( (int) (yyvsp[0].num)); }
    break;

  case 93:
#line 526 "../grap-1.39-src/grap.y"
    { (yyval.num) = (*(yyvsp[-2].String) == *(yyvsp[0].String)); delete (yyvsp[-2].String); delete (yyvsp[0].String); }
    break;

  case 94:
#line 528 "../grap-1.39-src/grap.y"
    { (yyval.num) = (*(yyvsp[-2].String) != *(yyvsp[0].String)); delete (yyvsp[-2].String); delete (yyvsp[0].String); }
    break;

  case 95:
#line 532 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[-1].num); }
    break;

  case 96:
#line 533 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 97:
#line 538 "../grap-1.39-src/grap.y"
    { (yyval.num) = assignment_statement((yyvsp[-1].String), (yyvsp[0].num));  }
    break;

  case 98:
#line 543 "../grap-1.39-src/grap.y"
    { (yyval.pt) = new point((yyvsp[-2].num), (yyvsp[0].num), 0); }
    break;

  case 99:
#line 545 "../grap-1.39-src/grap.y"
    { (yyval.pt) = new point((yyvsp[-3].num), (yyvsp[-1].num), 0); }
    break;

  case 100:
#line 549 "../grap-1.39-src/grap.y"
    { (yyval.pt) = new point((yyvsp[0].pt)->x, (yyvsp[0].pt)->y, (yyvsp[-1].coordptr)); delete (yyvsp[0].pt); }
    break;

  case 101:
#line 553 "../grap-1.39-src/grap.y"
    {
		(yyval.stringmod).size = 0;
		(yyval.stringmod).rel =0;
		(yyval.stringmod).just = (unaligned_default) ? unaligned : 0;
		(yyval.stringmod).clip = clip_default;
		(yyval.stringmod).color = 0;
	    }
    break;

  case 102:
#line 561 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).size = (yyvsp[0].num); (yyval.stringmod).rel = ((yyvsp[0].num)<0); }
    break;

  case 103:
#line 563 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).size = (yyvsp[0].num); (yyval.stringmod).rel = 1; }
    break;

  case 104:
#line 565 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) ljust; }
    break;

  case 105:
#line 567 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) rjust; }
    break;

  case 106:
#line 569 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) above; }
    break;

  case 107:
#line 571 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) below; }
    break;

  case 108:
#line 573 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) aligned; }
    break;

  case 109:
#line 575 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).just |= (int) unaligned; }
    break;

  case 110:
#line 577 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).clip = true; }
    break;

  case 111:
#line 579 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).clip = false; }
    break;

  case 112:
#line 581 "../grap-1.39-src/grap.y"
    { (yyval.stringmod).color = (yyvsp[0].String); }
    break;

  case 113:
#line 586 "../grap-1.39-src/grap.y"
    {
		DisplayString *s;

		s = new DisplayString(*(yyvsp[-1].String),(yyvsp[0].stringmod).just,(yyvsp[0].stringmod).size, (yyvsp[0].stringmod).rel, 
		    (yyvsp[0].stringmod).clip, (yyvsp[0].stringmod).color);
		delete (yyvsp[-1].String);
		(yyval.string_list) = new stringlist;
		(yyval.string_list)->push_back(s);
	    }
    break;

  case 114:
#line 596 "../grap-1.39-src/grap.y"
    { (yyval.string_list) = combine_strings((yyvsp[-2].string_list), (yyvsp[-1].String), (yyvsp[0].stringmod)); }
    break;

  case 115:
#line 601 "../grap-1.39-src/grap.y"
    {
  		the_graph->new_plot((yyvsp[-3].string_list),(yyvsp[-1].pt));
	    }
    break;

  case 116:
#line 605 "../grap-1.39-src/grap.y"
    { plot_statement((yyvsp[-4].num), (yyvsp[-3].ds), (yyvsp[-1].pt)); }
    break;

  case 117:
#line 610 "../grap-1.39-src/grap.y"
    { next_statement((yyvsp[-4].String), (yyvsp[-2].pt), (yyvsp[-1].lined)); }
    break;

  case 118:
#line 615 "../grap-1.39-src/grap.y"
    {
		(yyval.frameptr) = new frame;
		(yyval.frameptr)->ht = (yyvsp[0].num);
		(yyval.frameptr)->wid = 0;
	    }
    break;

  case 119:
#line 621 "../grap-1.39-src/grap.y"
    {
		(yyval.frameptr) = new frame;
		(yyval.frameptr)->wid = (yyvsp[0].num);
		(yyval.frameptr)->ht = 0;
	    }
    break;

  case 120:
#line 630 "../grap-1.39-src/grap.y"
    { (yyval.frameptr) = (yyvsp[0].frameptr); }
    break;

  case 121:
#line 632 "../grap-1.39-src/grap.y"
    {
		(yyval.frameptr) = (yyvsp[-1].frameptr);
		// Fill in non-default ht/wid
		
		if ( (yyvsp[0].frameptr)->ht != 0 ) (yyval.frameptr)->ht = (yyvsp[0].frameptr)->ht;
		if ( (yyvsp[0].frameptr)->wid != 0 ) (yyval.frameptr)->wid = (yyvsp[0].frameptr)->wid;
	    }
    break;

  case 122:
#line 643 "../grap-1.39-src/grap.y"
    { (yyval.side) = top_side;}
    break;

  case 123:
#line 645 "../grap-1.39-src/grap.y"
    { (yyval.side)= bottom_side;}
    break;

  case 124:
#line 647 "../grap-1.39-src/grap.y"
    { (yyval.side) = left_side;}
    break;

  case 125:
#line 649 "../grap-1.39-src/grap.y"
    { (yyval.side) = right_side; }
    break;

  case 126:
#line 654 "../grap-1.39-src/grap.y"
    {
		// This rule combines the explicit size settings with
		// the defaults. We create a new frame to have access
		// to the default sizes without needing to code them
		// explicitly (they're always implicit in a default
		// frame). N. B. that frames created by size (and
		// size_elem) use 0 to indicate no change to the ht or
		// wid.
		
		(yyval.frameptr) = new frame;

		if ( (yyvsp[0].frameptr)->ht != 0) (yyval.frameptr)->ht = (yyvsp[0].frameptr)->ht;
		if ( (yyvsp[0].frameptr)->wid != 0) (yyval.frameptr)->wid = (yyvsp[0].frameptr)->wid;
		delete (yyvsp[0].frameptr);
	    }
    break;

  case 127:
#line 671 "../grap-1.39-src/grap.y"
    {
		(yyval.frameptr) = new frame;
		(yyval.frameptr)->desc[(yyvsp[-1].side)] = *(yyvsp[0].lined);
		delete (yyvsp[0].lined);
	    }
    break;

  case 128:
#line 677 "../grap-1.39-src/grap.y"
    {
		if ( !(yyvsp[-2].frameptr) ) (yyval.frameptr) = new frame;
		else (yyval.frameptr) = (yyvsp[-2].frameptr);
		
		(yyval.frameptr)->desc[(yyvsp[-1].side)] = *(yyvsp[0].lined);
		delete (yyvsp[0].lined);
	    }
    break;

  case 129:
#line 703 "../grap-1.39-src/grap.y"
    { process_frame(0, 0, 0); }
    break;

  case 130:
#line 705 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-1].lined), 0, 0); }
    break;

  case 131:
#line 707 "../grap-1.39-src/grap.y"
    { process_frame(0, (yyvsp[-1].frameptr), 0); }
    break;

  case 132:
#line 709 "../grap-1.39-src/grap.y"
    { process_frame(0, 0, (yyvsp[-1].frameptr)); }
    break;

  case 133:
#line 711 "../grap-1.39-src/grap.y"
    { process_frame(0, (yyvsp[-2].frameptr), (yyvsp[-1].frameptr)); }
    break;

  case 134:
#line 713 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-2].lined), 0, (yyvsp[-1].frameptr)); }
    break;

  case 135:
#line 715 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-2].lined), (yyvsp[-1].frameptr), 0); }
    break;

  case 136:
#line 717 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-1].lined), (yyvsp[-2].frameptr), 0); }
    break;

  case 137:
#line 719 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-3].lined), (yyvsp[-2].frameptr), (yyvsp[-1].frameptr));}
    break;

  case 138:
#line 721 "../grap-1.39-src/grap.y"
    { process_frame((yyvsp[-2].lined), (yyvsp[-3].frameptr), (yyvsp[-1].frameptr)); }
    break;

  case 139:
#line 726 "../grap-1.39-src/grap.y"
    { (yyval.shift) = new shiftdesc(top_side, (yyvsp[0].num)); }
    break;

  case 140:
#line 728 "../grap-1.39-src/grap.y"
    { (yyval.shift) = new shiftdesc(bottom_side, (yyvsp[0].num)); }
    break;

  case 141:
#line 730 "../grap-1.39-src/grap.y"
    { (yyval.shift) = new shiftdesc(left_side, (yyvsp[0].num)); }
    break;

  case 142:
#line 732 "../grap-1.39-src/grap.y"
    { (yyval.shift) = new shiftdesc(right_side, (yyvsp[0].num)); }
    break;

  case 143:
#line 737 "../grap-1.39-src/grap.y"
    { (yyval.val) = -1; }
    break;

  case 144:
#line 739 "../grap-1.39-src/grap.y"
    { (yyval.val) = 1; }
    break;

  case 145:
#line 743 "../grap-1.39-src/grap.y"
    { (yyval.num) = 0.125; }
    break;

  case 146:
#line 745 "../grap-1.39-src/grap.y"
    {
		if ( (yyvsp[0].num) == 0 ) (yyval.num) = (yyvsp[-1].val) * 0.125;
		else (yyval.num) = (yyvsp[-1].val) * (yyvsp[0].num);
	    }
    break;

  case 147:
#line 753 "../grap-1.39-src/grap.y"
    { (yyval.tick_list) = ticklist_elem((yyvsp[-1].num), (yyvsp[0].ds), 0); }
    break;

  case 148:
#line 755 "../grap-1.39-src/grap.y"
    { (yyval.tick_list) = ticklist_elem((yyvsp[-1].num), (yyvsp[0].ds), (yyvsp[-3].tick_list)); }
    break;

  case 149:
#line 759 "../grap-1.39-src/grap.y"
    { (yyval.by).op = PLUS; (yyval.by).expr = 1; }
    break;

  case 150:
#line 761 "../grap-1.39-src/grap.y"
    {
		(yyval.by).op = PLUS;
		if ( (yyvsp[0].num) != 0.0 ) (yyval.by).expr = (yyvsp[0].num);
		else (yyval.by).expr = 1;
	    }
    break;

  case 151:
#line 767 "../grap-1.39-src/grap.y"
    { (yyval.by).op = PLUS; (yyval.by).expr = (yyvsp[0].num); }
    break;

  case 152:
#line 769 "../grap-1.39-src/grap.y"
    { (yyval.by).op = TIMES; (yyval.by).expr = (yyvsp[0].num); }
    break;

  case 153:
#line 771 "../grap-1.39-src/grap.y"
    { (yyval.by).op = DIV; (yyval.by).expr = (yyvsp[0].num); }
    break;

  case 154:
#line 776 "../grap-1.39-src/grap.y"
    {
		(yyval.tick_list) = (yyvsp[0].tick_list);
		for (ticklist::iterator t= (yyvsp[0].tick_list)->begin(); t != (yyvsp[0].tick_list)->end(); t++)
		    (*t)->c = (yyvsp[-1].coordptr);
	    }
    break;

  case 155:
#line 785 "../grap-1.39-src/grap.y"
    { (yyval.tick_list) = tick_for((yyvsp[-5].coordptr), (yyvsp[-4].num), (yyvsp[-2].num), (yyvsp[-1].by), (yyvsp[0].ds)); }
    break;

  case 156:
#line 789 "../grap-1.39-src/grap.y"
    { (yyval.tick_list) = (yyvsp[0].tick_list);}
    break;

  case 157:
#line 791 "../grap-1.39-src/grap.y"
    { (yyval.tick_list)= (yyvsp[0].tick_list); }
    break;

  case 158:
#line 796 "../grap-1.39-src/grap.y"
    {
		coordinateDictionary::iterator ci;

		if ( (yyvsp[0].String) ) {
		    ci = the_graph->coords.find(*(yyvsp[0].String));
		    if ( ci != the_graph->coords.end()) 
			(yyval.coordptr) = (*ci).second;
		    else {
			yyerror("Name must name a coordinate space");
		    }
		}
		else (yyval.coordptr) = 0;
		
	    }
    break;

  case 159:
#line 811 "../grap-1.39-src/grap.y"
    {
		(yyval.coordptr) = 0;
            }
    break;

  case 160:
#line 818 "../grap-1.39-src/grap.y"
    { ticks_statement((yyvsp[-4].side), (yyvsp[-3].num), (yyvsp[-2].shift_list), (yyvsp[-1].tick_list)); }
    break;

  case 161:
#line 820 "../grap-1.39-src/grap.y"
    {
		for ( int i = 0; i< 4; i++ )
		    the_graph->base->tickdef[i].size = 0;
	    }
    break;

  case 162:
#line 825 "../grap-1.39-src/grap.y"
    { the_graph->base->tickdef[(yyvsp[-2].side)].size = 0; }
    break;

  case 163:
#line 827 "../grap-1.39-src/grap.y"
    {
		the_graph->base->tickdef[(yyvsp[-3].side)].size = (yyvsp[-2].num);
		if ( (yyvsp[-1].coordptr) ) the_graph->base->tickdef[(yyvsp[-3].side)].c = (yyvsp[-1].coordptr);
	    }
    break;

  case 164:
#line 834 "../grap-1.39-src/grap.y"
    { (yyval.val) = 0; }
    break;

  case 165:
#line 836 "../grap-1.39-src/grap.y"
    { (yyval.val) = 1; }
    break;

  case 166:
#line 841 "../grap-1.39-src/grap.y"
    {
		grid_statement((yyvsp[-5].side), (yyvsp[-4].val), (yyvsp[-3].lined), (yyvsp[-2].shift_list), (yyvsp[-1].tick_list));
	    }
    break;

  case 167:
#line 845 "../grap-1.39-src/grap.y"
    {
		grid_statement((yyvsp[-5].side), (yyvsp[-4].val), (yyvsp[-3].lined), (yyvsp[-2].shift_list), 0);
		// Because turning on a grid on a given side disables
		// automatic tick generation there, this is sets up
		// that side with the proper coordinates.
		if ( (yyvsp[-1].coordptr) ) the_graph->base->griddef[(yyvsp[-5].side)].c = (yyvsp[-1].coordptr);
	    }
    break;

  case 168:
#line 856 "../grap-1.39-src/grap.y"
    {
		shiftdesc *sd;

		for (stringlist::iterator s = (yyvsp[-2].string_list)->begin(); s != (yyvsp[-2].string_list)->end(); s++)
		    if ( ! ((*s)->j & unaligned) ) (*s)->j |= aligned;
		
		the_graph->base->label[(yyvsp[-3].side)] = (yyvsp[-2].string_list);

		// Copy the label shifts into the frame
		while (!(yyvsp[-1].shift_list)->empty() ) {
		    sd = (yyvsp[-1].shift_list)->front();
		    (yyvsp[-1].shift_list)->pop_front();
		    the_graph->base->lshift[(yyvsp[-3].side)]->push_back(sd);
		}
		delete (yyvsp[-1].shift_list);
	    }
    break;

  case 169:
#line 874 "../grap-1.39-src/grap.y"
    { (yyval.num) = 0.025; }
    break;

  case 170:
#line 876 "../grap-1.39-src/grap.y"
    { (yyval.num) = (yyvsp[0].num); }
    break;

  case 171:
#line 881 "../grap-1.39-src/grap.y"
    {
		the_graph->new_circle((yyvsp[-3].pt),(yyvsp[-2].num),(yyvsp[-1].lined));
		delete (yyvsp[-3].pt); delete (yyvsp[-1].lined);
	    }
    break;

  case 172:
#line 889 "../grap-1.39-src/grap.y"
    { (yyval.val) = 1; }
    break;

  case 173:
#line 891 "../grap-1.39-src/grap.y"
    { (yyval.val) = 0; }
    break;

  case 174:
#line 896 "../grap-1.39-src/grap.y"
    { line_statement((yyvsp[-7].val), (yyvsp[-6].lined), (yyvsp[-4].pt), (yyvsp[-2].pt), (yyvsp[-1].lined)); }
    break;

  case 175:
#line 900 "../grap-1.39-src/grap.y"
    { (yyval.axistype).which=none; }
    break;

  case 176:
#line 902 "../grap-1.39-src/grap.y"
    { (yyval.axistype) = axis_description(x_axis, (yyvsp[-2].num), (yyvsp[0].num)); }
    break;

  case 177:
#line 905 "../grap-1.39-src/grap.y"
    { (yyval.axistype).which=none; }
    break;

  case 178:
#line 907 "../grap-1.39-src/grap.y"
    { (yyval.axistype) = axis_description(y_axis, (yyvsp[-2].num), (yyvsp[0].num)); }
    break;

  case 179:
#line 912 "../grap-1.39-src/grap.y"
    { (yyval.axisname) = combine_logs((yyvsp[-1].axisname), (yyvsp[0].axisname)); }
    break;

  case 180:
#line 914 "../grap-1.39-src/grap.y"
    { (yyval.axisname) = none; }
    break;

  case 181:
#line 919 "../grap-1.39-src/grap.y"
    { (yyval.axisname) = x_axis; }
    break;

  case 182:
#line 921 "../grap-1.39-src/grap.y"
    { (yyval.axisname) = y_axis; }
    break;

  case 183:
#line 923 "../grap-1.39-src/grap.y"
    { (yyval.axisname) = both; }
    break;

  case 184:
#line 929 "../grap-1.39-src/grap.y"
    {
		coord_statement((yyvsp[-4].String), (yyvsp[-3].axistype), (yyvsp[-2].axistype), (yyvsp[-1].axisname));
		delete (yyvsp[-4].String);
	    }
    break;

  case 185:
#line 936 "../grap-1.39-src/grap.y"
    { (yyval.copyd) = 0; }
    break;

  case 186:
#line 938 "../grap-1.39-src/grap.y"
    {
		unquote((yyvsp[0].String));
		(yyval.copyd) = new copydesc;
		(yyval.copyd)->t = copydesc::until;
		(yyval.copyd)->s = (yyvsp[0].String);
	    }
    break;

  case 187:
#line 945 "../grap-1.39-src/grap.y"
    {
		unquote((yyvsp[0].String));
		(yyval.copyd) = new copydesc;
		(yyval.copyd)->t = copydesc::fname;
		(yyval.copyd)->s = (yyvsp[0].String);
	    }
    break;

  case 188:
#line 960 "../grap-1.39-src/grap.y"
    {
		unquote((yyvsp[-1].String));
		if (!include_file((yyvsp[-1].String), false)) return 0;
	    }
    break;

  case 189:
#line 965 "../grap-1.39-src/grap.y"
    {
		unquote((yyvsp[-1].String));
		lex_begin_copy((yyvsp[-1].String));
	    }
    break;

  case 190:
#line 970 "../grap-1.39-src/grap.y"
    {
		string s="";
		while ((yyvsp[0].line_list) && !(yyvsp[0].line_list)->empty() ) {
		    string *ss;
		    ss = (yyvsp[0].line_list)->front();
		    (yyvsp[0].line_list)->pop_front();
		    if ( ss ) {
			s+= *ss;
			s+= '\n';
			delete ss;
			ss = 0;
		    }
		}
		include_string(&s, 0, GINTERNAL);
		delete (yyvsp[0].line_list);
	    }
    break;

  case 191:
#line 986 "../grap-1.39-src/grap.y"
    { lex_hunt_macro(); }
    break;

  case 192:
#line 987 "../grap-1.39-src/grap.y"
    {
		copydesc *c = 0; // To shut the compiler up about uninit
		if ( (yyvsp[-5].copyd) && (yyvsp[-1].copyd) ) {
		    delete (yyvsp[-5].copyd);
		    delete (yyvsp[-1].copyd);
		    yyerror("Only specify 1 until or filename\n");
		}
		else c = ((yyvsp[-5].copyd)) ? (yyvsp[-5].copyd) : (yyvsp[-1].copyd);
		// The else handles files with neither else clause, copying
		// text to the trailing .G2.  Fix from Bruce Lilly
		if ( c ) {
		    // lex_begin_copy takes command of the string that's
		    // passed to it, so don't delete it.  (I don't
		    // remember why I did that...)
		    if ( c->t == copydesc::until ) {
			lex_begin_copy(c->s);
			c->s = 0;
		    }
		    else {
			lex_begin_copy(0);
			include_file(c->s, false);
		    }
		    delete c;
		}
		else lex_begin_copy(0);
	    }
    break;

  case 193:
#line 1014 "../grap-1.39-src/grap.y"
    {
		string *s;
		string *t;
		int lim;
		char end;
		stack<string *> st;

		while ( (yyvsp[0].line_list) && !(yyvsp[0].line_list)->empty() ) {
		    int i = 0;
		    t = new string;
		    
		    s = (yyvsp[0].line_list)->front();
		    (yyvsp[0].line_list)->pop_front();
		    lim = s->length();
		    
		    while ( i < lim ) {
			if ( (*s)[i] == ' ' || (*s)[i] == '\t' ) {
			    if ( t->length() ) {
				if ( (yyvsp[-4].macro_val)->add_arg(t)) 
				    t = new string;
			    }
			} else *t += (*s)[i];
			i++;
		    }
		    if ( t->length() ) (yyvsp[-4].macro_val)->add_arg(t);
		    else if (t) delete t;
		    t = (yyvsp[-4].macro_val)->invoke();
		    // "here" macros should end with a SEP.  If the
		    // user hasn't done so, we add a SEP for them.
		    // Even named macros should get a sep when they're
		    // copied through,

		    end = (*t)[t->length()-1];

		    if ( end != ';' && end != '\n' ) 
			*t += ';';
		    // Because include string stacks the strings, we stack them
		    // here and call include_string in reverse order to ensure
		    // correct ordered execution of multiple lines.
		    st.push(t);
		    delete s;
		}
		delete (yyvsp[0].line_list);
		while ( !st.empty() ) {
		    include_string(st.top(), 0, GMACRO);
		    delete st.top();
		    st.pop();
	        }
		// don't delete defined macros
		if ( !(yyvsp[-4].macro_val)->name)
		    delete (yyvsp[-4].macro_val);
	    }
    break;

  case 194:
#line 1069 "../grap-1.39-src/grap.y"
    { lex_no_coord(); lex_no_macro_expansion();}
    break;

  case 195:
#line 1070 "../grap-1.39-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 196:
#line 1071 "../grap-1.39-src/grap.y"
    { lex_macro_expansion_ok(); lex_coord_ok(); define_macro((yyvsp[-3].String), (yyvsp[-1].String)); }
    break;

  case 197:
#line 1075 "../grap-1.39-src/grap.y"
    { lex_no_coord(); lex_no_macro_expansion(); }
    break;

  case 198:
#line 1075 "../grap-1.39-src/grap.y"
    {
	    lex_coord_ok();
	    lex_macro_expansion_ok();
	    macros.erase(*(yyvsp[-1].String));
	    delete (yyvsp[-1].String);
	}
    break;

  case 199:
#line 1083 "../grap-1.39-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 200:
#line 1084 "../grap-1.39-src/grap.y"
    {
		int len = (yyvsp[-1].String)->length()+1 ;
		char *sys = new char [len];
		int i=0;

		// String to char*
		       
		while ((sys[i] = (*(yyvsp[-1].String))[i]))
		    i++;

		delete (yyvsp[-1].String);
		
		system(sys);
	    }
    break;

  case 201:
#line 1101 "../grap-1.39-src/grap.y"
    { (yyval.String) = 0; }
    break;

  case 202:
#line 1102 "../grap-1.39-src/grap.y"
    {lex_begin_macro_text(); }
    break;

  case 203:
#line 1103 "../grap-1.39-src/grap.y"
    {
		// force else clause to end with a SEP
		*(yyvsp[0].String)+= ';';
		(yyval.String) = (yyvsp[0].String);
	    }
    break;

  case 204:
#line 1111 "../grap-1.39-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 205:
#line 1112 "../grap-1.39-src/grap.y"
    {
		// force all if blocks to be terminated by a SEP.  
		*(yyvsp[-2].String) += ';';
		// We use EPSILON in loop tests 
		if ( fabs((yyvsp[-5].num)) > EPSILON ) include_string((yyvsp[-2].String),0,GINTERNAL);
		else if ( (yyvsp[-1].String) ) include_string((yyvsp[-1].String),0,GINTERNAL);
		delete (yyvsp[-2].String);
		if ( (yyvsp[-1].String)) delete (yyvsp[-1].String);
	    }
    break;

  case 206:
#line 1125 "../grap-1.39-src/grap.y"
    { lex_begin_macro_text(); }
    break;

  case 207:
#line 1126 "../grap-1.39-src/grap.y"
    { for_statement((yyvsp[-9].String), (yyvsp[-7].num), (yyvsp[-5].num), (yyvsp[-4].by), (yyvsp[-1].String)); }
    break;

  case 208:
#line 1130 "../grap-1.39-src/grap.y"
    { lex_no_coord(); }
    break;

  case 209:
#line 1130 "../grap-1.39-src/grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 210:
#line 1131 "../grap-1.39-src/grap.y"
    {
		if ( !first_line ) {
		    // Only draw the graph and clear its internals if
		    // it is visible.  This allows a user to declare
		    // things like coordinate spaces before the graph
		    // itself is named.  This is a compatibility
		    // feature for DWB grap.
		    if ( the_graph->is_visible() ) {
			the_graph->draw(0);
			the_graph->init((yyvsp[-3].String), (yyvsp[-1].String));
			init_dict();
		    }
		    else
			the_graph->setname((yyvsp[-3].String));
		}
		else {
		    the_graph->init((yyvsp[-3].String), (yyvsp[-1].String));
		    init_dict();
		}
		    
		if ( (yyvsp[-3].String) ) delete (yyvsp[-3].String);
		if ( (yyvsp[-1].String) ) delete (yyvsp[-1].String);
	    }
    break;

  case 212:
#line 1162 "../grap-1.39-src/grap.y"
    {
		unquote((yyvsp[0].String));
		cerr <<  *(yyvsp[0].String) << endl;
	    }
    break;

  case 213:
#line 1167 "../grap-1.39-src/grap.y"
    {
		cerr << (yyvsp[0].num) << endl;
	    }
    break;

  case 214:
#line 1173 "../grap-1.39-src/grap.y"
    { lex_begin_rest_of_line(); }
    break;

  case 215:
#line 1174 "../grap-1.39-src/grap.y"
    { the_graph->passthru_string(*(yyvsp[-1].String)); delete (yyvsp[-1].String);}
    break;

  case 216:
#line 1178 "../grap-1.39-src/grap.y"
    { the_graph->passthru_string(*(yyvsp[-1].String)); delete (yyvsp[-1].String);}
    break;

  case 217:
#line 1183 "../grap-1.39-src/grap.y"
    { (yyval.side) = right_side; }
    break;

  case 218:
#line 1185 "../grap-1.39-src/grap.y"
    { (yyval.side) = top_side; }
    break;

  case 219:
#line 1191 "../grap-1.39-src/grap.y"
    { (yyval.bar_p) = new bar_param; (yyval.bar_p)->ht = (yyvsp[0].num); (yyval.bar_p)->have_ht = true; }
    break;

  case 220:
#line 1192 "../grap-1.39-src/grap.y"
    { (yyval.bar_p) = new bar_param; (yyval.bar_p)->wid = (yyvsp[0].num); }
    break;

  case 221:
#line 1193 "../grap-1.39-src/grap.y"
    { (yyval.bar_p) = new bar_param; (yyval.bar_p)->base = (yyvsp[0].num); }
    break;

  case 222:
#line 1197 "../grap-1.39-src/grap.y"
    { (yyval.bar_p) = (yyvsp[0].bar_p); }
    break;

  case 223:
#line 1198 "../grap-1.39-src/grap.y"
    { 
		(yyval.bar_p) = (yyvsp[-1].bar_p);
		if ( (yyvsp[0].bar_p) ) {
			if ((yyvsp[0].bar_p)->have_x ) { (yyval.bar_p)->x = (yyvsp[0].bar_p)->x; (yyval.bar_p)->have_x = true; }
			if ((yyvsp[0].bar_p)->have_ht ) { 
				(yyval.bar_p)->ht = (yyvsp[0].bar_p)->ht; (yyval.bar_p)->have_ht = true;
			}
			if ( (yyvsp[0].bar_p)->wid != 1.0 ) { (yyval.bar_p)->wid = (yyvsp[0].bar_p)->wid; }
			if ( (yyvsp[0].bar_p)->base != 0.0 ) { (yyval.bar_p)->base = (yyvsp[0].bar_p)->base; }
			delete (yyvsp[0].bar_p);
		}
	}
    break;

  case 224:
#line 1214 "../grap-1.39-src/grap.y"
    {
		// The point parsing has already autoscaled the
		// coordinate system to include those points.
		the_graph->new_box((yyvsp[-4].pt), (yyvsp[-2].pt), (yyvsp[-1].lined));
		delete (yyvsp[-4].pt); delete (yyvsp[-2].pt); delete (yyvsp[-1].lined);
	    }
    break;

  case 225:
#line 1221 "../grap-1.39-src/grap.y"
    { 
	   	if ( !(yyvsp[-2].bar_p) || !(yyvsp[-2].bar_p)->have_ht ) {
			yyerror("bar must have a position and ht ");
		}
		else {
			bar_statement((yyvsp[-5].coordptr), (yyvsp[-4].side), (yyvsp[-3].num), (yyvsp[-2].bar_p)->ht, (yyvsp[-2].bar_p)->wid, 
				(yyvsp[-2].bar_p)->base, (yyvsp[-1].lined));
		}
		delete (yyvsp[-2].bar_p);
	}
    break;

  case 226:
#line 1235 "../grap-1.39-src/grap.y"
    { if ( (yyvsp[-3].val) >=0 && (yyvsp[-3].val) < NVF1 ) jtvf1[(yyvsp[-3].val)]((yyvsp[-1].num)); }
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 3429 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping", yystos[yystate], yyvsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1237 "../grap-1.39-src/grap.y"


