/* config.h.  Generated automatically by configure.  */
#ifndef CONFIG_H
#define CONFIG_H
// This file is (c) 1998 Ted Faber (faber@lunabase.org) see COPYRIGHT
// for the full copyright and limitations of liabilities.

// The following are set by configure

#define STDC_HEADERS 1
#define HAVE_UNISTD_H 1
#define HAVE_HASH_MAP 1
/* #define USE_STD_STRING 1 */
/* #define HAVE_SNPRINTF 1 */
/* #define HAVE_RANDOM 1 */
#define HAVE_RAND 1
#define HAVE_STRDUP 1
#define RANDOM_DECLARED 1
/* #undef OPTARG_DEFINED */
/* #undef SPRINTF_NOT_INT */

#endif
