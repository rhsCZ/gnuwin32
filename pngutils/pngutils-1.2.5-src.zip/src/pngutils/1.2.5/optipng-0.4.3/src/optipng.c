/**
 ** OptiPNG: a PNG optimization program.
 ** http://www.cs.toronto.edu/~cosmin/pngtech/optipng/
 **
 ** Copyright (C) 2001-2003 Cosmin Truta <cosmin@cs.toronto.edu>
 ** The program is distributed under the same licensing and warranty
 ** terms as libpng.
 **
 ** This program functions as follows:
 ** For each input image, it reduces the bit depth, color type and
 ** palette without losing any information; combines several methods
 ** and strategies of compression; and reencodes the IDAT data using
 ** the best method found. If none of these methods yield a smaller
 ** IDAT, then the original IDAT is preserved.
 ** The output file will have all the IDAT data in a single chunk.
 **
 ** The idea of running multiple trials with different PNG filters
 ** and zlib parameters is based on the pngcrush program by
 ** Glenn Randers-Pehrson <randeg@alum.rpi.edu>.
 **
 ** Requirements:
 **    ANSI C or ISO C compiler and library.
 **    zlib (version 1.1.4 or newer is strongly recommended).
 **    libpng version 1.0.X or newer, with the following options enabled:
 **        PNG_bKGD,hIST,sBIT,tRNS_SUPPORTED
 **        PNG_INFO_IMAGE_SUPPORTED
 **        PNG_FREE_ME_SUPPORTED
 **        OPNG_IMAGE_REDUCTIONS_SUPPORTED
 **    cbitset (version 0.1 is bundled).
 **    cexcept version 1.0.0 or newer (version 2.0.0 is bundled).
 **/

#include <ctype.h>
#include <limits.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "opng.h"
#include "cbitset.h"
#include "cexcept.h"


static const char *msg_intro =
   "OptiPNG: PNG optimizer version 0.4.3\n"
   "Copyright (C) 2001-2003 Cosmin Truta\n\n";

static const char *msg_license =
   "This program is open-source software. See LICENSE for more details.\n";

static const char *msg_short_help =
   "Type \"optipng -h\" for advanced help.\n"
   "\n"
   "Usage:\n"
   "    optipng [options] files.png ...\n"
   "Basic options:\n"
   "    -h, -help\t\tshow the advanced help\n"
   "    -v\t\t\tverbose mode / show copyright, version and build info\n"
   "    -o  <level>\t\toptimization level (0-7)\t\tdefault 2\n"
   "    -i  <type>\t\tinterlace type (0-1)\t\t\tdefault <input>\n"
   "    -k, -keep\t\tkeep a backup of the input files\n"
   "    -log\t\tlog messages to \"optipng.log\"\n"
   "    -q, -quiet\t\tquiet mode\n"
   "Examples:\n"
   "    optipng -o5 file.png\t\t\t(moderately slow)\n"
   "    optipng -o7 file.png\t\t\t(very slow)\n"
   "    optipng -i1 -zc4,9 -zs0-2 -f0-2,4-5 file1.png file2.png\n";

static const char *msg_help =
   "Usage:\n"
   "    optipng [options] files.png ...\n"
   "Basic options:\n"
   "    -h, -help\t\tshow this help\n"
   "    -v\t\t\tverbose mode / show copyright, version and build info\n"
   "    -o  <level>\t\toptimization level (0-7)\t\tdefault 2\n"
#if 0  /* not implemented */
   "    -b  <depth>\t\tbit depth (1,2,4,8,16)\t\t\tdefault <input>\n"
   "    -c  <type>\t\tcolor type (0,2,3,4,6)\t\t\tdefault <input>\n"
#endif
   "    -i  <type>\t\tinterlace type (0-1)\t\t\tdefault <input>\n"
   "    -k, -keep\t\tkeep a backup of the input files\n"
   "    -log\t\tlog messages to \"optipng.log\"\n"
   "    -q, -quiet\t\tquiet mode\n"
   "Advanced options:\n"
   "    -zc <levels>\tzlib compression levels (1-9)\t\tdefault 9\n"
   "    -zm <levels>\tzlib memory levels (1-9)\t\tdefault 8\n"
   "    -zs <strategies>\tzlib compression strategies (0-2)\tdefault 0-2\n"
#ifdef WBITS_8_OK
   "    -zw <window size>\tzlib window size (32k,16k,8k,4k,2k,1k,512,256)\n"
#else
   "    -zw <window size>\tzlib window size (32k,16k,8k,4k,2k,1k,512)\n"
#endif
   "    -f  <filters>\tPNG delta filters (0-5)\t\t\tdefault 0,5\n"
   "    -fix\t\tenable error recovery\n"
   "    -force\t\twrite a new output even if it is larger than the input\n"
   "    -nb\t\t\tno bit depth reduction\n"
   "    -nc\t\t\tno color type reduction\n"
   "    -no\t\t\tno output (simulation mode)\n"
   "    -np\t\t\tno palette reduction\n"
#if 0
   "    -nt\t\t\tno text chunk optimization\n"
#endif
   "    -nx\t\t\tno IDAT recompression (disable all reductions)\n"
   "    --\t\t\tstop option switch parsing\n"
   "Optimization level presets:\n"
   "    -o0  <=>  -nx\n"
   "    -o1  <=>  [apply libpng heuristics]\t\t(1 trial)\n"
   "    -o2  <=>  -zc9 -zm8 -zs0-2 -f0,5\t\t(6 trials)\n"
   "    -o3  <=>  -zc9 -zm8-9 -zs0-2 -f0,5\t\t(12 trials)\n"
   "    -o4  <=>  -zc9 -zm8 -zs0-2 -f0-5\t\t(18 trials)\n"
   "    -o5  <=>  -zc9 -zm8-9 -zs0-2 -f0-5\t\t(36 trials)\n"
   "    -o6  <=>  -zc1-9 -zm8 -zs0-2 -f0-5\t\t(114 trials)\n"
   "    -o7  <=>  -zc1-9 -zm8-9 -zs0-2 -f0-5\t(228 trials)\n"
   "Examples:\n"
   "    optipng -o5 file.png\t\t\t(moderately slow)\n"
   "    optipng -o7 file.png\t\t\t(very slow)\n"
   "    optipng -i1 -zc4,9 -zs0-2 -f0-2,4-5 file1.png file2.png\n"
   "Notes:\n"
   "  - The options are cummulative; e.g.\n"
   "    -f0 -f5  <=>  -f0,5\n"
   "    -zs0 -zs1 -zs2  <=>  -zs0,1,2  <=>  -zs0-2\n"
   "  - The option letters are case-insensitive.\n"
   "  - The libpng heuristics consist of:\n"
   "    -o1  <=>  -zc9 -zm8 -zs0 -f0\t\t(if PLTE is present)\n"
   "    -o1  <=>  -zc9 -zm8 -zs1 -f5\t\t(if PLTE is not present)\n"
   "  - The zlib window size is set to a minimum that does not affect\n"
   "    the compression ratio.\n"
   "  - The output file will have all IDAT in a single chunk, even if\n"
   "    no recompression is performed.\n"
   "  - The most exhaustive search  -zc1-9 -zm1-9 -zs0-2 -f0-5  (1026 trials)\n"
   "    is offered only as an advanced option, and it is not recommended.\n";


/** Log file name **/
#define LOG_FILE_NAME "optipng.log"


/** Program tables, limits and presets **/
#define OPTIM_LEVEL_MIN     0
#define OPTIM_LEVEL_MAX     7
#define OPTIM_LEVEL_DEFAULT 2

/*  "-"  <=>  "MIN-MAX"  */

#define COMPR_LEVEL_MIN     1
#define COMPR_LEVEL_MAX     9
static const char *optim_compr_level_presets[OPTIM_LEVEL_MAX + 1] =
   { "", "", "9", "9", "9", "9", "-", "-" };

#define MEM_LEVEL_MIN       1
#define MEM_LEVEL_MAX       9
static const char *optim_mem_level_presets[OPTIM_LEVEL_MAX + 1] =
   { "", "", "8", "8-", "8", "8-", "8", "8-" };

#define STRATEGY_MIN        0
#define STRATEGY_MAX        2
static const char *optim_strategy_presets[OPTIM_LEVEL_MAX + 1] =
   { "", "", "-", "-", "-", "-", "-", "-" };

#define FILTER_MIN          0
#define FILTER_MAX          5
static const char *optim_filter_presets[OPTIM_LEVEL_MAX + 1] =
   { "", "", "0,5", "0,5", "-", "-", "-", "-" };


/** The only ancillary chunks handled by libpng and OptiPNG **/
static const png_byte sig_bKGD[4] = { 0x62, 0x4b, 0x47, 0x44 };
static const png_byte sig_hIST[4] = { 0x68, 0x49, 0x53, 0x54 };
static const png_byte sig_sBIT[4] = { 0x73, 0x42, 0x49, 0x54 };
static const png_byte sig_tRNS[4] = { 0x74, 0x52, 0x4e, 0x53 };
/** The chunks for which OptiPNG provides special handling **/
static const png_byte sig_IDAT[4] = { 0x49, 0x44, 0x41, 0x54 };
static const png_byte sig_IEND[4] = { 0x49, 0x45, 0x4e, 0x44 };


/** User exception setup -- see cexcept.h for more info **/
define_exception_type(const char *);
struct exception_context the_exception_context[1];


/** OptiPNG-specific info **/
static struct opng_image_struct
{
   png_uint_32 width, height;
   int bit_depth, color_type, compression_type, filter_type, interlace_type;
   png_colorp palette;            /* PLTE */
   int num_palette;
   png_bytepp row_pointers;       /* IDAT */
   png_color_16p background_ptr;
   png_color_16 background;       /* bKGD */
   png_uint_16p hist;             /* hIST */
   png_color_8p sig_bit_ptr;
   png_color_8 sig_bit;           /* sBIT */
   png_bytep trans;               /* tRNS */
   int num_trans;
   png_color_16p trans_values_ptr;
   png_color_16 trans_values;
   png_unknown_chunkp unknowns;
   int num_unknowns;
} opng_image;

static struct opng_info_struct
{
   png_uint_32 file_size, idat_size;
   png_uint_32 best_file_size, best_idat_size, total_idat_size;
   unsigned int num_idat_chunks;
   png_uint_32 reductions;
   int valid;
   int best_compr_level, best_mem_level, best_strategy, best_filter;
} opng_info;

static struct cmdline_struct
{
   int has_files;
   int help, ver;
   int interlace;
   int keep, log, quiet;
   int fix, force;
   int nb, nc, no, np, nx;
   bitset compr_level_table, mem_level_table, strategy_table, filter_table;
   int window_bits;
} cmdline;

static struct global_struct
{
   FILE *logfile;
   unsigned int err_count, fix_count;
} global;


/** Global variables, for quick access and bonus style points **/
static png_structp read_ptr, write_ptr;
static png_infop read_info_ptr, write_info_ptr;
static png_infop read_end_info_ptr, write_end_info_ptr;


/** Message output w/ logging **/
static void
opng_printf(const char *fmt, ...)
{
   va_list arg_ptr;
   FILE *confile;

   va_start(arg_ptr, fmt);

   /* If the message starts with '!', it is sent to stderr. */
   if (fmt[0] == '!')
   {
      ++fmt;
      confile = stderr;
   }
   else
      confile = stdout;
   if (cmdline.quiet)
      confile = NULL;

   if (confile != NULL)
      vfprintf(confile, fmt, arg_ptr);
   if (global.logfile != NULL)
   {
      vfprintf(global.logfile, fmt, arg_ptr);
      fflush(global.logfile);
   }

   va_end(arg_ptr);
}


/** Helper for statistics report **/
static void
opng_print_size_difference(png_uint_32 init_size, png_uint_32 final_size,
   int show_percent)
{
   long difference = (long)final_size - (long)init_size;

   if (difference == 0)
   {
      opng_printf("no change");
      return;
   }

   if (init_size == 0)
      show_percent = 0;
   if (show_percent)
   {
      if (difference > 0)
         opng_printf("%ld bytes = %ld.%02ld%% increase", difference,
            difference * 100 / init_size,
            ((difference * 100 % init_size) * 100 + init_size / 2) /
               init_size);
      else /* difference < 0 */
         opng_printf("%ld bytes = %ld.%02ld%% reduction", -difference,
            (-difference) * 100 / init_size,
            (((-difference) * 100 % init_size) * 100 + init_size / 2) /
               init_size);
   }
   else /* !show_percent */
   {
      if (difference > 0)
         opng_printf("%ld bytes increase", difference);
      else /* difference < 0 */
         opng_printf("%ld bytes reduction", -difference);
   }
}


/** User error handling **/
static void
opng_error(png_structp png_ptr, png_const_charp msg)
{
   msg += (png_ptr - png_ptr);  /* dummy, keep compilers happy */
   opng_info.valid = 0;
   Throw msg;
}


/** User warning **/
static void
opng_warning(png_structp png_ptr, png_const_charp msg)
{
   msg += (png_ptr - png_ptr);  /* dummy, keep compilers happy */
   opng_info.valid = 0;
   opng_printf("!Warning: %s\n", msg);
}


/** Query for chunk handling **/
static int
opng_handle_as_unknown(png_bytep chunk_type)
{
   if ((chunk_type[0] & 0x20) == 0  /* critical chunk? */  ||
       memcmp(chunk_type, sig_bKGD, 4) == 0 ||
       memcmp(chunk_type, sig_hIST, 4) == 0 ||
       memcmp(chunk_type, sig_sBIT, 4) == 0 ||
       memcmp(chunk_type, sig_tRNS, 4) == 0)
      return 0;
   return 1;
}


/** User chunk keeping **/
static void
opng_set_keep_unknown_chunk(png_structp png_ptr, png_bytep chunk_type)
{
   png_byte chunk_name[5];

   memcpy(chunk_name, chunk_type, 4);
   chunk_name[4] = 0;
   if (!png_handle_as_unknown(png_ptr, chunk_name))
      png_set_keep_unknown_chunks(png_ptr, HANDLE_CHUNK_ALWAYS, chunk_name, 1);
      /* ... but why HANDLE_CHUNK_... isn't PNG_HANDLE_CHUNK_... ? */
}


/** User reading/writing of data **/
static void
opng_read_write_data(png_structp png_ptr, png_bytep data, png_size_t length)
{
   static png_byte crt_chunk_len[4], crt_chunk_hdr[4];
   static png_uint_32 crt_idat_crc;
   static int crt_chunk_is_idat;
   FILE *fp = (FILE *)png_get_io_ptr(png_ptr);
   int io_state = opng_get_io_state(png_ptr);
   int io_state_loc = io_state & OPNG_IO_MASK_LOC;

   if (length == 0)
      return;
   assert(data != NULL);

   /* Reading is done at the beginning. */
   if (io_state & OPNG_IO_READING)
   {
      assert(fp != NULL);
      if (fread(data, length, 1, fp) != 1)
         png_error(png_ptr,
            "Can't read the input file or unexpected end of file");
   }

   /* Update file_size, idat_size, etc. */
   opng_info.file_size += length;
   if (io_state_loc == OPNG_IO_LEN)
   {
      assert(length == 4);
      memcpy(crt_chunk_len, data, 4);
   }
   else if (io_state_loc == OPNG_IO_HDR)
   {
      assert(length == 4);
      memcpy(crt_chunk_hdr, data, 4);
      if (memcmp(data, sig_IDAT, 4) == 0)
      {
         crt_chunk_is_idat = 1;
         ++opng_info.num_idat_chunks;
         opng_info.idat_size += png_get_uint_32(crt_chunk_len);
         if (opng_info.idat_size > PNG_MAX_UINT)
            png_error(png_ptr, "Overflow (file too big?)");
      }
      else
      {
         crt_chunk_is_idat = 0;
         if (opng_handle_as_unknown(data))
            opng_set_keep_unknown_chunk(png_ptr, data);
      }
   }

   /* Writing is done at the end. */
   if (fp == NULL || !(io_state & OPNG_IO_WRITING))
      return;

   /* Here comes an elaborate way of writing the data, in which
    * multiple IDATs are collapsed in a single chunk.
    * Normally, the user-supplied I/O routines are not so complicated.
    */
   if (opng_info.total_idat_size == 0)  /* if the target is unknown */
      crt_chunk_is_idat = 0;  /* act normally by pretending this isn't IDAT */
   switch (io_state_loc)
   {
      case OPNG_IO_LEN:
         /* Postpone the chunk length writing, to make sure it's not IDAT. */
         return;
      case OPNG_IO_HDR:
      {
         if (crt_chunk_is_idat)
         {
            if (opng_info.num_idat_chunks == 1)  /* the first */
            {
               /* Write the total IDAT length instead of the current one. */
               png_save_uint_32(crt_chunk_len, opng_info.total_idat_size);
               crt_idat_crc = crc32(0, sig_IDAT, 4);
            }
            else
            {
               opng_info.file_size -= 8;
               return;
            }
         }
         else
         {
            /* Sanity check: */
            /* Make sure IDAT is written completely, or not at all. */
            if (opng_info.num_idat_chunks != 0 &&
                opng_info.idat_size != opng_info.total_idat_size)
               png_error(png_ptr, "Internal error (inconsistent IDAT)");
         }
         /* Write the length before the header. */
         if (fwrite(crt_chunk_len, 4, 1, fp) != 1)
            length = 0;  /* this will trigger the error later */
         break;
      }
      case OPNG_IO_DATA:
      {
         if (crt_chunk_is_idat)
            crt_idat_crc = crc32(crt_idat_crc, data, length);
         break;
      }
      case OPNG_IO_CRC:
      {
         if (crt_chunk_is_idat)
         {
            if (opng_info.idat_size < opng_info.total_idat_size)
            {
               opng_info.file_size -= 4;
               return;
            }
            if (opng_info.idat_size > opng_info.total_idat_size)
               png_error(png_ptr, "Internal error (IDAT too big)");
            png_save_uint_32(data, crt_idat_crc);
         }
      }
   }
   if (fwrite(data, length, 1, fp) != 1)
      png_error(png_ptr, "Can't write the output file");
}


/** Image info transfer **/
static void
opng_get_image_info(png_structp png_ptr, png_infop info_ptr,
   png_infop end_info_ptr, int get_ancillary)
{
   png_debug(0, "Loading info struct\n");
   png_get_IHDR(png_ptr, info_ptr,
      &opng_image.width, &opng_image.height, &opng_image.bit_depth,
      &opng_image.color_type, &opng_image.interlace_type,
      &opng_image.compression_type, &opng_image.filter_type);
   png_get_PLTE(png_ptr, info_ptr,
      &opng_image.palette, &opng_image.num_palette);
   opng_image.row_pointers = png_get_rows(png_ptr, info_ptr);

   if (!get_ancillary)
      return;

   if (png_get_bKGD(png_ptr, info_ptr, &opng_image.background_ptr))
   {
      /* Double copying (pointer + value) is necessary here
       * due to an unfortunate design decision in libpng.
       */
      opng_image.background = *opng_image.background_ptr;
      opng_image.background_ptr = &opng_image.background;
   }
   png_get_hIST(png_ptr, info_ptr, &opng_image.hist);
   if (png_get_sBIT(png_ptr, info_ptr, &opng_image.sig_bit_ptr))
   {
      /* Same problem... */
      opng_image.sig_bit = *opng_image.sig_bit_ptr;
      opng_image.sig_bit_ptr = &opng_image.sig_bit;
   }
   if (png_get_tRNS(png_ptr, info_ptr,
      &opng_image.trans, &opng_image.num_trans,
      &opng_image.trans_values_ptr))
   {
      /* Same problem... */
      if (opng_image.trans_values_ptr != NULL)
      {
         opng_image.trans_values = *opng_image.trans_values_ptr;
         opng_image.trans_values_ptr = &opng_image.trans_values;
      }
   }
   opng_image.num_unknowns =
      png_get_unknown_chunks(png_ptr, info_ptr, &opng_image.unknowns);

   if (&end_info_ptr == NULL)  /* dummy, end_info_ptr is ignored */
      return;
}


/** Image info transfer **/
static void
opng_set_image_info(png_structp png_ptr, png_infop info_ptr,
   png_infop end_info_ptr, int set_ancillary)
{
   png_debug(0, "Storing info struct\n");
   png_set_IHDR(png_ptr, info_ptr,
      opng_image.width, opng_image.height, opng_image.bit_depth,
      opng_image.color_type, opng_image.interlace_type,
      opng_image.compression_type, opng_image.filter_type);
   if (opng_image.palette != NULL)
      png_set_PLTE(png_ptr, info_ptr,
         opng_image.palette, opng_image.num_palette);
   png_set_rows(write_ptr, write_info_ptr, opng_image.row_pointers);

   if (!set_ancillary)
      return;

   if (opng_image.background_ptr != NULL)
      png_set_bKGD(png_ptr, info_ptr, opng_image.background_ptr);
   if (opng_image.hist != NULL)
      png_set_hIST(png_ptr, info_ptr, opng_image.hist);
   if (opng_image.sig_bit_ptr != NULL)
      png_set_sBIT(png_ptr, info_ptr, opng_image.sig_bit_ptr);
   if (opng_image.trans != NULL || opng_image.trans_values_ptr != NULL)
      png_set_tRNS(png_ptr, info_ptr,
         opng_image.trans, opng_image.num_trans,
         opng_image.trans_values_ptr);
   if (opng_image.num_unknowns != 0)
   {
      int i;
      png_set_unknown_chunks(png_ptr, info_ptr,
         opng_image.unknowns, opng_image.num_unknowns);
      /* Is this really necessary? Shouldn't it be implemented in libpng? */
      for (i = 0; i < opng_image.num_unknowns; ++i)
         png_set_unknown_chunk_location(png_ptr, info_ptr,
            i, opng_image.unknowns[i].location);
   }

   if (&end_info_ptr == NULL)  /* dummy, end_info_ptr is ignored */
      return;
}


/** PNG file reading **/
static void
opng_read_png(FILE *infile)
{
   png_uint_32 reductions;
   const char *err_msg;

   static const char *color_type_name[7] =
   {
      "grayscale", "[invalid]", "RGB", "palette",
      "grayscale-alpha", "[invalid]", "RGB-alpha"
   };

   memset(&opng_image, 0, sizeof(opng_image));
   opng_info.file_size = opng_info.idat_size = 0;
   opng_info.num_idat_chunks = 0;

   assert(infile != NULL);

   Try
   {
      read_info_ptr = read_end_info_ptr = NULL;
      read_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
         NULL, opng_error, opng_warning);
      if (read_ptr != NULL)
      {
         read_info_ptr = png_create_info_struct(read_ptr);
         if (read_info_ptr != NULL)
            read_end_info_ptr = png_create_info_struct(read_ptr);
      }
      if (read_end_info_ptr == NULL)  /* something went wrong on the way */
         Throw "Out of memory";

      png_set_keep_unknown_chunks(read_ptr, HANDLE_CHUNK_ALWAYS, NULL, 0);

      png_debug(0, "Reading PNG file\n");
      opng_set_read_fn(read_ptr, infile, opng_read_write_data);
      png_read_png(read_ptr, read_info_ptr, 0, NULL);
   }
   Catch(err_msg)
   {
      /* If the critical info has been loaded, treat all errors as warnings.
         This enables a more advanced data recovery. */
      if (opng_validate_image(read_ptr, read_info_ptr))
         opng_warning(read_ptr, err_msg);
      else
      {
         /* Do the cleanup, then rethrow the exception. */
         png_data_freer(read_ptr, read_info_ptr,
            PNG_DESTROY_WILL_FREE_DATA, PNG_FREE_ALL);
         png_data_freer(read_ptr, read_end_info_ptr,
            PNG_DESTROY_WILL_FREE_DATA, PNG_FREE_ALL);
         png_destroy_read_struct(&read_ptr, &read_info_ptr,
            &read_end_info_ptr);
         Throw err_msg;
      }
   }

   png_debug(0, "Attempting to reduce image\n");
   reductions = OPNG_REDUCE_ALL;
   if (cmdline.nb)
      reductions &= ~OPNG_REDUCE_BIT_DEPTH;
   if (cmdline.nc)
      reductions &= ~OPNG_REDUCE_COLOR_TYPE;
   if (cmdline.np)
      reductions &= ~OPNG_REDUCE_PALETTE;
   opng_info.reductions = reductions =
      opng_reduce_image(read_ptr, read_info_ptr, reductions);

   opng_get_image_info(read_ptr, read_info_ptr, read_end_info_ptr, 1);

   if (reductions != OPNG_REDUCE_NONE)
   {
      opng_printf("The image type is losslessly reduced:\n");
      if (reductions & OPNG_REDUCE_BIT_DEPTH)
         opng_printf("  the bit depth is reduced to %d.\n",
            opng_image.bit_depth);
      if (reductions & OPNG_REDUCE_COLOR_TYPE)
         opng_printf("  the color type is reduced to %s.\n",
            color_type_name[opng_image.color_type]);
      if (reductions & OPNG_REDUCE_PALETTE)
         opng_printf("  the color palette or transparency is reduced.\n");
   }

   png_debug(0, "Destroying data structs\n");
   /* Leave the data for upcoming processing. */
   png_data_freer(read_ptr, read_info_ptr, PNG_USER_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_data_freer(read_ptr, read_end_info_ptr, PNG_USER_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_destroy_read_struct(&read_ptr, &read_info_ptr, &read_end_info_ptr);
}


/** PNG file writing **/
/** If the file name is NULL, opng_read_write_file() is still called,
    but no file is written. **/
static void
opng_write_png(FILE *outfile,
   int compression_level, int memory_level,
   int compression_strategy, int filter)
{
   const char *volatile err_msg;  /* volatile is required by cexcept */

   static int filter_table[FILTER_MAX + 1] =
   {
      PNG_FILTER_NONE, PNG_FILTER_SUB, PNG_FILTER_UP,
      PNG_FILTER_AVG, PNG_FILTER_PAETH, PNG_ALL_FILTERS
   };

   assert(compression_level >= COMPR_LEVEL_MIN &&
          compression_level <= COMPR_LEVEL_MAX);
   assert(memory_level >= MEM_LEVEL_MIN &&
          memory_level <= MEM_LEVEL_MAX);
   assert(compression_strategy >= STRATEGY_MIN &&
          compression_strategy <= STRATEGY_MAX);
   assert(filter >= FILTER_MIN &&
          filter <= FILTER_MAX);

   opng_info.file_size = opng_info.idat_size = 0;
   opng_info.num_idat_chunks = 0;

   Try
   {
      write_info_ptr = write_end_info_ptr = NULL;
      write_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
         NULL, opng_error, opng_warning);
      if (write_ptr != NULL)
      {
         write_info_ptr = png_create_info_struct(write_ptr);
         if (write_info_ptr != NULL)
            write_end_info_ptr = png_create_info_struct(write_ptr);
      }
      if (write_end_info_ptr == NULL)  /* something went wrong on the way */
         Throw "Out of memory";

      png_set_compression_level(write_ptr, compression_level);
      png_set_compression_mem_level(write_ptr, memory_level);
      png_set_compression_strategy(write_ptr, compression_strategy);
      png_set_filter(write_ptr, PNG_FILTER_TYPE_BASE, filter_table[filter]);
      if (filter_table[filter] != Z_HUFFMAN_ONLY)
      {
         if (cmdline.window_bits > 0)
            png_set_compression_window_bits(write_ptr, cmdline.window_bits);
      }
      else
      {
#ifdef WBITS_8_OK
         png_set_compression_window_bits(write_ptr, 8);
#else
         png_set_compression_window_bits(write_ptr, 9);
#endif
      }

      png_set_keep_unknown_chunks(write_ptr, HANDLE_CHUNK_ALWAYS, NULL, 0);

      /* The ancillary data is necessary during the final writing,
         and also whenever some reductions have been performed. */
      opng_set_image_info(write_ptr, write_info_ptr, write_end_info_ptr,
         outfile != NULL || opng_info.reductions != OPNG_REDUCE_NONE ? 1 : 0);

      png_debug(0, "Writing PNG file\n");
      opng_set_write_fn(write_ptr, outfile, opng_read_write_data, NULL);
      png_write_png(write_ptr, write_info_ptr, 0, NULL);

      err_msg = NULL;  /* everything is ok */
   }
   Catch (err_msg)
   {
   }

   png_debug(0, "Destroying data structs\n");
   /* The data is still needed. */
   png_data_freer(write_ptr, write_info_ptr, PNG_USER_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_data_freer(write_ptr, write_end_info_ptr, PNG_USER_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_destroy_info_struct(write_ptr, &write_end_info_ptr);
   png_destroy_write_struct(&write_ptr, &write_info_ptr);

   if (err_msg != NULL)
      Throw err_msg;
}


/** PNG file copying **/
static void
opng_copy_png(FILE *infile, FILE *outfile)
{
   volatile png_bytep buf;  /* volatile is required by cexcept */
   png_uint_32 buf_size, length;
   png_byte chunk_name[4];
   const char *volatile err_msg;

   assert(infile != NULL && outfile != NULL);

   opng_info.file_size = opng_info.idat_size = 0;
   opng_info.num_idat_chunks = 0;

   write_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
      NULL, opng_error, opng_warning);
   if (write_ptr == NULL)
      Throw "Out of memory";
   opng_set_write_fn(write_ptr, outfile, opng_read_write_data, NULL);

   Try
   {
      buf_size = 4096;
      buf = (png_bytep)png_malloc(write_ptr, buf_size);

      /* Copy the signature. */
      if (fread(buf, 8, 1, infile) != 1 || png_sig_cmp(buf, 0, 8) != 0)
         Throw "Not a PNG file";
      png_write_sig(write_ptr);

      do
      {
         /* Copy each chunk. */
         if (fread(buf, 8, 1, infile) != 1)  /* length + header */
            Throw "Read error";
         length = png_get_uint_32(buf);
         memcpy(chunk_name, buf + 4, 4);
         if (length > buf_size)
         {
            /* Don't use realloc() because it is slower. */
            png_free(write_ptr, buf);
            buf_size = length;
            buf = (png_bytep)png_malloc(write_ptr, buf_size);
         }
         if (fread(buf, 1, length, infile) != length)  /* data */
            Throw "Read error";
         png_write_chunk(write_ptr, chunk_name, buf, length);
         fread(buf, 4, 1, infile);  /* crc */
      } while (memcmp(chunk_name, sig_IEND, 4) != 0);

      err_msg = NULL;  /* everything is ok */
   }
   Catch (err_msg)
   {
   }

   png_free(write_ptr, buf);
   png_destroy_write_struct(&write_ptr, NULL);

   if (err_msg != NULL)
      Throw err_msg;
}


/** IDAT minimization via brute-force trials **/
static void
opng_minimize_idat(void)
{
   bitset compr_level_table = cmdline.compr_level_table;
   bitset mem_level_table   = cmdline.mem_level_table;
   bitset strategy_table    = cmdline.strategy_table;
   bitset filter_table      = cmdline.filter_table;
   int compr_level, mem_level, strategy, filter;

   /* Initialize the output. */
   opng_info.best_file_size   = opng_info.best_idat_size = PNG_MAX_UINT + 1;
   opng_info.best_compr_level = opng_info.best_mem_level =
      opng_info.best_strategy = opng_info.best_filter = -1;

   /* Replace the empty tables with the libpng's "best guess" heuristics. */
   if (compr_level_table == BITSET_EMPTY)
      BITSET_SET(compr_level_table, Z_BEST_COMPRESSION);  /* 9 */
   if (mem_level_table == BITSET_EMPTY)
      BITSET_SET(mem_level_table, 8);
   if (opng_image.bit_depth < 8 || opng_image.palette != NULL)
   {
      if (strategy_table == BITSET_EMPTY)
         BITSET_SET(strategy_table, Z_DEFAULT_STRATEGY);  /* 0 */
      if (filter_table == BITSET_EMPTY)
         BITSET_SET(filter_table, 0);
   }
   else
   {
      if (strategy_table == BITSET_EMPTY)
         BITSET_SET(strategy_table, Z_FILTERED);          /* 1 */
      if (filter_table == BITSET_EMPTY)
         BITSET_SET(filter_table, 5);
   }

   /* Iterate through the "hyper-rectangle" (zc, zm, zs, f). */
   opng_printf("Trying...\n");
   for (filter = FILTER_MIN; filter <= FILTER_MAX; ++filter)
      if (BITSET_GET(filter_table, filter))
         for (strategy = STRATEGY_MIN; strategy <= STRATEGY_MAX; ++strategy)
            if (BITSET_GET(strategy_table, strategy))
            {
               /* The output of Z_HUFFMAN_ONLY does not depend on
                  the compression level. */
               bitset saved_level_table = compr_level_table;
               if (strategy == Z_HUFFMAN_ONLY)
               {
                  compr_level_table = BITSET_EMPTY;
                  BITSET_SET(compr_level_table, 1);
               }
               for (compr_level = COMPR_LEVEL_MIN;
                    compr_level <= COMPR_LEVEL_MAX; ++compr_level)
                  if (BITSET_GET(compr_level_table, compr_level))
                  {
                     for (mem_level = MEM_LEVEL_MIN;
                          mem_level <= MEM_LEVEL_MAX; ++mem_level)
                        if (BITSET_GET(mem_level_table, mem_level))
                        {
                           opng_write_png(NULL,
                              compr_level, mem_level, strategy, filter);
                           opng_printf("  zc = %d  zm = %d  zs = %d  f = %d"
                              "\t\tIDAT size = %lu\n",
                              compr_level, mem_level, strategy, filter,
                              (unsigned long)opng_info.idat_size);
                           if (opng_info.best_idat_size < opng_info.idat_size)
                              continue;
                           if (opng_info.best_idat_size == opng_info.idat_size
                               && strategy != Z_HUFFMAN_ONLY
                               && opng_info.best_compr_level <= compr_level)
                              continue;  /* it's not a better combination */
                           opng_info.best_file_size   = opng_info.file_size;
                           opng_info.best_idat_size   = opng_info.idat_size;
                           opng_info.best_compr_level = compr_level;
                           opng_info.best_mem_level   = mem_level;
                           opng_info.best_strategy    = strategy;
                           opng_info.best_filter      = filter;
                        }
                  }
               compr_level_table = saved_level_table;
            }
}


/** PNG file optimization **/
static void
opng_optimize_png(const char *filename)
{
   static FILE *infile, *outfile;        /* static or volatile is required */
   volatile int replace;                 /* by cexcept */
   png_uint_32 init_file_size, init_idat_size;
   char bak_filename[FILENAME_MAX + 4];  /* make room for ".bak" */
   const char *err_msg;

   opng_printf("** Processing %s\n", filename);

   memset(&opng_info, 0, sizeof(opng_info));
   opng_info.valid = 1;
   replace = 0;
   if (cmdline.force)
      replace = 2;

   if ((infile = fopen(filename, "rb")) == NULL)
      Throw "Can't open the input file";
   Try
   {
      opng_read_png(infile);
   }
   Catch (err_msg)
   {
      fclose(infile);
      Throw err_msg;
   }
   fclose(infile);

   if (opng_info.num_idat_chunks > 1)
      replace = 1;  /* multiple IDATs must be collapsed */

   if (!opng_info.valid)
   {
      opng_printf("!Recoverable errors encountered. ");
      if (cmdline.fix)
      {
         opng_printf("!Fixing...\n");
         replace = 2;
         ++global.fix_count;
      }
      else
      {
         opng_printf("!Rerun the program with the -fix option.\n");
         Throw "Previous error(s) not fixed";
      }
   }

   if (cmdline.interlace >= 0 &&
       opng_image.interlace_type != cmdline.interlace)
   {
      opng_image.interlace_type = cmdline.interlace;
      replace = 2;
   }

   init_file_size = opng_info.file_size;
   init_idat_size = opng_info.total_idat_size = opng_info.idat_size;
   opng_printf("Input file size = %lu bytes\n"
               "Input IDAT size = %lu bytes\n",
      (unsigned long)init_file_size, (unsigned long)init_idat_size);

   if (replace >= 2 && cmdline.nx)
      opng_printf("!Warning: IDAT recompression is enforced.\n");
   if (replace >= 2 || !cmdline.nx)
   {
      opng_minimize_idat();
      opng_printf("\nThe best parameters are:\n"
         "  zc = %d  zm = %d  zs = %d  f = %d\t\tIDAT size = %lu\n",
         opng_info.best_compr_level, opng_info.best_mem_level,
         opng_info.best_strategy, opng_info.best_filter,
         (unsigned long)opng_info.best_idat_size);
      if (opng_info.reductions != OPNG_REDUCE_NONE)
      {
         if (opng_info.best_file_size < init_file_size)
            replace = 2;
      }
      else
      {
         if (opng_info.best_idat_size < init_idat_size)
            replace = 2;
      }
      if (replace == 2)
         opng_info.total_idat_size = opng_info.best_idat_size;
   }

   if (!replace)
   {
      opng_printf("\n%s is already optimized.\n\n", filename);
      return;
   }
   if (cmdline.no)
   {
      opng_printf("\nSimulation mode: %s not changed.\n\n", filename);
      return;
   }

   /* Rename the input and write the output. */
   /* This can be changed if you care about more limited file systems. */
   sprintf(bak_filename, "%s.bak", filename);
   if (rename(filename, bak_filename) != 0)
      Throw "Can't back up the input file";
   Try
   {
      if ((outfile = fopen(filename, "wb")) == NULL)
         Throw "Can't open the output file";

      if (replace == 1)
      {
         if ((infile = fopen(bak_filename, "rb")) == NULL)
            Throw "Can't reopen the input file";
         Try
         {
            opng_copy_png(infile, outfile);
         }
         Catch (err_msg)
         {
            fclose(infile);
            Throw err_msg;
         }
         fclose(infile);
      }
      else
      {
         opng_write_png(outfile,
            opng_info.best_compr_level, opng_info.best_mem_level,
            opng_info.best_strategy, opng_info.best_filter);
      }
   }
   Catch (err_msg)
   {
      if (outfile != NULL)
         fclose(outfile);
      /* Restore the original input file and rethrow the exception. */
      remove(filename);
      if (rename(bak_filename, filename) != 0)
         opng_printf("!Warning: "
            "The original file was not recovered from the backup.\n");
      Throw err_msg;
   }
   fclose(outfile);
   if (!cmdline.keep)
      remove(bak_filename);

   opng_printf("\nNew file size = %lu bytes (",
      (unsigned long)opng_info.file_size);
   opng_print_size_difference(init_file_size, opng_info.file_size, 0);
   opng_printf(")\nNew IDAT size = %lu bytes (",
      (unsigned long)opng_info.idat_size);
   opng_print_size_difference(init_idat_size, opng_info.idat_size, 1);
   opng_printf(")\n\n");
}


/** Memory cleanup **/
static void
opng_cleanup(void)
{
   if (opng_image.width == 0)
   {
      assert(opng_image.height == 0);
      return;  /* no need to clean up */
   }

   write_info_ptr = write_end_info_ptr = NULL;
   write_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
      NULL, opng_error, opng_warning);
   if (write_ptr != NULL)
   {
      write_info_ptr = png_create_info_struct(write_ptr);
      if (write_info_ptr != NULL)
         write_end_info_ptr = png_create_info_struct(write_ptr);
   }
   if (write_end_info_ptr == NULL)
      return;  /* can't clean up */

   opng_set_image_info(write_ptr, write_info_ptr, write_end_info_ptr, 1);

   png_data_freer(write_ptr, write_info_ptr, PNG_DESTROY_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_data_freer(write_ptr, write_end_info_ptr, PNG_DESTROY_WILL_FREE_DATA,
      PNG_FREE_ALL);
   png_destroy_info_struct(write_ptr, &write_end_info_ptr);
   png_destroy_write_struct(&write_ptr, &write_info_ptr);
}


/** Optimization level presets **/
static void
opng_load_level_presets(int optim_level)
{
   int load_defaults;

   if (optim_level < 0)
   {
      optim_level = OPTIM_LEVEL_DEFAULT;
      load_defaults = 1;
   }
   else
      load_defaults = 0;

   if (!load_defaults || cmdline.compr_level_table == BITSET_EMPTY)
      cmdline.compr_level_table |=
         text_to_bitset(optim_compr_level_presets[optim_level]);
   if (!load_defaults || cmdline.mem_level_table == BITSET_EMPTY)
      cmdline.mem_level_table |=
         text_to_bitset(optim_mem_level_presets[optim_level]);
   if (!load_defaults || cmdline.strategy_table == BITSET_EMPTY)
      cmdline.strategy_table |=
         text_to_bitset(optim_strategy_presets[optim_level]);
   if (!load_defaults || cmdline.filter_table == BITSET_EMPTY)
      cmdline.filter_table |=
         text_to_bitset(optim_filter_presets[optim_level]);
}


/** Command line parsing **/
static void
parse_args(int argc, char *argv[])
{
   char *arg;
   /* char */ int cmd;
   bitset interlace_table, optim_level_table;
   int stop_switch, optim_level, i, j;

   /* Initialize. */
   memset(&cmdline, 0, sizeof(cmdline));
   interlace_table = optim_level_table = BITSET_EMPTY;
   optim_level = -1;

   /* Parse the args. */
   stop_switch = 0;
   for (i = 1; i < argc; ++i)
   {
      arg = argv[i];
      if (arg[0] != '-' || stop_switch)
      {
         cmdline.has_files = 1;
         continue;
      }

      do ++arg;  /* multiple dashes are as good as one */
         while (arg[0] == '-');
      argv[i][0] = 0;  /* allow process_args() to skip it */
      if (argv[i][1] == '-' && arg[0] == 0)
      {
         stop_switch = 1;
         continue;
      }

      /* Options are case insensitive. */
      /* It's silly that tolower is ANSI C, but strlwr is not. */
      for (j = 0; arg[j] != 0; ++j)
         arg[j] = (char)tolower(arg[j]);

      if (strcmp(arg, "h") == 0 || strcmp(arg, "help") == 0)
      {
         cmdline.help = 1;
         continue;
      }
      if (strcmp(arg, "v") == 0)
      {
         cmdline.ver = 1;
         continue;
      }
      if (strcmp(arg, "k") == 0 || strcmp(arg, "keep") == 0)
      {
         cmdline.keep = 1;
         continue;
      }
      if (strcmp(arg, "q") == 0 || strcmp(arg, "quiet") == 0)
      {
         cmdline.quiet = 1;
         continue;
      }
      if (strcmp(arg, "fix") == 0)
      {
         cmdline.fix = 1;
         continue;
      }
      if (strcmp(arg, "force") == 0)
      {
         cmdline.force = 1;
         continue;
      }
      if (strcmp(arg, "log") == 0)
      {
         cmdline.log = 1;
         continue;
      }
      if (arg[0] == 'n' && arg[1] != 0 && arg[2] == 0)
      {
         switch (arg[1])
         {
            case 'b':
               cmdline.nb = 1;
               break;
            case 'c':
               cmdline.nc = 1;
               break;
            case 'o':
               cmdline.no = 1;
               break;
            case 'p':
               cmdline.np = 1;
               break;
            case 'x':
               cmdline.nx = 1;
               break;
            default:
               argv[i][0] = '-';  /* put back the '-' */
               Throw argv[i];
         }
         continue;
      }

      /* Parse the numeric or bitset parameters. */
      cmd = arg[0];
      if (cmd == 'z')
         cmd = toupper((++arg)[0]);
      if ((arg[1] < 'a' || arg[1] > 'z') && cmd != 0 &&
          strchr("ioCMSWf", cmd))
      {
         ++arg;
         if (arg[0] == 0)
            arg = argv[++i];
      }
      else
      {
         argv[i][0] = '-';  /* put back the '-' */
         Throw argv[i];
      }

      switch (cmd)
      {
#if 0  /* not implemented */
         case 'b':  /* bit depth */
            /* ... */
            break;
         case 'c':  /* color type */
            /* ... */
            break;
#endif
         case 'i':  /* interlace type */
            if (sscanf(arg, "%u", &cmdline.interlace) < 1 ||
                (cmdline.interlace & ~1) != 0 ||
                !BITSET_IS_VALID(interlace_table |= text_to_bitset(arg)))
               Throw /* invalid */ "interlace type";
            if (bitset_count(interlace_table) > 1)
               Throw "multiple interlace types are not permitted";
            break;
         case 'o':  /* optimization level */
            if (sscanf(arg, "%u", &optim_level) < 1 ||
                !BITSET_IS_VALID(optim_level_table |= text_to_bitset(arg)))
               Throw /* invalid */ "optimization level";
            if (bitset_count(optim_level_table) > 1)
               Throw "multiple optimization levels are not permitted";
            break;
         case 'C':  /* zlib compression level */
            if (!BITSET_IS_VALID(cmdline.compr_level_table |=
                text_to_bitset(arg)))
               Throw /* invalid */ "compression level(s)";
            break;
         case 'M':  /* zlib memory level */
            if (!BITSET_IS_VALID(cmdline.mem_level_table |=
                text_to_bitset(arg)))
               Throw /* invalid */ "memory level(s)";
            break;
         case 'S':  /* zlib strategy */
            if (!BITSET_IS_VALID(cmdline.strategy_table |=
                text_to_bitset(arg)))
               Throw /* invalid */ "strategy";
            break;
         case 'W':  /* zlib window size */
         {
            unsigned int wsize;
            int wbits;
            char wk;
            int nscanf = sscanf(arg, "%u%c", &wsize, &wk);
            if (nscanf == 0)
               wsize = 0;
            else if (nscanf == 2)
            {
               if (tolower(wk) == 'k' && wsize <= 32)
                  wsize *= 1024;
               else
                  wsize = 0;
            }
            for (wbits = 15; wbits >= 8; --wbits)
               if ((1U << wbits) == wsize)
                  break;
            if (wbits < 8)
               Throw /* invalid */ "window size";
#ifndef WBITS_8_OK
            else if (wbits == 8)
               wbits = 9;
#endif
            if (cmdline.window_bits == 0)
               cmdline.window_bits = wbits;
            else
               Throw "multiple window sizes are not permitted";
            break;
         }
         case 'f':  /* PNG filter */
            if (!BITSET_IS_VALID(cmdline.filter_table |= text_to_bitset(arg)))
               Throw /* invalid */ "filter(s)";
            break;
         default:
            if (argv[i][0] == 0)
               argv[i][0] = '-';  /* put back the '-' */
            Throw argv[i];
      }
      arg[0] = 0;  /* allow process_args() to skip it */
   }

   /* Finalize the data. */
   if (interlace_table == BITSET_EMPTY)
      cmdline.interlace = -1;

   if (optim_level_table == BITSET_EMPTY)
      opng_load_level_presets(-1);
   else if (optim_level <= OPTIM_LEVEL_MIN)
      cmdline.nx = 1;
   else
   {
      if (optim_level > OPTIM_LEVEL_MAX)
         optim_level = OPTIM_LEVEL_MAX;
      opng_load_level_presets(optim_level);
   }

   if (cmdline.nx)
      cmdline.nb = cmdline.nc = cmdline.np = 1;
}


/** Command line processing **/
static void
process_args(int argc, char *argv[])
{
   const char *err_msg;
   volatile int i;  /* no need to be volatile, but it keeps compilers happy */

   for (i = 1; i < argc; ++i)
   {
      if (argv[i][0] == 0)
         continue;
      Try
      {
         opng_optimize_png(argv[i]);
      }
      Catch (err_msg)
      {
         opng_printf("!\nError: %s\n\n", err_msg);
         ++global.err_count;
      }
      opng_cleanup();
   }
}


/** main **/
int
main(int argc, char *argv[])
{
   const char *option;
   int result;

   Try
   {
      parse_args(argc, argv);
   }
   Catch(option)
   {
      fprintf(stderr, "Invalid option: %s\n", option);
      return EXIT_FAILURE;
   }

   memset(&global, 0, sizeof(global));
   if (cmdline.log)
   {
      if ((global.logfile = fopen(LOG_FILE_NAME, "a")) == NULL)  /* append */
      {
         fprintf(stderr, "Error: Can't open the log file " LOG_FILE_NAME "\n");
         return EXIT_FAILURE;
      }
   }

   result = EXIT_SUCCESS;

   opng_printf(msg_intro);
   if (cmdline.ver)
   {
      opng_printf(msg_license);
      opng_printf("Compiled with libpng version %s and zlib version %s\n\n",
         PNG_LIBPNG_VER_STRING, ZLIB_VERSION);
   }
   if (cmdline.help)
   {
      opng_printf(msg_help);
      if (cmdline.has_files)
      {
         opng_printf("!Warning: No files processed.\n");
         cmdline.has_files = 0;
         result = EXIT_FAILURE;
      }
   }
   else if (!cmdline.ver && !cmdline.has_files)
      opng_printf(msg_short_help);

   if (cmdline.has_files)
   {
      process_args(argc, argv);
      if (global.err_count > 0)
      {
         opng_printf("!%u error(s) encountered.\n", global.err_count);
         if (global.fix_count > 0)
            opng_printf("!%u error(s) have been fixed.\n", global.fix_count);
         result = EXIT_FAILURE;
      }
   }

   if (global.logfile != NULL)
      fclose(global.logfile);

   return result;
}
