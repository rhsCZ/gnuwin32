extern unsigned long adler32(unsigned long adler, const unsigned char *buf,
			     int len);
