#ifndef PNGCP_H
#define PNGCP_H

char *pngcp_readimage(char *filename, unsigned long *width, unsigned long *height, 
		      int *bitdepth, int *channels);

int pngcp_writeimage(char *filename, unsigned long width, unsigned long height, 
		     int bitdepth, int channels, char *raster);

#endif
