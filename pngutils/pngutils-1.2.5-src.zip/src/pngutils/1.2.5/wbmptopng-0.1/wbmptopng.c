/*
** wbmptopng.c -
** read a WAP bitmap and produce a Portable Network Graphics file
**
** derived from wbmp2xpm.c (c) 1999 Thomas Neill
**
** derived from pnmtopng.c (c) 1995,1998 
** by Alexander Lehmann and Willem van Schaik
**
** derived from pnmtorast.c (c) 1990,1991 by Jef Poskanzer and some
** parts derived from ppmtogif.c by Marcel Wijkstra <wijkstra@fwi.uva.nl>
** thanks to Greg Roelofs <newt@pobox.com> for contributions and bug-fixes
**
** Copyright (C) 1999 by Simone Piunno <pioppo@ferrara.linux.it>
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <png.h>

int main (int argc, char *argv[]) {
	int i, j, width, height, line, block, offset;
	char c;
	png_info *info_ptr;
	png_struct *png_ptr;
	png_byte **bitmap;
  
	/* lettura del wbmp */
	i = getc(stdin);
	j = getc(stdin);
	width = getc(stdin);
	height = getc(stdin); 
	bitmap = (png_byte **)calloc(height+1, sizeof(png_byte *));
	for(line = 0; line < height; line++) {
		bitmap[line] = (png_byte *)calloc(width+1, sizeof(png_byte));
		for(block = 0; block < width; block += 8) {
			c = getc(stdin);
			for(offset = 0; (offset<8)&&((offset+block)<width); offset++) {
				bitmap[line][block+offset] = (c & (1 << (7 - offset)))?1:0;
			}
		}
	}
	
	/* scrittura del png */
  	png_ptr = png_create_write_struct (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (png_ptr == NULL) {
		fprintf(stderr, "cannot allocate LIBPNG structure");
		exit(1);
	}
	info_ptr = png_create_info_struct (png_ptr);
	if (info_ptr == NULL) {
		png_destroy_write_struct (&png_ptr, (png_infopp)NULL);
		fprintf(stderr, "cannot allocate LIBPNG structures");
		exit(2);
	}
	png_init_io (png_ptr, stdout);
	png_set_IHDR(png_ptr, info_ptr, width, height,
		1, PNG_COLOR_TYPE_GRAY, PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT); 
	png_write_info(png_ptr, info_ptr);
	png_set_packing (png_ptr);
	png_write_image(png_ptr, bitmap);
	png_write_end(png_ptr, NULL); 
	png_destroy_write_struct(&png_ptr, &info_ptr);
}
