/* package name */
#undef PACKAGE

/* package version */
#undef VERSION

/* Default Whois server */
#undef DEFAULTHOST

/* Default filename for the cache functionality */
#undef CACHEFILE

/* Default expire time for the cache functionality */
#undef CACHEEXPIRE

/* Define if you have the getaddrinfo function.  */
#undef HAVE_GETADDRINFO

/* Define if you want to disable cache functionality */
#undef NOCACHE

/* Define if you have the dbm_open function.  */
#undef HAVE_DBM_OPEN

/* Define if you have the gdbm_open function.  */
#undef HAVE_GDBM_OPEN

/* Default whois-servers.net domain for the whois-servers support */
#undef WHOISSERVERS
