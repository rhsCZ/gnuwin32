int 
cut_pbm_swath(pbm_stat* pbm,ppa_stat* prn,int maxlines,
              ppa_sweep_data* sweep_data);

