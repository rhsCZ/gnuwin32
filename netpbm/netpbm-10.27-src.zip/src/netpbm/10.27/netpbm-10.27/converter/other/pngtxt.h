#include "pm.h"

void 
pnmpng_read_text (png_info * const info_ptr, 
                  FILE *     const tfp, 
                  bool const ztxt,
                  bool const verbose);
