#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-Lc:/progra~1/libxslt/lib"
XSLT_LIBS="-lxslt  -Lc:/progra~1/libxml2/lib -lxml2 -lz -liconv -lm -Wl,-s -lwsock32 -liberty -lMsup -lMstubs "
XSLT_INCLUDEDIR="-Ic:/progra~1/libxslt/include"
MODULE_VERSION="xslt-1.0.9"
