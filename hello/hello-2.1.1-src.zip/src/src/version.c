/* version.c
   Copyright (C) 1995 Free Software Foundation, Inc. */

#include "config.h"

char version[] = VERSION;

/* eof version.c */
