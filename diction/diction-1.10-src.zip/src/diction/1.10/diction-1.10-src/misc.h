/* Notes */ /*{{{C}}}*//*{{{*/
/*

This file is free software; as a special exception the author gives
unlimited permission to copy and/or distribute it, with or without
modifications, as long as this notice is preserved.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY, to the extent permitted by law; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/
/*}}}*/

#ifndef MISC_H
#define MISC_H

#ifdef BROKEN_REALLOC
#define realloc(p,s) myrealloc(p,s)
#endif

#ifndef _POSIX_PATH_MAX
#define _POSIX_PATH_MAX MAX_PATH
#endif

#include <fcntl.h>
#ifndef O_BINARY
# ifdef _O_BINARY
#  define O_BINARY _O_BINARY
# else
#  define O_BINARY 0
# endif
#endif /* O_BINARY */

#if O_BINARY
#  define setmode(fd,m)                      _setmode(fd,m)
# define SET_BINARY(fd)                      do {if (!isatty(fd)) _setmode(fd,O_BINARY);} while (0)
#else  /* not O_BINARY, i.e., Unix */
# define SET_BINARY(fd)                      (void)0
#endif /* not O_BINARY */


#endif
