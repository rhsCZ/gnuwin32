/* config.h.  Generated from config.h.in by configure.  */
/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if realloc(0,n) fails. */
/* #undef BROKEN_REALLOC */

/* Define if you have the msgfmt(1) program and the gettext(3) function. */
#define HAVE_GETTEXT 1

/* The version string. */
#define VERSION "1.11"
