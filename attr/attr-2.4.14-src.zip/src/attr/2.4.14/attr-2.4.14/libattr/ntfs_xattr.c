/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <io.h>
#include <windows.h>

ssize_t
fgetxattr (int __fd, const char *__name,
	   void *__value, size_t __size)
{
	HANDLE hFile;
	
	hFile = (HANDLE) _get_osfhandle (__fd);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (fgetxattr)");
		set_werrno;
		return -1;
	}
	return ntfs_getxattr (hFile, __name, __value, __size);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <io.h>
#include <windows.h>

ssize_t
flistxattr (int __fd, char *__list, size_t __size)
{
	HANDLE hFile;
	
	hFile =  (HANDLE) _get_osfhandle (__fd);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (flistxattr)");
		set_werrno;
		return -1;
	}
	return ntfs_listxattr (hFile, __list, __size);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <io.h>
#include <windows.h>

int
fremovexattr (int __fd, const char *__name)
{
	HANDLE hFile;
	
	hFile =  (HANDLE) _get_osfhandle (__fd);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (fremovexattr)");
		set_werrno;
		return -1;
	}
	return ntfs_removexattr (hFile, __name);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <io.h>
#include <windows.h>

int
fsetxattr (int __fd, const char *__name, const void *__value,
	   size_t __size, int __flags)
{
	HANDLE hFile;
	
	hFile =  (HANDLE) _get_osfhandle (__fd);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (fsetxattr)");
		set_werrno;
		return -1;
	}
	return ntfs_setxattr (hFile, __name, __value, __size, __flags);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/xattr.h>

ssize_t
getxattr (const char *__path, const char *__name,
	  void *__value, size_t __size)
{
	struct stat64 sb;
	char linkname[MAX_PATH];

	strcpy (linkname, __path);
	if ((stat64(__path, &sb) != -1) && S_ISLNK (sb.st_mode))
		readlink (__path, linkname, MAX_PATH);
	return lgetxattr (linkname, __name, __value, __size);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <windows.h>

ssize_t
lgetxattr (const char *__path, const char *__name,
	   void *__value, size_t __size)
{
	ssize_t res;
	HANDLE hFile;
	
	hFile = CreateFile (__path, FILE_READ_EA, FILE_SHARE_READ, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS  | FILE_ATTRIBUTE_READONLY, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (lgetxattr)");
		set_werrno;
		return -1;
	}
	res = ntfs_getxattr (hFile, __name, __value, __size);
	CloseHandle (hFile);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/xattr.h>

ssize_t
listxattr (const char *__path, char *__list, size_t __size)
{
	struct stat64 sb;
	char linkname[MAX_PATH];

	strcpy (linkname, __path);
	if ((stat64(__path, &sb) != -1) && S_ISLNK (sb.st_mode))
		readlink (__path, linkname, MAX_PATH);
	return llistxattr (linkname, __list, __size);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>

ssize_t
llistxattr (const char *__path, char *__list, size_t __size)
{
	int res;
	HANDLE hFile;
	
	hFile = CreateFile (__path, FILE_READ_EA, FILE_SHARE_READ, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_ATTRIBUTE_READONLY, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (llistxattr)");
		set_werrno;
		return -1;
	}
	res = ntfs_listxattr (hFile, __list, __size);
	CloseHandle (hFile);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>

int
lremovexattr (const char *__path, const char *__name)
{
	int res;
	HANDLE hFile;

	hFile = CreateFile (__path, FILE_WRITE_EA, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile");
		set_werrno;
		return -1;
	}
	res = ntfs_removexattr (hFile, __name);
	CloseHandle (hFile);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>

int
lsetxattr (const char *__path, const char *__name,
	   const void *__value, size_t __size, int __flags)
{
	int res;
	HANDLE hFile;
	
	hFile = CreateFile (__path, FILE_WRITE_EA, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		WinErr ("CreateFile (lsetxattr)");
		set_werrno;
		return -1;
	}
	res = ntfs_setxattr (hFile, __name, __value, __size, __flags);
	CloseHandle (hFile);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

/* References:
	http://www.ccas.ru/~posp/popov/ea.htm 
	http://podgoretsky.com/ftp/Docs/Microsoft/NTFSDrv/AppendixA.pdf
	http://msdn.microsoft.com/library/en-us/kmarch/hh/kmarch/k112_8jw2.asp
	http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/File/NtQueryEaFile.html
*/

/*
typedef struct _FILE_FULL_EA_INFORMATION {
     ULONG NextEntryOffset;
     UCHAR Flags;
     UCHAR EaNameLength;
     USHORT EaValueLength;
     CHAR EaName[1];
} FILE_FULL_EA_INFORMATION, *PFILE_FULL_EA_INFORMATION;
  
FILE_FULL_EA_INFORMATION provides extended attribute information.
This structure is used primarily by network drivers.

Members

NextEntryOffset:
The offset of the next FILE_FULL_EA_INFORMATION-type entry.
This member is zero if no other entries follow this one. 

Flags:
Can be zero or can be set with FILE_NEED_EA, indicating that
the file to which the EA belongs cannot be interpreted without
understanding the associated extended attributes.

EaNameLength: 
The length in bytes of the EaName array. This value does not
include a zero-terminator to EaName. 

EaValueLength:
The length in bytes of each EA value in the array.

EaName:
An array of characters naming the EA for this entry.
 
Comments:
This structure is longword-aligned. If a set of FILE_FULL_EA_INFORMATION
entries is buffered, NextEntryOffset value in each entry, except the
last, falls on a longword boundary. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 


NtQueryEaFile:

NTSTATUS NtQueryEaFile(
IN HANDLE			   FileHandle,        
OUT PIO_STATUS_BLOCK   loStatusBlock,     
OUT PVOID			   Buffer,            
IN ULONG			   Length,            
IN BOOLEAN			   ReturnSingleEntry, 
IN PVOID			   EaList OPTIONAL,   
IN ULONG			   EaListLength,      
IN PULONG			   Ealndex OPTIONAL,  
IN BOOLEAN			   RestartScan)       

Parameters:

FileHandle: 
Handle to a file object. The handle is created by a successful call to
NtCreateFile or NtOpenFile.

IoStatusBlock:
Pointer to a variable that receives the final completion status and
information about the operation. 

Buffer:
Pointer to a caller-allocated buffer or variable that receives the
desired information about the file. The contents of Buffer are a
sequence of FILE_FULL_EA_INFORMATION structures, one for each
requested extended attribute.
This buffer. In each FILE_FULL_EA_INFORMATION entry, NextEntryOffset
value in each entry, except the last, falls on a longword boundary.
NextEntryOffset is the offset of the next FILE_FULL_EA_INFORMATION-type
entry. This member is zero if no other entries follow this one. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 

Length:  
Specifies the size in bytes of Buffer, which the caller should set.

ReturnSingleEntry:
If TRUE, a single, matching extended attribute will be returned.

EaList:
Pointer to a sequence of longword-aligned FILE_GET_EA_INFORMATION
structures, each of which specifies an extended attribute:

typedef struct _FILE_GET_EA_INFORMATION {
	ULONG NextEntryOffset;
	UCHAR EaNameLength;
	CHAR EaName[1];
} FILE_GET_EA_INFORMATION, *PFILE_GET_EA_INFORMATION;

NextEntryOffset is the offset of the next FILE_FULL_EA_INFORMATION-type
entry. This member is zero if no other entries follow this one. 

EaListLength:
Specifies the size in bytes of Buffer, which the caller should set; it
should be set to 0 if EaList is set to NULL.

EaIndex:
Extended attributes will be returned starting with the one associated with EaIndex;
the first extended attribute has EaIndex = 1, and so on. If, however, EaList
is nonnull, this argument will be ignored.

RestartScan:
If FALSE, then extended attributes will be returned starting with the one
following the last returned by previous calls of NtQueryEaFile.
If TRUE, then extended attributes will be returned starting with the first one.
This flag is ignored if either EaList or Ealndex are nonnull.

Return code:
� STATUS_SUCCESS 
� STATUS_ACCESS_DENIED
� STATUS_INSUFFICIENT_RESOURCES
� STATUS_INVALID_PARAMETER
� STATUS_INVALID_DEVICE_REQUEST
� STATUS_NO_MORE_EAS ((NTSTATUS)0x80000012L)
� STATUS_INVALID_EA_NAME ((NTSTATUS)0x80000013L)
� STATUS_EA_LIST_INCONSISTENT ((NTSTATUS)0x80000014L)
� STATUS_INVALID_EA_FLAG ((NTSTATUS)0x80000015L)
� STATUS_EAS_NOT_SUPPORTED ((NTSTATUS)0xC000004FL)
� STATUS_EA_TOO_LARGE ((NTSTATUS)0xC0000050L)
� STATUS_NONEXISTENT_EA_ENTRY ((NTSTATUS)0xC0000051L)
� STATUS_NO_EAS_ON_FILE ((NTSTATUS)0xC0000052L)
� STATUS_EA_CORRUPT_ERROR ((NTSTATUS)0xC0000053L)

It also returns the number of bytes actually written to the given
Buffer in the Information member of IoStatusBlock.

*/

#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>
#include <ntdll.h>
#include <ddk/ntstatus.h>
#include <io.h>
#include <stdio.h>

#define MINEASIZE 40

ssize_t
ntfs_getxattr (HANDLE hFile, const char *__name,
	   void *__value, size_t __size)
{
	IO_STATUS_BLOCK IoStatusBlock;
	ULONG namelen;
	DWORD EaSize, EaListLength;
	ssize_t res, EaValueLength;
	PFILE_FULL_EA_INFORMATION pEaInformation;
	PFILE_GET_EA_INFORMATION pEaList;
	NTSTATUS Status;
	HMODULE hNtdll = GetModuleHandle ("ntdll.dll");
	FARPROC pfnNtQueryEaFile = GetProcAddress (hNtdll, "NtQueryEaFile"); 
	
	if (!pfnNtQueryEaFile) {
		__set_errno (ENOSYS);
		return -1;
	}
	// printf ("size: %d\n", __size);
 	namelen = strlen (__name);
	// printf ("name: %s\n", __name);
	EaSize = sizeof (*pEaInformation) - sizeof (CHAR) + namelen + 1 + __size 
		     + (sizeof (DWORD) - 1);
	// printf ("EaSize: %d\n", EaSize);
	EaSize &= ~(sizeof (DWORD) - 1);
	// printf ("EaSize: %d\n", EaSize);
	if (EaSize < MINEASIZE)
		EaSize = MINEASIZE;
	// printf ("EaSize: %d\n", EaSize);
	if (!(pEaInformation = (PFILE_FULL_EA_INFORMATION) malloc (EaSize))) {
		WinErr ("malloc pEaInformation (ntfs_getxattr)");
		set_werrno;
		return -1;
	}
	ZeroMemory (pEaInformation, EaSize);

	EaListLength = sizeof (*pEaList) - sizeof (CHAR) + namelen + 1 
		     + (sizeof (DWORD) - 1);
	EaListLength &= ~(sizeof (DWORD) - 1);
	if (!(pEaList = (PFILE_GET_EA_INFORMATION) malloc (EaListLength))) {
		WinErr ("malloc pEaList (ntfs_getxattr)");
		free (pEaInformation);
		set_werrno;
		return -1;
	}
	ZeroMemory (pEaList, EaListLength);
	pEaList->EaNameLength = namelen;
	strcpy (pEaList->EaName, __name);
	strupr(pEaList->EaName);
	// printf ("pEaList->EaName: %s\n", pEaList->EaName);

	Status = pfnNtQueryEaFile (hFile, &IoStatusBlock, pEaInformation, EaSize, FALSE, pEaList,
			EaListLength, NULL, TRUE);
	if (Status == STATUS_NO_EAS_ON_FILE) {
		__set_errno (ENOATTR);
		free (pEaInformation);
		free (pEaList);
		return -1;
	}
	else if (Status == STATUS_EAS_NOT_SUPPORTED) {
		__set_errno (ENOTSUP);
		free (pEaInformation);
		free (pEaList);
		return -1;
	}
	else if ((Status != STATUS_SUCCESS) && (__size > 0)) {
//		printf ("NtStatus: %#lX\n", Status);
		SetNtLastError (Status);
//		WinErr ("NtQueryEaFile (ntfs_getxattr)");
//		printf ("size: %d\n", __size);
//		printf ("EaSize: %ld\n", EaSize);
//		printf ("EaListLength: %ld\n", EaListLength);
//		printf ("EaName: %s\n", pEaList->EaName);
//		printf ("EaNameLength: %d\n", pEaList->EaNameLength);
		set_werrno;
		free (pEaInformation);
		free (pEaList);
		return -1;
	}
	EaValueLength = pEaInformation->EaValueLength;
	// printf ("EaValueLength: %d\n", EaValueLength);
	// printf ("EaNameLength: %d\n", pEaInformation->EaNameLength);
	// printf ("NextEntryOffset: %d\n", pEaInformation->NextEntryOffset);
	// printf ("EaName: %s\n", pEaInformation->EaName);
	// printf ("EaValue: %s\n", (char *) pEaInformation->EaName + (pEaInformation->EaNameLength + 1));
	res = IoStatusBlock.Information;
	// printf ("IoStatusBlock: %lu\n", IoStatusBlock.Information);
	if (__size > 0) {
		memcpy (__value, pEaInformation->EaName + (pEaInformation->EaNameLength + 1),
				EaValueLength);
		res = EaValueLength;
	}
	// printf ("Result: %lu\n", res);
	free (pEaInformation);
	free (pEaList);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

/* References:
	http://www.ccas.ru/~posp/popov/ea.htm 
	http://podgoretsky.com/ftp/Docs/Microsoft/NTFSDrv/AppendixA.pdf
	http://msdn.microsoft.com/library/en-us/kmarch/hh/kmarch/k112_8jw2.asp
	http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/File/NtQueryEaFile.html
*/

/*
typedef struct _FILE_FULL_EA_INFORMATION {
     ULONG NextEntryOffset;
     UCHAR Flags;
     UCHAR EaNameLength;
     USHORT EaValueLength;
     CHAR EaName[1];
} FILE_FULL_EA_INFORMATION, *PFILE_FULL_EA_INFORMATION;
  
FILE_FULL_EA_INFORMATION provides extended attribute information.
This structure is used primarily by network drivers.

Members

NextEntryOffset:
The offset of the next FILE_FULL_EA_INFORMATION-type entry.
This member is zero if no other entries follow this one. 

Flags:
Can be zero or can be set with FILE_NEED_EA, indicating that
the file to which the EA belongs cannot be interpreted without
understanding the associated extended attributes.

EaNameLength: 
The length in bytes of the EaName array. This value does not
include a zero-terminator to EaName. 

EaValueLength:
The length in bytes of each EA value in the array.

EaName:
An array of characters naming the EA for this entry.
 
Comments:
This structure is longword-aligned. If a set of FILE_FULL_EA_INFORMATION
entries is buffered, NextEntryOffset value in each entry, except the
last, falls on a longword boundary. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 


NtQueryEaFile:

NTSTATUS NtQueryEaFile(
IN HANDLE			   FileHandle,        
OUT PIO_STATUS_BLOCK   loStatusBlock,     
OUT PVOID			   Buffer,            
IN ULONG			   Length,            
IN BOOLEAN			   ReturnSingleEntry, 
IN PVOID			   EaList OPTIONAL,   
IN ULONG			   EaListLength,      
IN PULONG			   Ealndex OPTIONAL,  
IN BOOLEAN			   RestartScan)       

Parameters:

FileHandle: 
Handle to a file object. The handle is created by a successful call to
NtCreateFile or NtOpenFile.

IoStatusBlock:
Pointer to a variable that receives the final completion status and
information about the operation. 

Buffer:
Pointer to a caller-allocated buffer or variable that receives the
desired information about the file. The contents of Buffer are a
sequence of FILE_FULL_EA_INFORMATION structures, one for each
requested extended attribute.
This buffer. In each FILE_FULL_EA_INFORMATION entry, NextEntryOffset
value in each entry, except the last, falls on a longword boundary.
NextEntryOffset is the offset of the next FILE_FULL_EA_INFORMATION-type
entry. This member is zero if no other entries follow this one. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 

Length:  
Specifies the size in bytes of Buffer, which the caller should set.

ReturnSingleEntry:
If TRUE, a single, matching extended attribute will be returned.

EaList:
Pointer to a sequence of longword-aligned FILE_GET_EA_INFORMATION
structures, each of which specifies an extended attribute:

typedef struct _FILE_GET_EA_INFORMATION {
	ULONG NextEntryOffset;
	UCHAR EaNameLength;
	CHAR EaName[1];
} FILE_GET_EA_INFORMATION, *PFILE_GET_EA_INFORMATION;

NextEntryOffset is the offset of the next FILE_FULL_EA_INFORMATION-type
entry. This member is zero if no other entries follow this one. 

EaListLength:
Specifies the size in bytes of Buffer, which the caller should set; it
should be set to 0 if EaList is set to NULL.

EaIndex:
Extended attributes will be returned starting with the one associated with EaIndex;
the first extended attribute has EaIndex = 1, and so on. If, however, EaList
is nonnull, this argument will be ignored.

RestartScan:
If FALSE, then extended attributes will be returned starting with the one
following the last returned by previous calls of NtQueryEaFile.
If TRUE, then extended attributes will be returned starting with the first one.
This flag is ignored if either EaList or Ealndex are nonnull.

Return code:
� STATUS_SUCCESS 
� STATUS_ACCESS_DENIED
� STATUS_INSUFFICIENT_RESOURCES
� STATUS_INVALID_PARAMETER
� STATUS_INVALID_DEVICE_REQUEST
� STATUS_NO_MORE_EAS ((NTSTATUS)0x80000012L)
� STATUS_INVALID_EA_NAME ((NTSTATUS)0x80000013L)
� STATUS_EA_LIST_INCONSISTENT ((NTSTATUS)0x80000014L)
� STATUS_INVALID_EA_FLAG ((NTSTATUS)0x80000015L)
� STATUS_EAS_NOT_SUPPORTED ((NTSTATUS)0xC000004FL)
� STATUS_EA_TOO_LARGE ((NTSTATUS)0xC0000050L)
� STATUS_NONEXISTENT_EA_ENTRY ((NTSTATUS)0xC0000051L)
� STATUS_NO_EAS_ON_FILE ((NTSTATUS)0xC0000052L)
� STATUS_EA_CORRUPT_ERROR ((NTSTATUS)0xC0000053L)

It also returns the number of bytes actually written to the given
Buffer in the Information member of IoStatusBlock.

*/

#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>
#include <ntdll.h>
#include <ddk/ntstatus.h>
#include <io.h>
#include <stdio.h>

#define MINEASIZE 40


ssize_t
ntfs_listxattr (HANDLE hFile, char *__list, size_t __size)
{
	IO_STATUS_BLOCK IoStatusBlock;
	DWORD EaSize, NextEntryOffset;
	PFILE_FULL_EA_INFORMATION pEaInformation;
	NTSTATUS Status;
	ssize_t res;
	char *p;
	HMODULE hNtdll = GetModuleHandle ("ntdll.dll");
	FARPROC pfnNtQueryEaFile = GetProcAddress (hNtdll, "NtQueryEaFile"); 
	
	if (!pfnNtQueryEaFile) {
		__set_errno (ENOSYS);
		return -1;
	}
	// printf ("size: %d\n", __size);
	EaSize = sizeof (*pEaInformation) - sizeof (WCHAR**) + 1 + __size
		     + (sizeof (DWORD) - 1);
	// printf ("EaSize: %d\n", EaSize);
	EaSize &= ~(sizeof (DWORD) - 1);
	// printf ("EaSize: %d\n", EaSize);
	if (EaSize < MINEASIZE)
		EaSize = MINEASIZE;
	// printf ("EaSize: %d\n", EaSize);
	if (!(pEaInformation = (PFILE_FULL_EA_INFORMATION) malloc (EaSize))) {
		WinErr ("malloc pEaInformation (ntfs_listxattr)");
		set_werrno;
		return -1;
	}
	ZeroMemory (pEaInformation, EaSize);

	Status = pfnNtQueryEaFile (hFile, &IoStatusBlock, pEaInformation, EaSize, FALSE, NULL,
			0, NULL, TRUE);
	if (Status == STATUS_NO_EAS_ON_FILE) {
		__set_errno (ENOATTR);
		free (pEaInformation);
		return -1;
	}
	else if (Status == STATUS_EAS_NOT_SUPPORTED) {
		__set_errno (ENOTSUP);
		free (pEaInformation);
		return -1;
	}
	else if ((Status != STATUS_SUCCESS) && (__size > 0)) {
//		printf ("NtStatus: %#lX\n", Status);
		SetNtLastError (Status);
//		WinErr ("NtQueryEaFile (ntfs_listxattr)");
//		printf ("size: %d\n", __size);
//		printf ("EaSize: %ld\n", EaSize);
		set_werrno;
		free (pEaInformation);
		return -1;
	}
	res = IoStatusBlock.Information;
	// printf ("IoStatusBlock: %lu\n", IoStatusBlock.Information);
	if (__size > 0) {
		p = __list;
		do {
			NextEntryOffset = pEaInformation->NextEntryOffset;
			// printf ("NextEntryOffset: %d\n", NextEntryOffset);
			// printf ("EaName: %s\n", pEaInformation->EaName);
			// printf ("EaValue: %s\n", (char *) pEaInformation->EaName + (pEaInformation->EaNameLength + 1));
			strcpy (p, pEaInformation->EaName);
// 			printf ("list: %s\n", p);
			p += pEaInformation->EaNameLength + 1;
			pEaInformation = (PFILE_FULL_EA_INFORMATION) ((char *) pEaInformation + NextEntryOffset);
		} while (NextEntryOffset);
		res = p - __list;
	}
//	printf ("Result: %lu\n", res);
	free (pEaInformation);
	return res;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>

int
ntfs_removexattr (HANDLE hFile, const char *__name)
{
	return ntfs_setxattr (hFile, __name, 0, 0, 0);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

/* References:
	http://www.ccas.ru/~posp/popov/ea.htm 
	http://podgoretsky.com/ftp/Docs/Microsoft/NTFSDrv/AppendixA.pdf
	http://msdn.microsoft.com/library/en-us/kmarch/hh/kmarch/k112_8jw2.asp
	http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/File/NtQueryEaFile.html
*/

/*
typedef struct _FILE_FULL_EA_INFORMATION {
     ULONG NextEntryOffset;
     UCHAR Flags;
     UCHAR EaNameLength;
     USHORT EaValueLength;
     CHAR EaName[1];
} FILE_FULL_EA_INFORMATION, *PFILE_FULL_EA_INFORMATION;
  
FILE_FULL_EA_INFORMATION provides extended attribute information.
This structure is used primarily by network drivers.

Members

NextEntryOffset:
The offset of the next FILE_FULL_EA_INFORMATION-type entry.
This member is zero if no other entries follow this one. 

Flags:
Can be zero or can be set with FILE_NEED_EA, indicating that
the file to which the EA belongs cannot be interpreted without
understanding the associated extended attributes.

EaNameLength: 
The length in bytes of the EaName array. This value does not
include a zero-terminator to EaName. 

EaValueLength:
The length in bytes of each EA value in the array.

EaName:
An array of characters naming the EA for this entry.
 
Comments:
This structure is longword-aligned. If a set of FILE_FULL_EA_INFORMATION
entries is buffered, NextEntryOffset value in each entry, except the
last, falls on a longword boundary. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 


NtSetEaFile:

NTSTATUS NtSetEaFile (
IN HANDLE 				FileHandle,
OUT PIO_STATUS_BLOCK 	loStatusBlock,
OUT PVOID 				Buffer,
IN ULONG 				Length)

FileHandle: 
Handle to a file object. The handle is created by a successful call to
NtCreateFile or NtOpenFile.

IoStatusBlock:
Pointer to a variable that receives the final completion status and
information about the operation. 

Buffer:
Pointer to a caller-allocated buffer or variable that receives the
desired information about the file. The contents of Buffer are a
sequence of FILE_FULL_EA_INFORMATION structures, one for each
requested extended attribute.
This buffer. In each FILE_FULL_EA_INFORMATION entry, NextEntryOffset
value in each entry, except the last, falls on a longword boundary.
NextEntryOffset is the offset of the next FILE_FULL_EA_INFORMATION-type
entry. This member is zero if no other entries follow this one. 
The value(s) associated with each entry follows the EaName array. That is,
an EA's values are located at EaName + (EaNameLength + 1). 

Length:  
Specifies the size in bytes of Buffer, which the caller should set.

Return code:
� STATUS_SUCCESS 
� STATUS_ACCESS_DENIED
� STATUS_INSUFFICIENT_RESOURCES
� STATUS_INVALID_PARAMETER
� STATUS_INVALID_DEVICE_REQUEST
� STATUS_NO_MORE_EAS ((NTSTATUS)0x80000012L)
� STATUS_INVALID_EA_NAME ((NTSTATUS)0x80000013L)
� STATUS_EA_LIST_INCONSISTENT ((NTSTATUS)0x80000014L)
� STATUS_INVALID_EA_FLAG ((NTSTATUS)0x80000015L)
� STATUS_EAS_NOT_SUPPORTED ((NTSTATUS)0xC000004FL)
� STATUS_EA_TOO_LARGE ((NTSTATUS)0xC0000050L)
� STATUS_NONEXISTENT_EA_ENTRY ((NTSTATUS)0xC0000051L)
� STATUS_NO_EAS_ON_FILE ((NTSTATUS)0xC0000052L)
� STATUS_EA_CORRUPT_ERROR ((NTSTATUS)0xC0000053L)

If an error was encountered (e.g., an invalid character in an EaName),
the Information field in the IoStatusBlock argument contains the byte
offset to the EA entry that caused the failure; otherwise, it contains the number of
bytes of extended attributes information written to the file.

*/

#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/mount.h>
#include <windows.h>
#include <ntdll.h>
#include <ddk/ntstatus.h>
#include <io.h>
#include <stdio.h>

int
ntfs_setxattr (HANDLE hFile, const char *__name,
	   const void *__value, size_t __size, int __flags)
{
	IO_STATUS_BLOCK IoStatusBlock;
	ULONG namelen;
	DWORD EaSize;
	PFILE_FULL_EA_INFORMATION pEaInformation;
	NTSTATUS Status;
	HMODULE hNtdll = GetModuleHandle ("ntdll.dll");
	FARPROC pfnNtSetEaFile = GetProcAddress (hNtdll, "NtSetEaFile"); 
	
	if (!pfnNtSetEaFile) {
		__set_errno (ENOSYS);
		return -1;
	}

	if (__flags & XATTR_CREATE) {
		if (ntfs_getxattr (hFile, __name, __value, __size) > 0) {
			__set_errno (EEXIST);
			return -1;
		}
	}
	else if (__flags & XATTR_REPLACE) {
		if (ntfs_getxattr (hFile, __name, __value, __size) <= 0) {
			__set_errno (ENOATTR);
			return -1;
		}
	}
	namelen = strlen (__name);
	EaSize = sizeof (*pEaInformation) - sizeof (CHAR) + namelen + 1 + __size
		     + (sizeof (DWORD) - 1);
	EaSize &= ~(sizeof (DWORD) - 1);
	if (!(pEaInformation = (PFILE_FULL_EA_INFORMATION) malloc (EaSize))) {
		WinErr ("malloc pEaInformation (ntfs_setxattr)");
		set_werrno;
		return -1;
	}
	ZeroMemory (pEaInformation, EaSize);
	pEaInformation->EaNameLength = namelen;
	pEaInformation->EaValueLength = __size;
	strcpy (pEaInformation->EaName, __name);
	memcpy (pEaInformation->EaName + (pEaInformation->EaNameLength + 1), __value, __size);

	Status = pfnNtSetEaFile (hFile, &IoStatusBlock, pEaInformation, EaSize);
	if (Status == STATUS_NO_EAS_ON_FILE) {
		__set_errno (ENOATTR);
		free (pEaInformation);
		return -1;
	}
	else if (Status == STATUS_EAS_NOT_SUPPORTED) {
		__set_errno (ENOTSUP);
		free (pEaInformation);
		return -1;
	}
	else if ((Status != STATUS_SUCCESS) && (__size > 0)) {
//		printf ("NtStatus: %#lX\n", Status);
		SetNtLastError (Status);
//		WinErr ("NtSetEaFile (ntfs_setxattr)");
//		printf ("size: %d\n", __size);
//		printf ("EaSize: %ld\n", EaSize);
		set_werrno;
		free (pEaInformation);
		return -1;
	}
	free (pEaInformation);
	return 0;
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <io.h>
#include <windows.h>

int
removexattr (const char *__path, const char *__name)
{
	struct stat64 sb;
	char linkname[MAX_PATH];

	strcpy (linkname, __path);
	if ((stat64(__path, &sb) != -1) && S_ISLNK (sb.st_mode))
		readlink (__path, linkname, MAX_PATH);
	return lremovexattr (linkname, __name);
}
/* Copyright (C) 2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.  */

#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/xattr.h>

int
setxattr (const char *__path, const char *__name,
	  const void *__value, size_t __size, int __flags)
{
	struct stat64 sb;
	char linkname[MAX_PATH];

	strcpy (linkname, __path);
	if ((stat64(__path, &sb) != -1) && S_ISLNK (sb.st_mode))
		readlink (__path, linkname, MAX_PATH);
	return lsetxattr (linkname, __name, __value, __size, __flags);
}
