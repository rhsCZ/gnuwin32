/* $Id: scanner.h,v 1.7 2004/11/01 04:35:57 nuffer Exp $ */
#ifndef _scanner_h
#define	_scanner_h

#include <iosfwd>
#include "token.h"

namespace re2c
{

class Scanner
{

private:
	std::istream&	in;
	char	*bot, *tok, *ptr, *cur, *pos, *lim, *top, *eof;
	uint	tchar, tline, cline;

private:
	char *fill(char*);
	Scanner(const Scanner&); //unimplemented
	Scanner& operator=(const Scanner&); //unimplemented

public:
	Scanner(std::istream&);
	int echo(std::ostream&);
	int scan();
	void fatal(char*);
	SubStr token();
	uint line();
};

inline SubStr Scanner::token()
{
	return SubStr(tok, cur - tok);
}

inline uint Scanner::line()
{
	return cline;
}

} // end namespace re2c

#endif
