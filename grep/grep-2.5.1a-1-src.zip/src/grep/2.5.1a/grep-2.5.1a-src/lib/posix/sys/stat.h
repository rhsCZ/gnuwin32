#ifndef _NONPOSIX_SYS_STAT_H
#define _NONPOSIX_SYS_STAT_H 1

#include_next <sys/stat.h>
#include <errno.h>

#ifdef _WIN32

#define  _S_IFSOCK       0xC000    /* socket */
#define  _IFSOCK         _S_IFSOCK
#define  _S_ISSOCK(m)    (((m) & _S_IFMT) == _S_IFSOCK)
#define __S_IFSOCK       _S_IFSOCK
#ifndef _NO_OLDNAMES
# define   S_IFSOCK       _S_IFSOCK
# define   S_ISSOCK(m)   _S_ISSOCK(m)
#endif    /* Not _NO_OLDNAMES */


#define stat		_stati64
#define _stat		_stati64
#define lstat		_stati64
#define fstat		_fstati64
#define off_t		__int64

#endif /* _WIN32 */

#endif /* _NONPOSIX_SYS_STAT_H */
