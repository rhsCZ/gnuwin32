#ifndef _NONPOSIX_SYS_STAT_H
#define _NONPOSIX_SYS_STAT_H 1

#include_next <sys/stat.h>
#include <errno.h>

#ifdef _WIN32

#define stat		_stati64
#define _stat		_stati64
#define lstat		_stati64
#define fstat		_fstati64
#define off_t		__int64

#endif /* _WIN32 */

#endif /* _NONPOSIX_SYS_STAT_H */
