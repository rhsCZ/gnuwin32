#define FGREP_PROGRAM
#include "grep.c"
