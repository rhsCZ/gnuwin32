#ifndef _NONPOSIX_SYS_TYPES_H
#define _NONPOSIX_SYS_TYPES_H 1

#include_next <sys/types.h>

#ifdef _WIN32

#include <sys/stat.h>

#define off_t		__int64

#endif /* _WIN32 */

#endif /* _NONPOSIX_SYS_TYPES_H */
