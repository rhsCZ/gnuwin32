#define FGREP_PROGRAM
#include "search.c"
