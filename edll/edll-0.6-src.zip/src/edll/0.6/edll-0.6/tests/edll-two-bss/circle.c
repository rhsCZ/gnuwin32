/* This file is public domain */

/*
 * This file represents a plugin that your main
 * application will load as required at runtime.
 */


/* needed for the EDLL_ADDLIB() */
#include	<edll/edll.h>

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>
#include	<math.h>


/* set COMMON to 0 to test the .bss section instead */ 
/*#define COMMON 1 -- defined in the Makefile.am */

#if COMMON
/* here the compiler generates a COMMON symbol */
unsigned char	image[256 * 256 * 3];
#endif

extern int save_targa(const char *filename, const unsigned char *image,
				int width, int height, const char *name);



int Program(int argc, char *argv[])
{
	int		angle, x, y;
	char		*name;
	unsigned char	*d;
#if !COMMON
/* here the compiler generates a .bss */
	static unsigned char	image[256 * 256 * 3];
#endif

	if(argc >= 2) {
		name = argv[1];
	}
	else {
		name = "";
	}

	/* The image buffer is supposed to be all zeroes if EDLL works properly
	 * You can make the following #if 0, #if 1 instead to test the circle
	 * on a white background!
	 */
#if 0
	memset(image, -1, sizeof(image));
#endif

	printf("PLUGIN: the circle image is at %p\n", image);

	for(angle = 0; angle < 360; angle += 5) {
		x = (int) (cosf(angle * (float) M_PI / 180.0f) * 125.0f) + 128;
		y = (int) (sinf(angle * (float) M_PI / 180.0f) * 125.0f) + 128;
		d = image + (x + y * 256) * 3;
		/* BGR */
		d[0] = 255;
		d[1] = 128;
		d[2] = 0;
		d[0 + 3] = 128;
		d[1 + 3] = 64;
		d[2 + 3] = 0;
		d[0 - 3] = 128;
		d[1 - 3] = 64;
		d[2 - 3] = 0;
		d[0 + 256 * 3] = 128;
		d[1 + 256 * 3] = 64;
		d[2 + 256 * 3] = 0;
		d[0 - 256 * 3] = 128;
		d[1 - 256 * 3] = 64;
		d[2 - 256 * 3] = 0;
	}

	save_targa("circle", image, 256, 256, name);

	printf("PLUGIN: saved circle.tga image file.\n");

	return 11;
}





/* link to the Microsoft VCR library version 7.0 */
//EDLL_ADDLIB("msvcr70.dll");
EDLL_ADDLIB("");


