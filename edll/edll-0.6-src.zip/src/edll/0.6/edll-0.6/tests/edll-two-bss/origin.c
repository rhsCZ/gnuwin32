/* This file is public domain */

/*
 * This file represents a plugin that your main
 * application will load as required at runtime.
 */


/* needed for the EDLL_ADDLIB() */
#include	<edll/edll.h>

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>


/* set COMMON to 0 to test the .bss section instead */ 
/*#define COMMON 1 -- defined in the Makefile.am */

#if COMMON
/* here the compiler generates a COMMON symbol */
unsigned char	image[512 * 512 * 3];
#endif


extern int save_targa(const char *filename, const unsigned char *image,
				int width, int height, const char *name);


int Program(int argc, char *argv[])
{
	int		x, y;
	char		*name;
	unsigned char	*d;
#if !COMMON
/* here the compiler generates a .bss */
	static unsigned char	image[512 * 512 * 3];
#endif

	if(argc >= 2) {
		name = argv[1];
	}
	else {
		name = "";
	}

	/* The image buffer is supposed to be all zeroes if EDLL works properly
	 * You can make the following #if 0, #if 1 instead to test the circle
	 * on a white background!
	 */
#if 0
	memset(image, -1, sizeof(image));
#endif

	printf("PLUGIN: the origin image is at %p\n", image);

	x = 256;
	for(y = 0; y < 512; ++y) {
		d = image + (x + y * 512) * 3;
		/* BGR */
		d[0] = 255;
		d[1] = 128;
		d[2] = 0;
		d[0 + 3] = 128;
		d[1 + 3] = 64;
		d[2 + 3] = 0;
		d[0 - 3] = 128;
		d[1 - 3] = 64;
		d[2 - 3] = 0;
	}

	y = 256;
	for(x = 0; x < 512; ++x) {
		d = image + (x + y * 512) * 3;
		/* BGR */
		d[0] = 255;
		d[1] = 128;
		d[2] = 0;
		if(x != 256) {
			d[0 + 512 * 3] = 128;
			d[1 + 512 * 3] = 64;
			d[2 + 512 * 3] = 0;
			d[0 - 512 * 3] = 128;
			d[1 - 512 * 3] = 64;
			d[2 - 512 * 3] = 0;
		}
	}

	save_targa("origin", image, 512, 512, name);

	printf("PLUGIN: saved origin.tga image file.\n");

	return 22;
}




/* link to the Microsoft VCR library version 7.0 */
//EDLL_ADDLIB("msvcr70.dll");
EDLL_ADDLIB("");


