/* This file is public domain */

/*
 * This file represents an application which at some point in
 * time wants to load a plug-in. It does so using the ltdl
 * library.
 */

#include	<edll/ltdl.h>

#include	<stdio.h>
#include	<stdlib.h>



/* in our plug-in, we have a function which prototype is as follow: */
typedef int (*program_t)(int argc, char **argv);


int main(int argc, char *argv[])
{
	lt_dlhandle	main_module;
	char		*filename, *args[2];
	program_t	addr;
	int		r;

/** Initialize the ltdl library **/
	if(lt_dlinit() != 0) {
		fprintf(stderr, "FATAL ERROR: can't initialize the dynamic loader library.\n");
		exit(1);
	}

	r = lt_dlsetsearchpath(".");
	if(r != 0) {
		printf("FATAL ERROR: can't setup the search path for the dynamic loader library.\n");
		lt_dlexit();
		exit(1);
	}

/** Now we can load our application **/

	filename = "plugin.so";
	printf("STARTUP: loading plug-in: \"%s\".\n", filename);
	main_module = lt_dlopen(filename);

	if(main_module == 0) {
		printf("FATAL ERROR: can't load \"%s\".\n", filename);
		lt_dlexit();
		exit(1);
	}

/** Get the address of the function we want to run **/
	addr = (program_t) lt_dlsym(main_module, "_Program");
	if(addr == 0) {
		printf("FATAL ERROR: can't find the Program() function in this module.\n");
		lt_dlclose(main_module);
		lt_dlexit();
		exit(1);
	}

	printf("STARTUP: Program() was successfully loaded at 0x%8p\n", addr);

/** Call this function **/
	args[0] = "startup!";
	args[1] = 0;
	printf("STARTUP: calling Program()...\n");
	r = (*addr)(1, args);
	printf("STARTUP: Program() returned with %d...\n", r);

	r = lt_dlclose(main_module);
	if(r != 0) {
		printf("WARNING: there was an error closing the module.\n");
	}

/** We're done, make sure the ltdl library closes just fine **/

	/*
	 * We do not need to remove our module, but
	 * just to make sure it works...
	 */
	r = lt_dlexit();
	if(r != 0) {
		printf("WARNING: lt_dlexit() returned %d... 0 was expected.\n", r);
	}

	printf("STARTUP: success!\n");

	return 0;
}

