/* This file is public domain */

/*
 * This file represents a plugin that your main
 * application will load as required at runtime.
 */


/* needed for the EDLL_ADDLIB() */
#include	<edll/edll.h>

#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>
#include	<math.h>


/* set COMMON to 0 to test the .bss section instead */ 
#define COMMON	1

#if COMMON
/* here the compiler generates a COMMON symbol */
unsigned char	image[256 * 256 * 3];
#endif


/* the following are offsets to write in the header of a targa
 * image file format (see http://sswf.sourceforge.net)
 * */
enum targa_header_t {
	TGA_OFFSET_IDENTIFIER_LENGTH = 0,
	TGA_OFFSET_COLORMAP_TYPE,
	TGA_OFFSET_IMAGE_TYPE,			// includes compression flag
	TGA_OFFSET_COLORMAP_INDEX_LO,
	TGA_OFFSET_COLORMAP_INDEX_HI,
	TGA_OFFSET_COLORMAP_LENGTH_LO,
	TGA_OFFSET_COLORMAP_LENGTH_HI,
	TGA_OFFSET_COLORMAP_SIZE,
	TGA_OFFSET_ORIGIN_X_LO,
	TGA_OFFSET_ORIGIN_X_HI,
	TGA_OFFSET_ORIGIN_Y_LO,
	TGA_OFFSET_ORIGIN_Y_HI,
	TGA_OFFSET_WIDTH_LO,
	TGA_OFFSET_WIDTH_HI,
	TGA_OFFSET_HEIGHT_LO,
	TGA_OFFSET_HEIGHT_HI,
	TGA_OFFSET_BITS_PER_PIXEL,
	TGA_OFFSET_FLAGS,

	TGA_HEADER_SIZE			// the size of the targa files header
};



void DrawCircle()
{
	FILE		*f;
	int		angle, x, y;
	unsigned char	*d, header[TGA_HEADER_SIZE];
#if !COMMON
/* here the compiler generates a .bss */
	static unsigned char	image[256 * 256 * 3];
#endif

	/* The image buffer is supposed to be all zeroes if EDLL works properly
	 * You can make the following #if 0, #if 1 instead to test the circle
	 * on a white background!
	 */
#if 0
	memset(image, -1, sizeof(image));
#endif

	for(angle = 0; angle < 360; angle += 5) {
		x = (int) (cosf(angle * (float) M_PI / 180.0f) * 125.0f) + 128;
		y = (int) (sinf(angle * (float) M_PI / 180.0f) * 125.0f) + 128;
		d = image + (x + y * 256) * 3;
		if(d >= image + sizeof(image)) {
			printf("Ooops! Overflow!\n");
			fflush(stdout);
			d = image;
		}
		/* BGR */
		d[0] = 255;
		d[1] = 128;
		d[2] = 0;
		d[0 + 3] = 128;
		d[1 + 3] = 64;
		d[2 + 3] = 0;
		d[0 - 3] = 128;
		d[1 - 3] = 64;
		d[2 - 3] = 0;
		d[0 + 256 * 3] = 128;
		d[1 + 256 * 3] = 64;
		d[2 + 256 * 3] = 0;
		d[0 - 256 * 3] = 128;
		d[1 - 256 * 3] = 64;
		d[2 - 256 * 3] = 0;
	}

	f = fopen("circle.tga", "wb");
	if(f == 0) {
		printf("ERROR: cannot open the circle.tga file.\n");
		return;
	}

	memset(header, 0, sizeof(header));
	header[TGA_OFFSET_IDENTIFIER_LENGTH] = 0;
	header[TGA_OFFSET_IMAGE_TYPE]        = 2;
	header[TGA_OFFSET_WIDTH_LO]          = (unsigned char) 256;
	header[TGA_OFFSET_WIDTH_HI]          = 256 >> 8;
	header[TGA_OFFSET_HEIGHT_LO]         = (unsigned char) 256;
	header[TGA_OFFSET_HEIGHT_HI]         = 256 >> 8;
	header[TGA_OFFSET_BITS_PER_PIXEL]    = 24;
	header[TGA_OFFSET_FLAGS]             = 0x20;	// top to bottom
	fwrite(header, 1, sizeof(header), f);

	fwrite(image, 1, sizeof(image), f);
	fclose(f);

	printf("PLUGIN: saved circle.tga image file.\n");
}





/* print this source file on screen */
int Program(int argc, char *argv[])
{
	char		buf[256];
	const char	*filename;
	FILE		*f;
	int		line;

	filename = "plugin.c";

	f = fopen(filename, "r");
	if(f) {
		line = 1;
		while(fgets(buf, 256, f) && line <= 10) {
			printf("PLUGIN:%2d: %s", line, buf);
			++line;
		}
		fclose(f);
	}
	else {
		printf("PLUGIN: couldn't open \"%s\".\n", filename);
	}

	DrawCircle();

	/* to see that we can return any value */
	return 10;
}

void test()
{
	printf("bla\n");
}



/* link to the Microsoft VCR library version 7.0 */
EDLL_ADDLIB("msvcr70.dll");


