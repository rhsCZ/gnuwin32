/* This file is public domain */

/*
--edll_init
--edll_setsearchpath
edll_open
edll_sym
edll_close
edll_exit
*/



/*
 * This file represents an application which at some point in
 * time wants to load a plug-in. It does so using the edll
 * library.
 */

#include	<edll/edll.h>

#include	<stdio.h>
#include	<stdlib.h>



/* in our plug-in, we have a function which prototype is as follow: */
typedef int (*program_t)(int argc, char **argv);

int main(int argc, char *argv[])
{
	edll_module *main_module;
	char		*filename, *args[2];
	program_t	addr;
	int		r;

/** Initialize the edll library **/
	if(edll_init() != 0) {
		fprintf(stderr, "FATAL ERROR: can't initialize the dynamic loader library.\n");
		exit(1);
	}

	r = edll_setsearchpath (".");
	if(r != 0) {
		printf("FATAL ERROR: can't setup the search path for the dynamic loader library.\n");
		edll_exit();
		exit(1);
	}

/** Now we can load our application **/

	filename = "plugin.so";
	printf("STARTUP: loading plug-in: \"%s\".\n", filename);
	main_module = edll_open(filename);

	if(main_module == 0) {
		printf("FATAL ERROR: can't load \"%s\". %s\n", filename, edll_strerror());
		edll_exit();
		exit(1);
	}

/** Get the address of the function we want to run **/
	addr = (program_t) edll_sym(main_module, "_Program");
	if(addr == 0) {
		printf("FATAL ERROR: can't find the Program() function in this module. %s\n", edll_strerror());
		edll_close(main_module);
		edll_exit();
		exit(1);
	}

	printf("STARTUP: Program() was successfully loaded at 0x%8p\n", addr);

/** Call this function **/
	args[0] = "startup!";
	args[1] = 0;
	printf("STARTUP: calling Program()...\n");
	r = (*addr)(1, args);
	printf("STARTUP: Program() returned with %d...\n", r);

	r = edll_close(main_module);
	if(r != 0) {
		printf("WARNING: there was an error closing the module.\n");
	}

/** We're done, make sure the edll library closes just fine **/

	/*
	 * I don't think we need to remove our module, but
	 * just to make sure it works...
	 */
	r = edll_exit();
	if(r != 0) {
		printf("WARNING: edll_exit() returned %d... 0 was expected.\n", r);
	}

	printf("STARTUP: success!\n");

	return 0;
}

void bla()
{
	FILE f;
	char *c;
	fgets(c, 1, &f);
}
