/* This file is public domain */

/*
 * This file represents a plugin that your main
 * application will load as required at runtime.
 */


/* needed for the EDLL_ADDLIB() */
#include	<edll/edll.h>

#include	<stdio.h>
#include	<stdlib.h>

/* print this source file on screen */
int Program(int argc, char *argv[])
{
	char		buf[256];
	const char	*filename;
	FILE		*f;
	int		line;

	filename = "plugin.c";

	f = fopen(filename, "r");
	if(f) {
		line = 1;
		while(fgets(buf, 256, f) && line <= 10) {
			printf("PLUGIN:%2d: %s", line, buf);
			++line;
		}
		fclose(f);
	}
	else {
		printf("PLUGIN: couldn't open \"%s\".\n", filename);
	}

	/* to see that we can return any value */
	return 10;
}

void test()
{
	printf("bla\n");
}



/* link to the Microsoft VCR library version 7.0 */
//EDLL_ADDLIB("msvcr70.dll");
EDLL_ADDLIB("");


