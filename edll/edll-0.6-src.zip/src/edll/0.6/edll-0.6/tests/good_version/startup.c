/* This file is public domain */

/*
 * This file represents an application which at some point in
 * time wants to load a plug-in. It does so using the ltdl
 * library.
 */

/* needed for the EDLL_VERSION() */
#include	<edll/edll.h>
#include	<edll/ltdl.h>

#include	<stdio.h>
#include	<stdlib.h>



/* in our plug-in, we have a function which prototype is as follow: */
typedef int (*program_t)(int argc, char **argv);


int main(int argc, char *argv[])
{
	lt_dlhandle	main_module;
	char		*filename;
	int		r;

/** Initialize the ltdl library **/
	if(lt_dlinit() != 0) {
		fprintf(stderr, "FATAL ERROR: can't initialize the dynamic loader library.\n");
		exit(1);
	}

	r = lt_dlsetsearchpath(".");
	if(r != 0) {
		printf("FATAL ERROR: can't setup the search path for the dynamic loader library.\n");
		lt_dlexit();
		exit(1);
	}

/** Now we can load our application **/

	filename = "plugin.so";
	printf("STARTUP: loading plug-in: \"%s\".\n", filename);
	main_module = lt_dlopen(filename);

	if(main_module == 0) {
		printf("FATAL ERROR: can't load \"%s\". %s.\n", filename, edll_strerror());
		lt_dlexit();
		exit(1);
	}

/** this is a failure since the versions weren't checked properly **/
	/* this is actually what we expect since the versions do not match! */
	printf("STARTUP: success!\n");

	lt_dlexit();
	exit(0);
}

/* This is the version of the executable:
 *
 * WARNING: this will stick to your executable ONLY if you apply the
 *          dev/version.patch file to your ld script file(s).
 */
EDLL_MODULE_VERSION("0.4.0");

