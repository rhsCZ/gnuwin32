
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/misc.c"
    LAST MODIFIED: "Do, 25 Aug 2005 21:36:18 CEST (joze)"
    (C) 1999 - 2005 by Johannes Zellner
    johannes@zellner.org
    $Id: misc.c,v 1.68 2005/08/25 19:36:30 joze Exp $
    ---
    Copyright (c) 1999 - 2005, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"

static void shiftleft(char* buf);
static char* copyright(void);

static char*
copyright(void)
{
    static char cpy[0x80];
    strcpy(cpy, "Copyright (c) 1999 - 2005 by Johannes Zellner <johannes@zellner.org>");
    return cpy;
}

void
help(void)
{
    (void) fprintf(stdout, 
"Usage: %s [OPTION]... [FILE ...]\n"
"zimg displays ascii or binary data as"
#ifdef GD_HAS_PNG
    " png"
#endif
#ifdef GD_HAS_GIF
    " gif"
#endif
#ifdef GD_JPEG_VERSION
" or jpeg"
#endif
" image.\n\n"
"Mandatory arguments to long options are mandatory for short options too.\n"
"INPUT\n"
"  -r, --size=<width>[x<height>]\n"
"                              dimension of the 2d data\n"
"  -M, --matrix                input is in ASCII matrix format. Width and height\n"
"                              taken as the number of columns and lines of the\n"
"                              input file but can be overwritten by --size.\n"
"  -p, --pattern=<pattern>     <pattern> marks a comment line for ascii input\n"
"                              (default: '#')\n"
"  -n, --column[=<no>]         read column <no> (ascii input). Multiple columns\n"
"                              can be selected by using this option repeatedly\n"
"                              This is limited to the 32 first cols\n"
"                              If <no> is omitted, all columns are selected\n"
"  -k, --skip[=<bytes/lines>]  ascii input: skip <lines>\n"
"                              binary input: skip <bytes>\n"
"                              if used w/o argument the default is restored\n"
#ifdef HAVE_REGEX_H
"      --options=/<regexp>/<switches>\n"
"                              apply <switches> if filename matches <regexp>\n"
#endif
#ifdef HAVE_POPEN
"      --input-filter=<filter> use <filter> for reading input files\n"
#endif
"BINARY INPUT\n"
"      --swap                  swap bytes (overwritten by big/little endian)\n"
"      --big-endian            binary input data is big endian\n"
"      --little-endian         binary input data is little endian\n"
"  -f, --float\n"
"  -d, --double\n"
"      --char\n"
"      --short\n"
"      --int\n"
"      --long-int\n"
"  -c, --unsigned-char\n"
"  -s, --unsigned-short\n"
"  -i, --unsigned-int\n"
"      --unsigned-long-int\n"
"      --complex-float=(abs/length|phase|real|imaginary)  [abs]\n"
"      --complex-double=(abs/length|phase|real|imaginary) [abs]\n"
"OUTPUT\n"
"  -o, --output=<name>         filename for output, default is stdout; if more\n"
"                              than one input file is given, <name> must be a\n"
"                              directory unless it is - for stdout\n"
"      --interlace             write an interlaced image\n"
#if defined(GD_HAS_PNG) && defined (GD_HAS_GIF)
"  -g, --gif                   write gif instead of png.\n"
#endif
#ifdef GD_JPEG_VERSION
"  -j, --jpeg[=<q>]            write jpeg, with the given quality\n"
"                              (0 -- 100)\n"
#endif
"  -P, --ppmorpgm              write PPM or PGM file for color or\n"
"                              gray palette image, respectively\n"
"      --ppm                   write portable pixmap (PPM) instead of png\n"
"      --pgm                   write portable graymap (PGM) instead of png; to be\n"
"                              used only for --gray palette images\n"
"  -S, --scale=<x>[,<y>]       image scaling\n"
#if 0
"  -B, --bin=<x>[,<y>]         integer data binning\n"
#endif
"  -C, --crop=[<left>-<right>x<top>-<bottom>]\n"
"  -A, --align=<horizontal>[x<vertical>][,bordercolor]\n"
#if 0
/* TODO: see also cmdln.c */
"  -E, --extend=<left>-<right>x<top>-<bottom>\n"
#endif
"COLOR MAPPING\n"
"      --red\n"
"      --blue\n"
"      --grey, --gray          (default is --colormap=1)\n"
"  -m, --colormap[=<file>]     use custom colormap file. The colormapfile must\n"
"                              hold r g b triplets in the range from 0 to 0xff\n"
"                              Empty lines and lines starting with a hash `#'\n"
"                              mark are skipped\n"
"  -m  --colormap[=r[,g[,b]]]  use color formulae to create the colormap\n"
"                              color formulae are documented on the man page\n"
"  -b, --cbox, --colorbox[=n]  draw colorbox with <n> levels\n"
"      --cbox-fmt=<format>     format for formatting the colorbox numbers\n"
"      --cbox-label=<label>    colorbox label\n"
"      --dump-colormap         dumps a colormap file as it can be read by -m\n"
"  -I, --invert                invert the selected color map\n"
"  -x, --xor[=spec]            exclusive or with the LINE COLOR spec [white]\n"
"  -z, --crange=<min>,<max>    data range for color mapping (default autoscale)\n"
"  -l, --logarithmic[=scale]   logarithmic color mapping. This is done by scaling\n"
"                              the data to 0 - scale [1] and taking the log\n"
"      --differentiate         display a discrete differentiation of the data\n"
"  -u, --curvature             display the curvature (2'nd derivative)\n"
"      --smooth[=<threshold>]  wipe out hot spots. The average and sigma of\n"
"                              the nearest neighbours of each pixel are\n"
"                              calculated. If the pixel's value is greater\n"
"                              than (`threshold' * sigma + average), it\n"
"                              will be set to the average of the neighbours\n"
"  -a, --fabs                  take the absolute value of the input data\n"
"      --absolute=<min>,<max>  set everything below <min> to <min> and every-\n"
"                              thing above <max> to <max> (applied to raw data)\n"
"      --relative=<min>,<max>  same as above, but <min> and <max> are given\n"
"                              relative (in percent) to the <max> and <min>\n"
"                              of the raw data\n"
"  -N, --no-data=[[@]<val>[,<c>]]\n"
"      --nda=[[@]<val>[,<c>]]  undefined data points with <val> are colored\n"
"                              with a 3 or 6 digit hex color c (0 <= x <= ff)\n"
"                              Specify @<val> as a threshold for automatic\n"
"                              nda calculation\n"
"      --contours=<levels>[,log][,bg=color|,fg=color]\n"
"                              draw contour lines (experimental)\n"
"                              the optional argument `log' distributes the\n"
"                              contour levels logarithmically over the image\n"
"                              the optional argument bg=color forces controur-\n"
"                              only drawing i.e. colors the background with\n"
"                              the specified color. The optional argument\n"
"                              fg=color uses the specified color for the\n"
"                              contour lines\n"
"                              is used as contour foreground color instead\n"
#if defined HAVE_DLSYM || defined HAVE_SHL_LOAD
"  -e, --expr=<string>         c-syntax string expression for data-filtering\n"
"  -R, --expr-source=<file.c>  c source file for compiling the expression\n"
"  -O, --expr-object=<file.so> shared object file for compiling the expression\n"
#endif
"MISCELLANEOUS\n"
"  -t, --label=[+-]x[+-]y,txt  horizontal label <txt> at x,y\n"
"      --vlabel=[+-]x[+-]y,txt vertical label <txt> at x,y\n"
"      --legend=<string>       print (multiline) <string> at the right outside\n"
"  -F  --font=<integer>        font size (1 <= <integer> <= 4), [automatic]\n"
"  -T  --textcolor=<spec>      3 or 6 digit hex text color c (0 <= x <= ff)\n"
"      --line=[+-]x1[+-]y1[+-]x2[+-]y2...\n"
"                              line or polyline starting from x1, y1\n"
"      --rline=[+-]x1[+-]y1[+-]x2[+-]y2...\n"
"                              similar to --line, but relative coordinates\n"
"  -L, --license\n"
"  -V, --version\n"
"  -v, --verbose\n"
"      --statistics[=<levels>] print statistics of the processed data to stderr\n"
"  -h, --help\n"
"  -D, --debug                 (discouraged)\n"
"\n"
"Before processing command line switches, the resource files\n"
"    " SYSCONFDIR "/zimgrc, $HOME/.zimgrc, .zimgrc and zimgrc\n"
"are processed. Command line options overwrite options from resource files.\n"
"\n"
"%s, compiled: %s\n" /* version(), __DATE__ */
/* TODO: use a defined date here */
"%s\n" /* copyright() */
"%s comes with ABSOLUTELY NO WARRANTY; for details type `%s --license'.\n"
"This is free software, and you are welcome to redistribute it under the\n"
"terms of a BSD type License.\n"
"Report bugs to <johannes@zellner.org>\n",
    PROGRAMNAME,
    version(), __DATE__,
    copyright(),
    PROGRAMNAME, PROGRAMNAME);
    
    exit(0);
}

void license (void)
{
    (void) fprintf(stderr, 
"   %s\n"
"   %s\n"
"   All rights reserved.\n"
"   \n"
"   Redistribution and use in source and binary forms, with or without\n"
"   modification, are permitted provided that the following conditions\n"
"   are met:\n"
"   \n"
"     * Redistributions of source code must retain the above copyright\n"
"       notice, this list of conditions and the following disclaimer.\n"
"     * Redistributions in binary form must reproduce the above copyright\n"
"       notice, this list of conditions and the following disclaimer in the\n"
"       documentation and/or other materials provided with the distribution.\n"
"     * Neither the name of Johannes Zellner nor the names of contributors\n"
"       to this software may be used to endorse or promote products derived\n"
"       from this software without specific prior written permission.\n"
"       \n"
"   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n"
"   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n"
"   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n"
"   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR\n"
"   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,\n"
"   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,\n"
"   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR\n"
"   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF\n"
"   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING\n"
"   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS\n"
"   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n",
    version(), copyright());

    exit (1);
}

char*
version(void)
{
    static char vers[0xff];
    char* komma = ", ";
    char* start = " [";
    char* sep = start;

    sprintf(vers, "%s %s%s%s%s", PROGRAMNAME, VERSION,
#ifdef GD_HAS_PNG
		    " png"
#else
		    ""
#endif
		    ,
#ifdef GD_HAS_GIF
		    " gif"
#else
		    ""
#endif
		    ,
#ifdef GD_JPEG_VERSION
		    " jpeg"
#else
		    ""
#endif
		    );

#define VERS_APPEND(x) \
do { \
    strcat(vers, sep); \
    strcat(vers, (x)); \
    if (sep != komma) sep = komma; \
} while (0)

#if defined(ENABLE_EDF)
    VERS_APPEND("edf");
#endif

#if defined(HAVE_DLSYM) || defined(HAVE_SHL_LOAD)
    VERS_APPEND("dynaload");
#endif

#if defined(HAVE_POPEN)
    VERS_APPEND("popen");
#endif

#if defined(HAVE_REGEX_H)
    VERS_APPEND("regexp");
#endif

#if defined(ENABLE_EDF) || defined(HAVE_DLSYM) || defined(HAVE_SHL_LOAD) || defined(HAVE_POPEN) || defined(HAVE_REGEX_H)
    strcat(vers, "]");
#endif

#undef VERS_APPEND

    return vers;
}

char *ztime (void)
{
    time_t current;
    static char Zeile[BUFSIZ];

    time(&current);

    /* emitting a RFC822-conformant date */
    strftime(Zeile, sizeof(Zeile),
	"%a, %d %b %Y %H:%M:%S %z", localtime(&current));

    return Zeile;
}

void
perrorexit(const char *Zeile)
{
    perror(Zeile);
    exit (-1);
}

void
Fatal(const char *msg)
{
    fprintf(stderr, "%s: %s\n", PROGRAMNAME, msg);
    exit(1);
}

double
minmax(float *data, unsigned char* flags, unsigned int len, float *min, float *max)
{
    float val;
    unsigned int i;
    double integral = (double)0.0;

    unsigned char valid = 0;

    for (i = 0; i < len; i++) {

	if (flags && *(flags + i)) { /* ignore masked (nda) points */
	    continue;
	}

	val = *(data + i);

	integral += (double)val;

	if (!valid) {
	    *max = val;
	    *min = val;
	    valid = 1;
	} else {
	    if (*max < val) {
		*max = val;
	    }
	    if (*min > val) {
		*min = val;
	    }
	}
    }

    return integral;
}

static void
shiftleft(char* buf)
{
    char* ptr;
    for (ptr = buf-- + 1; *buf++; ptr++) {
	*buf = *ptr;
    }
}


/* parse -- split the command in buf into
 *          individual arguments.
 */
int
parse(char **args, int maxargs, char *buf)
{
    int nr = 0;

    while (*buf != '\0' && nr < maxargs) {

	int quoted = 0;

        /* Strip whitespace.  Use nulls, so that
	 * the previous argument is terminated
         * automatically.
         */
        while ((*buf == ' ') || (*buf == '\t') || (*buf == '\n'))
            *buf++ = '\0';

        if (!(*buf)) /* don't count the terminating NULL */
            break;

        /* Save the argument. */
	*args++ = buf;
        nr++;

        /* Skip over the argument. */
        while ('\0' != *buf) {
	    if ('"' == *buf || '\'' == *buf) {
		if (quoted == *buf) {
		    shiftleft(buf);
		    quoted = 0;
		} else if (!quoted) {
		    quoted = *buf;
		    shiftleft(buf);
		}
	    }
	    if (!quoted
		&& (' ' == *buf || '\t' == *buf || '\n' == *buf)) {
		break;
	    }
            buf++;
	}
    }

    *args = '\0';
    return nr;
}

#ifndef HAVE_LOG1P
double
log1p(double arg)
{
    return log(arg + 1);
}
#endif

static int (*zclose)(FILE*) = fclose;

#ifdef HAVE_POPEN
struct suffix_dispatcher {
    const char* suffix;
    const char* filter;
};

static struct suffix_dispatcher dispatcher[] = {
    { ".gz", "gunzip -c %s" },
    { ".bz2", "bunzip2 -c %s" },
    { ".z", "uncompress -c %s" },
    { ".Z", "uncompress -c %s" },
    { (const char*) 0, (const char*) 0 }
};
#endif

FILE*
varopen(const char* filename, const char* mode
#ifdef HAVE_POPEN
       	, const char* filter
#endif
	)
{
    zclose = fclose;
    if (!filename || filename[0] == '\0') {
	return stdin;
    } else {
	FILE* fp = (FILE*) 0;
#ifdef HAVE_POPEN
	const char* end;
	char cmd[BUFSIZ];
	zclose = pclose;

	/* 1. user supplied input filter */
	if (filter) {
	    if (strstr(filter, "%s")) {
		sprintf(cmd, filter, filename);
	    } else {
		strcpy(cmd, filter);
		strcat(cmd, " ");
		strcat(cmd, filename);
	    }
	    fp = popen(cmd, mode);
	    if (!fp) {
		perrorexit(cmd);
	    }
	}

	/* 2. predefined input filters (uncompression) */
	if (!fp) {
	    char modified_filename[BUFSIZ];
	    struct suffix_dispatcher* ptr;
	    strcpy(modified_filename, filename);
#ifdef HAVE_ACCESS
	    /* this is a `multiview' (a la apache): if the file
	     * is not readable, it is tried with some known
	     * suffixes. */
	    if (0 != access(modified_filename, R_OK)) {
		for (ptr = dispatcher; ptr->suffix; ptr++) {
		    strcpy(modified_filename, filename);
		    strcat(modified_filename, ptr->suffix);
		    if (0 == access(modified_filename, R_OK)) {
			break;
		    }
		}
		if (!(ptr->suffix)) {
		    perrorexit(filename);
		}
	    }
#endif
	    end = modified_filename + strlen(modified_filename);
	    for (ptr = dispatcher; ptr->suffix; ptr++) {
		if (end - strlen(ptr->suffix) ==
			strstr(modified_filename, ptr->suffix)) {
		    sprintf(cmd, ptr->filter, modified_filename);
		    fp = popen(cmd, mode);
		}
	    }
	}

	if (!fp) {
	    zclose = fclose;
#endif
	    fp = fopen(filename, mode);
#ifdef HAVE_POPEN
	}
#endif
	if (!fp) {
	    perrorexit(filename);
	}
	return fp;
    }
}

void
varclose(FILE* fp)
{
    if (fp != stdin)
        zclose(fp);
}

/* libgd does not provide function to save the image as portable graymap format
 * (PGM), thus we implement it ourselves
 * note: it is supposed that the image is really gray, but the user may have
 *	 added some labels or text in another color; thus, we will output
 *	 no:  max(r,g,b) of the current pixel
 *	 no:  (r,g,b)/3 of the current pixel
 *	 yes: r of the current pixel
 * consequently, use always -P or --pgm --gray
 */
void
zimgGdImagePgm(gdImagePtr im, FILE* fp)
{
    int x, y, g, p;
    unsigned char *ptr, *line = malloc(gdImageSX(im));
    assert(line);
    fprintf(fp, "P5\n%i %i\n255\n", gdImageSX(im), gdImageSY(im));
    for (y=0; y<gdImageSY(im); y++) {
	ptr = line;
	for (x=0; x<gdImageSX(im); x++) {
	    g = gdImageGetPixel(im, x, y);
#if 0
#define mymax(x,y) ((x)>=(y) ? (x) : (y))
	    p = mymax(gdImageRed(im, g), gdImageGreen(im, g));
	    p = mymax(p, gdImageBlue(im, g));
#elif 1
	    p = (gdImageRed(im, g) + gdImageGreen(im, g) + gdImageBlue(im, g)) / 3;
#elif 0
	    p = gdImageRed(im, g);
#endif
	    *ptr++ = p;
	}
	fwrite(&line[0], gdImageSX(im), 1, fp);
    }
    free(line);
}

/* libgd does not provide function to save the image as portable pixmap format
 * (PPM), thus we implement it ourselves
 */
void
zimgGdImagePpm(gdImagePtr im, FILE* fp)
{
    int x, y, g;
    unsigned char *ptr, *line = malloc(3*gdImageSX(im));
    assert(line);
    fprintf(fp, "P6\n%i %i\n255\n", gdImageSX(im), gdImageSY(im));
    for (y=0; y<gdImageSY(im); y++) {
	ptr = line;
	for (x=0; x<gdImageSX(im); x++) {
	    g = gdImageGetPixel(im, x, y);
	    *ptr++ = gdImageRed(im, g);
	    *ptr++ = gdImageGreen(im, g);
	    *ptr++ = gdImageBlue(im, g);
	}
	fwrite(&line[0], 3*gdImageSX(im), 1, fp);
    }
    free(line);
}

