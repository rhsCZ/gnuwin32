
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/contours.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:12:15 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner <johannes@zellner.org>
    $Id: contours.c,v 1.10 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"


#define LINE(x1, y1, x2, y2, c) gdImageLine \
    (im, (x1) * xscale, (y1) * yscale, (x2) * xscale, (y2) * yscale, (uniform ? *color : color[(c)]))

int contours (zimg_t *z, float *data, gdImagePtr im, int entries,
              float data_min, float data_max)
{
    int i;
    register int x, y;
    float amplitude = (float) z->contour.levels / (data_max - data_min);
    float l_amplitude = (float) z->contour.levels / log1p (data_max - data_min);

    int *up = (int*) 0, *low, *class[2];
    /* north-west, north-east, south-west .. */
    int nw = 0, ne = 0, sw = 0, se = 0;
    int *color, c;
    
    float xscale = (float) z->ximg / (float) z->data.x;
    float yscale = (float) z->yimg / (float) z->data.y;

    char uniform = (0 == z->contour.background && z->contour.color.set);

    for (i = 0; i < 2; i++) {
        assert(class[i] = (int *) malloc(sizeof (int) * z->data.x));
    }

    assert(color = (int *) malloc(sizeof (int) * (uniform ? 1 : z->contour.levels)));

    if (uniform) {
	color[0] = zimg_gdImageLineColorAllocate(im, z->contour.color.red,
	    z->contour.color.green, z->contour.color.blue);
    } else {
	for (i = 0; i < z->contour.levels; i++) {
	    /*
	     * a logarithmic color mapping does
	     * for some reason not look good.
	     if (z->contour.log)
	     c = entries * (1 - (log1p ((float) i) * l_contour));
	     else
	     */
	    if (z->contour.color.set)
		/* normal colormapping on 'set' background */
		c = entries * ((float) i / z->contour.levels);
	    else
		/* inverse colormapping on normal background */
		c = entries * (1 - (float) i / z->contour.levels);
	    color[i] = c;
	}
    }


    /* calculate contour segments */
    low = class[0];

    for (y = 0; y < z->data.y; y++) {

        for (x = 0; x < z->data.x; x++) {

            if (z->contour.log)
                *low = (int) ((float) ((log1p ((*data) - data_min))
                                       * l_amplitude));
            else
                *low = (int) ((float) (((*data) - data_min) * amplitude));
            *low = *low < 0 ? 0: *low;
            *low = *low >= z->contour.levels ? z->contour.levels - 1: *low;


            if (y && x) {


                nw = up[x - 1];
                ne = up[x];
                se = *low;
                /*
                if (*low > 5)
                    fprintf (stderr, "DEBUG> %4d %4d %4d %4d\n", nw, ne, sw, se);
                */

                if (ne > se && ne > sw && nw > se && nw > sw) /* - n */
                    LINE (x - 1, y - 1, x, y - 1, nw);
                else if (se > ne && se > nw && sw > ne && sw > nw) /* - s */
                    LINE (x - 1, y, x, y, se);

                if (nw > ne && nw > se && sw > ne && sw > se) /* | w */
                    LINE (x - 1, y - 1, x - 1, y, nw);
                else if (ne > nw && ne > sw && se > nw && se > sw) /* | e */
                    LINE (x, y - 1, x, y, se);

                if ((nw >= sw && nw >= ne && sw > se && ne > se)
                    || (nw < sw && nw < ne && sw <= se && ne <= se)) /* / */
                    LINE (x - 1, y, x, y - 1, sw);
                if ((ne >= se && ne >= nw && se > sw && nw > sw)
                    || (ne < se && ne < nw && se <= sw && nw <= sw)) /* \ */
                    LINE (x - 1, y - 1, x, y, nw);


            }

            sw = se;
            data++;
            low++;
        }
        up  = (up == class[0])? class[1]: class[0];
        low = (up == class[0])? class[1]: class[0];
    } 

    for (i = 0; i < 2; i++) {
        free ((void *) class[i]);
    }
    free ((void *) color);

    return (OK);
}

