/* -*- C -*-
 * FILE: "/home/joze/pub/zimg/zimg/dynaload.h"
 * LAST MODIFICATION: "Wed, 02 Jul 2003 21:12:26 CEST (joze)"
 * (C) 2003 by Johannes Zellner, <johannes@zellner.org>
 * $Id: dynaload.h,v 1.5 2003/07/02 19:19:56 joze Exp $
 */

#ifdef HAVE_CONFIG_H
#   include "config.h"
#endif

#include "zimg.h"

#if defined (HAVE_DLSYM) || defined(HAVE_SHL_LOAD)

/* prototypes */
char* dynaload_compile(char* str, char* dynaload_source, char* dynaload_dest);
void dynaload_prepare(void);
zimg_expression_t dynaload_expression_load(const char* objectfile);
void dynaload_expression_unload(void);

#endif
