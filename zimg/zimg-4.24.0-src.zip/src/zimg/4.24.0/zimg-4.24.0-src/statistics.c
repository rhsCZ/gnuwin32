
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/statistics.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:14:19 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: statistics.c,v 1.9 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"

int statistics(const float *data, unsigned char* flags,
       	int width, int height, float min, float max, int levels)
{
    int i, len = width * height, index, *hist;
    const float *rawptr = data;
    float incr, offset;
    float fact = ((float) (levels)) / (max - min);

#if 0
    fprintf (stderr, "levels=%d\n", levels);
    fprintf (stderr, "max, min, max - min = %f %f %f\n", max, min, max - min);
    fprintf (stderr, "fact=%f\n", fact);
#endif
    
    assert (hist = (int *) malloc (sizeof (int) * levels));
    
    memset ((void *) hist, 0, sizeof (int) * levels);
    
    for (i = 0; i < len; i++, rawptr++) {
	if (flags && *(flags + i)) /* ignore masked (nda) points */
	    continue;
        index = (int) ((float) (*rawptr - min) * fact);
        if (index < levels && index > 0)
            hist[index]++;
#if 0
        else
            fprintf (stderr, "index = %d\n", index);
#endif
    }

    incr = (float) 1.0 / fact;
    for (offset = 0, i = 0; i < levels; i++, offset += incr) {
        fprintf (stderr, "    % 12.6g - % 12.6g: %d\n",
                 offset, offset + incr, hist[i]);
    }
    
    free (hist);

    return (OK);
}

