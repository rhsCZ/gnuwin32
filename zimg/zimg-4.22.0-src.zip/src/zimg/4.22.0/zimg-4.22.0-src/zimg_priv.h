
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/zimg_priv.h"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:19:35 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: zimg_priv.h,v 1.18 2003/11/30 11:36:41 mikulik Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#ifndef lint
#ifdef MAIN
char *RCSDate = "$Date: 2003/11/30 11:36:41 $";
char *RCSRevision = "$Revision: 1.18 $";
int verbose = 0;
int debug = 0;
#define EXTERN
#else
extern char *RCSDate;
extern char *RCSRevision;
extern int verbose;
extern int debug;
#endif /* MAIN */
#endif /* lint */

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <assert.h>

#include <gd.h>

#include <unistd.h>

/* define this to double, if the data
 * storage and handling should be double */
#define FLOAT float

/* for times() */
#include <sys/types.h>
#include <limits.h>

#ifdef HAVE_SYS_TIMES_H
#    include <sys/times.h>
#endif

#ifdef HAVE_REGEX_H
#   include <regex.h>
#endif

#define PROGRAMNAME "zimg"
#define RCFILE "zimgrc"


#ifdef TRUE
#   undef TRUE
#endif /* TRUE */
#ifdef FALSE
#   undef FALSE
#endif /* FALSE */

#define TRUE	(1)
#define FALSE	(0)

/* available output formats 
 * note 1: IMFORMAT_GIFPNG chooses between gif and png file according 
 *	   to GD_GIF_VERSION
 * note 2: IMFORMAT_PPMorPGM chooses between PGM and PPM according to --gray
 */
#define IMFORMAT_GIFPNG   0
#define IMFORMAT_JPG	  1
#define IMFORMAT_PPM	  2
#define IMFORMAT_PGM	  3
#define IMFORMAT_PPMorPGM 99

#define OK	(0)
#define ERROR	(-1)
#define UNSET	(-1)

#define MAX_PATTERNS	(10)
#define MAX_ARGS	(1000)

#define ASCII_FORMAT		(0)
#define FLOAT_FORMAT		(1 << 0)
#define DOUBLE_FORMAT		(1 << 1)
#define CHAR_FORMAT		(1 << 2)
#define SHORT_FORMAT		(1 << 3)
#define INT_FORMAT		(1 << 4)
#define L_INT_FORMAT		(1 << 5)
#define U_CHAR_FORMAT		(1 << 6)
#define U_SHORT_FORMAT		(1 << 7)
#define U_INT_FORMAT		(1 << 8)
#define U_L_INT_FORMAT		(1 << 9)
#define COMPLEX_FLOAT_FORMAT	(1 << 10)
#define COMPLEX_DOUBLE_FORMAT	(1 << 11)

#define GD_FORMAT	(7)

#define RGBMAP		(1 << 26)
#define REDMAP		(1 << 27)
#define BLUEMAP		(1 << 28)
#define GRAYMAP		(1 << 29)
#define INVERT_MAP	(1 << 30)
#define XOR_MAP		(1 << 31)

/*
 * FIXME:
 *   this works for 4 byte unsigned int
 *   and for nothing else.
 */
#define ALL_COLUMNS (0xffffffff)

#define BLACK (-2)

#define ACCESS2D(x, y, ptr, width) (*((ptr) + ((width) * (y)) + (x)))

enum {
    COMPLEX_ACTION_ABS   = (0),
    COMPLEX_ACTION_PHASE = (1 << 0),
    COMPLEX_ACTION_REAL  = (1 << 2),
    COMPLEX_ACTION_IMAG  = (1 << 3),
};

#define TRANSFORM_CHUNK_SIZE (0x100)

#define TRANS(z) ((z)->transform[(z)->transform_valid])

enum TRANSFORM_TYPE {
    differentiate_TT,
    curvature_TT,
    smooth_TT,             /* p1 = sigma */
    logarithmic_TT,        /* p1 = factor for log scaling */
    fabs_TT,
    absolute_TT,           /* p1 = min, p2 = max */
    absolute_min_TT,       /* p1 = min, --absolute=min, */
    absolute_max_TT,       /* p2 = max, --absolute=,max */
    relative_TT,           /* p1 = min, p2 = max */
    relative_min_TT,       /* p1 = min, --relative=min, */
    relative_max_TT,       /* p2 = max, --relative=,max */
};

typedef struct transform_t {
    enum TRANSFORM_TYPE type;
    double p1;
    double p2;
} transform_t;

typedef struct scale_t {
    int x;
    int y;
    int pixels;
} scale_t;

typedef enum zimg_label_flag_t {
    ZIMG_HORIZONTAL = 0,
    ZIMG_VERTICAL
} zimg_label_flag_t;

typedef struct zimg_label_t {
    int x;
    int y;
    char* text;
    zimg_label_flag_t flag;
    struct zimg_label_t* prev;
    struct zimg_label_t* next;
} zimg_label_t;

typedef struct zimg_vertex_t {
    int x;
    int y;
    struct zimg_vertex_t* prev;
    struct zimg_vertex_t* next;
} zimg_vertex_t;

typedef enum zimg_polyline_flag_t {
    ZIMG_LINE_ABSOLUTE = 0,
    ZIMG_LINE_RELATIVE
} zimg_polyline_flag_t;

typedef struct zimg_polyline_t {
    zimg_vertex_t* vertex;
    int n;
    zimg_polyline_flag_t flag;
    struct zimg_polyline_t* prev;
    struct zimg_polyline_t* next;
} zimg_polyline_t;

typedef struct zimg_color_t {
    unsigned char set;
    unsigned char red;
    unsigned char green;
    unsigned char blue;
} zimg_color_t;

typedef struct crange_t {
    unsigned char setMin, setMax;
    float theMin, theMax;
} crange_t;

typedef struct contour_t {
    /*
     * TODO:
     *   add non-equally spaced
     *   user definable levels.
     */
    int levels;
    int log;
    char background;
    zimg_color_t color;
} contour_t;

typedef struct zimg_data_t {

    unsigned int x;
    unsigned int y;

    unsigned int len;    /* len = x * y */

    /* cropping */
    unsigned int xleft;
    unsigned int xright;
    unsigned int ytop;
    unsigned int ybottom;
    unsigned char autocrop;

    unsigned int xibin;
    unsigned int yibin;
    double xdscale;
    double ydscale;

} zimg_data_t;

typedef struct zimg_colorbox_t {
    unsigned char show;
    int levels;
    char* fmt;
    char* label;
} zimg_colorbox_t;

#ifdef HAVE_REGEX_H
typedef struct zimg_options_t {
    regex_t preg;
    char* switches;
} zimg_options_t;

enum { ZIMG_MAX_OPTIONS = 0xff };
#endif

enum zimg_font { FONT_UNDEFINED = 0, FONT_TINY,
    FONT_SMALL, FONT_LARGE, FONT_GIANT };

typedef struct zimg_t {

    transform_t* transform;
    int transform_valid;       /* number of valid entries in transform */
    int transform_allocated;   /* number of allocated entries in transform */

    crange_t crange;

    int    color;              /* flag */
    zimg_color_t xor_color;
    int    rgbformulae[3];     /* see getcolor.c */
    char*  colormapfile;       /* custom color map */
    int    dump_colormap;      /* dump colormap to stdout */

    int    statistics;         /* flag */

    /*
     * file stuff 
     */
    char   oname[BUFSIZ];
    FILE  *ifp;
    FILE  *ofp;

    /*
     * file format stuff
     */
    int    inputformat; /* ASCII or BINARY ( INT or FLOAT ) */
    int    b_len;
    int    skip;

#ifdef HAVE_REGEX_H
    unsigned int noptions;
    zimg_options_t options[ZIMG_MAX_OPTIONS];
#endif

#ifdef HAVE_POPEN
    char* filter;
#endif

    int    swap;
    unsigned int column;

    int  nn_pattern;
    char pattern[MAX_PATTERNS][BUFSIZ];
    
    int complex_action;


    /* data "source" dimensions */
    zimg_data_t data;


    /* image "target" dimensions */
    unsigned int ximg;
    unsigned int yimg;

    char* legend;

    int align[2];
    int extend[4]; /* TODO: unused, see cmdln.c / misc.c */
    zimg_color_t bordercolor;

    int interlace;
    int imformat; /* which output image IMFORMAT_* ? */
#ifdef GD_JPEG_VERSION
    int jpeg_quality;
#endif
    
    contour_t contour;

    zimg_polyline_t* line;
    zimg_label_t* label;

    int font;
    zimg_color_t textcolor;

    char nda_specified;
    double nda_thres;
    double nda;
    zimg_color_t nda_color;

    char* expr;
    char* expr_source;
    char* expr_object;

    zimg_colorbox_t colorbox;

} zimg_t;



/* cmdln.c */
void	readcmdln(int argc, char *argv[], zimg_t *z, int* ifiles, char*** iname);
void	init_z(zimg_t *z);
void	free_z(zimg_t *z);
void	parse_switches(zimg_t* z, char* line);
char*	checkmodeline(zimg_t* z, char* buf);

/* color.c */
int*	get_next_custom_entry(FILE* fp);
int	getGdColorMap(gdImagePtr im, int gdcolor[0x100],
       	const int color, int rgbformulae[3], char* colormapfile,
       	const zimg_color_t* xor_color);
int	zimg_gdImageLineColorAllocate(gdImagePtr im,
	int red, int green, int blue);
int	zimg_dump_color(gdImagePtr im, int r, int g, int b);

/* img.c */
void	differentiate(FLOAT *data, unsigned int width, unsigned int height);
void	torange(FLOAT* data, int len, FLOAT low, FLOAT high);
FLOAT*	curvature(FLOAT* data, unsigned int width, unsigned int height);

/* misc.c */
void	help	(void);
void	license (void);
char*	version (void);
char	*ztime	(void);
void	perrorexit(const char *Zeile);
void	Fatal(const char *Zeile);
double	minmax	(float *data, unsigned char* flags, unsigned int len, float *min, float *max);
int	parse	(char **args, int maxargs, char *buf);
#ifndef HAVE_LOG1P
double	log1p(double arg);
#endif
FILE*	varopen(const char* filename, const char* mode
#ifdef HAVE_POPEN
       	, const char* filter
#endif
	);
void	varclose(FILE* fp);
void	zimgGdImagePgm(gdImagePtr im, FILE* fp);
void	zimgGdImagePpm(gdImagePtr im, FILE* fp);

/* read.c */
int	readfile	(zimg_t *z, float *data);
int	readascii	(zimg_t *z, float *data) ;
char	*terminate_if_comment	(zimg_t *z, char *Zeile);
char	*shiftleftline	(char *Zeile);
int	readbin	(zimg_t *z, float *data);
void	swapbytes	(unsigned char *tmp, int b_len, int len);
gdImagePtr fgets_dimension(zimg_t *z);

/* contours.c */
int contours(zimg_t *z, float *data, gdImagePtr im,
    int entries, float data_min, float data_max);

/* smooth.c */
int smooth(float *data, int width, int height, float sigma);

/* statistics.c */
int statistics(const float *data, unsigned char* flags,
       	int width, int height, float min, float max, int levels);

/* getcolor.c */
double GetColorValueFromFormula(int formula, double x /* gray */);
