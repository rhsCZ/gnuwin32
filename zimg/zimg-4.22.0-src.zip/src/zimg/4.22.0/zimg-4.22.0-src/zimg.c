
 /* ==================================================================
    FILE: "/home/y1zln/pub/zimg/zimg.c"
    LAST MODIFIED: "Wed, 09 Jul 2003 08:47:03 CEST (y1zln)"
    (C) 1999 - 2003 by Johannes Zellner <johannes@zellner.org>
    $Id: zimg.c,v 1.71 2003/11/30 11:38:34 mikulik Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#define MAIN
#include "zimg_priv.h"
#include "zimg.h"
#include "dynaload.h"
#include <gd.h>
#include <gdfontt.h>  /* tiny */
#include <gdfonts.h>  /* small */
#include <gdfontmb.h> /* medium bold */
#include <gdfontl.h>  /* large */
#include <gdfontg.h>  /* giant */

#if !defined(unix) && !defined(__unix) && !defined(__unix__)
#   include <fcntl.h> /* for setmode() */
#endif

typedef struct grow_str {
    char* str;
    int len;
} grow_str;

/* not more than 0xff lines */
#define ZIMG_MULTILINE_MAXLINES (0xff)

typedef struct zimg_multiline_t {
    int x;
    int y;
    int width;  /* max number of characters */
    int height; /* number of lines */
    char* lines[ZIMG_MULTILINE_MAXLINES];
    grow_str str;
} zimg_multiline_t;

typedef struct zimg_escape_info_t {
    float max;
    float min;
    double integral;
    char* filename;
} zimg_escape_info_t;

#if 0
static unsigned int
getIndex(const zimg_data_t* spec, unsigned int x, unsigned int y)
{
    return spec->x * (spec->ytop + y) + spec->xleft + x;
}

static const unsigned char
getValueUnscaledUnbinned(float* value, const float* data,
       	const unsigned char* flags, const zimg_data_t* spec, unsigned int x, unsigned int y)
{
    unsigned int idx = getIndex(spec, x, y);
    if (flags && flags[idx]) {
	/* invalid (masked) */
	return 1;
    } else {
	*value = *(data + idx);
	return 0;
    }
}
#endif

static void
getValueCroppedBinned(float* value /* out */, unsigned char* flags /* out */,
       	const float* data /* in */, const zimg_data_t* spec /* in */,
       	unsigned int x /* in */, unsigned int y /* in */, float nda /* in */)
{
    unsigned int valid = 0;

    unsigned int yb, yend;
    unsigned int idx, idxend;
    float dval;

    *value = 0;

    for (yb = spec->ytop + y * spec->yibin, yend = yb + spec->yibin; yb < yend; yb++) {
	for (idx = spec->xleft + x * spec->xibin + yb * spec->x, idxend = idx + spec->xibin; idx < idxend; idx++) {
	    dval = *(data + idx);
	    if (!flags || nda != dval) {
		*value += *(data + idx);
		valid++;
	    }
	}
    }

    if (flags) {
	*flags = (valid == 0);
    }

    if (valid) {
	*value /= valid;
    }
}

static float
bicubicspline(float z[5], float x, float y)
{
    float z0_ = 0.5 * z[0];
    float z1  = z[1];
    float z2_ = 0.5 * z[2];
    float z3_ = 0.5 * z[3];
    float z4_ = 0.5 * z[4];

    float a = -z1 + z0_ + z2_;
    float b = -z0_ + z2_;
    float c = z1;
    float d = -z1 + z3_ + z4_;
    float e = -z3_ + z4_;

    return a * x * x + b * x + c + d * y * y + e * y;
}

static unsigned char
getData(float* value /* out */, const float* data /* in */,
	const unsigned char* flags /* in */, const zimg_data_t* spec /* in */,
	unsigned int x /* in */, unsigned int y /* in */)
{
    unsigned int idx;

    if (x >= spec->x || y >= spec->y)
	return 1;

    idx = y * spec->x + x;

    if (flags && *(flags + idx))
	return 1;

    *value = *(data + idx);
    return 0;
}

static float
triangle1quadrant(float z1, float z2, float z3, float x, float y)
{
    float a = -z1 + z2;
    float b = -z3 + z1;
    float c = z1;
    return a * x + b * y + c;
}

static float
triangle2quadrant(float z1, float z2, float z3, float x, float y)
{
    float a = -z3 + z1;
    float b =  z1 - z2;
    float c = z1;
    return a * x + b * y + c;
}

static float
triangle3quadrant(float z1, float z2, float z3, float x, float y)
{
    float a = z1 - z2;
    float b = z3 - z1;
    float c = z1;
    return a * x + b * y + c;
}

static float
triangle4quadrant(float z1, float z2, float z3, float x, float y)
{
    float a =  z3 - z1;
    float b = -z1 + z2;
    float c = z1;
    return a * x + b * y + c;
}

static unsigned char
getValueScaled(float* value /* out */, const float* data /* in */,
       	const unsigned char* flags /* in */, const zimg_data_t* spec /* in */,
       	unsigned int x /* in, image property */, unsigned int y /* in, image property */)
{
    double data_dx = (double)x / spec->xdscale;
    double data_dy = (double)y / spec->ydscale;

    unsigned int data_xcen = (int)rint(data_dx);
    unsigned int data_ycen = (int)rint(data_dy);

    unsigned int data_xright = data_xcen + 1;
    unsigned int data_xleft = data_xcen - 1;

    unsigned int data_ytop = data_ycen - 1;
    unsigned int data_ybot = data_ycen + 1;

    unsigned char left   = 0;
    unsigned char center = 0;
    unsigned char right  = 0;
    unsigned char top    = 0;
    unsigned char bot    = 0;

    float z[5];

    /* if (data_dx > spec->x - 1 || data_dx < 1 || data_dy > spec->y - 1 || data_dy < 1) { */
    if (data_xcen >= spec->x - 1 || data_xcen < 1 || data_ycen >= spec->y - 1 || data_ycen < 1) {
	/* border */
	if (data_xcen >= spec->x)
	    data_xcen = spec->x - 1;
	if (data_ycen >= spec->y)
	    data_ycen = spec->y - 1;
	return getData(value, data, flags, spec, data_xcen, data_ycen);
    }

    data_dx -= (double)data_xcen;
    data_dy -= (double)data_ycen;

    center = !getData(z + 1, data, flags, spec, data_xcen, data_ycen);

    if (!center) {
	/* fprintf(stderr, "(getValueScaled) !center\n"); */
	return 1;
    }

    if (data_xcen > 0) {
	left = !getData(z + 0, data, flags, spec, data_xleft , data_ycen);
    }
    if (data_xright < spec->x) {
	right = !getData(z + 2, data, flags, spec, data_xright, data_ycen);
    }
    if (data_ycen > 0) {
	top = !getData(z + 3, data, flags, spec, data_xcen, data_ytop);
    }
    if (data_ybot < spec->y) {
	bot = !getData(z + 4, data, flags, spec, data_xcen, data_ybot);
    }

    if (left && right && top && bot) {
	/* all five points are valid */
	*value = bicubicspline(z, data_dx, data_dy);
	return 0;
    }

    if (data_dx > 0) {
	if (right) {
	    /* interpolation */
	    if (data_dy > 0) {
		if (bot) {
		    *value = triangle4quadrant(z[1], z[4], z[2], data_dx, data_dy);
		    return 0;
		}
	    } else {
		if (top) {
		    *value = triangle1quadrant(z[1], z[2], z[3], data_dx, data_dy);
		    return 0;
		}
	    }
	}
    } else {
	/* data_dx < 0 */
	if (left) {
	    if (data_dy > 0) {
		if (bot) {
		    *value = triangle3quadrant(z[1], z[0], z[4], data_dx, data_dy);
		    return 0;
		}
	    } else {
		if (top) {
		    *value = triangle2quadrant(z[1], z[3], z[0], data_dx, data_dy);
		    return 0;
		}
	    }
	}
    }

#if 0
    fprintf(stderr, "cen = %d %d  data_dx, data_dy = %f %f   left=%d right=%d top=%d bot=%d\n",
	    data_xcen, data_ycen, data_dx, data_dy, left, right, top, bot);
#endif

    return 1;
}

#if 0
static const unsigned char
getValueScaledUnbinned(float* value, const float* data,
       	const unsigned char* flags, const zimg_data_t* spec, unsigned int x, unsigned int y)
{
    unsigned int idx = getIndex(spec, x, y);
    if (flags && flags[idx]) {
	/* invalid (masked) */
	return 1;
    } else {
	*value = *(data + idx);
	return 0;
    }
}

static const unsigned char
getValueScaledBinned(float* value, const float* data,
       	const unsigned char* flags, const zimg_data_t* spec, unsigned int x, unsigned int y)
{
    unsigned int idx = getIndex(spec, x, y);
    if (flags && flags[idx]) {
	/* invalid (masked) */
	return 1;
    } else {
	*value = *(data + idx);
	return 0;
    }
}
#endif

#if 0

		    dval = 0.0;

		    for (ib = 0; ib < z.data.yibin; ib++)
			for (jb = 0; jb < z.data.xibin; jb++)
			    dval += data[((i + ib) * z.data.x) + j + jb];

		    dval *= rez_bin;

		    /*
		    * rely here on a correct
		    * scaling, so I can remove
		    * this check to speed up.
		    *
		    if (value >= entries) {
		    value = entries - 1;
		    } else if (value < 0) {
		    value = 0;
		    }
		    */

		    xend = ximg + z.data.xdscale;
		    yend = yimg + z.data.ydscale;

		    for (y = yimg; y < yend; y++) {
			for (x = ximg; x < xend; x++) {
			    gdImageSetPixel(im, x, y, value);
			}
		    }
#endif

static void
GrowStrInit(grow_str* s)
{
    s->str = (char*)0;
    s->len = 0;
}

static void
GrowStrFree(grow_str* s)
{
    if (s->str)
	free(s->str);
    GrowStrInit(s);
}

static void
GrowStrAppendN(grow_str* s, char* rhs, int n)
{
    if (n > 0) {
	int new_len = s->len + n + 1 /* terminating 0 */;
	s->str = (char*)realloc((void*)s->str, new_len);
	assert(s->str);
	if (s->len) {
	    /* append */
	    strncat(s->str, rhs, n);
	} else {
	    /* first string */
	    strncpy(s->str, rhs, n);
	}
	s->len = new_len - 1; /* string length w/o terminating 0 */
	s->str[s->len] = '\0'; /* terminate */
    }
}

static void
GrowStrAppend(grow_str* s, char* rhs)
{
    GrowStrAppendN(s, rhs, strlen(rhs));
}

static void
MultilineInit(zimg_multiline_t* spec)
{
    spec->x = 0;
    spec->y = 0;
    spec->width = 0;
    spec->height = 0;
    GrowStrInit(&spec->str);
}

static void
MultilineFree(zimg_multiline_t* spec)
{
    GrowStrFree(&spec->str);
    MultilineInit(spec);
}

static void
MultilinePutTextVertical(gdImagePtr im, gdFontPtr font,
       	const zimg_multiline_t* spec, int color)
{
    int i;
    int x = spec->x;
    int y = spec->y;
    for (i = 0; i < spec->height; i++, x += font->h) {
	gdImageStringUp(im, font, x, y, spec->lines[i], color);
    }
}

static void
MultilinePutText(gdImagePtr im, gdFontPtr font,
       	const zimg_multiline_t* spec, int color)
{
    int i;
    int x = spec->x;
    int y = spec->y;
    for (i = 0; i < spec->height; i++, y += font->h) {
	gdImageString(im, font, x, y, spec->lines[i], color);
    }
}

static int
parse_lines(char* text, char** args, int maxargs)
{
    char* ptr;
    int i = 0;

    if (!text || !(*text))
	return 0;

    args[i++] = text; /* first line */
    for (ptr = text; ptr && *ptr && i < maxargs; /* empty */) {
	switch (*ptr) {
	    case '\\':
		if ('n' == *(ptr+1)) {
		    *ptr = '\0'; /* terminate */
		    ptr += 2; /* skip backslash and n */
		}
		break;
	    case '\n':
	    case '\r':
		*ptr = '\0'; /* terminate */
		ptr++; /* skip */
		break;
	    default:
		ptr++;
		continue;
	}
	if (*ptr)
	    args[i++] = ptr;
    }
    return i;
}

static void
MultilineGet(zimg_multiline_t* dest, char* source, const zimg_escape_info_t* escape_info)
{
    char* ptr;
    char tmp[BUFSIZ];
    int i;

    /* first pass: replace escape strings */

    while (source && *source && (ptr = strchr(source, '%'))) {
	GrowStrAppendN(&dest->str, source, ptr - source);
	ptr++;
	switch (*ptr) {
	    case 'c':
		/* not really %c, but a RFC822-conformant date */
		GrowStrAppend(&dest->str, ztime());
		break;
	    case 'f':
		GrowStrAppend(&dest->str, escape_info->filename);
		break;
	    case 'm':
		/* min */
		{
		    sprintf(tmp, "%f", escape_info->min);
		    GrowStrAppend(&dest->str, tmp);
		}
		break;
	    case 'M':
		/* max */
		{
		    sprintf(tmp, "%f", escape_info->max);
		    GrowStrAppend(&dest->str, tmp);
		}
		break;
	    case 'i':
		/* max */
		{
		    sprintf(tmp, "%f", escape_info->integral);
		    GrowStrAppend(&dest->str, tmp);
		}
		break;
#ifdef HAVE_POPEN
	    case '{':
		/* insert output of shell command */
		{
		    char* close = strchr(ptr + 1, '}');
		    if (close) {
			char* cmd;
			int len = close - ptr - 1;
			FILE* fp;
			cmd = (char*)malloc(len + 1);
			assert(cmd);
			strncpy(cmd, ptr + 1, len);
			cmd[len] = '\0'; /* terminate */
			ptr = close; /* advance ptr */
			fp = popen(cmd, "r");
			if (fp) {
			    char buf[BUFSIZ];
			    int items;
			    while ((items = fread(buf, 1, sizeof (buf), fp))) {
				GrowStrAppendN(&dest->str, buf, items);
			    }
			}
			pclose(fp);
			free(cmd);
		    }
		}
		break;
#endif
	    default:
		/* unknown escape sequence */
		GrowStrAppendN(&dest->str, ptr, 1);
		break;
	}
	source = ptr + 1;
    }

    /* append rest of the string which contains no escape sequences */
    if (source && *source)
	GrowStrAppend(&dest->str, source);

#if 0
    fprintf(stderr, "(MultilineGet) dest->str = %s\n", dest->str.str);
#endif

    dest->height = parse_lines(dest->str.str, dest->lines, ZIMG_MULTILINE_MAXLINES);

    dest->width = 0;
    for (i = 0; i < dest->height; i++) {
	int len = strlen(dest->lines[i]);
	if (len > dest->width)
	    dest->width = len;
    }
}

int
main(int argc, char *argv[])
{
    int i = 0, file;
    int items = 0;

    float* data;
    float data_min;
    float data_max;
    float fact;
    double integral;
#ifdef ENABLE_PNG_AS_SOURCE
    int dumped = 0;
#endif

    register int x, y, xpad = 0, ypad = 0;

    zimg_t z;

    gdImagePtr im = (gdImagePtr) 0;
    int gdcolor[0x100];

    gdFontPtr font = (gdFontPtr)0;
    int textcolor = (int)0;
    int nda_color;

#if defined HAVE_DLSYM || defined HAVE_SHL_LOAD
    /* float (*zimg_expression)(unsigned int, unsigned int, float, const zimg_expression_info_t*) = (zimg_expression_t)0; */
    zimg_expression_t zimg_expression = (zimg_expression_t)0;
    zimg_expression_info_t info;
    char* objectfile = (char*)0;
#endif

    int ximg = 0;
    int yimg = 0;

    /* rc file arguments */
    int Argc = 0;
#define RCFILE_MAX_ARGV 0xfff
    char* Argv[RCFILE_MAX_ARGV];

    int    ifiles; /* number of input files */
    char **iname;  /* names of input files */

    int pixel;
    int color_index;
    int entries = ZIMG_MAP_COLORS;
    int entries_ = entries - 1;
    char* ptr;

    char* rcfiles[4];

#define DATA(xx, yy) (*(data + (yy) * z.data.x + (xx)))

#define COLOR_TO_PIXEL(v)                             \
    do {                                              \
	color_index = (int)(((v) - data_min) * fact); \
	if (color_index < 0)                          \
	    color_index = 0;                          \
	if (color_index >= entries)                   \
	    color_index = entries_;                   \
	pixel = gdcolor[color_index];                 \
    } while (0)


    /* Argv[0] should contain the command name */
    Argc = 1; /* the command name is at least present */
    Argv[0] = argv[0]; /* command name */

    /* [-- check for rc files --] */

    /* system wide zimgrc, e.g. /etc/zimgrc or /usr/local/etc/zimgrc */
    rcfiles[0] = strdup(SYSCONFDIR "/" RCFILE);

    /* ~/.zimgrc */
    if ((ptr = getenv((const char *) "HOME"))) {
	char* home = (char*)malloc(strlen(ptr) + strlen(RCFILE) + 3);
	strcpy(home, ptr);
	strcat(home, "/." RCFILE);
	rcfiles[1] = strdup(home);
	free(home);
    } else {
	rcfiles[1] = "";
    }

    /* .zimgrc in the local directory */
    rcfiles[2] = strdup("." RCFILE);

    /* zimgrc in the local directory */
    rcfiles[3] = strdup(RCFILE);

    for (i = 0; i < 4; i++) {

	char rcbuf[0xffff];
	char ibuf[BUFSIZ];
	FILE* fp;

	if (!rcfiles[i] || !(*(rcfiles[i]))) {
	    continue;
	}

	if (!(fp = fopen(rcfiles[i], "r"))) {
	    free(rcfiles[i]);
	    rcfiles[i] = (char*)0;
	    continue;
    }

    /* copy options from the rc file to Argv */

	rcbuf[0] = '\0';

	while (fgets(ibuf, sizeof(ibuf), fp)) {
	    char* ptr;
	    if ((ptr = strchr(ibuf, '#'))) /* discard comments */
		*ptr = '\0';
	    strcat(rcbuf, " ");
	    strcat(rcbuf, ibuf);
	}
	/* must do a strdup(rcbuf), because the Argv will
	 * be saved and point to rcbuf */
	Argc += parse(Argv + Argc, RCFILE_MAX_ARGV - Argc, strdup(rcbuf));
	fclose(fp);
    }

    if (1 == Argc) {
       	/* no rcfile found, Argv[0] contains only the program name */
	Argc = 0;
    }

    /* set z default values */
    init_z(&z);
    /* parse arguments of .zimgrc or ~/.zimgrc */
    readcmdln(Argc, Argv, &z, (int*)0, (char***)0);
    /* read in commandline arguments */
    readcmdln(argc, argv, &z, &ifiles, &iname);

    if (TRUE == verbose) {
	if (Argc > 0) {
	    fprintf(stderr, "arguments from rcfiles: ");
	    for (i = 0; i < 4; i++) {
		if (rcfiles[i] && *rcfiles[i]) {
		    fprintf(stderr, " [%s]", rcfiles[i]);
		}
	    }
	    fprintf(stderr, "\n");
	    for (i = 1 /* omit command name */; i < Argc; i++) {
		fprintf(stderr, "  %s\n", Argv[i]);
	    }
	}
	fprintf(stderr, "command line arguments:\n");
	for (i = 1 /* omit command name */; i < argc; i++) {
	    fprintf(stderr, "  %s\n", argv[i]);
	}
    }
    
#if defined HAVE_DLSYM || defined HAVE_SHL_LOAD
    {
	if (z.expr || z.expr_source) {
	    objectfile = dynaload_compile(z.expr, z.expr_source, z.expr_object);
	} else if (z.expr_object) {
	    objectfile = z.expr_object;
	}
	if (objectfile) {
	    zimg_expression = dynaload_expression_load(objectfile);
	}
    }
#endif

    if (!z.column) {
        z.column = 1; /* read column 1 by default */
    }

    if (z.dump_colormap && !ifiles) {
	goto dump_colormap;
    }


    for (file = 0; file < ifiles || 0 == ifiles;
	file++, ifiles = (0 == ifiles ? -1 : ifiles)) {

	unsigned char *flags = (unsigned char*)0;
	unsigned char cropping = 0;
	int colorbox_width = 0;
	int colorbox_boxwidth = 0;
	int colorbox_ticwidth = 0;
	int colorbox_height = 0;
	char** colorbox_strings = (char**)0;
	zimg_multiline_t cbox_label;
	zimg_multiline_t legend;
	zimg_escape_info_t escape_info;
#ifdef HAVE_POPEN
	int (*ofp_close)(FILE*) = fclose;
#endif

	if (0 != file) {
	    /* free allocated space */
	    free_z(&z);
	    /* set z default values */
	    init_z(&z);
	    /* parse arguments of .zimgrc or ~/.zimgrc */
	    readcmdln(Argc, Argv, &z, (int*)0, (char***)0);
	    /* read in commandline arguments */
	    readcmdln(argc, argv, &z, (int*)0, (char***)0);
	}

	if (TRUE == verbose && ifiles) {
	    fprintf (stderr, "zimg: %s\n", iname[file]);
	}

#ifdef HAVE_REGEX_H
	if (ifiles) {
	    for (i = 0; i < z.noptions; i++) {
		if (!regexec(&(z.options[i].preg), iname[file],
			    0, (regmatch_t*)0, 0)) {
		    parse_switches(&z, z.options[i].switches);
		}
	    }
	}
#endif

	/* open input file */
	z.ifp = varopen(ifiles ? iname[file] : (char*)0,
	    z.inputformat == ASCII_FORMAT ? "r" : "rb"
#ifdef HAVE_POPEN
	    , z.filter
#endif
	    );

	/* if no dimensions are given via 
	 * commandline, read them from file.  */
	im = (gdImagePtr)0;
	if (z.data.len == 0)
	    im = fgets_dimension(&z);

	if (0 == z.data.x || 0 == z.data.y) {
	    fprintf(stderr, "WARNING: '%s' has zero size\n", (ifiles ? iname[file] : "<stdin>"));
	    continue;
	}

#ifdef ENABLE_PNG_AS_SOURCE
	if (im) {
	    /* 'data' source is a png image */
	    varclose(z.ifp);
	    z.data.x = im->sx;
	    z.data.y = im->sy;
	    z.data.len = z.data.x * z.data.y;
	    data = (float*)0;
	    if (z.dump_colormap) {
		dumped = 1;
		printf("# zimg colormap\n");
		if (iname[file]) {
		    printf("# %s\n", iname[file]);
		}
		for (i = 0; i < im->colorsTotal; i++) {
		    zimg_dump_color((gdImagePtr)0,
			im->red[i], im->green[i], im->blue[i]);
		}
		gdImageDestroy(im);
		/* if dump_colormap was selected, no further
		 * processing is done */
		continue;
	    } else if (z.color) {
		/* create a copy with a new colormap */
		gdImagePtr newim = gdImageCreate(z.data.x, z.data.y);
		entries = getGdColorMap(newim, gdcolor, z.color,
		    z.rgbformulae, z.colormapfile, &z.xor_color);
		for (y = 0; y < z.data.y; y++) {
		    for (x = 0; x < z.data.x; x++) {
			gdImageSetPixel(newim, x, y, gdImageGetPixel(im, x, y));
		    }
		}
		gdImageDestroy(im);
		im = newim;
	    }
	    goto image_created;
	} else if (z.dump_colormap) {
	    continue;
	}
#endif

	/* allocate memory and read data */
	data = (float*)malloc(sizeof (float) * z.data.len);
	items = readfile(&z, data); /* read input file */

	varclose(z.ifp);


	if (items < z.data.len) {
	    char msg[0xff];
	    sprintf(msg, "bad defined dimensions. read %d items (should be %d)",
		items, z.data.len);
	    Fatal(msg);
	}

	/* eventually guess nda value */
	if (z.nda_color.set) {

	    if (!z.nda_specified) {

		/* guess NDA value from the border:
		 * count the number of occurences of each border value. The NDA
		 * value will be set to the value with the highest count, i.e.
		 * the value which occurs most often at the border */

		int end;
		int other[2];

		typedef struct counter_t {
		    struct counter_t* next;
		    double value;
		    int count;
		} counter_t;

#define INSERT_COUNTER(val) \
    do { \
	counter_t* new = (counter_t*)malloc(sizeof (counter_t)); \
	assert(new); \
	new->next = (counter_t*)0; \
	new->value = val; \
	new->count = 1; \
	last->next = new; \
	last = new; \
    } while (0)

		counter_t start;
		counter_t* ptr;
		counter_t* last;
		counter_t* max_counter = (counter_t*)0;

		start.count = 0;
		start.value = *data;
		start.next = (counter_t*)0;
		last = &start;

		/* left and right column, omit top and bottom pixels,
		 * as they're counted when evaluating the top and
		 * bottom row (see below) */
		other[0] = 0;
		other[1] = z.data.x - 1;
		for (i = 0; i < 2; i++) {
		    for (y = 1, end = z.data.y - 1; y < end; y++) {

			double val = DATA(other[i], y);
			unsigned char found = 0;
			for (ptr = &start; ptr; ptr = ptr->next) {
			    if (ptr->value == val) {
				ptr->count++;
				found = 1;
				break;
			    }
			}
			if (!found) {
			    INSERT_COUNTER(val);
			}
		    }
		}

		/* top and bottom row */
		other[0] = 0;
		other[1] = z.data.y - 1;
		for (i = 0; i < 2; i++) {
		    for (x = 0, end = z.data.x; x < end; x++) {

			double val = DATA(x, other[i]);
			unsigned char found = 0;
			for (ptr = &start; ptr; ptr = ptr->next) {
			    if (ptr->value == val) {
				ptr->count++;
				found = 1;
				break;
			    }
			}
			if (!found) {
			    INSERT_COUNTER(val);
			}
		    }
		}

		max_counter = &start;
		for (ptr = &start; ptr; ptr = ptr->next) {
		    if (ptr->count > max_counter->count) {
			max_counter = ptr;
		    }
		}

		if (z.nda_thres < 0 ||
			max_counter->count > (z.nda_thres * (double)((2 * z.data.x) + (2 * (z.data.y - 1))))) {
		    z.nda = max_counter->value;
		} else {
		    z.nda_color.set = 0; /* disable nda */
		}

		/* free counters */
		for (ptr = start.next; ptr; /* empty */) {
		    counter_t* next = ptr->next;
		    free(ptr);
		    ptr = next;
	    }
	}
	} /* if (z.nda_color.set) */

	if (z.data.xright == 0)
	    z.data.xright = z.data.x;
	if (z.data.ybottom == 0)
	    z.data.ybottom = z.data.y;

	if (z.data.xleft < 0)
	    z.data.xleft = 0;
	if (z.data.xright > z.data.x)
	    z.data.xright = z.data.x;
	if (z.data.ytop < 0)
	    z.data.ytop = 0;
	if (z.data.ybottom > z.data.y)
	    z.data.ybottom = z.data.y;

	if (z.data.xleft != 0 || z.data.xright != z.data.x || z.data.ytop != 0
	       	|| z.data.ybottom != z.data.y || z.data.autocrop) {

	    cropping = 1;

	    if (z.data.autocrop) {

		float topleft     = DATA(0, 0);
		float topright    = DATA(z.data.x - 1, 0);
		float bottomleft  = DATA(0, z.data.y - 1);
		float bottomright = DATA(z.data.x - 1, z.data.y - 1);

		float* ptr;
		float* end = data + z.data.len;

		/* cropping from top */
		z.data.ytop = 0;
		if (topleft == topright) {
		    float val = topleft;
		    unsigned char found = 0;
		    for (ptr = data, y = 0; y < z.data.y && !found; y++) {
			for (x = 0; x < z.data.x; x++, ptr++) {
			    if (*ptr != val) {
				found = 1;
				break;
			    }
			}
		    }
		    z.data.ytop = y;
		}

		/* cropping from bottom */
		if (bottomleft == bottomright) {
		    float val = bottomleft;
		    unsigned char found = 0;
		    for (ptr = end - 1, y = z.data.y - 1; y >= 0 && !found; y--) {
			for (x = 0; x < z.data.x; x++, ptr--) {
			    if (*ptr != val) {
				found = 1;
				break;
			    }
			}
		    }
		    z.data.ybottom = y;
		}

		/* cropping from left */
		if (bottomleft == topleft) {
		    float val = bottomleft;
		    unsigned char found = 0;
		    for (x = 0; x < z.data.x && !found; x++) {
			for (ptr = data + x; ptr < end; ptr += z.data.x) {
			    if (*ptr != val) {
				found = 1;
				break;
			    }
			}
		    }
		    z.data.xleft = x;
		}

		/* cropping from right */
		if (bottomright == topright) {
		    float val = bottomright;
		    unsigned char found = 0;
		    for (x = z.data.x - 1; x >= 0 && !found; x--) {
			for (ptr = data + x; ptr < end; ptr += z.data.x) {
			    if (*ptr != val) {
				found = 1;
				break;
			    }
			}
		    }
		    z.data.xright = x;
		}

	    } else {
		if (z.data.xleft >= z.data.xright) {
		    unsigned int tmp = z.data.xleft;
		    z.data.xleft = z.data.xright;
		    z.data.xright = tmp;
		} else if (z.data.ytop >= z.data.ybottom) {
		    unsigned int tmp = z.data.ytop;
		    z.data.ytop = z.data.ybottom;
		    z.data.ybottom = tmp;
		}
	    }
	}

	z.ximg = (int)floor((double)((z.data.xright - z.data.xleft)) / (double)z.data.xibin);
	z.yimg = (int)floor((double)((z.data.ybottom - z.data.ytop)) / (double)z.data.yibin);

	/* raw target image dimensions z.ximg, z.yimg are calculated now */

	/* first pass: integer size operations 'bin' / 'crop' */
	if (z.data.xibin > 1 || z.data.yibin > 1 || cropping) {

	    unsigned int imagelen = z.ximg * z.yimg;

	    float* newdata = (float*)malloc(sizeof (float) * imagelen);
	    float* newdata_ptr = newdata;
	    unsigned char* flags_ptr = (unsigned char*)0;

	    if (!newdata) {
		perror("zimg->newdata");
		exit(2);
	    }

	    if (z.nda_color.set) {
		flags = (unsigned char*)malloc(sizeof (unsigned char) * imagelen);
		flags_ptr = flags;
		if (!flags) {
		    perror("zimg->flags");
		    exit(2);
		}
	    }

	    for (y = 0; y < z.yimg; y++) {
		for (x = 0; x < z.ximg; x++) {
		    getValueCroppedBinned(newdata_ptr++, flags_ptr, data, &z.data, x, y, z.nda);
		    if (flags_ptr) {
			flags_ptr++;
		    }
		}
	    }

	    free(data);
	    data = newdata;

	    z.data.x = z.ximg;
	    z.data.y = z.yimg;
	    z.data.len = z.data.x * z.data.y;

	} else if (z.nda_color.set) {
	    /* build nda mask for unbinned & uncropped values */

	    float* ptr;
	    float* end;
	    unsigned char* flagptr;
	    flags = (unsigned char*)malloc(sizeof (unsigned char) * z.data.len);

	    if (!flags) {
		perror("zimg->flags");
		exit(2);
	    }

	    /* create mask */
	    for (ptr = data, end = ptr + z.data.len, flagptr = flags; ptr < end; ptr++, flagptr++) {
		*flagptr = ((*ptr == z.nda) ? 1 : 0);
	    }
	}

	if (z.data.xdscale != 1) {
	    double dtmp = rint((double)z.ximg * z.data.xdscale);
	    z.data.xdscale = dtmp / z.ximg;
	    z.ximg = dtmp;
	}

	if (z.data.ydscale != 1) {
	    double dtmp = rint((double)z.yimg * z.data.ydscale);
	    z.data.ydscale = dtmp / z.yimg;
	    z.yimg = dtmp;
	}

	if (z.align[0]) {
	    int tmp = (int)ceil((double)z.ximg / (double)z.align[0]) * (double)z.align[0];
	    xpad = (tmp - z.ximg);
#if 0
	    z.ximg = tmp;
#endif
	} else {
	    xpad = 0;
	}

	if (z.align[1]) {
	    int tmp = (int)ceil((double)z.yimg / (double)z.align[1]) * (double)z.align[1];
	    ypad = (tmp - z.yimg);
#if 0
	    z.yimg = tmp;
#endif
	} else {
	    ypad = 0;
	}

	/* get font */
	if (z.legend || z.label || z.colorbox.show) {

	    if (FONT_UNDEFINED != z.font) {
		switch (z.font) {
		    case FONT_GIANT:
			font = gdFontGiant;
			break;
		    case FONT_LARGE:
			font = gdFontLarge;
			break;
		    case FONT_SMALL:
			font = gdFontSmall;
			break;
		    case FONT_TINY:
			font = gdFontTiny;
			break;
		    default:
			/* ignore */
			break;
		}
	    }

	    if (!font) {
		/* TODO:
		 * selectable font */
		font = gdFontTiny;
		if (z.ximg > 300)
		    font = gdFontSmall;
		if (z.ximg > 600)
		    font = gdFontLarge;
		if (z.ximg > 900)
		    font = gdFontGiant;
	    }
	}

	ximg = z.ximg + xpad;
	yimg = z.yimg + ypad;

	for (i = 0; i < z.transform_valid; i++) {
	    switch (z.transform[i].type) {
		case differentiate_TT:
		    if (debug) {
			fprintf(stderr, "differentiating ...");
			fflush(stderr);
		    }
		    differentiate(data, z.data.x, z.data.y);
		    break;
		case curvature_TT:
		    if (debug) {
			fprintf(stderr, "curvature ...");
			fflush(stderr);
		    }
		    curvature(data, z.data.x, z.data.y);
		    break;
		case smooth_TT:
		    if (debug) {
			fprintf(stderr, "smoothing ...");
			fflush(stderr);
		    }
		    smooth(data, z.data.x, z.data.y, z.transform[i].p1 /* sigma */);
		    break;
		case logarithmic_TT:
		    {
			float* ptr;
			float* end;

			if (debug) {
			    fprintf(stderr, "taking the logarithm ...");
			    fflush(stderr);
			}

			integral = minmax(data, flags, z.data.len, &data_min, &data_max); /* get min/max */

			/* scale to 0 -- z.logarithmic */
			fact = (float)z.transform[i].p1 / (data_max - data_min);

			for (ptr = data, end = data + z.data.len; ptr < end; ptr++) {
			    *ptr = log1p((double)((*ptr - data_min) * fact));
			}

			data_max = log1p((double) z.transform[i].p1);
			data_min = 0.0; /* == log1p (0.0) */
			if (TRUE == verbose) {
			    fprintf(stderr, "zimg: data_min=%f\n", data_min);
			    fprintf(stderr, "zimg: data_max=%f\n", data_max);
			}
		    }
		    break;
		case fabs_TT:
		    {
			float* ptr;
			float* end;

			if (debug) {
			    fprintf(stderr, "taking the absolute value (fabs) ...");
			    fflush(stderr);
			}

			for (ptr = data, end = data + z.data.len; ptr < end; ptr++) {
			    *ptr = fabs(*ptr);
			}
		    }
		    break;
		case absolute_TT:
		case absolute_min_TT:
		case absolute_max_TT:
		    {
			if (debug) {
			    fprintf(stderr, "absolute scaling ...");
			    fflush(stderr);
			}
			integral = minmax(data, flags, z.data.len, &data_min, &data_max); /* get min/max */
			/* Overwrite 'data_min' and 'data_max'
			 * data values over  'data_max' are set to 'data_max' and
			 * data values below 'data_min' are set to 'data_min'.*/
			if (absolute_max_TT != z.transform[i].type)
			    data_min = (float)z.transform[i].p1; /* abs min */
			if (absolute_min_TT != z.transform[i].type)
			    data_max = (float)z.transform[i].p2; /* abs max */
			torange(data, (int)(z.data.len), data_min, data_max);
		    }
		    break;
		case relative_TT:
		case relative_min_TT:
		case relative_max_TT:
		    {
			if (debug) {
			    fprintf(stderr, "relative scaling ...");
			    fflush(stderr);
			}
			integral = minmax(data, flags, z.data.len, &data_min, &data_max); /* get min/max */
			/* Overwrite 'data_min' and 'data_max'
			 * data values over  'data_max' are set to 'data_max' and
			 * data values below 'data_min' are set to 'data_min'.*/
			/* TODO: check this */
			if (relative_max_TT != z.transform[i].type)
			    data_min = (data_min * (1. - z.transform[i].p1)) + (data_max * z.transform[i].p1);
			if (relative_min_TT != z.transform[i].type)
			    data_max = (data_min * (1. - z.transform[i].p2)) + (data_max * z.transform[i].p2);
			torange(data, (int)(z.data.len), data_min, data_max);
		    }
		    break;
		default:
		    fprintf(stderr, "%s:%d ERROR", __FILE__, __LINE__);
		    exit(1);
		    break;
	    }
	    if (debug) {
		fprintf(stderr, "done.\n");
	    }
	}

#if defined (HAVE_DLSYM) || (defined HAVE_SHL_LOAD)
	if (zimg_expression) {
	    float* data_ptr = data;
	    float rez_cen_x = 1.0 / ((float)(z.data.x - 1) * 0.5);
	    float rez_cen_y = 1.0 / ((float)(z.data.y - 1) * 0.5);
	    info.width = z.data.x;
	    info.height = z.data.y;
	    for (y = 0; y < z.data.y; y++) {
		for (x = 0; x < z.data.x; x++, data_ptr++) {
		    *data_ptr = zimg_expression(x, y,
			    (((float)x) * rez_cen_x) - 1.0,
			    (((float)y) * rez_cen_y) - 1.0,
			    *data_ptr, &info);
		}
	    }
	}
#endif
	/* min and max from the image: */
	integral = minmax(data, flags, z.data.len, &data_min, &data_max);
	/* min and max color range forced by command line */
	if (z.crange.setMin)
	    data_min = z.crange.theMin;
	if (z.crange.setMax)
	    data_max = z.crange.theMax;

	if (z.statistics) 
	    statistics(data, flags, z.data.x, z.data.y, data_min, data_max, z.statistics);

	/* XXX data processing is finished here XXX */
	escape_info.filename = ifiles ? iname[file] : "<stdin>";
	escape_info.min = data_min;
	escape_info.max = data_max;
	escape_info.integral = integral;

	if (z.colorbox.show) {

	    char tmp[0xff];
	    char* default_fmt_pos = "%-g";
	    char* default_fmt = "%- g";
	    char* fmt;
	    int len;
	    double delta;
	    int maxlen = 0;

	    colorbox_boxwidth = (z.ximg + xpad) * 0.1;
	    colorbox_height = yimg - font->h;
	    if (colorbox_boxwidth < 10)
		colorbox_boxwidth = 10;
	    colorbox_ticwidth = colorbox_boxwidth * 0.2;
	    if (colorbox_ticwidth < 5)
		colorbox_ticwidth = 5;

	    if (z.colorbox.label) {
		/* reserve space for label above colorbox */
		MultilineInit(&cbox_label);
		MultilineGet(&cbox_label, z.colorbox.label, &escape_info);
		colorbox_height -= cbox_label.height * font->h;
	    }

	    if (z.colorbox.levels < 0) {
		/* calculate a reasonable number of levels automatically */
		z.colorbox.levels = colorbox_height / (2 * font->h);
		if (z.colorbox.levels < 2)
		    z.colorbox.levels = 2;
	    }

	    delta = (data_max - data_min) / (float)(z.colorbox.levels - 1);

	    colorbox_strings = (char**)malloc(sizeof (char*) * z.colorbox.levels);
	    assert(colorbox_strings);

	    if (z.colorbox.fmt)
		fmt = z.colorbox.fmt;
	    else if (data_min > 0)
		fmt = default_fmt_pos;
	    else
		fmt = default_fmt;

	    for (i = 0; i < z.colorbox.levels; i++) {
		sprintf(tmp, fmt, data_min + ((float)i) * delta);
		colorbox_strings[i] = strdup(tmp);
		assert(colorbox_strings[i]);
		if ((len = strlen(tmp)) > maxlen)
		    maxlen = len;
	    }

	    colorbox_width = colorbox_boxwidth + colorbox_ticwidth + ((maxlen + 2) * font->w);

	    if (z.colorbox.label) {
	       	int label_width = (cbox_label.width + 2) * font->w;
		if (label_width > colorbox_width)
		    colorbox_width = label_width;
	    }

	    ximg += colorbox_width;
	}

	/* maximal width of legend */
	if (z.legend && font) {

	    float ratio_legend_right;
	    float ratio_legend_bottom;
	    int legend_width;
	    int legend_height;

	    MultilineInit(&legend);
	    MultilineGet(&legend, z.legend, &escape_info);

	    legend_width = font->w * (1 + legend.width);
	    legend_height = (legend.height) * font->h;

	    ratio_legend_right  = (float)(ximg + legend_width) / (float)(yimg < legend_height ? legend_height : yimg);
	    ratio_legend_bottom = (float)(yimg + legend_height) / (float)(ximg < legend_width ? legend_width : ximg);

	    if (ratio_legend_right < ratio_legend_bottom) {
		/* place the legend at the right */
		if (yimg < legend_height)
		    yimg = legend_height;
		legend.x = ximg + 0.5 * font->w;
		legend.y = 0;
		ximg += legend_width;
	    } else {
		/* place the legend below the image */
		if (ximg < legend_width)
		    ximg = legend_width;
		legend.x = 0.5 * font->w;
		legend.y = yimg;
		yimg += legend_height;
	    }
	}

	/* allocate gd colors. */
	im = gdImageCreate(ximg, yimg);

	entries = getGdColorMap(im, gdcolor, z.color,
	    z.rgbformulae, z.colormapfile, &z.xor_color);
	entries_ = entries - 1;

	fact = (float) (entries) / (data_max - data_min);

	if (debug == TRUE) 
	    fprintf (stderr, "\n fact = %f == %d / (%f - %f)\n", fact, entries, data_max, data_min);


	/* eventually allocate nda color */
	if (z.nda_color.set) {
	    nda_color = zimg_gdImageLineColorAllocate(im,
		    z.nda_color.red, z.nda_color.green, z.nda_color.blue);
	} else {
	    /* nda_color is also used, if align is non-zero
	     * and z.bordercolor.set is NOT set.
	     */
	    nda_color = zimg_gdImageLineColorAllocate(im, 0xff, 0xff, 0xff); /* white */
	}

	/* white color for colorbox / legend background */
	if (z.legend || z.colorbox.show) {
	    int white = zimg_gdImageLineColorAllocate(im, 0xff, 0xff, 0xff);
	    if (z.legend)
		gdImageFilledRectangle(im, 0, 0, ximg - 1, yimg - 1, white);
	    else /* z.colorbox.show */
		gdImageFilledRectangle(im, ximg - colorbox_width, 0, ximg - 1, yimg - 1, white);
	}

	/* drawing the colorbox */
	if (z.colorbox.show) {

	    /* draw the colored box itself */
	    float value;
	    int ivalue;
	    int pixel;
	    int sep = colorbox_boxwidth * 0.2;
	    unsigned int x_beg = z.ximg + sep;
	    unsigned int x_end = x_beg + colorbox_boxwidth - sep;
	    unsigned int x_text;
	    float delta = (float)(entries) / (float)(colorbox_height);
	    int black = zimg_gdImageLineColorAllocate(im, 0, 0, 0);
	    int font_h2 = (int)ceil((float)font->h * 0.5);
	    int ystart = font_h2 + colorbox_height;

	    if (z.colorbox.label)
		ystart += cbox_label.height * font->h;
#if 0
	    fprintf(stderr, "(main) font->h=%d\n", font->h);
	    fprintf(stderr, "(main) font_h2=%d\n", font_h2);
#endif

	    for (i = 0, y = ystart, value = 0;
		    i < colorbox_height; i++, y--, value += delta) {
		ivalue = (int)floor(value);
		pixel = gdcolor[ivalue];
		gdImageLine(im, x_beg, y, x_end, y, pixel);
		/* fprintf(stderr, "(main) y = %d\n", y); */
	    }

	    /* placing tics and strings */
	    delta = (float)(colorbox_height - 1) / (float)(z.colorbox.levels - 1);
	    sep = 2;
	    x_beg = x_end + sep;
	    x_end = x_beg + colorbox_ticwidth - sep;
	    x_text = x_end + font->w * 1.5; /* we've allocated (maxlen + 2), see above */

	    for (i = 0; i < z.colorbox.levels; i++) {
		y = (int)rint((float)ystart - (float)i * delta);
		gdImageLine(im, x_beg, y, x_end, y, black); /* tic */
		gdImageString(im, font, x_text, y - font_h2, colorbox_strings[i], black);
		/* fprintf(stderr, "(main) y = %d\n", y); */
	    }

	    /* freeing the colorbox strings */
	    for (i = 0; i < z.colorbox.levels; i++) {
		free(colorbox_strings[i]);
	    }
	    free(colorbox_strings);

	    /* place label? */
	    if (z.colorbox.label) {
		cbox_label.x = z.ximg + font->w;
		cbox_label.y = 0;
		MultilinePutText(im, font, &cbox_label, black);
		MultilineFree(&cbox_label);
	    }
	}

	if (z.align[0] || z.align[1]) {

	    int bordercolor = 0;

	    if (!z.bordercolor.set) {

		/* determine the border color */

		int idx;
		int max_frequency = 0;
		int x_ = z.data.x - 1;
		unsigned int frequency[0x100];
		int value;

		for (idx = 0; idx < 0x100; idx++)
		    frequency[idx] = 0;

#define UPDATE_FREQUENCY                                  \
		do { \
		    if (flags && !flags[idx]) { \
			value = (int)((data[idx] - data_min) * fact); \
			if (value >= 0 && value < 0x100)          \
			    frequency[value] ++; \
		    } \
		} while (0)

		/* top row (w/o left and rightmost pixel) */
		for (idx = 1; idx < x_; idx++) {
		    UPDATE_FREQUENCY;
		}

		/* left column */
		for (idx = 0; idx < z.data.len; idx += z.data.x) {
		    UPDATE_FREQUENCY;
		}

		/* right column */
		for (idx = x_; idx < z.data.len; idx += z.data.x) {
		    UPDATE_FREQUENCY;
		}

		/* bottom row (w/o left and rightmost pixel) */
		for (idx = 1; idx < x_; idx++) {
		    UPDATE_FREQUENCY;
		}

		for (idx = 0; idx < 0x100; idx++) {
		    if (frequency[idx] > max_frequency) {
			bordercolor = idx;
			max_frequency = frequency[idx];
		    }
		}

		if (0 == max_frequency) {
		    /* all border pixels were nda */
		    bordercolor = nda_color;
		}

	    } else {
		bordercolor = zimg_gdImageLineColorAllocate(im,
			z.bordercolor.red, z.bordercolor.green,
		       	z.bordercolor.blue);
	    }

	    if (debug) {
		fprintf(stderr, "using bordercolor = %d\n", bordercolor);
	    }
#if 0
	    /* fill with the border color */
	    for (yimg = 0; yimg < yend; yimg++) {
		for (ximg = 0; ximg < xend; ximg++) {
		    gdImageSetPixel(im, ximg, yimg, bordercolor);
		}
	    }
#else
	    gdImageFilledRectangle(im, 0, 0, z.ximg + xpad - 1, yimg - 1, bordercolor);
#endif
	}


	/* write the gd image region (NOT the border).  */

	if (!z.contour.background) {

	    unsigned int ximg, yimg;

	    if (z.data.xdscale == 1 && z.data.ydscale == 1) {

		float* data_ptr = data;
		unsigned char* flags_ptr = flags;

		for (y = 0, yimg = ypad / 2; y < z.yimg; y++, yimg++) {
		    for (x = 0, ximg = xpad / 2; x < z.ximg; x++, ximg++) {

			if (flags_ptr && *flags_ptr++) {
			    /* not valid (nda / masked) */
			    pixel = nda_color;
			} else {
			    COLOR_TO_PIXEL(*data_ptr);
			}

			gdImageSetPixel(im, ximg, yimg, pixel);

			data_ptr++;
		    }
		}
	    } else {

		/* scaled image (option -S) */

		float dval;
		for (y = 0, yimg = ypad / 2; y < z.yimg; y++, yimg++) {
		    for (x = 0, ximg = xpad / 2; x < z.ximg; x++, ximg++) {

			if (getValueScaled(&dval, data, flags, &z.data, x, y)) {
			    /* not valid (nda / masked) */
			    pixel = nda_color;
			} else {
			    COLOR_TO_PIXEL(dval);
			}

			gdImageSetPixel(im, ximg, yimg, pixel);
		    }
		}
	    }

#if 0
	    int y_max = z.data.ybottom - z.data.yibin + 1;
	    int x_max = z.data.xright - z.data.xibin + 1;
	    int idx;
	    int entries_ = entries - 1;

	    for (yimg = ypad, i = z.data.ytop; i < y_max;
		i += z.data.yibin, yimg += z.data.ydscale) {

		for (ximg = xpad, j = z.data.xleft; j < x_max;
		    j += z.data.xibin, ximg += z.data.xdscale) {

		    dval = 0.0;

		    for (ib = 0; ib < z.data.yibin; ib++)
			for (jb = 0; jb < z.data.xibin; jb++)
			    dval += data[((i + ib) * z.data.x) + j + jb];

		    dval *= rez_bin;
		    if (-1 != nda_color && dval == z.nda) {
			value = nda_color;
		    } else {
			idx = (int)((dval - data_min) * fact);
			if (idx < 0)
			    idx = 0;
			if (idx >= entries_)
			    idx = entries_;
			value = gdcolor[idx];
		    }

		    /*
		    * rely here on a correct
		    * scaling, so I can remove
		    * this check to speed up.
		    *
		    if (value >= entries) {
		    value = entries - 1;
		    } else if (value < 0) {
		    value = 0;
		    }
		    */

		    xend = ximg + z.data.xdscale;
		    yend = yimg + z.data.ydscale;

		    for (y = yimg; y < yend; y++) {
			for (x = ximg; x < xend; x++) {
			    gdImageSetPixel(im, x, y, value);
			}
		    }
		}
	    }
#endif

	} else {
	    /* fill background */
	    int contourcolor = zimg_gdImageLineColorAllocate(im,
		    z.contour.color.red, z.contour.color.green,
		    z.contour.color.blue);
	    for (y = 0; y < z.yimg; y++) {
		for (x = 0; x < z.ximg; x++) {
		    gdImageSetPixel(im, x, y, contourcolor);
		}
	    }
	}

	if (z.contour.levels) {
	    /* TODO: check, if this works with alignment/padding */
	    contours(&z, data, im, entries, data_min, data_max);
	}

	/* data is now written to the image, the plain image is created */

#ifdef ENABLE_PNG_AS_SOURCE
image_created:
#endif

	if (z.label || z.line) {
	    /* int xor = z.color & INVERT_MAP ? 0x00 : 0xff; */
	    if (z.textcolor.set) {
		textcolor = zimg_gdImageLineColorAllocate(im, z.textcolor.red,
			z.textcolor.green, z.textcolor.blue);
	    } else {
		/* try to get a text color with high contrast */
		int c1 = gdImageGetPixel(im, 0     , 0);
		int c2 = gdImageGetPixel(im, 0     , z.ximg);
		int c3 = gdImageGetPixel(im, z.yimg, 0);
		int c4 = gdImageGetPixel(im, z.yimg, z.ximg);
		int color
		    = im->red[c1] + im->green[c1] + im->blue[c1]
		    + im->red[c2] + im->green[c2] + im->blue[c2]
		    + im->red[c3] + im->green[c3] + im->blue[c3]
		    + im->red[c4] + im->green[c4] + im->blue[c4];
		if (color < 2 * 256)
		    /* dark background --> use white as textcolor */
		    textcolor = zimg_gdImageLineColorAllocate(im, 0xff, 0xff, 0xff);
		else
		    /* light background --> use black as textcolor */
		    textcolor = zimg_gdImageLineColorAllocate(im, 0, 0, 0);
	    }
	}

	if (z.legend) {
	    int black = zimg_gdImageLineColorAllocate(im, 0, 0, 0);
	    MultilinePutText(im, font, &legend, black);
	    MultilineFree(&legend);
	}

	if (z.line) {

	    zimg_polyline_t* line;

	    for (line = z.line; line; line = line->next) {

		zimg_vertex_t* vertex = line->vertex;
		unsigned char first = 1;
		int x1 = 0, y1 = 0, x2, y2;

		for (vertex = line->vertex; vertex; vertex = vertex->next) {

		    if (!first && (line->flag & ZIMG_LINE_RELATIVE)) {
			x2 = x1 + vertex->x;
			y2 = y1 + vertex->y;
		    } else {
			if (vertex->x < 0)
			    x2 = z.ximg - vertex->x;
			else
			    x2 = vertex->x;

			if (vertex->y < 0)
			    y2 = z.yimg - vertex->y;
			else
			    y2 = vertex->y;
		    }

		    if (!first)
			gdImageLine(im, x1, y1, x2, y2, textcolor);
		    else
			first = 0;

		    x1 = x2;
		    y1 = y2;
		}
	    }
	}

	if (z.label) {

	    zimg_label_t* current;
	    zimg_multiline_t label;

	    MultilineInit(&label);

	    for (current = z.label; current; current = current->next) {

		int width;
		int height;

		MultilineGet(&label, current->text, &escape_info);
		label.x = current->x;
		label.y = current->y;

		/* horizontal text */
		width = label.width * font->w;
		height = label.height * font->h;

		if (current->flag & ZIMG_VERTICAL) {
		    /* swap width and height */
		    int tmp = width;
		    width = height;
		    height = tmp;
		}

		/* if label.x or label.y are positive, do NOT make any
		 * check, if the text will be entirely on the image */

		if (label.x < 0) {
		    if (width >= z.ximg)
			label.x = 0; /* width of label is larger than width of image */
		    else
			label.x = z.ximg - width + label.x;
		}

		if (current->flag & ZIMG_VERTICAL) {
		    if (label.y < 0) {
			if (height >= z.yimg)
			    label.y = z.yimg - 1; /* height of label is larger than height of image */
			else
			    label.y += z.yimg;
		    }
		    MultilinePutTextVertical(im, font, &label, textcolor);
		} else {
		    if (label.y < 0) {
			if (height >= z.yimg)
			    label.y = 0; /* height of label is larger than height of image */
			else
			    label.y += z.yimg - height;
		    }
		    MultilinePutText(im, font, &label, textcolor);
		}

		MultilineFree(&label);
	    }
	}

	if (z.interlace)
	    gdImageInterlace(im, 1);

	if (ifiles > 1 && strcmp(z.oname,"-")) {
	    /* TODO: this is not tested */
	    /* multiple files are given --> z.oname is a directory */
	    int len = (*z.oname ? strlen(z.oname) : 0) + strlen(iname[file]) + 7;
	    char* oname = (char*) malloc(len);
	    assert(oname);
	    if (*z.oname) {
		strcpy(oname, z.oname);
		strcat(oname, "/");
		strcat(oname, iname[file]);
	    } else {
		strcpy(oname, iname[file]);
	    }
	    /* append ".gif", ".png", ".jpg", ".ppm" or ".pgm" to the filename */
	    switch (z.imformat){
		case IMFORMAT_PPM: strcat(oname, ".ppm"); break;
		case IMFORMAT_PGM: strcat(oname, ".pgm"); break;
		case IMFORMAT_JPG: strcat(oname, ".jpg"); break;
		default:
#ifdef GD_GIF_VERSION
		    strcat(oname, ".gif");
#else
		    strcat(oname, ".png");
#endif
	    }

	    if (!(z.ofp = fopen(oname, "wb")))
		perrorexit(oname);
	    free(oname);
	} else if (*z.oname && strcmp(z.oname, "-")) {
	    /* one input file or stdin --> only one output file */
	    if (!(z.ofp = fopen(z.oname, "wb")))
		perrorexit(z.oname);
	} else {
	    if (!ttyname(fileno(stdout))) {
		z.ofp = stdout;
#if !defined(unix) && !defined(__unix) && !defined(__unix__)
		setmode(fileno(stdout), O_BINARY);
#endif
#ifdef HAVE_POPEN
	    } else {
		/* output is a terminal. The user probably forgot to
		 * redirect the output to a file or a program --> launch
		 * a viewer, e.g. xv - */
		char* viewer = getenv("ZIMG_VIEWER");
		/* NOTE: "wb" fails on linux (popen() returns (FILE*)0) */
		z.ofp = popen((viewer ? viewer : X_VIEWER), "w");
		if (!z.ofp) {
		    /* fallback to stdout */
		    z.ofp = stdout;
#if !defined(unix) && !defined(__unix) && !defined(__unix__)
		    setmode(fileno(stdout), O_BINARY);
#endif
		} else {
		    ofp_close = pclose;
		}
	    }
#endif
	}

	/* Write GD */
	switch (z.imformat) {
	    case IMFORMAT_PPM: zimgGdImagePpm(im, z.ofp); break;
	    case IMFORMAT_PGM: zimgGdImagePgm(im, z.ofp); break;
# ifdef GD_JPEG_VERSION
	    case IMFORMAT_JPG: gdImageJpeg(im, z.ofp, z.jpeg_quality); 
			     break;
# endif
	    default:
#ifdef GD_GIF_VERSION
	gdImageGif(im, z.ofp);
#else
	    gdImagePng(im, z.ofp);
#endif
	}
	gdImageDestroy(im);

	if (z.ofp != stdout) {
#ifdef HAVE_POPEN
	    ofp_close(z.ofp);
#else
	    fclose(z.ofp);
#endif
	}

	if (data)
	    free(data);
	data = (float*)0;
	if (flags)
	    free(flags);
	flags = (unsigned char*)0;
    } /* loop over input files */

#if defined(HAVE_DLSYM) || defined(HAVE_SHL_LOAD)
    if (zimg_expression) {
	dynaload_expression_unload();
    }
    if (objectfile) {
	if (!z.expr_object)
	    unlink(objectfile);
	free(objectfile);
    }
#endif

dump_colormap:
    if (z.dump_colormap
#ifdef ENABLE_PNG_AS_SOURCE
	&& !dumped
#endif
	) {
	/* getGdColorMap() will print the colormap instead
	 * of allocating the colors if it is called with
	 * (gdImagePtr)0 */
	entries = getGdColorMap((gdImagePtr)0, gdcolor, z.color,
	    z.rgbformulae, z.colormapfile, &z.xor_color);
    }

    /* free allocated space */
    free_z(&z);

    exit (0);
}
