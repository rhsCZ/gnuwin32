/* -*- C -*-
 * FILE: "/home/joze/pub/zimg/zimg/path.h"
 * LAST MODIFICATION: "Wed, 02 Jul 2003 21:13:59 CEST (joze)"
 * (C) 2003 by Johannes Zellner, <johannes@zellner.org>
 * $Id: path.h,v 1.2 2003/07/02 19:19:56 joze Exp $
 */

#ifndef path_h_
#define path_h_

char* search_file(const char* filename, const char* subdir, const char* path_prefix, unsigned char absolute);

#endif /* path_h_ */
