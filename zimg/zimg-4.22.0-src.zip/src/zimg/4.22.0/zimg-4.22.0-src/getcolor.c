
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/getcolor.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:12:30 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner <johannes@zellner.org>
    $Id: getcolor.c,v 1.12 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  


/* this code is derived from Petr Mikulik's pm3d patch
 * for gnuplot. The original copyright from Petr is
 * included below:
 */

/*[
 *
 * Petr Mikulik, December 1998 -- June 1999
 * Copyright: open source as much as possible
 *
 ]*/

#ifdef HAVE_CONFIG_H
#   include "config.h"
#endif

#include "zimg_priv.h"
#include <math.h>
#ifndef M_PI
#   include <float.h>
#   ifndef M_PI
#       define M_PI 3.14159265358979323846
#   endif
#endif


static const double DEG2RAD = (M_PI / 180.0);

double
GetColorValueFromFormula(int formula, double x /* gray */)
{
    /* the input gray x is supposed to be in interval [0,1] */
    if (formula < 0) { /* negate the value for negative formula */
	x = 1 - x;
	formula = -formula;
    }
    switch (formula) {
	case 0:
	    return 0;
	case 1:
	    return 0.5;
	case 2:
	    return 1;
	case 3:
	    /* x = x */ 
	    break;
	case 4:
	    x = x * x; 
	    break;
	case 5:
	    x = x * x * x; 
	    break;
	case 6:
	    x = x * x * x * x; 
	    break;
	case 7:
	    x = sqrt(x); 
	    break;
	case 8:
	    x = sqrt(sqrt(x)); 
	    break;
	case 9:
	    x = sin(90 * x * DEG2RAD); 
	    break;
	case 10:
	    x = cos(90 * x * DEG2RAD); 
	    break;
	case 11:
	    x = fabs(x - 0.5); 
	    break;
	case 12:
	    x = (2 * x - 1) * (2.0 * x - 1); 
	    break;
	case 13:
	    x = sin(180 * x * DEG2RAD); 
	    break;
	case 14:
	    x = fabs(cos(180 * x * DEG2RAD)); 
	    break;
	case 15:
	    x = sin(360 * x * DEG2RAD); 
	    break;
	case 16:
	    x = cos(360 * x * DEG2RAD); 
	    break;
	case 17:
	    x = fabs(sin(360* x * DEG2RAD)); 
	    break;
	case 18:
	    x = fabs(cos(360* x * DEG2RAD)); 
	    break;
	case 19:
	    x = fabs(sin(720* x * DEG2RAD)); 
	    break;
	case 20:
	    x = fabs(cos(720* x * DEG2RAD)); 
	    break;
	case 21:
	    x = 3 * x; 
	    break;
	case 22:
	    x = 3 * x - 1; 
	    break;
	case 23:
	    x = 3 * x - 2; 
	    break;
	case 24:
	    x = fabs(3 * x - 1); 
	    break;
	case 25:
	    x = fabs(3 * x -2); 
	    break;
	case 26:
	    x = (1.5 * x - 0.5); 
	    break;
	case 27:
	    x = (1.5 * x - 1); 
	    break;
	case 28:
	    x = fabs(1.5 * x - 0.5); 
	    break;
	case 29:
	    x = fabs(1.5 * x - 1); 
	    break;
	case 30:
	    if (x <= 0.25)
		return 0;
	    if (x >= 0.57)
		return 1;
	    x = x / 0.32 - 0.78125; 
	    break;
	case 31:
	    if (x <= 0.42)
		return 0;
	    if (x >= 0.92)
		return 1;
	    x = 2 * x - 0.84; 
	    break;
	case 32:
	    if (x <= 0.42)
		x *= 4;
	    else
		x = (x <= 0.92) ? -2 * x + 1.84 : x / 0.08 - 11.5;
	    break;
	case 33:
	    x = fabs(2 * x - 0.5); 
	    break;
	case 34:
	    x = 2 * x;
	    break;
	case 35:
	    x = 2 * x - 0.5;
	    break;
	case 36:
	    x = 2 * x - 1;
	    break;
	default:
	    Fatal("undefined color formula (can be +-(0 - 36))");
		 
    }
    if (x <= 0)
	return 0;
    if (x >= 1)
	return 1;
    return x;
}
