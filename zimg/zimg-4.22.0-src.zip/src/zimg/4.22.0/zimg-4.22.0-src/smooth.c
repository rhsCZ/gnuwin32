
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/smooth.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:14:12 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: smooth.c,v 1.7 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"

#define SQR(x) ((x) * (x))

int smooth (float *data, int width, int height, float sigma)
{
    int x, xp, xn, width_ = width - 1, corrected = 0;
    
    float frame, frame_sigma;

    float *prev = data;
    float *this = prev + width;
    float *next = this + width;
    float *end = prev + width * height;
    
    for (/* EMPTY */; next < end;
         prev = this, this = next, next += width) {
        
        for (x = 1, xp = 0, xn = 2; x < width_; x++, xp = x - 1, xn = x + 1) {
            
            frame
                = prev[xp] + prev[x] + prev[xn]
                + this[xp] +           this[xn]
                + next[xp] + next[x] + next[xn];
            
            frame *= 0.125; // 1 / 8
            
            frame_sigma
                = SQR (prev[xp] - frame)
                + SQR (prev[x]  - frame)
                + SQR (prev[xn] - frame)
                + SQR (this[xp] - frame)
                + SQR (this[xn] - frame)
                + SQR (next[xp] - frame)
                + SQR (next[x]  - frame)
                + SQR (next[xn] - frame);

            frame_sigma /= 7; // n - 1
            
            frame_sigma = sqrt (frame_sigma);
            
            // fprintf (stderr, "frame, sigma = %f, %f\n", frame, frame_sigma);
            
            /*
            fprintf (stderr, "this[x] * 8 = %f, frame = %f\n",
                     ((float) this[x] * 8), frame);
            */
            
            if (this[x] > frame + (frame_sigma * sigma)) {
                this[x] = frame;
                corrected++;
            }

        }
    }

    if (verbose)
        fprintf (stderr, "    corrected %d pixels.\n", corrected);

    return (OK);
}
