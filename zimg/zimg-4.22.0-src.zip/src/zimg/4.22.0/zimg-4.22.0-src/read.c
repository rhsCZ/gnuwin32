
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/read.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:14:04 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: read.c,v 1.29 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"

int
readfile(zimg_t *z, float *data)
{
    int count = 0;
    /* read ASCII file */
    if (z->inputformat == ASCII_FORMAT)
        count += readascii(z, data);
    /* read BINARY file */
    if (z->inputformat != ASCII_FORMAT)
        count += readbin(z, data);
    return count;
}


/* read ASCII file */
int
readascii(zimg_t *z, float *data) 
{

    char Zeile[BUFSIZ];
    char *args[MAX_ARGS];
    char *ptr = (char*) 0;

    int i;
    int no = 0;
    int nargs;
    unsigned int shift;

    for (i = 0; i < z->skip; i++) /* skip lines */ {
        fgets(Zeile, sizeof (Zeile), z->ifp);
    }

    /*
     * read all columns or selective
     * column data, or check for
     * comment patterns.
     */
    if (z->nn_pattern > 0 || z->column > 1) {

	int* col;
	int column[33];
	int j;
	for (i = 0, j = 0, shift = 1; i < 32; i++, shift <<= 1) {
	    if (shift & z->column) {
		column[j++] = i;
	    }
	}
	column[j] = -1;

        while (no < z->data.len && fgets (Zeile, sizeof (Zeile), z->ifp) != NULL) {

            if (z->nn_pattern > 0) {
                ptr = terminate_if_comment (z, Zeile);
                if (*ptr == '\0') {
		    if (!no) {
			checkmodeline(z, Zeile);
			if (z->inputformat != ASCII_FORMAT) {
			    return 0;
			}
		    }
                    continue;
		}
	    } else if (!no) {
		/* check for modelines only, if no data was read yet. */
		checkmodeline(z, Zeile);
		if (z->inputformat != ASCII_FORMAT) {
		    return 0;
		}
	    }

            nargs = parse (args, sizeof (args), Zeile);

	    if (!(z->nn_pattern) && nargs && '#' == *(args[0])) {
		/* normal '#' comment line */
		continue;
	    }
            
            if (z->column == ALL_COLUMNS) { /* read **all** available columns */
                for (i = 0; i < nargs; i++) {
                    if (sscanf (args[i], "%f", data + no) == 1)
                        no ++;

                }

            } else if (z->column != 1) {

		for (col = column; -1 != *col; col++) {
		    if (*col < nargs && (sscanf (args[*col], "%f", data + no) == 1)) {
			no++;
		    } else {
			break;
		    }
		}
            }
        }

    } else {
	/*
	* fast read version can handle 
	* hash mark as comment at position 0
	* and reads the first column only.
	*/
        while (no < z->data.len && fgets (Zeile, sizeof (Zeile), z->ifp) != NULL) {
	    if (1 == sscanf (Zeile, "%f", data + no)) {
		++no;
	    } else if (!no) {
		/* check for modelines only, if no data was read yet. */
		checkmodeline(z, Zeile);
		if (z->inputformat != ASCII_FORMAT) {
		    return 0;
		}
	    }
            /*
             * formerly, all other cases were considered
             * to be an error. I decided, that it is 
             * smarter just to skip silently these lines.
             */
        }
    }

    return no;
}


/*
 * compare with all patterns
 */
char*
terminate_if_comment(zimg_t *z, char *Zeile)
{

    int i;
    char *ptr;
    char *ptr2;

    ptr = shiftleftline (Zeile);

    for (i = 0; i < z->nn_pattern; i ++) {
        if ((ptr2 = strstr (ptr, z->pattern[i])) != NULL)
            * ptr2 = '\0'; /* 0 - terminate */
    }

    return (ptr);
}


/* throw away leading white spaces */
char*
shiftleftline(char* Zeile)
{
    char *ptr = Zeile;

    while ((* ptr == ' ' || * ptr == '\t') && * ptr != '\0') 
        ptr ++;


    return ptr;
}




/* read binary file */
int
readbin(zimg_t *z, float *data)
{
    register int b_len = z->b_len;
    unsigned int len = z->data.len * b_len;
    unsigned char *ibuf = (unsigned char*) 0;
    unsigned char *sbuf = (unsigned char*) 0;

    register unsigned char *ptr, *end;

    if (!(ibuf = sbuf = (unsigned char *) malloc ((size_t) (len))))
	perrorexit ("input buffer");

    if (z->skip >= 0) {


	if (z->skip > 0) {
	    /* skip was specified by the user; don't
	     * use fseek(), so we can skip stdin.
	     * XXX this works only, if the header
	     *     size is smaller than the data size
	     * XXX
	     */
	    if (fread(ibuf, (size_t)1, (size_t)z->skip, z->ifp) != z->skip)
		perrorexit("unable to skip");
	}
	/* read the data part */
	if (fread(ibuf, (size_t)b_len, (size_t)z->data.len, z->ifp) != z->data.len) 
	    perrorexit("file seems to be truncated");
#if 0
	int rd = 0;
	while (rd < len) {
	    rd += read(fileno(z->ifp), ibuf + rd, (size_t)len - rd);
	    fprintf(stderr, "(readbin) rd = %d\n", rd);
	}
#endif

    } else if (UNSET == z->skip) {

	int newsize;
	const int chunk_size = 0xffff;

	/* try to determine automatically how many byte to
	 * skip;  we can read at least the size of the image */
	if (fread(ibuf, (size_t) b_len, (size_t) z->data.len, z->ifp) != z->data.len) 
	    perrorexit("file seems to be truncated");

	/* read the rest in chunks of size `chunk_size' */
	for (newsize = len + chunk_size; 1; newsize += chunk_size) {
	    int bytes;
	    if (!(sbuf = (unsigned char *) realloc(sbuf, (size_t) (newsize))))
		perrorexit("input buffer");
	    bytes = fread(sbuf + newsize - chunk_size,
		(size_t) 1, (size_t) chunk_size, z->ifp);
	    if (chunk_size != bytes /* EOF */) {
		newsize += -chunk_size + bytes;
		ibuf = sbuf + newsize - len;
		break;
	    }
	}
    }

    end = ibuf + len;

    if (z->swap) {
	if (COMPLEX_FLOAT_FORMAT == z->inputformat
	    || COMPLEX_DOUBLE_FORMAT == z->inputformat) {
	    swapbytes(ibuf, b_len / 2, z->data.len * 2);
	} else {
	    swapbytes(ibuf, b_len, z->data.len);
	}
    }

    if (debug)
        fprintf (stderr, "DEBUG> len = %d\n", len);

    /*
     * copy to array
     */
    if (z->inputformat == FLOAT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((float *) ptr);
    }
    else if (z->inputformat == DOUBLE_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((double *) ptr);
    }
    else if (z->inputformat == U_CHAR_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((unsigned char *) ptr);
    }
    else if (z->inputformat == U_SHORT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((unsigned short *) ptr);
    }
    else if (z->inputformat == U_INT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((unsigned int *) ptr);
    }
    else if (z->inputformat == U_L_INT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((unsigned long int *) ptr);
    }
    else if (z->inputformat == CHAR_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((signed char *) ptr);
    }
    else if (z->inputformat == SHORT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((signed short *) ptr);
    }
    else if (z->inputformat == INT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((signed int *) ptr);
    }
    else if (z->inputformat == L_INT_FORMAT) {
        for (ptr = ibuf; ptr < end; ptr += b_len, data++)
            *data = (float) *((signed long int *) ptr);
    }
    else if (z->inputformat == COMPLEX_FLOAT_FORMAT) {
	unsigned int b_len_2 = b_len / 2;
	if (COMPLEX_ACTION_ABS == z->complex_action) {
	    float re, im;
	    for (ptr = ibuf; ptr < end; ptr += b_len_2, data++) {
		re = *((float*) ptr);
		ptr += b_len_2;
		im = *((float*) ptr);
		*data = (float) hypot(re, im);
	    }
	} else if (COMPLEX_ACTION_PHASE == z->complex_action) {
	    float re, im;
	    double pi2 = atan2(1., 1.) * 8.0; /* 2 * PI */
	    for (ptr = ibuf; ptr < end; ptr += b_len_2, data++) {
		re = *((float*) ptr);
		ptr += b_len_2;
		im = *((float*) ptr);
		*data = fmod(atan2(im, re), pi2);
	    }
	} else if (COMPLEX_ACTION_REAL == z->complex_action
	    || COMPLEX_ACTION_IMAG == z->complex_action) {
	    for (ptr = ibuf + (COMPLEX_ACTION_IMAG == z->complex_action ? b_len_2 : 0);
		ptr < end; ptr += b_len, data++)
		*data = (float) *((float*) ptr);
	} else {
	    fprintf(stderr, "%s:%d: this is a potential program error\n", __FILE__, __LINE__);
	    fprintf(stderr, "please report this bug to <johannes@zellner.org>\n");
	    exit(1);
	}
    }
    else if (z->inputformat == COMPLEX_DOUBLE_FORMAT) {
	unsigned int b_len_2 = b_len / 2;
	if (COMPLEX_ACTION_ABS == z->complex_action) {
	    double re, im;
	    for (ptr = ibuf; ptr < end; ptr += b_len_2, data++) {
		re = *((double*) ptr);
		ptr += b_len_2;
		im = *((double*) ptr);
		*data = (float) hypot(re, im);
	    }
	} else if (COMPLEX_ACTION_PHASE == z->complex_action) {
	    double re, im;
	    double pi2 = atan2(1., 1.) * 8.0; /* 2 * PI */
	    for (ptr = ibuf; ptr < end; ptr += b_len_2, data++) {
		re = *((double*) ptr);
		ptr += b_len_2;
		im = *((double*) ptr);
		*data = (float) fmod(atan2(im, re), pi2);
	    }
	} else if (COMPLEX_ACTION_REAL == z->complex_action
	    || COMPLEX_ACTION_IMAG == z->complex_action) {
	    for (ptr = ibuf + (COMPLEX_ACTION_IMAG == z->complex_action ? b_len_2 : 0);
		ptr < end; ptr += b_len, data++)
		*data = (float) *((double*) ptr);
	} else {
	    fprintf(stderr, "%s:%d: this is a potential program error\n", __FILE__, __LINE__);
	    fprintf(stderr, "please report this bug to <johannes@zellner.org>\n");
	    exit(1);
	}
    }
    else
        perrorexit("could not convert input to binary type ..");

    free(sbuf);
    return z->data.len;
}




/* swap whole array */
void
swapbytes(unsigned char *data, int b_len, int len)
{


    unsigned char word[16];

    register unsigned char *ptr = data;
    register unsigned char *end = data + b_len * len;
    register unsigned char *wptr;
    register unsigned char *wend = word + b_len - 1;


    /*
     * loop over all entries
     */
    while (ptr < end) { 

        memcpy (word, ptr, b_len);

        /*
         * loop to swap one entry
         */
        for (wptr = wend; wptr >= word; wptr--, ptr++) { 
            *ptr = *wptr;
        }

    }

    return;
}

#ifdef ENABLE_PNG_AS_SOURCE

typedef struct {
    FILE* fp;
    char* buf;
    int len;
} png_wrapper_t;

static int
create_from_png_read_wrapper(void* context, char* buf, int len)
{
    int bytes = 0;
    png_wrapper_t* png_wrapper = (png_wrapper_t*)context;
    if (png_wrapper->len) {
	/* consume first the bytes which were already read */
	bytes = png_wrapper->len > len ? len : png_wrapper->len;
	png_wrapper->len -= bytes;
	memcpy(buf, png_wrapper->buf, bytes);
	png_wrapper->buf += bytes; /* advance the pointer */
	if (bytes == len)
	    return bytes;
	else
	    bytes += fread(buf + bytes, 1, len - bytes, png_wrapper->fp);
    } else {
	bytes = fread(buf, 1, len, png_wrapper->fp);
    }
    return bytes;
}

static gdImagePtr
create_from_png(zimg_t* z, char* buf, int len)
{
    gdSource s;
    png_wrapper_t png_wrapper;
    s.source = create_from_png_read_wrapper;
    png_wrapper.buf = buf;
    png_wrapper.len = len; /* length of PNG header which is stored in buf */
    png_wrapper.fp = z->ifp;
    s.context = (void*)(&png_wrapper);
    return gdImageCreateFromPngSource(&s);
}
#endif


/*
 * get two numbers if no dimensions 
 * are specified via commandline
 */
gdImagePtr
fgets_dimension(zimg_t *z)
{

    int i, argc, dtmp, found = 0;
    char Zeile[BUFSIZ];
    char* ptr = Zeile;
    int size = sizeof (Zeile);
    char *args[256];
#ifdef ENABLE_EDF
    int edf = FALSE;
    int alternative_file = FALSE;
    char alternative_file_name[0xff];
#endif

#ifdef ENABLE_PNG_AS_SOURCE
    int n = 0;

    if (fread(Zeile +   n, 1, 1, z->ifp) && 0x89 == (unsigned char) Zeile[n] &&
	fread(Zeile + ++n, 1, 1, z->ifp) && 'P'  == Zeile[n] &&
	fread(Zeile + ++n, 1, 1, z->ifp) && 'N'  == Zeile[n] &&
	fread(Zeile + ++n, 1, 1, z->ifp) && 'G'  == Zeile[n] &&
	fread(Zeile + ++n, 1, 1, z->ifp) && 0xd  == Zeile[n]) {
	/* the source is a png file */
	return create_from_png(z, Zeile, 5);
    }
    if (Zeile[n] != '\n' && Zeile[n] != '\r') {
	size -= (n + 1);
	ptr += (n + 1);
    }
#endif

    while ((found < 2
#ifdef ENABLE_EDF
	    || TRUE == edf
#endif
	    ) && fgets(ptr, size, z->ifp)) {

#ifdef ENABLE_PNG_AS_SOURCE
	/* reset the input buffer and size to the
	 * full value for all subsequent cycles */
	if (ptr != Zeile) {
	    ptr = Zeile;
	    size = sizeof (Zeile);
	}
#endif

#ifdef ENABLE_EDF
	if (FALSE == edf) {
	    if (Zeile == strchr(Zeile, '{') ||
		Zeile == strstr(Zeile, "HeaderID") ||
		Zeile == strstr(Zeile, "Image") ||
		Zeile == strstr(Zeile, "ByteOrder") ||
		Zeile == strstr(Zeile, "DataType") ||
		Zeile == strstr(Zeile, "Dim_1") ||
		Zeile == strstr(Zeile, "Dim_2") ||
		Zeile == strstr(Zeile, "Size")) {
		edf = TRUE;
	    }
	}

	if (TRUE == edf) {
	    if (strstr(Zeile, "Dim_1")) {
		char* eq = strchr(Zeile, '=');
		if (!eq) {
		    Fatal(Zeile);
		}
		found += sscanf(eq + 1, "%d", &(z->data.x));
	    } else if (strstr(Zeile, "Dim_2")) {
		char* eq = strchr(Zeile, '=');
		if (!eq) {
		    Fatal(Zeile);
		}
		found += sscanf(eq + 1, "%d", &(z->data.y));
	    } else if (strstr(Zeile, "SIZE1")) {
		char* eq = strchr(Zeile, '=');
		if (!eq) {
		    Fatal(Zeile);
		}
		found += sscanf(eq + 1, "%d", &(z->data.x));
	    } else if (strstr(Zeile, "SIZE2")) {
		char* eq = strchr(Zeile, '=');
		if (!eq) {
		    Fatal(Zeile);
		}
		found += sscanf(eq + 1, "%d", &(z->data.y));
	    } else if (strstr(Zeile, "DataType")) {
		char* eq = strchr(Zeile, '=');
		char datatype[0xff];
		if (!eq) {
		    Fatal(Zeile);
		}
		if (sscanf(eq + 1, "%s", datatype)) {
		    if (!strcmp(datatype, "UnsignedByte")) {
			z->inputformat = U_CHAR_FORMAT;
			z->b_len = sizeof (unsigned char);
		    } else if (!strcmp(datatype, "SignedByte")) {
			z->inputformat = CHAR_FORMAT;
			z->b_len = sizeof (signed char);
		    } else if (!strcmp(datatype, "UnsignedShort")) {
			z->inputformat = U_SHORT_FORMAT;
			z->b_len = sizeof (unsigned short);
		    } else if (!strcmp(datatype, "SignedShort")) {
			z->inputformat = SHORT_FORMAT;
			z->b_len = sizeof (signed short);
		    } else if (!strcmp(datatype, "UnsignedInteger")) {
			z->inputformat = U_INT_FORMAT;
			z->b_len = sizeof (unsigned int);
		    } else if (!strcmp(datatype, "SignedInteger")) {
			z->inputformat = INT_FORMAT;
			z->b_len = sizeof (signed int);
		    } else if (!strcmp(datatype, "UnsignedLong")) {
			z->inputformat = U_L_INT_FORMAT;
			z->b_len = sizeof (unsigned long);
		    } else if (!strcmp(datatype, "SignedLong")) {
			z->inputformat = L_INT_FORMAT;
			z->b_len = sizeof (signed long);
		    } else if (!strcmp(datatype, "FloatValue")) {
			z->inputformat = FLOAT_FORMAT;
			z->b_len = sizeof (float);
		    } else if (!strcmp(datatype, "DoubleValue")) {
			z->inputformat = DOUBLE_FORMAT;
			z->b_len = sizeof (double);
		    } else if (!strcmp(datatype, "ComplexFloat")) {
			z->inputformat = COMPLEX_FLOAT_FORMAT;
			z->b_len = 2 * sizeof (float);
		    } else if (!strcmp(datatype, "ComplexDouble")) {
			z->inputformat = COMPLEX_DOUBLE_FORMAT;
			z->b_len = 2 * sizeof (double);

			/*
			 * other COMPLEX formats not supported yet.
			 * ComplexByte
			 * ComplexShortInteger
			 * ComplexInteger
			 * ComplexLongInteger
			 */
		    }
		}
	    } else if (strstr(Zeile, "TYPE")) {
		char* eq = strchr(Zeile, '=');
		char datatype[0xff];
		if (!eq) {
		    Fatal(Zeile);
		}
		if (sscanf(eq + 1, "%s", datatype)) {
		    if (!strcmp(datatype, "unsigned_byte")) {
			z->inputformat = U_CHAR_FORMAT;
			z->b_len = sizeof (unsigned char);
		    } else if (!strcmp(datatype, "signed_byte")) {
			z->inputformat = CHAR_FORMAT;
			z->b_len = sizeof (signed char);
		    } else if (!strcmp(datatype, "unsigned_short")) {
			z->inputformat = U_SHORT_FORMAT;
			z->b_len = sizeof (unsigned short);
		    } else if (!strcmp(datatype, "signed_short")) {
			z->inputformat = SHORT_FORMAT;
			z->b_len = sizeof (signed short);
		    } else if (!strcmp(datatype, "unsigned_int")) {
			z->inputformat = U_INT_FORMAT;
			z->b_len = sizeof (unsigned int);
		    } else if (!strcmp(datatype, "signed_int")) {
			z->inputformat = INT_FORMAT;
			z->b_len = sizeof (signed int);
		    } else if (!strcmp(datatype, "unsigned_long")) {
			z->inputformat = U_L_INT_FORMAT;
			z->b_len = sizeof (unsigned long);
		    } else if (!strcmp(datatype, "signed_long")) {
			z->inputformat = L_INT_FORMAT;
			z->b_len = sizeof (signed long);
		    } else if (!strcmp(datatype, "float")) {
			z->inputformat = FLOAT_FORMAT;
			z->b_len = sizeof (float);
		    } else if (!strcmp(datatype, "double")) {
			z->inputformat = DOUBLE_FORMAT;
			z->b_len = sizeof (double);
		    }
		}
	    } else if (strstr(Zeile, "ByteOrder")) {
		char* eq = strchr(Zeile, '=');
		char byteorder[0xff];
		if (!eq) {
		    Fatal(Zeile);
		}
		if (sscanf(eq + 1, "%s", byteorder)) {
		    if (!strcmp(byteorder, "HighByteFirst")) {
#ifdef WORDS_BIGENDIAN
			z->swap = FALSE;
#else
			z->swap = TRUE;
#endif
		    } else if (!strcmp(byteorder, "LowByteFirst")) {
#ifdef WORDS_BIGENDIAN
			z->swap = TRUE;
#else
			z->swap = FALSE;
#endif
		    }
		}
	    } else if (strstr(Zeile, "BYTE_ORDER")) {
		char* eq = strchr(Zeile, '=');
		char byteorder[0xff];
		if (!eq) {
		    Fatal(Zeile);
		}
		if (sscanf(eq + 1, "%s", byteorder)) {
		    if (!strcmp(byteorder, "big_endian")) {
#ifdef WORDS_BIGENDIAN
			z->swap = FALSE;
#else
			z->swap = TRUE;
#endif
		    } else if (!strcmp(byteorder, "little_endian")) {
#ifdef WORDS_BIGENDIAN
			z->swap = TRUE;
#else
			z->swap = FALSE;
#endif
		    }
		}
	    /* the following two items are for edh file support
	     * as proposed by Petr Mikulik (21 Mar 2000) */
	    } else if (strstr(Zeile, "EDF_BinaryFilePosition") && UNSET == z->skip) {
		/* the second check (UNSET == z->skip) ensures that the user can
		 * overwrite the EDF_BinaryFilePosition by a command line switch */
		char* eq = strchr(Zeile, '=');
		int itmp;
		if (!eq || !sscanf(eq + 1, "%d", &(itmp))) {
		    Fatal(Zeile);
		}
		if (itmp > 0) {
		    z->skip = itmp;
		}
	    } else if (strstr(Zeile, "EDF_BinaryFileName")) {
		char *eq = strchr(Zeile, '=');
		if (!eq) {
		    Fatal(Zeile);
		}
		if (sscanf(eq + 1, "%s", alternative_file_name)) {
		    alternative_file = TRUE;
		    eq = strchr(Zeile, ';');
		    if (eq) {
			*eq = '\0';
		    }
		} else {
		    Fatal(Zeile);
		}
	    } else if (strchr(Zeile, '}')) {
		edf = FALSE;
	    } else {
		/* allow modelines as comments in the edf header
		 * this would look like this:
		 *
		 * ; zimg:<zimg options>:
		 */
		checkmodeline(z, Zeile);
	    }
	} else {
#endif /* ENABLE_EDF */

	    checkmodeline(z, Zeile);
	    if (z->data.x > 0 && z->data.y > 0) {
		/* dimensions were set in a modeline */
		found = 2;
		break;
	    }
	    argc = parse(args, sizeof(args), Zeile);

	    /* read all convertable values of one line */
	    for (i = 0; i < argc; i ++) {

		if (sscanf(args[i], "%i", &dtmp) == 1) {

		    if (found == 0) {
			z->data.x = dtmp;
			found ++;
		    } else if (found == 1) {
			z->data.y = dtmp;
			found ++;
			break;
		    }
		}
	    }
#ifdef ENABLE_EDF
	}
#endif
    }

    z->data.len = z->data.x * z->data.y;
#ifdef ENABLE_EDF
    if (TRUE == alternative_file) {
	varclose(z->ifp);
	z->ifp = varopen(alternative_file_name,
	    z->inputformat == ASCII_FORMAT ? "r" : "rb"
#ifdef HAVE_POPEN
	    , z->filter
#endif
	    );
    }
#endif
    return (gdImagePtr)0;
}
