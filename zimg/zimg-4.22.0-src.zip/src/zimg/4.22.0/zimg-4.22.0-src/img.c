
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/img.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:13:10 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: img.c,v 1.8 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#include "zimg_priv.h"


/* ========================
 * 2D - differentiate image
 * ========================
 */
void
differentiate(FLOAT* data, unsigned int x, unsigned int y)
{
    int     i, j;
    int     x_ = x - 1;
    int     y_ = y - 1;
    int     len = x * y;
    FLOAT   center;
    FLOAT  *tmp;

    tmp =  (FLOAT *) malloc (sizeof (FLOAT) * len);

    for(i = 0; i < len; i++) 
	*(tmp + i) = 0.0;

    for (i = 1; i < x_; i++) {
	for (j = 1; j < y_; j++) {

	    center = *(data +  (i * y) + j); /* current 'center' pixel */


	    /* --------------------------------
	     * set tmp to the difference to all 
	     * neighbouring pixels
	     * --------------------------------
	     */
	    *(tmp +  (i * y) + j) 
		/* x= 0, y=+1 */
		= fabs (center - *(data +  (i * y) + j + 1))
		/* x= 0, y=-1 */
		+ fabs (center - *(data +  (i * y) + j - 1))

		/* x=+1, y= 0 */
		+ fabs (center - *(data +  ((i + 1) * y) + j))
		/* x=-1, y= 0 */
		+ fabs (center - *(data +  ((i - 1) * y) + j))

		/* x=+1, y=+1 */
		+ fabs (center - *(data +  ((i + 1) * y) + j + 1))
		/* x=+1, y=-1 */
		+ fabs (center - *(data +  ((i + 1) * y) + j - 1))

		/* x=-1, y=+1 */
		+ fabs (center - *(data +  ((i - 1) * y) + j + 1))
		/* x=-1, y=-1 */
		+ fabs (center - *(data +  ((i - 1) * y) + j - 1));

	}
    }


    /* -----------------------
     * edges and corners need
     * some special treatment.
     * first the edges:
     * -----------------------
     */
    for (i = 0; i < x; i++) {
	for (j = 0; j < y; j++) {

	    if (i == 0) 
		*(tmp +  (i * y) + j) = *(tmp +  ((i + 1) * y) + j); 
	    if (i == x) 
		*(tmp +  (i * y) + j) = *(tmp +  ((i - 1) * y) + j); 

	    if (j == 0) 
		*(tmp +  (i * y) + j) = *(tmp +  (i * y) + j + 1); 
	    if (j == y) 
		*(tmp +  (i * y) + j) = *(tmp +  (i * y) + j - 1); 

	}
    }


    /* -------
     * corners
     * -------
     */
    *(tmp) = *(tmp + 1);
    *(tmp + y - 1) = *(tmp + y - 2);
    *(tmp +  ((x_) * y)) = *(tmp +  (x_) * y_); 
    *(tmp +  ((x_) * y) + y_) = *(tmp +  ((x_) * y) + y - 2);


    /* copy tmp back to data */
    memcpy(data, tmp, sizeof(FLOAT) * len);

    free (tmp);
    return;
}	

/* f(x) curvature for one point
   on a uniform grid */
FLOAT
curvature1d(FLOAT center, FLOAT p1, FLOAT p2)
{
    FLOAT angle1 = atan(p1 - center);
    FLOAT angle2 = atan(p2 - center);

    return angle1 + angle2;
}

/* f(x, y) curvature for one point
   on a uniform grid */
FLOAT
curvature2d(FLOAT center, FLOAT left, FLOAT right, FLOAT top, FLOAT bottom)
{
    return curvature1d(center, left, right) + curvature1d(center, top, bottom);
}

FLOAT*
curvature(FLOAT* data, unsigned int width, unsigned int height)
{
    unsigned int len = width * height;
    unsigned int width_1 = width - 1;
    unsigned int height_1 = height - 1;
    unsigned int width_2 = width - 2;
    unsigned int height_2 = height - 2;
    unsigned int width_3 = width - 3;
    unsigned int height_3 = height - 3;

    unsigned int y, x;

    FLOAT* result = malloc(sizeof(FLOAT) * len);
    FLOAT* ptr = result;
    assert(result);

    for (y = 0; y < height; y++) {
	for (x = 0; x < width; x++, ptr++) {

	    unsigned int cen_x;
	    unsigned int cen_y;
	    unsigned int left;
	    unsigned int right;
	    unsigned int top;
	    unsigned int bottom;

	    if (0 == x) {
		left   = 0;
		cen_x  = 1;
		right  = 2;
	    } else if (width_1 == x) {
		left   = width_3;
		cen_x  = width_2;
		right  = width_1;
	    } else {
		left   = x - 1;
		cen_x  = x;
		right  = x + 1;
	    }

	    if (0 == y) {
		top    = 0;
		cen_y  = 1;
		bottom = 2;
	    } else if (height_1 == y) {
		top    = height_3;
		cen_y  = height_2;
		bottom = height_1;
	    } else {
		top    = y - 1;
		cen_y  = y;
		bottom = y + 1;
	    }

	    *ptr = curvature2d
		(ACCESS2D(cen_x, cen_y, data, width),
		 ACCESS2D(left, cen_y, data, width),
		 ACCESS2D(right, cen_y, data, width),
		 ACCESS2D(cen_x, top, data, width),
		 ACCESS2D(cen_x, bottom, data, width));
	}
    }

    /* copy tmp back to data */
    memcpy(data, result, sizeof(FLOAT) * len);
    free(result);

    return data;
}


void
torange(FLOAT* data, int len, FLOAT low, FLOAT high)
{
    int i;

    for (i = 0; i < len; i++) {
	if (*(data + i) > high)
	    *(data + i) = high;
	if (*(data + i) < low)
	    *(data + i) = low;
    }

    return;
}

