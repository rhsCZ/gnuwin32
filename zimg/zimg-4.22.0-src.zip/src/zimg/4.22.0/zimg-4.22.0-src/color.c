
 /* ==================================================================
    FILE: "/home/joze/pub/zimg/zimg/color.c"
    LAST MODIFIED: "Wed, 02 Jul 2003 21:10:52 CEST (joze)"
    (C) 1999 - 2003 by Johannes Zellner
    johannes@zellner.org
    $Id: color.c,v 1.19 2003/07/02 19:19:56 joze Exp $
    ---
    Copyright (c) 1999 - 2003, Johannes Zellner <johannes@zellner.org>
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    
      * Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.
      * Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
      * Neither the name of Johannes Zellner nor the names of contributors
        to this software may be used to endorse or promote products derived
        from this software without specific prior written permission.
        
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    ================================================================== */  

#ifdef HAVE_CONFIG_H
#   include "config.h"
#endif

#include "zimg_priv.h"
#include "zimg.h"
#include "path.h"

int* get_next_custom_entry (FILE* fp)
{
    static int itmp[3];
    char buf[BUFSIZ];
    while (fgets (buf, sizeof (buf), fp)) {
        if (*buf == '#') {
            /* skip lines which start with a # mark */
	    /* fprintf (stderr, "skipping |%s|\n", buf); */
            continue;
        }
        if (sscanf (buf, "%i%i%i", itmp, itmp + 1, itmp + 2) != 3
            || itmp[0] < 0 || itmp[0] > 0xff
            || itmp[1] < 0 || itmp[1] > 0xff
            || itmp[2] < 0 || itmp[2] > 0xff) {
	    char* ptr;
	    /* check if it's an empty line */
	    for (ptr = buf; ptr && *ptr; ptr++) {
		if (!(' ' == *ptr || '\t' == *ptr || '\n' == *ptr)) {
		    fprintf (stderr, "bad line `%s' in colormap file\n", buf);
		    exit (1);
		}
	    }
	    /* it's an empty line --> read the next line */
	    continue;
        } else {
            return (itmp);
        }
    }
    return ((int *) NULL);
}

int
zimg_dump_color(gdImagePtr im, int r, int g, int b)
{
    printf("%3d %3d %3d\n", r, g, b);
    return 0;
}

static void
invert_colormap(int gdcolor[0x100], int len)
{
    int* tmp;
    int i, j;

    assert(len > 0);

    tmp = (int*)malloc(sizeof (int) * len);

    if (!tmp) {
	perror("invert_colormap->tmp");
	exit(2);
    }
    memcpy(tmp, gdcolor, len * sizeof (int));

    for (i = 0, j = len - 1; j >= 0; i++, j--) {
	gdcolor[i] = tmp[j];
    }

    free(tmp);
}

int
getGdColorMap(gdImagePtr im, int gdcolor[0x100],
    const int color, int rgbformulae[3], char *colormapfile,
    const zimg_color_t* xor_color)
{
    int i, j, len = ZIMG_MAP_COLORS;
    double color_scaling = 0xff / ZIMG_MAP_COLORS;
    int R = 0, G = 0, B = 0;
    int (*allocColor)(gdImagePtr, int, int, int) = gdImageColorAllocate;
    
    if (!im) {
	printf("# zimg colormap\n");
	if (color & RGBMAP) {
	    printf("# -m%d,%d,%d\n", rgbformulae[0],
		rgbformulae[1], rgbformulae[2]);
	} else if (color & REDMAP) {
	    printf("# --red\n");
	} else if (color & BLUEMAP) {
	    printf("# --blue\n");
	} else if (color & GRAYMAP) {
	    printf("# --gray\n");
	} else if (colormapfile) {
	    printf("# -m%s\n", colormapfile);
	}
	allocColor = zimg_dump_color;
    }
    
    if (color & XOR_MAP) {
        R = xor_color->red;
        G = xor_color->green;
        B = xor_color->blue;
    }

    if (color & RGBMAP) {
	double dlen = (double) --len;
        for (i = 0; i < len; i++) {
	    double gray = (double) i / dlen;
	    int red   = (int) (GetColorValueFromFormula
		(rgbformulae[0], gray) * dlen);
	    int green = (int) (GetColorValueFromFormula
		(rgbformulae[1], gray) * dlen);
	    int blue  = (int) (GetColorValueFromFormula
		(rgbformulae[2], gray) * dlen);
            gdcolor[i] = allocColor(im, red^R, green^G, blue^B);
#if 0
	    fprintf(stderr, "(getGdColorMap) %02x,%02x,%02x\n", red, green, blue);
#endif
        }
    } else if (color & REDMAP) {
        for (j = 0, i = 0; j < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, ((int)((double)j * color_scaling))^R, 0^G, 0^B);
        }
        for (j = 0; j < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, 0xff^R, ((int)((double)j * color_scaling))^G, 0^B);
        }
        for (j = 0; i < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, 0xff^R, 0xff^G, ((int)((double)j * color_scaling))^B);
        }
	len = i; /* actually allocated colors */
    } else if (color & BLUEMAP) {
        for (j = 0, i = 0; j < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, 0^R, 0^G, ((int)((double)j * color_scaling))^B);
        }
        for (j = 0; j < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, ((int)((double)j * color_scaling))^R, 0^G, 0xff^B);
        }
        for (j = 0; i < len; i++, j += 3) {
            gdcolor[i] = allocColor(im, 0xff^R, ((int)((double)j * color_scaling))^G, 0xff^B);
        }
	len = i; /* actually allocated colors */
    } else if (color & GRAYMAP) {
        for (i = 0; i < len; i++) {
	    int c = (int)((double)i * color_scaling);
            gdcolor[i] = allocColor(im, c^R, c^G, c^B);
        }
    } else if (colormapfile) {
        /* read custom colormap file */
        int* itmp;
        FILE* fp = (FILE*)0;
	char* path_colormapfile = search_file(colormapfile, "cmap", PKGDATADIR, 0 /* relative */);
	if (!path_colormapfile)
	    Fatal("unable to find colormap file ");
        fp = fopen(path_colormapfile, "r");
        len = 0;
	if (!fp) {
	    perror(path_colormapfile);
	    exit(2);
	}
        while (len < ZIMG_MAP_COLORS && (itmp = get_next_custom_entry(fp))) {
            gdcolor[len] = allocColor
                (im, (itmp[0])^R, (itmp[1])^G, (itmp[2])^B);
            len++;
        }
        fclose(fp);
	free(path_colormapfile);
    } else {
	/* use default colormap */
	int len1, len2, len3, len4;
	len = ZIMG_MAP_COLORS;
	len1 = len * 0.2;
	len2 = len1 * 2;
	len3 = len1 * 3;
	len4 = len1 * 4;
#if 0
	fprintf(stderr, "(getGdColorMap) len1 = %d\n", len1);
	fprintf(stderr, "(getGdColorMap) len2 = %d\n", len2);
	fprintf(stderr, "(getGdColorMap) len3 = %d\n", len3);
	fprintf(stderr, "(getGdColorMap) len4 = %d\n", len4);
#endif
        for (j = ZIMG_MAP_COLORS - 1, i = 0; i < len1; i++, j--) {
            gdcolor[j] = allocColor(im,
		    ((int)((double)0xff))^R,
		    ((int)((double)0xff * (double)i / (double)len1))^G,
		    ((int)((double)0x00))^B);

        }
        for (; i < len2; i++, j--) {
            gdcolor[j] = allocColor(im,
		    ((int)((double)0xff * (double)(len2 - i) / (double)len1))^R,
		    ((int)((double)0xff))^G,
		    ((int)((double)0x00))^B);

        }
        for (; i < len3; i++, j--) {
            gdcolor[j] = allocColor(im,
		    ((int)((double)0x00))^R,
		    ((int)((double)0xff))^G,
		    ((int)((double)0xff * (double)(i - len2) / (double)len1))^B);

        }
        for (; i < len4; i++, j--) {
            gdcolor[j] = allocColor(im,
		    ((int)((double)0x00))^R,
		    ((int)((double)0xff * (double)(len4 - i) / (double)len1))^G,
		    ((int)((double)0xff))^B);

        }
        for (; i < len; i++, j--) {
            gdcolor[j] = allocColor(im,
		    ((int)((double)0xff * (double)(i - len4) / (double)len1))^R,
		    ((int)((double)0x00))^G,
		    ((int)((double)0xff))^B);

        }
    }

    if (color & INVERT_MAP)
        invert_colormap(gdcolor, len);

    return len;
}

int
zimg_gdImageLineColorAllocate(gdImagePtr im,
       	int red, int green, int blue)
{
    int color = gdImageColorExact(im, red, green, blue);
    if (color < 0) {
	color = gdImageColorAllocate(im, red, green, blue);
    }
    if (color < 0) {
	color = gdImageColorClosest(im, red, green, blue);
    }
    return color;
}

