/* classes: h_files */

#ifndef RXPOSIXH
#define RXPOSIXH
/*	Copyright (C) 1995, 1996 Tom Lord
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, 59 Temple Place - Suite 330, 
 * Boston, MA 02111-1307, USA. 
 */


#include "rxspencer.h"
#include "rxcontext.h"
#include "inst-rxposix.h"

#ifndef __GNUC__
# define __DLL_IMPORT__	__declspec(dllimport)
# define __DLL_EXPORT__	__declspec(dllexport)
#else
# define __DLL_IMPORT__	__attribute__((dllimport)) extern
# define __DLL_EXPORT__	__attribute__((dllexport)) extern
#endif 

#if (defined __WIN32__) || (defined _WIN32)
# ifdef BUILD_RX_DLL
#  define RX_DLL_IMPEXP	__DLL_EXPORT__
# elif defined(RX_STATIC)
#  define RX_DLL_IMPEXP	 
# elif defined (USE_RX_DLL)
#  define RX_DLL_IMPEXP	__DLL_IMPORT__
# elif defined (USE_RX_STATIC)
#  define RX_DLL_IMPEXP 	 
# else /* assume USE_RX_DLL */
#  define RX_DLL_IMPEXP	__DLL_IMPORT__
# endif
#else /* __WIN32__ */
# define RX_DLL_IMPEXP	 
#endif

#ifdef __STDC__
RX_DLL_IMPEXP int regncomp (regex_t * preg, const char * pattern, int len, int cflags);
RX_DLL_IMPEXP int regcomp (regex_t * preg, const char * pattern, int cflags);
RX_DLL_IMPEXP size_t regerror (int errcode, const regex_t *preg,
			char *errbuf, size_t errbuf_size);
RX_DLL_IMPEXP int rx_regmatch (regmatch_t pmatch[], const regex_t *preg, struct rx_context_rules * rules, int start, int end, const char *string);
RX_DLL_IMPEXP int rx_regexec (regmatch_t pmatch[], const regex_t *preg, struct rx_context_rules * rules, int start, int end, const char *string);
RX_DLL_IMPEXP int regnexec (const regex_t *preg, const char *string, int len, size_t nmatch, regmatch_t **pmatch, int eflags);
RX_DLL_IMPEXP int regexec (const regex_t *preg, const char *string, size_t nmatch, regmatch_t pmatch[], int eflags);
RX_DLL_IMPEXP void regfree (regex_t *preg);

#else /* STDC */
RX_DLL_IMPEXP int regncomp ();
RX_DLL_IMPEXP int regcomp ();
RX_DLL_IMPEXP size_t regerror ();
RX_DLL_IMPEXP int rx_regmatch ();
RX_DLL_IMPEXP int rx_regexec ();
RX_DLL_IMPEXP int regnexec ();
RX_DLL_IMPEXP int regexec ();
RX_DLL_IMPEXP void regfree ();

#endif /* STDC */

#endif /* RXPOSIXH */
