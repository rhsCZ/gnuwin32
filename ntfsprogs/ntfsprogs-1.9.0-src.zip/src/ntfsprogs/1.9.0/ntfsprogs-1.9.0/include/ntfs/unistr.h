/*
 * unistr.h - Exports for unicode string handling. Part of the Linux-NTFS
 *	      project.
 *
 * Copyright (c) 2000-2002 Anton Altaparmakov
 *
 * This program/include file is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program/include file is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (in the main directory of the Linux-NTFS
 * distribution in the file COPYING); if not, write to the Free Software
 * Foundation,Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _NTFS_UNISTR_H
#define _NTFS_UNISTR_H

#include "types.h"
#include "layout.h"

extern const u8 legal_ansi_char_array[0x40];

extern BOOL ntfs_names_are_equal(const uchar_t *s1, size_t s1_len,
		const uchar_t *s2, size_t s2_len, const IGNORE_CASE_BOOL ic,
		const uchar_t *upcase, const u32 upcase_size);

extern int ntfs_names_collate(const uchar_t *name1, const u32 name1_len,
		const uchar_t *name2, const u32 name2_len,
		const int err_val, const IGNORE_CASE_BOOL ic,
		const uchar_t *upcase, const u32 upcase_len);

extern int ntfs_ucsncmp(const uchar_t *s1, const uchar_t *s2, size_t n);

extern int ntfs_ucsncasecmp(const uchar_t *s1, const uchar_t *s2, size_t n,
		const uchar_t *upcase, const u32 upcase_size);

extern u32 ntfs_ucsnlen(const uchar_t *s, u32 maxlen);

extern void ntfs_name_upcase(uchar_t *name, u32 name_len,
		const uchar_t *upcase, const u32 upcase_len);

extern void ntfs_file_value_upcase(FILE_NAME_ATTR *file_name_attr,
		const uchar_t *upcase, const u32 upcase_len);

extern int ntfs_file_values_compare(FILE_NAME_ATTR *file_name_attr1,
		FILE_NAME_ATTR *file_name_attr2,
		const int err_val, const IGNORE_CASE_BOOL ic,
		const uchar_t *upcase, const u32 upcase_len);

extern int ntfs_ucstombs(const uchar_t *ins, const int ins_len, char **outs,
		int outs_len);
extern int ntfs_mbstoucs(const char *ins, uchar_t **outs, int outs_len);

#endif /* defined _NTFS_UNISTR_H */

