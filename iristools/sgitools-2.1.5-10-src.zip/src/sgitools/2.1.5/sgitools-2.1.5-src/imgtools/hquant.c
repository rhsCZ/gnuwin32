/*
 *	hquant - 
 *		Quantify an image to n most frequent colors.
 *
 *			Paul Haeberli - 1990
 */
#include "image.h"
#include "quant.h"

short rbuf[4096];
short gbuf[4096];
short bbuf[4096];

main(argc,argv)
int argc;
char **argv;
{
    cmap *map;
    IMAGE *iimage;
    int xsize, ysize, zsize;
    int y, mode, nc;

    if( argc<4 ) {
	printf("usage: hquant inimage.rgb out.map ncolors [-h]\n");
	exit(1);
    } 
    iimage=iopen(argv[1],"r");
    if(!iimage) {
	printf("hquant: can't open input file %s\n",argv[1]);
	exit(1);
    }
    mode = 0;
    if(argc>4)
	mode = 1;
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    zsize = iimage->zsize;
    nc = atoi(argv[3]);
    optmapbegin(nc,mode);
    for(y=0; y<ysize; y++) {
	getrow(iimage,rbuf,y,0%zsize);
	getrow(iimage,gbuf,y,1%zsize);
	getrow(iimage,bbuf,y,2%zsize);
	optmapadd(rbuf,gbuf,bbuf,xsize);
    }
    map = optmapend();
    writecmap(argv[2],map);
    exit(0);
}
