/* 
 *	fromtiff -
 *		Convert almost any tiff file into an IRIS image file.
 *
 *			Sam Leffler and Paul Haeberli - 1990
 */
#include "stdio.h"
#include "image.h"
#include "tiffio.h"

long	xsize, ysize;
unsigned short	bitspersample;
unsigned short	samplesperpixel;
unsigned short	photometric;
unsigned short	orientation;
IMAGE *oimage;

main(argc, argv)
char *argv[];
{
    char *rindex();
    TIFF *tif;

    if (argc < 3) {
	fprintf(stderr, "usage: fromtiff inimage.tif image.rgb\n");
	exit(1);
    }
    tif = TIFFOpen(argv[1], "r");
    if (tif == NULL) {
	fprintf(stderr, "fromtiff: can't open %s\n",argv[1]);
	exit(1);
    }
    if (argc > 3 && !TIFFSetDirectory(tif, atoi(argv[3]))) {
	    fprintf(stderr, 
	"fromtiff: Error seeking to directory %s for %s.\n", argv[1], argv[3]);
	    exit(1);
    }
    bitspersample = getbitspersample(tif);
    samplesperpixel = getsamplesperpixel(tif);
    getimgsize(tif,&xsize,&ysize);
    oimage = iopen(argv[2],"w",RLE(1),3,xsize,ysize,3);
    gt(tif,xsize,ysize);
    TIFFClose(tif);
    iclose(oimage);
    exit(0);
}

putarow(y,r,g,b)
int y;
unsigned short *r, *g, *b;
{
    putrow(oimage,r,y,0);
    putrow(oimage,g,y,1);
    putrow(oimage,b,y,2);
}

#define	CVT16to8(x)	(((x) * 256) / ((1L<<16)-1))
#define	SHORTPTR(x)	((unsigned short *)(x))
unsigned char **BWmap;
unsigned short	*rcmap, *gcmap, *bcmap;
unsigned short *rbuf;
unsigned short *gbuf;
unsigned short *bbuf;

gt(tif, w, h)
TIFF *tif;
int w, h;
{
    unsigned short minsamplevalue, maxsamplevalue, planarconfig;
    unsigned char *Map;
    int e;

    rbuf = (unsigned short *)malloc(w*sizeof(unsigned short));
    gbuf = (unsigned short *)malloc(w*sizeof(unsigned short));
    bbuf = (unsigned short *)malloc(w*sizeof(unsigned short));
    if (!TIFFGetField(tif, TIFFTAG_PHOTOMETRIC, &photometric)) {
	switch (samplesperpixel) {
	    case 1:
		photometric = PHOTOMETRIC_MINISBLACK;
		break;
	    case 3: 
	    case 4:
		photometric = PHOTOMETRIC_RGB;
		break;
	    default:
		fprintf(stderr, "Missing PhotometricInterpretation tag\n");
		return 0;
	}
	fprintf(stderr,"No \"PhotometricInterpretation\" tag, assuming %s.\n",
		photometric == PHOTOMETRIC_RGB ? "RGB" : "min-is-black");
    }
    if (!TIFFGetField(tif, TIFFTAG_MINSAMPLEVALUE, &minsamplevalue))
	minsamplevalue = 0;
    if (!TIFFGetField(tif, TIFFTAG_MAXSAMPLEVALUE, &maxsamplevalue))
	maxsamplevalue = (1<<bitspersample)-1;
    Map = NULL;
    switch (photometric) {
	case PHOTOMETRIC_RGB:
	    if (minsamplevalue == 0 && maxsamplevalue == 255)
		break;
	    /* fall thru... */
	case PHOTOMETRIC_MINISBLACK:
	case PHOTOMETRIC_MINISWHITE: {
	    register int x, range;

	    range = maxsamplevalue - minsamplevalue;
	    Map = (unsigned char *)malloc((range + 1) * sizeof (unsigned char));
	    if (Map == NULL) {
		fprintf(stderr, "%s.\n",
			    "No space for photometric conversion table");
		return 0;
	    }
	    if (photometric == PHOTOMETRIC_MINISWHITE) {
		for (x = 0; x <= range; x++)
		    Map[x] = ((range - x) * 255) / range;
	    } else {
		for (x = 0; x <= range; x++)
		    Map[x] = (x * 255) / range;
	    }
	    if (bitspersample != 8 && photometric != PHOTOMETRIC_RGB) {
		makebwmap(Map);
		free(Map); 	/* no longer need Map, free it */
		Map = NULL;
	    }
	    break;
	}
	case PHOTOMETRIC_PALETTE:
	    if (!TIFFGetField(tif, TIFFTAG_COLORMAP,
					&rcmap, &gcmap, &bcmap)) {
		fprintf(stderr, "Missing required \"Colormap\" tag.\n");
		return 0;
	    }
	    /*
	     * Convert 16-bit colormap to 8-bit.
	     */
	    { int i;
	      	for (i = (1<<bitspersample)-1; i > 0; i--) {
		    rcmap[i] = CVT16to8(rcmap[i]);
		    gcmap[i] = CVT16to8(gcmap[i]);
		    bcmap[i] = CVT16to8(bcmap[i]);
	      	}
	    }
	    break;
    }
    TIFFGetField(tif, TIFFTAG_PLANARCONFIG, &planarconfig);
    if (planarconfig == PLANARCONFIG_SEPARATE)
	e = gtseparate(tif, Map, h, w);
    else
	e = gtcontig(tif, Map, h, w);
    if (Map)
	free(Map);
    free(rbuf);
    free(gbuf);
    free(bbuf);
    return e;
}

setorientation(tif, h)
TIFF *tif;
int h;
{
    int y;

    if (!TIFFGetField(tif, TIFFTAG_ORIENTATION, &orientation))
	orientation = ORIENTATION_TOPLEFT;
    switch (orientation) {
	case ORIENTATION_BOTRIGHT:
	case ORIENTATION_RIGHTBOT:	/* XXX */
	case ORIENTATION_LEFTBOT:	/* XXX */
	    fprintf(stderr,"Warning, using bottom-left orientation.\n");
	    orientation = ORIENTATION_BOTLEFT;
	    /* fall thru... */
	case ORIENTATION_BOTLEFT:
	    y = 0;
	    break;
	case ORIENTATION_TOPRIGHT:
	case ORIENTATION_RIGHTTOP:	/* XXX */
	case ORIENTATION_LEFTTOP:	/* XXX */
	    fprintf(stderr,"Warning, using top-left orientation.\n");
	    orientation = ORIENTATION_TOPLEFT;
	    /* fall thru... */
	case ORIENTATION_TOPLEFT:
	    y = h-1;
	    break;
    }
    return y;
}

gtcontig(tif, Map, h, w)
TIFF *tif;
register unsigned char *Map;
int h, w;
{
    register unsigned char *pp;
    register int x;
    int scanline, row, y;
    unsigned char *buf;
    unsigned short *rptr, *gptr, *bptr;

    buf = (unsigned char *)malloc(TIFFScanlineSize(tif));
    if (buf == 0) {
	fprintf(stderr, "No space for scanline buffer\n");
	return 0;
    }
    y = setorientation(tif, h);
    for (row = 0; row < h; row++) {
	if (myTIFFReadScanline(tif, buf, row, 0) < 0)
	    break;
	switch (photometric) {
	    case PHOTOMETRIC_RGB:
		switch (bitspersample) {
		    case 8:
			if (Map) {
			    pp = buf;
			    for (x = w; x-- > 0;) {
				pp[0] = Map[pp[0]];
				pp[1] = Map[pp[1]];
				pp[2] = Map[pp[2]];
				pp += samplesperpixel;
			    }
			}
			rptr = rbuf;
			gptr = gbuf;
			bptr = bbuf;
			pp = buf;
			for (x = w; x-- > 0;) {
			    *rptr++ = pp[0];
			    *gptr++ = pp[1];
			    *bptr++ = pp[2];
			    pp += samplesperpixel;
			}
			putarow(y,rbuf,gbuf,bbuf);
			break;
		    case 16: {
			register unsigned short *wp;

			if (Map) {
			    pp = buf;
			    wp = (unsigned short *)pp;
			    for (x = w; x-- > 0;) {
				wp[0] = Map[wp[0]];
				wp[1] = Map[wp[1]];
				wp[2] = Map[wp[2]];
				wp += samplesperpixel;
			    }
			}
			rptr = rbuf;
			gptr = gbuf;
			bptr = bbuf;
			pp = buf;
			wp = (unsigned short *)pp;
			for (x = w; x-- > 0;) {
			    *rptr++ = wp[0];
			    *gptr++ = wp[1];
			    *bptr++ = wp[2];
			    wp += samplesperpixel;
			}
			putarow(y,rbuf,gbuf,bbuf);
			break;
		    }
		}
		break;
	    case PHOTOMETRIC_PALETTE:
		rptr = rbuf;
		gptr = gbuf;
		bptr = bbuf;
		pp = buf;
		for (x = w; x-- > 0;) {
		    unsigned char c;

		    c = *pp++;
		    *rptr++ = rcmap[c];
		    *gptr++ = gcmap[c];
		    *bptr++ = bcmap[c];
		}
		putarow(y,rbuf,gbuf,bbuf);
		break;
	    case PHOTOMETRIC_MINISWHITE:
	    case PHOTOMETRIC_MINISBLACK:
		if (bitspersample == 8) {
		    register unsigned char c;

		    rptr = rbuf;
		    gptr = gbuf;
		    bptr = bbuf;
		    pp = buf;
		    for (x = w; x-- > 0;) {
			c = Map[*pp++];

			*rptr++ = c;
			*gptr++ = c;
			*bptr++ = c;
		    }
		    putarow(y,rbuf,gbuf,bbuf);
		} else {
		    pp = buf;
		    gtbw(bitspersample, w, pp, rbuf);
		    putarow(y,rbuf,rbuf,rbuf);
		}
		break;
	}
	y += (orientation == ORIENTATION_TOPLEFT ? -1 : 1);
    }
    return 1;
}

gtseparate(tif, Map, h, w)
TIFF *tif;
register unsigned char *Map;
int h, w;
{
    register int x;
    unsigned char *buf;
    int scanline, row, y;
    unsigned short *rptr, *gptr, *bptr;

    scanline = TIFFScanlineSize(tif);
    switch (samplesperpixel) {
	case 1:
	    buf = (unsigned char *)malloc(scanline);
	    break;
	case 3: 
	case 4:
	    buf = (unsigned char *)malloc(3*scanline);
	    break;
    }
    y = setorientation(tif, h);
    for (row = 0; row < h; row++) {
	if (myTIFFReadScanline(tif,buf,row,0) < 0)
	    break;
	switch (photometric) {
	    case PHOTOMETRIC_RGB: {
		register unsigned char *r, *g, *b;

		r = buf+0*scanline;
		g = buf+1*scanline;
		b = buf+2*scanline;
		if (myTIFFReadScanline(tif,g,row,1) < 0)
		    break;
		if (myTIFFReadScanline(tif,b,row,2) < 0)
		    break;
		switch (bitspersample) {
		    case 8:
			rptr = rbuf;
			gptr = gbuf;
			bptr = bbuf;
			for (x = w; x-- > 0;) {
			    *rptr++ = *r++;
			    *gptr++ = *g++;
			    *bptr++ = *b++;
			}
			putarow(y,rbuf,gbuf,bbuf);
			break;
		    case 16:
			rptr = rbuf;
			gptr = gbuf;
			bptr = bbuf;
			for (x = 0; x < w; x++) {
			    *rptr++ = Map[SHORTPTR(r)[x]];
			    *gptr++ = Map[SHORTPTR(g)[x]];
			    *bptr++ = Map[SHORTPTR(b)[x]];
			}
			putarow(y,rbuf,gbuf,bbuf);
			break;
		    }
		    break;
		}
		case PHOTOMETRIC_PALETTE: {
		    register unsigned char *pp;

		    rptr = rbuf;
		    gptr = gbuf;
		    bptr = bbuf;
		    pp = buf;
		    for (x = w; x-- > 0;) {
			unsigned char c = *pp++;

			*rptr++ = rcmap[c];
			*gptr++ = gcmap[c];
			*bptr++ = bcmap[c];
		    }
		    putarow(y,rbuf,gbuf,bbuf);
		    break;
		}
		case PHOTOMETRIC_MINISWHITE:
		case PHOTOMETRIC_MINISBLACK:
		    if (bitspersample == 8) {
			register unsigned short *pp;
			register unsigned char c;

			rptr = rbuf;
			pp = (unsigned short *)buf;
			for (x = w; x-- > 0;) {
			    c = Map[*pp++];
			    *rptr++ = c;
			}
			putarow(y,rbuf,rbuf,rbuf);
		    } else {
			register unsigned char *pp;

			pp = buf;
			gtbw(bitspersample, w, pp, rbuf);
			putarow(y,rbuf,rbuf,rbuf);
		    }
		    break;
		}
		y += (orientation == ORIENTATION_TOPLEFT ? -1 : 1);
	}
	if (buf)
	    free(buf);
	return 1;
}

/*
 * Greyscale images with less than 8 bits/sample are handled
 * with a table to avoid lots of shifts and masks.  The table
 * is setup so that gtbw (below) can retrieve 8/bitspersample
 * pixel values simply by indexing into the table with one
 * number.
 */
makebwmap(Map)
unsigned char *Map;
{
    register int i;
    int nsamples = 8 / bitspersample;
    register unsigned char *p;

    BWmap = (unsigned char **)malloc(
	    256*sizeof(unsigned char*)+(256*nsamples*sizeof(unsigned char)));
    if (BWmap == NULL) {
	fprintf(stderr, "No space for B&W mapping table.\n");
	exit(1);
    }
    p = (unsigned char *)(BWmap + 256);
    for (i = 0; i < 256; i++) {
	BWmap[i] = p;
	switch (bitspersample) {
	    case 1:
		*p++ = Map[(i>>7)&1];
		*p++ = Map[(i>>6)&1];
		*p++ = Map[(i>>5)&1];
		*p++ = Map[(i>>4)&1];
		*p++ = Map[(i>>3)&1];
		*p++ = Map[(i>>2)&1];
		*p++ = Map[(i>>1)&1];
		*p++ = Map[(i>>0)&1];
		break;
	    case 2:
		*p++ = Map[(i>>6)&3];
		*p++ = Map[(i>>4)&3];
		*p++ = Map[(i>>2)&3];
		*p++ = Map[(i>>0)&3];
		break;
	    case 4:
		*p++ = Map[(i>>4)&0xf];
		*p++ = Map[(i>>0)&0xf];
		break;
	    }
    }
    return 1;
}

gtbw(bitspersample, w, pp, sptr)
int bitspersample, w;
register unsigned char *pp;
register unsigned short *sptr;
{
    register unsigned char c, *bw;
    register int x;

    switch (bitspersample) {
	case 1:
	    for (x = w; x >= 8; x -= 8) {
		bw = BWmap[*pp++];
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
	    }
	    break;
	case 2:
	    for (x = w; x >= 4; x -= 4) {
		bw = BWmap[*pp++];
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
	    }
	    break;
	case 4:
	    for (x = w; x >= 2; x -= 2) {
		bw = BWmap[*pp++];
		*sptr++ =  *bw++; 
		*sptr++ =  *bw++; 
	    }
	    break;
    }
    bw = BWmap[*pp++];
    for (; x > 0; x--) 
	*sptr++ =  *bw++; 
}

getbitspersample(tif)
TIFF *tif;
{
    unsigned short bps;

    if (!TIFFGetField(tif, TIFFTAG_BITSPERSAMPLE, &bps))
	bps = 1;
    switch (bps) {
	case 1: 
	case 2: 
	case 4:
	case 8: 
	case 16:
	    break;
	default:
	    fprintf(stderr, "fromtiff: Can't handle %d-bit pictures\n",bps);
	    exit(1);
    }
    return bps;
}

getsamplesperpixel(tif)
TIFF *tif;
{
    unsigned short spp;

    if (!TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &spp))
	spp = 1;
    switch (spp) {
	case 1: 
	case 3: 
	case 4:
	    break;
	default:
	    fprintf(stderr,"fromtiff: Can't handle %d-channel images\n",spp);
	    exit(1);
    }
    return spp;
}

getimgsize(tif,xsize,ysize)
TIFF *tif;
long *xsize, *ysize;
{
    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH,xsize);
    TIFFGetField(tif, TIFFTAG_IMAGELENGTH,ysize);
}

myTIFFReadScanline(tif,buf,row,sample)
TIFF *tif;
unsigned char *buf;
int row, sample;
{
    int ret;

    ret = TIFFReadScanline(tif,buf,row,sample);
    if(ret<0) {
	bzero(buf,TIFFScanlineSize(tif));
    }
    return 1;
}
