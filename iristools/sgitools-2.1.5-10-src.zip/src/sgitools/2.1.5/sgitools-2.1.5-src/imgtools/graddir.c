/*
 *	graddir- 
 *		Determine the direction of the gradient across an image. 
 *
 * 		    	Paul Haeberli - 1990
 */
#include "stdio.h"
#include "math.h"
#include "image.h"

int globalz;
short *sbufs[3];
short *rbuf, *gbuf, *bbuf;
IMAGE *iimage, *oimage;

main(argc, argv)
int argc;
char **argv;
{
    int xsize, ysize;
    int i, y, oy, noflip;
    float mag;
    short *sptr;

    if (argc<2) {
	fprintf(stderr,"usage: graddir inimage.bw outimage.rgb -n\n");
	exit(1);
    }
    if(argc>2) 
        noflip = 1;
    else
        noflip = 0;
    iimage = iopen(argv[1], "r");
    if (!iimage) {
	fprintf(stderr,"izoom: can't open input file %s\n",argv[1]);
	exit(1);
    }
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    for(i=0; i<3; i++) 
	sbufs[i] = (short *)malloc(xsize*sizeof(short));
    rbuf = (short *)malloc(xsize*sizeof(short));
    gbuf = (short *)malloc(xsize*sizeof(short));
    bbuf = (short *)malloc(xsize*sizeof(short));
    oimage = iopen(argv[2],"w",RLE(1),3,xsize,ysize,3);
    oy = 0;
    zerorow(bbuf,xsize);
    putrow(oimage,bbuf,oy,0);
    putrow(oimage,bbuf,oy,1);
    putrow(oimage,bbuf,oy,2);
    oy++;
    for(y=0; y<ysize; y++) {
	getrow(iimage,sbufs[2],y,0);
	if(y>=2) {
	    findgradient(sbufs,rbuf,gbuf,xsize,noflip);
	    putrow(oimage,rbuf,oy,0);
	    putrow(oimage,gbuf,oy,1);
	    putrow(oimage,bbuf,oy,2);
	    oy++;
	}
	sptr = sbufs[0];
	sbufs[0] = sbufs[1];
	sbufs[1] = sbufs[2];
	sbufs[2] = sptr;
    }
    putrow(oimage,bbuf,oy,0);
    putrow(oimage,bbuf,oy,1);
    putrow(oimage,bbuf,oy,2);
    iclose(oimage);
    exit(0);
}

findgradient(sbufs,rbuf,gbuf,n,noflip)
short *sbufs[3];
short *rbuf, *gbuf;
int n, noflip;
{
    short *sptr0, *sptr1, *sptr2;
    int dx, dy;

    n -= 2;
    *rbuf++ = 0;
    *gbuf++ = 0;
    sptr0 = sbufs[0];
    sptr1 = sbufs[1];
    sptr2 = sbufs[2];
    while(n--) {
	dx = sptr1[0]-sptr1[2];
	dy = sptr0[1]-sptr2[1];
	if(noflip) {
	    dx = dx+128;
	    dy = dy+128;
	} else {
	    if(dx<0) {
		dx = -dx;
		dy = -dy;
	    }
	    dx = dx+128;
	    dy = dy+128;
	}
	if(dx<0)
	    dx = 0;
	if(dx>255)
	    dx = 255;
	if(dy<0)
	    dy = 0;
	if(dy>255)
	    dy = 255;
	*rbuf++ = dx;
	*gbuf++ = dy;
	sptr0++;
	sptr1++;
	sptr2++;
    }
}
