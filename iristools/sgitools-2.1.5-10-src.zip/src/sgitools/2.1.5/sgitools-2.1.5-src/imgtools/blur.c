/*
 *	blur - 
 *		Blur an image by zooming it down and then up.
 *
 *				Paul Haeberli - 1988
 */
#include "image.h"
#include "izoom.h"
#include "math.h"

IMAGE *iimage, *oimage;
zoom *zoomdown, *zoomup;
int curz;
short buf[8192];

getimgrow(buf,y)
short *buf;
int y;
{
    getrow(iimage,buf,y,curz);
}

getsmallrow(buf,y)
short *buf;
int y;
{
    getzoomrow(zoomdown,buf,y);
}

main(argc,argv)
int argc;
char **argv;
{
    int y;
    int xsize, ysize, zsize;
    int sxsize, sysize, max;
    float radius, xfactor, yfactor;
    float xrad, yrad;
    char cmd[256];

    if( argc<4 ) {
	fprintf(stderr,"usage: blur inimage outimage [freq] [xfreq yfreq]\n");
	exit(1);
    } 
    if( (iimage=iopen(argv[1],"r")) == NULL ) {
	fprintf(stderr,"blur: can't open input file %s\n",argv[1]);
	exit(1);
    }
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    zsize = iimage->zsize;
    oimage = iopen(argv[2],"w",RLE(1),3,xsize,ysize,zsize);
    if(xsize>ysize)
	max = xsize;
    else
	max = ysize;
    if(argc==4) {
	radius = atof(argv[3]);
	radius = radius/max;
	sxsize = (xsize*radius)+0.5;
	sysize = (ysize*radius)+0.5;
    } else {
	xrad = atof(argv[3]);
	yrad = atof(argv[4]);
	xrad = xrad/xsize;
	yrad = yrad/ysize;
	sxsize = (xsize*xrad)+0.5;
	sysize = (ysize*yrad)+0.5;
    }
    xfactor = (float)sxsize/xsize;
    yfactor = (float)sysize/ysize;
    if(xfactor>1.0)
	xfactor = 1.0;
    if(yfactor>1.0)
	yfactor = 1.0;
    zoomdown = newzoom(getimgrow,xsize,ysize,sxsize,sysize,QUADRATIC,1.0);
    zoomup = newzoom(getsmallrow,sxsize,sysize,xsize,ysize,QUADRATIC,1.0);
    for(curz=0; curz<zsize; curz++) {
	for(y=0; y<ysize; y++) {
	    getzoomrow(zoomup,buf,y);
	    putrow(oimage,buf,y,curz);
	}
    }
    iclose(oimage);
    exit(0);
}
