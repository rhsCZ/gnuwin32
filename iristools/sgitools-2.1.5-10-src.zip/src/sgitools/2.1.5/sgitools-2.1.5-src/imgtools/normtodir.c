/*
 *	normtodir- 
 *	    Determine the direction of the gradient across an image. 
 *
 * 		    	Paul Haeberli - 1990
 */
#include "stdio.h"
#include "image.h"
#include "vect.h"

int globalz;
short rbuf[8192];
short gbuf[8192];
short bbuf[8192];
short obuf[8192];
vect pref, prefs[3];
int how;

float frand();

main(argc, argv)
int argc;
char **argv;
{
    IMAGE *iimage, *oimage;
    int i, y;
    int xsize, ysize, zsize;

    if (argc<3) {
	fprintf(stderr,"usage: normtodir norm.rgb dir.bw [how [px py]]\n");
	exit(1);
    }
    if(argc>3)
	how = atoi(argv[3]);
    else
	how = 0;
    pref.x = 0.0;
    pref.y = 0.0;
    pref.z = 1.0;
    if(argc == 6) {
	pref.x = atof(argv[4]);
	pref.y = atof(argv[5]);
	for(i=0; i<3; i++) 
	    prefs[i] = pref;
    } else {
	prefs[0].x = 0.0;
	prefs[0].y = 0.5;
	prefs[0].z = 0.5;
	prefs[1].x = -0.3;
	prefs[1].y = -0.4;
	prefs[1].z = 0.5;
	vcross(prefs+0,prefs+1,prefs+2);
	vcross(prefs+2,prefs+0,prefs+1);
    }
    for(i=0; i<3; i++) 
	vnormal(prefs+i);
    iimage = iopen(argv[1], "r");
    if (!iimage) {
	fprintf(stderr,"normtodir: can't open input file %s\n",argv[1]);
	exit(1);
    }
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    zsize = iimage->ysize;
    if(zsize < 3) {
	fprintf(stderr,"normtodir: input image must have 3 channels\n");
	exit(1);
    }
    oimage = iopen(argv[2],"w",RLE(1),2,xsize,ysize,1);
    for(y=0; y<ysize; y++) {
	getrow(iimage,rbuf,y,0);
	getrow(iimage,gbuf,y,1);
	getrow(iimage,bbuf,y,2);
	normtodir(rbuf,gbuf,bbuf,obuf,xsize);
	putrow(oimage,obuf,y,0);
    }
    iclose(oimage);
    exit(0);
}

normtodir(rbuf,gbuf,bbuf,obuf,n)
short *rbuf, *gbuf, *bbuf, *obuf;
int n;
{
    vect norm, cross;
    float mag, curdir;
    int i;
    float dir[3], qual[3], qtot, r, max;

    switch(how) {
	case 0:	/* use x and y components of the normal */
	    while(n--) {
		norm.x = ((*rbuf++)-128)/128.0;
		norm.y = ((*gbuf++)-128)/128.0;
		norm.z = ((*bbuf++)-128)/128.0;
		mag = (norm.x*norm.x+norm.y*norm.y);
		if(mag>0.001) {
		    curdir = (atan2(norm.y,norm.x)/(2.0*M_PI))+0.25;
		    while(curdir<0.0)
			curdir+=1.0;
		    while(curdir>1.0)
			curdir-=1.0;
		} else
		    curdir = 0.0;
		*obuf++ = 255.0*curdir;
	    }
	    break;
	case 1:	/* pick the best of 3 */
	    while(n--) {
		norm.x = ((*rbuf++)-128)/128.0;
		norm.y = ((*gbuf++)-128)/128.0;
		norm.z = ((*bbuf++)-128)/128.0;
		qtot = 0.0;
		for(i=0; i<3; i++) {
		    vcross(&norm,&prefs[i],&cross);
		    mag = (cross.x*cross.x+cross.y*cross.y+cross.z*cross.z);
		    qual[i] = mag;
		    qtot += mag;
		    if(mag>0.001) {
			curdir = (atan2(cross.y,cross.x)/(2.0*M_PI));
			while(curdir<0.0)
			    curdir+=1.0;
			while(curdir>1.0)
			    curdir-=1.0;
		    } else
			curdir = 0.0;
		    dir[i] = curdir;
		}
		max = 0.0;
		for(i=0; i<3; i++) {
		    if(max<(0.8+0.2*frand())*qual[i]) {
			max = qual[i];
			curdir = dir[i];
		    }
		}
		*obuf++ = 255.0*curdir;
	    }
	    break;
	case 2:	/* stocasically chose between three based on quality */
	    while(n--) {
		norm.x = ((*rbuf++)-128)/128.0;
		norm.y = ((*gbuf++)-128)/128.0;
		norm.z = ((*bbuf++)-128)/128.0;
		qtot = 0.0;
		for(i=0; i<3; i++) {
		    vcross(&norm,&prefs[i],&cross);
		    mag = (cross.x*cross.x+cross.y*cross.y+cross.z*cross.z);
		    mag = mag*mag;
		    qual[i] = mag;
		    qtot += mag;
		    if(mag>0.001) {
			curdir = (atan2(cross.y,cross.x)/(2.0*M_PI));
			while(curdir<0.0)
			    curdir+=1.0;
			while(curdir>1.0)
			    curdir-=1.0;
		    } else
			curdir = 0.0;
		    dir[i] = curdir;
		}
		for(i=0; i<3; i++)
		    qual[i] /= qtot;
		r = frand();
		if(r<qual[0])
		    curdir = dir[0];
		else if(r<(qual[0]+qual[1]))
		    curdir = dir[1];
		else
		    curdir = dir[2];
		*obuf++ = 255.0*curdir;
	    }
	    break;
    }
}
