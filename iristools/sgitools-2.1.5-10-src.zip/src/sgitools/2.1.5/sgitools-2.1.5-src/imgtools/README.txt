Here are IRIS 4D executables.  These are all compressed to save 
space.  ftp them to your machine using binary mode and them
uncompress them using "uncompress"

ALL.tar.Z	- All of the following binary programs.

imp.Z		- a cute little paint program for the IRIS 

enhance.Z	- a general purpose image enhancement program.

fromalias.Z	- convert an Alias image file format to IRIS format
fromeps.Z	- convert an Encapsulated PostScript file to IRIS format (needs Impressario)
fromgif.Z	- convert a GIF iimage to IRIS format
frommac.Z	- convert a MAC Paint file to IRIS format
frompic.Z	- convert a BYU pic image to IRIS format
frompict.Z	- convert a PICT image to IRIS format
fromps.Z	- convert a PostScript doc to IRIS image files (needs Impressario)
fromppm.Z	- convert a PPM image to IRIS format
fromrla.Z	- convert a Wavefront image file to IRIS format
fromsun.Z	- convert a Sun raster file to IRIS format
fromtarga.Z	- convert a TARGA image file to IRIS format
fromtiff.Z	- convert a TIFF image file to IRIS format
fromutah.Z	- convert a UTAH raster toolkit image to IRIS format v2.4
fromxbm.Z	- convert an X bitmap to IRIS format
fromxwd.Z	- convert an X window dump file to IRIS format
fromyuv.Z	- convert an Abekas YUV digital video image to IRIS format

toalias.Z	- convert an IRIS image to Alias format
togif.Z		- convert an IRIS image to GIF format
tomac.Z		- convert an IRIS image to Mac Paint format
topict.Z	- convert an IRIS image to Mac PICT format
toppm.Z		- convert an IRIS image to PPM format
tops.Z		- convert an IRIS image to PostScript format
tosun.Z		- convert an IRIS image to Sun rasterfile format
totarga.Z	- convert an IRIS image to TARGA format
totiff.Z	- convert an IRIS image to TIFF format v2.4
toutah.Z	- convert an IRIS image to Utah raster toolkit format
toxbm.Z		- convert an IRIS image to X Bitmap  format
toxpm.Z		- convert an IRIS image to XPM format
toyuv.Z		- convert an IRIS image to Abekas YUV digital video format

unframe.Z	- remove extra space from around an image

psview.Z	- a minimal PostScript previewer (needs impressario)

This software is provided without support and without any obligation on the
part of Silicon Graphics, Inc. to assist in its use, correction, modification 
or enhancement.  There is no guarantee that this software will be included 
in future software releases.

THIS SOFTWARE IS PROVIDED "AS IS" WITH NO WARRANTIES OF ANY KIND INCLUDING THE
WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
