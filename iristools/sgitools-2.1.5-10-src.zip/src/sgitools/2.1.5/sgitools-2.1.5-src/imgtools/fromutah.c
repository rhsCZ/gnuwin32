/* 
 * 	fromutah -
 *		Convert a UTAH raster toolkit image into an IRIS image.
 *
 *				Paul Haeberli - 1988
 */
#include "stdio.h"
#include "image.h"
#include "rle.h"

short sbuf[4096];

rle_hdr hdr;

main(argc,argv)
int argc;
char *argv[];
{
    unsigned char *rows[3];
    int i, y, xsize, ysize;
    IMAGE *oimage;
    FILE *infile;

/* get args */
    if(argc<3) {
	fprintf(stderr,"usage: fromutah in.rle outimage.rgb\n");
	exit(1);
    }

/* open the input file */
    infile = fopen(argv[1],"r");
    if(!infile) {
	fprintf(stderr,"fromutah: can't open input file %s\n",argv[1]);
	exit(1);
    }
    hdr.rle_file = infile;
    if(rle_get_setup(&hdr)<0) {
	fprintf(stderr,"fromutah: error reading rle header\n");
	exit(1);
    }
    RLE_CLR_BIT(hdr,RLE_ALPHA);
    if(hdr.ncolors != 3) {
	fprintf(stderr,"fromutah: input image must have 3 channels\n");
	exit(1);
    }
/* get the size */
    xsize = hdr.xmax-hdr.xmin+1;
    ysize = hdr.ymax-hdr.ymin+1;

/* open the output file */
    oimage = iopen(argv[2],"w",RLE(1),3,xsize,ysize,3);

/* allocate row buffers */
    rows[0] = (unsigned char*)malloc(xsize);
    rows[1] = (unsigned char*)malloc(xsize);
    rows[2] = (unsigned char*)malloc(xsize);

/* copy the image data */
    for(y=0; y<ysize; y++) {
	rle_getrow( &hdr, rows );
	ctos(rows[0],sbuf,xsize);
	putrow(oimage,sbuf,y,0);
	ctos(rows[1],sbuf,xsize);
	putrow(oimage,sbuf,y,1);
	ctos(rows[2],sbuf,xsize);
	putrow(oimage,sbuf,y,2);
    }

/* close the output file */
    iclose(oimage);
    exit(0);
}
