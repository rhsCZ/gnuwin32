/*
 *	tobw - 
 *		Convert a color image into a b/w image by combining the 
 *		three bands. Check lum.h to see contributions"
 *
 *				Paul Haeberli - 1985
 */
#include "math.h"
#include "image.h"

short	rbuf[8192];
short	gbuf[8192];
short	bbuf[8192];
short	obuf[8192];
int newwgt;
float rwgt, gwgt, bwgt, div;

main(argc,argv)
int argc;
char **argv;
{
    IMAGE *iimage, *oimage;
    unsigned int xsize, ysize;
    unsigned int y;

    if( argc<3 ) {
	fprintf(stderr,"usage: tobw inimage.rgb outimge.bw [rwgt gwgt bwgt]\n");
	exit(1);
    } 
    if(argc>=6) {
	rwgt = atof(argv[3]);
	gwgt = atof(argv[4]);
	bwgt = atof(argv[5]);
	div = rwgt+gwgt+bwgt;
	if(div<0.001 && div>-0.001) {
	    fprintf(stderr,"tobw: bad weights\n");
	    exit(1);
	}
	newwgt = 1;
    }
    if( (iimage=iopen(argv[1],"r")) == NULL ) {
	fprintf(stderr,"tobw: can't open input file %s\n",argv[1]);
	exit(1);
    }
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    oimage = iopen(argv[2],"w",RLE(1),2,xsize,ysize); 
    for(y=0; y<ysize; y++) {
	if(iimage->zsize<3) {
	    getrow(iimage,obuf,y,0);
	} else {
	    getrow(iimage,rbuf,y,0);
	    getrow(iimage,gbuf,y,1);
	    getrow(iimage,bbuf,y,2);
	    if(newwgt)
		myrgbrowtobw(rbuf,gbuf,bbuf,obuf,xsize);
	    else
		rgbrowtobw(rbuf,gbuf,bbuf,obuf,xsize);
	}
	putrow(oimage,obuf,y,0);
    }
    iclose(oimage);
    exit(0);
}

myrgbrowtobw(rbuf,gbuf,bbuf,obuf,n)
unsigned short *rbuf, *gbuf, *bbuf, *obuf;
int n;
{
    float r;

    while(n--) {
	r = (rwgt*(*rbuf++)+gwgt*(*gbuf++)+bwgt*(*bbuf++))/div;
	if(r<0)
	    r = 0;
	if(r>255)
	    r = 255;
	*obuf++ = r+0.499;
    } 
}
