/*
 *	encode - 
 *		Classify an image.  Chose colors from a specified
 *	color map.
 *
 *				Paul Haeberli - 1987
 */
#include "image.h"
#include "vect.h"
#include "cmap.h"
#include "lum.h"

short rbuf[4096];
short gbuf[4096];
short bbuf[4096];

cmap *map;
int rerr, gerr, berr;
int weight;

main(argc,argv)
int argc;
char **argv;
{
    IMAGE *iimage, *oimage;
    unsigned int xsize, ysize, zsize;
    unsigned int y, z;

    if( argc<4 ) {
	fprintf(stderr,"usage: encode inimage.rgb outimage.rgb quant.map [-w]\n");
	exit(1);
    } 
    if(argc==5)
	weight = 1;
    if( (iimage=iopen(argv[1],"r")) == NULL ) {
	fprintf(stderr,"%s: can't open input file %s\n",argv[0],argv[1]);
	exit(1);
    }
    map = readcmap(argv[3]);
    xsize = iimage->xsize;
    ysize = iimage->ysize;
    zsize = iimage->zsize;
    oimage = iopen(argv[2],"w",RLE(1),iimage->dim,xsize,ysize,iimage->zsize); 
    for(y=0; y<ysize; y++) {
	if(zsize<3) {
	    getrow(iimage,rbuf,y,0);
	    getrow(iimage,gbuf,y,0);
	    getrow(iimage,bbuf,y,0);
	} else {
	    getrow(iimage,rbuf,y,0);
	    getrow(iimage,gbuf,y,1);
	    getrow(iimage,bbuf,y,2);
	}
	doit(rbuf,gbuf,bbuf,xsize,y);
	if(y == 0) 
	    addtable(rbuf,gbuf,bbuf,xsize);
	putrow(oimage,rbuf,y,0);
	putrow(oimage,gbuf,y,1);
	putrow(oimage,bbuf,y,2);
	rerr = gerr = berr = 0;
    }
    iclose(oimage);
    exit(0);
}

doit(rbuf,gbuf,bbuf,n)
register unsigned short *rbuf, *gbuf, *bbuf;
register int n;
{
    while(n--)
	encode(rbuf++,gbuf++,bbuf++);
}

addtable(r,g,b,n)
short *r, *g, *b;
int n;
{
    int i, start;

    start = (n-map->ncolors)/2;
    if(start<0)
	start = 0;
    if(start>0) {
	r[start-1] = 0;
	g[start-1] = 0;
	b[start-1] = 0;
    }
    for(i=start; i<start+map->ncolors; i++) {
	r[i] = map->r[i-start];
	g[i] = map->g[i-start];
	b[i] = map->b[i-start];
    }
    r[i] = 0;
    g[i] = 0;
    b[i] = 0;
}

cdist(r0,g0,b0,r1,g1,b1)
int r0,g0,b0,r1,g1,b1;
{
    register int dist, dr, dg, db;

    if(weight) {
	dr = RINTLUM*(r0-r1);
	dg = GINTLUM*(g0-g1);
	db = BINTLUM*(b0-b1);
    } else {
        dr = 100*(r0-r1);
        dg = 100*(g0-g1);
        db = 100*(b0-b1);
    }
    dist = 0;
    if(dr<0) 
	dist -= dr;
    else
	dist += dr;
    if(dg<0) 
	dist -= dg;
    else 
	dist += dg;
    if(db<0) 
	dist -= db;
    else 
	dist += db;
    return dist;
}

#define THRESH	10

encode(r,g,b)
unsigned short *r, *g, *b;
{
    int i, min, dist, slot;
    int rwant, gwant, bwant;
    short *rtab, *gtab, *btab;

    slot = 0;
    min = 1000000;
    rwant = *r + rerr;
    gwant = *g + gerr;
    bwant = *b + berr;
    rtab = map->r;
    gtab = map->g;
    btab = map->b;
    for(i=0; i<map->ncolors; i++) {
	dist = cdist(rwant,gwant,bwant,
				 rtab[i],gtab[i],btab[i]);
	if(dist<min) {
	    min = dist;
	    slot = i;
	}
    }
    *r = rtab[slot];
    *g = gtab[slot];
    *b = btab[slot];
#ifdef DITHER
    rerr = (rwant-*r);
    gerr = (gwant-*g);
    berr = (bwant-*b);
    if(rerr>-THRESH && rerr<THRESH)
	rerr = 0;
    if(gerr>-THRESH && gerr<THRESH)
	gerr = 0;
    if(berr>-THRESH && berr<THRESH)
	berr = 0;
#endif
}
