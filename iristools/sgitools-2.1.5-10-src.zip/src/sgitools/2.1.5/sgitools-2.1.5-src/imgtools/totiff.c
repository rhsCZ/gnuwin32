/* 
 *	totiff -
 *		Convert a color or black and white IRIS image file into
 *	tiff format.
 *
 *			Paul Haeberli and Sam Leffler - 1990
 *
 */
#include "stdio.h"
#include "image.h"
#include "tiffio.h"

short rbuf[8192];
short gbuf[8192];
short bbuf[8192];
unsigned char obuf[3*8192];

main(argc, argv)
int argc;
char **argv;
{
    TIFF *out;
    IMAGE *image;
    int xsize, ysize, zsize;
    int y;
    char doctext[1024];
    int rowsperstrip;

    if(argc<3) {
	fprintf(stderr,"usage: totiff image.rgb image.tif [-c]\n");
	exit(1);
    }
    image = iopen(argv[1],"r");
    if(!image) {
	fprintf(stderr,"totiff: can't open input image %s\n",argv[1]);
	exit(1);
    }
    xsize = image->xsize;
    ysize = image->ysize;
    zsize = image->zsize;
    out = TIFFOpen(argv[2], "w");
    if (out == NULL) {
	fprintf(stderr,"totiff: can't open output file %s\n",argv[2]);
	exit(1);
    }
    if(zsize<3) {
	TIFFSetField(out,TIFFTAG_PHOTOMETRIC,PHOTOMETRIC_MINISBLACK);
	TIFFSetField(out,TIFFTAG_SAMPLESPERPIXEL,1);
	sprintf(doctext,"color iris image file named %s",argv[1]);
    } else {
	TIFFSetField(out,TIFFTAG_PHOTOMETRIC,PHOTOMETRIC_RGB);
	TIFFSetField(out,TIFFTAG_SAMPLESPERPIXEL,3);
	sprintf(doctext,"color iris image file named %s",argv[1]);
    }
    TIFFSetField(out,TIFFTAG_IMAGEWIDTH,xsize);
    TIFFSetField(out,TIFFTAG_IMAGELENGTH,ysize);
    TIFFSetField(out,TIFFTAG_BITSPERSAMPLE,8);
    TIFFSetField(out,TIFFTAG_PLANARCONFIG,PLANARCONFIG_CONTIG);
    if(argc>3) {
        TIFFSetField(out,TIFFTAG_COMPRESSION,COMPRESSION_LZW);
    }
#ifdef DODOC
    TIFFSetField(out,TIFFTAG_IMAGEDESCRIPTION,doctext);
#endif
    TIFFSetField(out,TIFFTAG_ORIENTATION,ORIENTATION_TOPLEFT);
    rowsperstrip = (8*1024)/TIFFScanlineSize(out);
    TIFFSetField(out,TIFFTAG_ROWSPERSTRIP,
	rowsperstrip == 0 ? 1 : rowsperstrip);
    if(zsize<3) {
	for (y=0; y<ysize; y++) {
	    getrow(image,rbuf,image->ysize-1-y,0);
	    stoc(rbuf,obuf,xsize);
	    if (TIFFWriteScanline(out,obuf,y,0) < 0) {
		fprintf(stderr,"totiff: error on write of scanline\n");
		exit(1);
	    }
	}
    } else {
	for (y=0; y<ysize; y++) {
	    getrow(image,rbuf,image->ysize-1-y,0);
	    getrow(image,gbuf,image->ysize-1-y,1);
	    getrow(image,bbuf,image->ysize-1-y,2);
	    compress(rbuf,gbuf,bbuf,obuf,xsize);
	    if (TIFFWriteScanline(out,obuf,y,0) < 0) {
		fprintf(stderr,"totiff: error on write of scanline\n");
		exit(1);
	    }
	}
    }
    TIFFClose(out);
    exit(0);
}

compress(r,g,b,o,n)
short *r, *g, *b;
unsigned char *o;
int n;
{
    while(n--) {
	*o++ = *r++;
	*o++ = *g++;
	*o++ = *b++;
    }
}
