/*
 *	bgpaste - paste an image onto the root screen.
 *
 *			dave ratcliffe and Paul Haeberli - 1991	
 */
#include "gl.h"
#include "device.h"
#include "image.h"
#include "port.h"
#include "dispimg.h"

DISPIMAGE *di;
DISPIMAGE *readit();

int drawit();

static int xorg, yorg;
static int xorig, yorig;
static int resetorg = FALSE;
static int xscreensize, yscreensize;

static int xless = 0;
static int yless = 0;
static int red = 122;
static int gre = 122;
static int blu = 122;

main(argc,argv)
int argc;
char **argv;
{
    int i;

    if( argc<2 ) {
	fprintf(stderr,"usage: bgpaste inimage [-t r g b] [-o xorig yorig]\n");
	exit(1);
    } 

    for(i=1; i<argc; i++) {
        if(strcmp(argv[i],"-t") == 0) {
	    if (argc <6) {
	        fprintf(stderr,"usage: bgpaste inimage [-t r g b] [-o xorig yorig]\n");
		exit(1);
            }
            red = atoi(argv[++i]);
            gre = atoi(argv[++i]);
            blu = atoi(argv[++i]);
        }
        if(strcmp(argv[i],"-o") == 0) {
	    if (argc <5) {
	        fprintf(stderr,"usage: bgpaste inimage [-t r g b] [-o xorig yorig]\n");
		exit(1);
            }
            xorig = atoi(argv[++i]);
            yorig = atoi(argv[++i]);
	    resetorg = TRUE;
        }
    }               
    xscreensize = getgdesc(GD_XPMAX);
    yscreensize = getgdesc(GD_YPMAX);
    di = readit(argv[1]);
    drawfunc(drawit);
}


DISPIMAGE *readit(filename)
char *filename;
{
    register IMAGE *image;
    register DISPIMAGE *di;
    int x1, x2, y1, y2;
    int xdisplen, ydisplen;

/* allocate the display image struct, and open the input file for reading */
    di = (DISPIMAGE *)malloc(sizeof(DISPIMAGE));
    if( (image=iopen(filename,"r")) == NULL ) {
	fprintf(stderr,"paste: can't open input file %s\n",filename);
	exit(1);
    }

/* calculate the image size */
    di->xsize = image->xsize;
    di->ysize = image->ysize;

    if (resetorg) {
	xorg = xorig;
	if (xorig < 0) {
            xdisplen = di->xsize + xorig;
	    x1 = abs(xorig);
	    xorg = 0;
	    if (xdisplen > xscreensize - 1)
	        x2 = (xscreensize + x1) - 1;
	    else {
	        x2 = di->xsize - 1;
    		xless = 0x1;
	    }
	} else {
	    xdisplen = di->xsize;
	    x1 = 0;
	    if (xdisplen > (xscreensize - xorig - 1))
	        xdisplen = xscreensize - xorig;
	    else 
    		xless = 0x2;
	    x2 = xdisplen - 1;
	}
	yorg = yorig;
	if (yorig < 0) {
            ydisplen = di->ysize + yorig;
	    y1 = abs(yorig);
	    yorg = 0;
	    if (ydisplen > yscreensize - 1)
		y2 = (yscreensize + y1) - 1;
	    else {
	        y2 = di->ysize - 1;
		yless = 0x1;
	    }
	    printf("yorig=%d  yorg=%d   ydisplen=%d   y1=%d   y2=%d\n",
	                 yorig,    yorg,       ydisplen,  y1,    y2);
	} else {
	    ydisplen = di->ysize;
	    y1 = 0;
	    if (ydisplen > (yscreensize - yorig - 1)) 
	        ydisplen = yscreensize - yorig;
	    else
    		yless = 0x2;
	    y2 = ydisplen - 1;
	}
    } else {
	if (di->xsize > xscreensize) {
	    x1 = (di->xsize - xscreensize - 1) / 2;
	    x2 = x1 + xscreensize - 1;
	    xorg = 0;
	} else {
	    x1 = 0;
	    x2 = di->xsize - 1;
	    xorg = (xscreensize - di->xsize - 1) / 2;
	    if (di->xsize < xscreensize)
		xless = 0x3;
	}

	if (di->ysize > yscreensize) {
	    y1 = (di->ysize - yscreensize - 1) / 2;
	    y2 = y1 + yscreensize - 1;
	    di->ysize = yscreensize;
	    yorg = 0;
	} else  {
	    y1 = 0;
	    y2 = di->ysize - 1;
	    yorg = (yscreensize - di->ysize) / 2;
	    if (di->ysize < yscreensize)
		yless = 0x3;
	}
    }

/* open the window */
    imakebackground();
    winopen("ipaste");
    subpixel(1);
    wintitle(filename);

/* set the display mode for the image */

    setimagemode(image);
    rgbi(red,gre,blu);
    clear();
    makeframe();
    di = makedisprgn(image, x1, x2, y1, y2, 1, xorg, yorg);
    iclose(image);
    return di;
}

drawit()
{
    makeframe();
    if (xless || yless) {
	rgbi(red, gre, blu);
	if (xless && yless) {
	    rectfi(0,0,xscreensize,yorg);
	    rectfi(0,yorg+di->ysize,xscreensize,yscreensize);
	    rectfi(0,yorg,xorg,yorg+di->ysize);
	    rectfi(xorg+di->xsize,yorg,xscreensize,yorg+di->ysize);
	} else if (xless) {
	    rectfi(0,0,xorg,yscreensize);
	    rectfi(xorg+di->xsize,0,xscreensize,yscreensize);
	} else {
	    rectfi(0,0,xscreensize,yorg);
	    rectfi(0,yorg+di->ysize,xscreensize,yscreensize);
	}
    }
    drawimage(di,xorg,yorg);
}

makeframe()
{
    viewport(0,xscreensize-1,0,yscreensize-1);
    ortho2(-0.5,(float)(xscreensize-0.5),-0.5,(float)(yscreensize-0.5));
}
