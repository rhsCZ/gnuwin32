/*
 * 	toutah - 
 *		Convert a IRIS image to Utah raster toolkit.
 *
 * 				Paul Haeberli - 1990
 */
#include "stdio.h"
#include "image.h"
#include "rle.h"

short rbuf[8192]; 
short gbuf[8192]; 
short bbuf[8192]; 

rle_hdr	hdr;

main(argc,argv)
int argc;
char **argv;
{
    IMAGE *image;
    int i, y, z;
    int xsize, ysize, zsize;
    unsigned char *rows[3];

/* get args */
    if(argc != 3) {
	fprintf(stderr,"usage: toutah inimage.rgb outimage.rgb\n");
	exit(1);
    } 

/* open the input file */
    image=iopen(argv[1],"r");
    if(!image) {
	fprintf(stderr,"toutah: can't open input file %s\n",argv[1]);
	exit(1);
    }
    xsize = image->xsize;
    ysize = image->ysize;
    zsize = image->zsize;

/* open the output file */
    hdr.rle_file = fopen(argv[2],"w");
    if(!hdr.rle_file) {
	fprintf(stderr,"toutah: can't open output file %s\n",argv[2]);
	exit(1);
    }

/* allocate row buffers */
    rows[0] = (unsigned char *)malloc(xsize*sizeof(unsigned char));
    rows[1] = (unsigned char *)malloc(xsize*sizeof(unsigned char));
    rows[2] = (unsigned char *)malloc(xsize*sizeof(unsigned char));

/* set up the header */
    hdr.xmin = 0;
    hdr.xmax = xsize - 1;
    hdr.ymin = 0;
    hdr.ymax = ysize - 1;
    hdr.ncolors = 3;
    hdr.background = 0;
    hdr.alpha = 0;
    hdr.ncmap = 0;
    RLE_SET_BIT(hdr,RLE_RED);
    RLE_SET_BIT(hdr,RLE_GREEN);
    RLE_SET_BIT(hdr,RLE_BLUE);
    rle_put_setup(&hdr);

/* copy image data */
    for(y=0; y<ysize; y++) {
	if(image->zsize<3) {
	    getrow(image,rbuf,y,0);
	    stoc(rbuf,rows[0],xsize);
	    stoc(rbuf,rows[1],xsize);
	    stoc(rbuf,rows[2],xsize);
	} else {
	    getrow(image,rbuf,y,0);
	    getrow(image,gbuf,y,1);
	    getrow(image,bbuf,y,2);
	    stoc(rbuf,rows[0],xsize);
	    stoc(gbuf,rows[1],xsize);
	    stoc(bbuf,rows[2],xsize);
	}
	rle_putrow(rows,xsize,&hdr);
    }

/* close the output file */
    rle_puteof(&hdr);
    exit(0);
}
