#ifndef QUANTDEF
#define QUANTDEF

#include "cmap.h"

void optmapbegin(int ncolors, int mode);
cmap *optmapend( void );
void optmapadd( short *r,  short *g,  short *b, int n);

#endif
