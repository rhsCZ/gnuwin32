#ifndef CMAPDEF
#define CMAPDEF

typedef struct cmap {
    int ncolors;
    int nchans;
    short *r;
    short *g;
    short *b;
    short *a;
} cmap;

cmap *newcmap();
cmap *readcmap();

#endif 
