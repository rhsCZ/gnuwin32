 
#include "image.h"

unsigned short rbuf[8192];
unsigned short gbuf[8192];
unsigned short bbuf[8192];

main(argc,argv)
int argc;
char **argv;
{
    int y;
    int xsize, zsize, ysize;
    IMAGE *inimage;
    IMAGE *outimage;

    if(argc<2) {
	fprintf(stderr,"usage fixdim inimage outimage \n");
	exit(1);
    }

    if( (inimage=iopen(argv[1],"r")) == NULL ) {
        fprintf(stderr,"readimg: can't open input file %s\n",argv[1]);
        exit(1);
    }

    xsize = inimage->xsize;
    ysize = inimage->ysize;
    zsize = inimage->zsize;

    outimage = iopen(argv[2],"w",RLE(1),3,xsize,ysize,zsize);

    for(y=0; y<ysize; y++) {
	/*
		fill rbuf, gbuf, and bbuf with pixel values 
	*/
        getrow(inimage,rbuf,y,0);
        getrow(inimage,gbuf,y,1);
        getrow(inimage,bbuf,y,2);
	putrow(outimage,rbuf,y,0);		/* red row */
	putrow(outimage,gbuf,y,1);		/* green row */
	putrow(outimage,bbuf,y,2);		/* blue row */
 
    }
    iclose(inimage);
    iclose(outimage);
    exit(0);
}
