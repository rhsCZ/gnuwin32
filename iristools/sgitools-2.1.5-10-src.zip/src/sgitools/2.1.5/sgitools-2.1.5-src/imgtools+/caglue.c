/*
 *	caglue - 
 *		Glue together 2 images into a rgb-alpha image
 *
 */
#include "image.h"

short rbuf[8192];
short gbuf[8192];
short bbuf[8192];
short abuf[8192];

main(argc,argv)
int argc;
char **argv;
{
    IMAGE *cimage, *aimage, *oimage;
    unsigned int xsize, ysize;
    unsigned int y;
    int havealpha;

    havealpha = 0;
    if( argc<3 ) {
	printf("usage: caglue image.rgb image.alpha outimage.rgba\n");
	exit(0);
    } 
    if( (cimage=iopen(argv[1],"r")) == NULL ) {
	printf("caglue: can't open input file %s\n",argv[1]);
	exit(0);
    }
    if(cimage->zsize != 3)
    {
	printf("caglue: image %s is not rgb\n", argv[1]);
	exit(0);
    }
    if( (aimage=iopen(argv[2],"r")) == NULL ) {
	printf("caglue: can't open input file %s\n",argv[2]);
	exit(0);
    }
    if(aimage->zsize != 1)
    {
	printf("caglue: image %s is not 1 component\n", argv[2]);
	exit(0);
    }
    
    oimage = iopen(argv[3],"w",RLE(1),3,cimage->xsize,cimage->ysize,4); 

    isetname(oimage,cimage->name);
    ysize = cimage->ysize;
    xsize = cimage->xsize;

    for(y=0; y<ysize; y++) {
	getrow(cimage,rbuf,y,0);
	getrow(cimage,gbuf,y,1);
	getrow(cimage,bbuf,y,2);
	getrow(aimage,abuf,y,0);
	putrow(oimage,rbuf,y,0);
	putrow(oimage,gbuf,y,1);
	putrow(oimage,bbuf,y,2);
	putrow(oimage,abuf,y,3);
    }
    iclose(oimage);
    exit(0);
}
