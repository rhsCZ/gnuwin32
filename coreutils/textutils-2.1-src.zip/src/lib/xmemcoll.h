extern int xmemcoll_exit_failure;
int xmemcoll (char *, size_t, char *, size_t);
