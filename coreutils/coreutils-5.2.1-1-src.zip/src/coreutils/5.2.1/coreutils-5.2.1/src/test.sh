echo '#define LOCALEDIR "c:/progra~1/CoreUtils/share/locale"' >localedir.h-t
cmp localedir.h-t localedir.h > /dev/null 2>&1 && rm -f localedir.h-t || { rm -f localedir.h; mv localedir.h-t localedir.h; }
if gcc -E -DINSTALLDIR=\"c:/progra~1/CoreUtils\"  -DHAVE_CONFIG_H -I. -I../../coreutils-5.2.1-src/src -I..  -I.. -I../../coreutils-5.2.1-src/src -I../../coreutils-5.2.1-src/lib -I../lib -D__GW32__ -D_LARGEFILE_SOURCE=1 -D_LARGEFILE64_SOURCE=1 -D_FILE_OFFSET_BITS=64     -Ie:/progra~1/gnuwin32/include -idirafter h:/glibc/include     -Wall -O3 -fms-extensions -mms-bitfields  -fno-exceptions -fomit-frame-pointer -march=i386 -mcpu=i686   -MT stat.o -MD -MP -MF ".deps/stat.Tpo" -c -o stat.E ../../coreutils-5.2.1-src/src/stat.c; \
then mv -f ".deps/stat.Tpo" ".deps/stat.Po"; else rm -f ".deps/stat.Tpo"; exit 1; fi

