#define LOCALEDIR "c:/progra~1/CoreUtils/share/locale"
