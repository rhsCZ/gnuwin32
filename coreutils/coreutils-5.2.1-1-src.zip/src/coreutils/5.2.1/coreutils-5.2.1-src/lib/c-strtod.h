double c_strtod (char const *, char **);
