#include "timespec.h"
int utimens (char const *, struct timespec const [2]);
