#include <stdbool.h>
bool set_cloexec_flag (int desc, bool value);
