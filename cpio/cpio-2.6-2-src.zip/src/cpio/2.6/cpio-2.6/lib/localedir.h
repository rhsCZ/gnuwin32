#define LOCALEDIR "c:/progra~1/Cpio/share/locale"
#ifndef DEFAULT_RMT_COMMAND
# define DEFAULT_RMT_COMMAND "c:/progra~1/Cpio/libexec/rmt.exe"
#endif
