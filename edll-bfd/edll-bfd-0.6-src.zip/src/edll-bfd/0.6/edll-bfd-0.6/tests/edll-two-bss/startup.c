/* This file is public domain */

/*
 * This file represents an application which at some point in
 * time wants to load a plug-in. It does so using the edll
 * library.
 */

#include	<edll/edll.h>

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>




/* the following are offsets to write in the header of a targa
 * image file format (see http://sswf.sourceforge.net)
 * */
enum targa_header_t {
	TGA_OFFSET_IDENTIFIER_LENGTH = 0,
	TGA_OFFSET_COLORMAP_TYPE,
	TGA_OFFSET_IMAGE_TYPE,			// includes compression flag
	TGA_OFFSET_COLORMAP_INDEX_LO,
	TGA_OFFSET_COLORMAP_INDEX_HI,
	TGA_OFFSET_COLORMAP_LENGTH_LO,
	TGA_OFFSET_COLORMAP_LENGTH_HI,
	TGA_OFFSET_COLORMAP_SIZE,
	TGA_OFFSET_ORIGIN_X_LO,
	TGA_OFFSET_ORIGIN_X_HI,
	TGA_OFFSET_ORIGIN_Y_LO,
	TGA_OFFSET_ORIGIN_Y_HI,
	TGA_OFFSET_WIDTH_LO,
	TGA_OFFSET_WIDTH_HI,
	TGA_OFFSET_HEIGHT_LO,
	TGA_OFFSET_HEIGHT_HI,
	TGA_OFFSET_BITS_PER_PIXEL,
	TGA_OFFSET_FLAGS,

	TGA_HEADER_SIZE			// the size of the targa files header
};



int save_targa(const char *filename, const unsigned char *image,
				int width, int height, const char *name)
{
	unsigned char	header[TGA_HEADER_SIZE];
	char		fullname[256];
	FILE		*f;

	snprintf(fullname, sizeof(fullname), "%s%s.tga", filename, name);

	f = fopen(fullname, "wb");
	if(f == 0) {
		printf("ERROR: cannot open the \"%s\" file to save the image.\n", fullname);
		return -1;
	}

	memset(header, 0, sizeof(header));
	header[TGA_OFFSET_IDENTIFIER_LENGTH] = 0;
	header[TGA_OFFSET_IMAGE_TYPE]        = 2;
	header[TGA_OFFSET_WIDTH_LO]          = (unsigned char) width;
	header[TGA_OFFSET_WIDTH_HI]          = width >> 8;
	header[TGA_OFFSET_HEIGHT_LO]         = (unsigned char) height;
	header[TGA_OFFSET_HEIGHT_HI]         = height >> 8;
	header[TGA_OFFSET_BITS_PER_PIXEL]    = 24;
	header[TGA_OFFSET_FLAGS]             = 0x20;	// top to bottom
	fwrite(header, 1, sizeof(header), f);

	fwrite(image, 1, width * height * 3, f);
	fclose(f);

	return 0;
}



/* in our plug-in, we have a function which prototype is as follow: */
typedef int (*program_t)(int argc, char **argv);

edll_module *run_module(const char *modulename, int bss, const char *name)
{
	edll_module	*module;
	char		filename[256];
	char		*args[3];
	program_t	addr;
	int		r;

	snprintf(filename, sizeof(filename), "%s%s.so", modulename, bss ? "-bss" : "");

/** Now we can load our application **/
	printf("STARTUP: loading plug-in: \"%s\" (%s).\n", filename, modulename);
	module = edll_open(filename);
	if(module == 0) {
		printf("FATAL ERROR: can't load \"%s\". %s\n", modulename, edll_strerror());
		edll_exit();
		exit(1);
	}

/** Get the address of the function we want to run **/
	printf("STARTUP: searching for Program() in plug-in: \"%s\"\n", modulename);
	addr = (program_t) edll_sym(module, "_Program");
	if(addr == 0) {
		printf("FATAL ERROR: can't find the Program() function in module \"%s\". %s\n", modulename, edll_strerror());
		edll_close(module);
		edll_exit();
		exit(1);
	}

	printf("STARTUP: Program() was successfully loaded at 0x%8p\n", addr);

/** Call this function **/
	args[0] = "Program()";
	args[1] = (char *) name;
	args[2] = 0;
	printf("STARTUP: calling Program() from \"%s\"...\n", modulename);
	r = (*addr)(2, args);
	printf("STARTUP: Program() returned with %d...\n", r);

	return module;
}


void close_module(edll_module *module)
{
	int r = edll_close(module);
	if(r != 0) {
		printf("WARNING: there was an error closing the module at %p.\n", module);
	}
}


int main(int argc, char *argv[])
{
	edll_module	*circle_module, *origin_module;
	const char	*name;
	int		i, r, circle_first, late_cleanup, bss;

/** get parameters **/
	circle_first = 1;
	late_cleanup = 0;
	bss = 0;
	name = 0;
	i = 1;
	while(i < argc) {
		if(strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
			printf("startup [-opt] --name <name>");
			printf("  --circle          draw the circle first");
			printf("  --origin          draw the origin first");
			printf("  --late-cleanup    draw both shapes and then cleanup");
			printf("  --bss             run the -bss plugins (vs. COMMON)");
			printf("  --name <name>     name extension to the output targa's");
		}
		else if(strcmp(argv[i], "--circle") == 0) {
			circle_first = 1;
		}
		else if(strcmp(argv[i], "--origin") == 0) {
			circle_first = 0;
		}
		else if(strcmp(argv[i], "--late-cleanup") == 0) {
			late_cleanup = 1;
		}
		else if(strcmp(argv[i], "--bss") == 0) {
			bss = 1;
		}
		else if(strcmp(argv[i], "--name") == 0) {
			i++;
			if(i >= argc) {
				printf("ERROR: missing a parameter to the --name option.\n");
				exit(1);
			}
			name = argv[i];
		}
		i++;
	}

	if(name == 0) {
		printf("ERROR: missing --name parameter, this test requires a name.\n");
		exit(1);
	}

/** Initialize the edll library **/
	if(edll_init() != 0) {
		fprintf(stderr, "FATAL ERROR: can't initialize the dynamic loader library.\n");
		exit(1);
	}

	r = edll_setsearchpath (".");
	if(r != 0) {
		printf("FATAL ERROR: can't setup the search path for the dynamic loader library.\n");
		edll_exit();
		exit(1);
	}

/** load and run the modules **/
	if(circle_first) {
		circle_module = run_module("circle", bss, name);
		if(late_cleanup == 0) {
			close_module(circle_module);
			circle_module = 0;
		}
		origin_module = run_module("origin", bss, name);
	}
	else {
		origin_module = run_module("origin", bss, name);
		if(late_cleanup == 0) {
			close_module(origin_module);
			origin_module = 0;
		}
		circle_module = run_module("circle", bss, name);
	}
	if(circle_module != 0) {
		close_module(circle_module);
	}
	if(origin_module != 0) {
		close_module(origin_module);
	}

/** We're all done, make sure the edll library closes just fine **/

	/*
	 * I don't think we need to remove our module, but
	 * just to make sure it works...
	 */
	r = edll_exit();
	if(r != 0) {
		printf("WARNING: edll_exit() returned %d... 0 was expected.\n", r);
	}

	printf("STARTUP: success!\n");

	return 0;
}

