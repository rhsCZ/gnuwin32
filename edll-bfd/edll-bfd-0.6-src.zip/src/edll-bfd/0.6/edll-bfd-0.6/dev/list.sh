#
# This file is public domain.
#
# Script I used to list all of the symbols available in all the
# different files available in MinGW. You will need MSYS to run
# it.
#


rm -rf list.txt list.tmp

for l in /mingw/lib/*.[ao] /mingw/lib/gcc*/mingw32/*/*.[ao] /mingw/bin/*.dll /mingw/bin/*.lib
do
	echo "****************************************"
	echo "{ $l }"
	objdump -r -d -t $l
	echo "****************************************"
	echo
done >>list.tmp

sed -e 's/\r//g' list.tmp >list.txt

