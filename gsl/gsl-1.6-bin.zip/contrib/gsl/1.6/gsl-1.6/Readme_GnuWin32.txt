GSL may be built using MinGW and ftjam.  
See .\jam\Jamfile for more information on this build option.

GSL may also be built using VC7.
See .\VC7\Readme_VC7.htm for more information on this build option.

