/* Author:  G. Jungman
 * RCS:     $Id: gsl_specfunc.h,v 1.7 2000/03/13 19:47:22 bjg Exp $
 */
	
/* Convenience header */
#ifndef __GSL_SPECFUNC_H__
#define __GSL_SPECFUNC_H__

#include <gsl/gsl_sf.h>

#endif /* __GSL_SPECFUNC_H__ */
