/* Author:  G. Jungman */

	
/* Convenience header */
#ifndef __GSL_SPECFUNC_H__
#define __GSL_SPECFUNC_H__

#include <gsl/gsl_sf.h>

#endif /* __GSL_SPECFUNC_H__ */
