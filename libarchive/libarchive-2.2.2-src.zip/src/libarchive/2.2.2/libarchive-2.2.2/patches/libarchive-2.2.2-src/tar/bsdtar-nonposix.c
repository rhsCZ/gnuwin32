#ifdef _WIN32

#include "archive_platform.h"
#include "libarchive-nonposix.h"

int readlink (const char *path, char *buf, size_t len)
{
	set_errno (ENOSYS);
	return -1;
}

#endif /* _WIN32 */
