/*-
 * Copyright (c) 2003-2007 Tim Kientzle
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR(S) ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "test.h"
__FBSDID("$FreeBSD$");

/*
 * Most of these tests are system-independent, though a few depend on
 * features of the local system.  Such tests are conditionalized on
 * the platform name.  On unsupported platforms, only the
 * system-independent features will be tested.
 *
 * No, I don't want to use config.h in the test files because I want
 * the tests to also serve as a check on the correctness of config.h.
 * A mis-configured library build should cause tests to fail.
 */

DEFINE_TEST(test_entry)
{
	char buff[128];
	wchar_t wbuff[128];
	struct stat st;
	struct archive_entry *e;
	const struct stat *pst;
	unsigned long set, clear; /* For fflag testing. */

	assert((e = archive_entry_new()) != NULL);

	/*
	 * Basic set/read tests for all fields.
	 * We should be able to set any field and read
	 * back the same value.
	 *
	 * For methods that "copy" a string, we should be able
	 * to overwrite the original passed-in string without
	 * changing the value in the entry.
	 *
	 * The following tests are ordered alphabetically by the
	 * name of the field.
	 */
	/* atime */
	archive_entry_set_atime(e, 13579, 24680);
	assertEqualInt(archive_entry_atime(e), 13579);
	assertEqualInt(archive_entry_atime_nsec(e), 24680);
	/* ctime */
	archive_entry_set_ctime(e, 13580, 24681);
	assertEqualInt(archive_entry_ctime(e), 13580);
	assertEqualInt(archive_entry_ctime_nsec(e), 24681);
	/* dev */
	archive_entry_set_dev(e, 235);
	assertEqualInt(archive_entry_dev(e), 235);
	/* devmajor/devminor are tested specially below. */
	/* filetype */
	archive_entry_set_filetype(e, AE_IFREG);
	assertEqualInt(archive_entry_filetype(e), AE_IFREG);
	/* fflags are tested specially below */
	/* gid */
	archive_entry_set_gid(e, 204);
	assertEqualInt(archive_entry_gid(e), 204);
	/* gname */
	archive_entry_set_gname(e, "group");
	assertEqualString(archive_entry_gname(e), "group");
	wcscpy(wbuff, L"wgroup");
	archive_entry_copy_gname_w(e, wbuff);
	assertEqualWString(archive_entry_gname_w(e), L"wgroup");
	memset(wbuff, 0, sizeof(wbuff));
	assertEqualWString(archive_entry_gname_w(e), L"wgroup");
	/* hardlink */
	archive_entry_set_hardlink(e, "hardlinkname");
	assertEqualString(archive_entry_hardlink(e), "hardlinkname");
	strcpy(buff, "hardlinkname2");
	archive_entry_copy_hardlink(e, buff);
	assertEqualString(archive_entry_hardlink(e), "hardlinkname2");
	memset(buff, 0, sizeof(buff));
	assertEqualString(archive_entry_hardlink(e), "hardlinkname2");
	wcscpy(wbuff, L"whardlink");
	archive_entry_copy_hardlink_w(e, wbuff);
	assertEqualWString(archive_entry_hardlink_w(e), L"whardlink");
	memset(wbuff, 0, sizeof(wbuff));
	assertEqualWString(archive_entry_hardlink_w(e), L"whardlink");
	/* ino */
	archive_entry_set_ino(e, 8593);
	assertEqualInt(archive_entry_ino(e), 8593);
	/* link */
	/* TODO: implement these tests. */
	/* mode */
	archive_entry_set_mode(e, 0123456);
	assertEqualInt(archive_entry_mode(e), 0123456);
	/* mtime */
	archive_entry_set_mtime(e, 13581, 24682);
	assertEqualInt(archive_entry_mtime(e), 13581);
	assertEqualInt(archive_entry_mtime_nsec(e), 24682);
	/* nlink */
	archive_entry_set_nlink(e, 736);
	assertEqualInt(archive_entry_nlink(e), 736);
	/* pathname */
	archive_entry_set_pathname(e, "path");
	assertEqualString(archive_entry_pathname(e), "path");
	archive_entry_set_pathname(e, "path");
	assertEqualString(archive_entry_pathname(e), "path");
	strcpy(buff, "path2");
	archive_entry_copy_pathname(e, buff);
	assertEqualString(archive_entry_pathname(e), "path2");
	memset(buff, 0, sizeof(buff));
	assertEqualString(archive_entry_pathname(e), "path2");
	wcscpy(wbuff, L"wpath");
	archive_entry_copy_pathname_w(e, wbuff);
	assertEqualWString(archive_entry_pathname_w(e), L"wpath");
	memset(wbuff, 0, sizeof(wbuff));
	assertEqualWString(archive_entry_pathname_w(e), L"wpath");
	/* rdev */
	archive_entry_set_rdev(e, 532);
	assertEqualInt(archive_entry_rdev(e), 532);
	/* rdevmajor/rdevminor are tested specially below. */
	/* size */
	archive_entry_set_size(e, 987654321);
	assertEqualInt(archive_entry_size(e), 987654321);
	/* symlink */
	archive_entry_set_symlink(e, "symlinkname");
	assertEqualString(archive_entry_symlink(e), "symlinkname");
	strcpy(buff, "symlinkname2");
	archive_entry_copy_symlink(e, buff);
	assertEqualString(archive_entry_symlink(e), "symlinkname2");
	memset(buff, 0, sizeof(buff));
	assertEqualString(archive_entry_symlink(e), "symlinkname2");
	archive_entry_copy_symlink_w(e, L"wsymlink");
	assertEqualWString(archive_entry_symlink_w(e), L"wsymlink");
	/* uid */
	archive_entry_set_uid(e, 83);
	assertEqualInt(archive_entry_uid(e), 83);
	/* uname */
	archive_entry_set_uname(e, "user");
	assertEqualString(archive_entry_uname(e), "user");
	wcscpy(wbuff, L"wuser");
	archive_entry_copy_gname_w(e, wbuff);
	assertEqualWString(archive_entry_gname_w(e), L"wuser");
	memset(wbuff, 0, sizeof(wbuff));
	assertEqualWString(archive_entry_gname_w(e), L"wuser");

	/* Test fflags interface. */
	archive_entry_set_fflags(e, 0x55, 0xAA);
	archive_entry_fflags(e, &set, &clear);
	failure("Testing set/get of fflags data.");
	assertEqualInt(set, 0x55);
	failure("Testing set/get of fflags data.");
	assertEqualInt(clear, 0xAA);
#ifdef __FreeBSD__
	/* Converting fflags bitmap to string is currently system-dependent. */
	/* TODO: Make this system-independent. */
	assertEqualString(archive_entry_fflags_text(e),
	    "uappnd,nouchg,nodump,noopaque,uunlnk");
	/* TODO: Test archive_entry_copy_fflags_text_w() */
#endif

	/* TODO: Test ACL set/get consistency. */


	/* TODO: Test xattrs set/get consistency. */

	/*
	 * TODO: Test clone() implementation.
	 *  1) Set a bunch of values in one entry.
	 *  2) Create a clone
	 *  3) Verify the values in the clone
	 *  4) Change the values in the original
	 *  5) Verify the values are unchanged in the clone
	 *
	 * Note: I'm pretty sure the clone() implementation
	 * is incomplete; the initial implementation here is likely
	 * to find some values not copied and/or some values that
	 * end up shared.  These will need to be fixed, of course.
	 *
	 * TODO: After testing and fixing the clone implementation,
	 * run libarchive_test under a memory debugger to ensure there
	 * are no leaks or double-frees.  It's easy for a clone
	 * implementation to leak.
	 */

	/*
	 * TODO: Test clear() implementation.
	 *  1) Take fully-populated entry from above
	 *  2) invoke clear()
	 *  3) verify that everything has been reset to zero.
	 */

	/*
	 * Test archive_entry_copy_stat().
	 */
	memset(&st, 0, sizeof(st));
	/* Set all of the standard 'struct stat' fields. */
	st.st_atime = 456789;
	st.st_ctime = 345678;
	st.st_dev = 123;
	st.st_gid = 34;
	st.st_ino = 234;
	st.st_mode = 077777;
	st.st_mtime = 234567;
	st.st_nlink = 345;
	st.st_size = 123456789;
	st.st_uid = 23;
#ifdef __FreeBSD__
	/* On FreeBSD, high-res timestamp data should come through. */
	st.st_atimespec.tv_nsec = 6543210;
	st.st_ctimespec.tv_nsec = 5432109;
	st.st_mtimespec.tv_nsec = 3210987;
#endif
	/* Copy them into the entry. */
	archive_entry_copy_stat(e, &st);
	/* Read each one back separately and compare. */
	assertEqualInt(archive_entry_atime(e), 456789);
	assertEqualInt(archive_entry_ctime(e), 345678);
	assertEqualInt(archive_entry_dev(e), 123);
	assertEqualInt(archive_entry_gid(e), 34);
	assertEqualInt(archive_entry_ino(e), 234);
	assertEqualInt(archive_entry_mode(e), 077777);
	assertEqualInt(archive_entry_mtime(e), 234567);
	assertEqualInt(archive_entry_nlink(e), 345);
	assertEqualInt(archive_entry_size(e), 123456789);
	assertEqualInt(archive_entry_uid(e), 23);
#if __FreeBSD__
	/* On FreeBSD, high-res timestamp data should come through. */
	assertEqualInt(archive_entry_atime_nsec(e), 6543210);
	assertEqualInt(archive_entry_ctime_nsec(e), 5432109);
	assertEqualInt(archive_entry_mtime_nsec(e), 3210987);
#endif

	/*
	 * Test archive_entry_stat().
	 */
	/* First, clear out any existing stat data. */
	memset(&st, 0, sizeof(st));
	archive_entry_copy_stat(e, &st);
	/* Set a bunch of fields individually. */
	archive_entry_set_atime(e, 456789, 321);
	archive_entry_set_ctime(e, 345678, 432);
	archive_entry_set_dev(e, 123);
	archive_entry_set_gid(e, 34);
	archive_entry_set_ino(e, 234);
	archive_entry_set_mode(e, 012345);
	archive_entry_set_mode(e, 012345);
	archive_entry_set_mtime(e, 234567, 543);
	archive_entry_set_nlink(e, 345);
	archive_entry_set_size(e, 123456789);
	archive_entry_set_uid(e, 23);
	/* Retrieve a stat structure. */
	assert((pst = archive_entry_stat(e)) != NULL);
	/* Check that the values match. */
	assertEqualInt(pst->st_atime, 456789);
	assertEqualInt(pst->st_ctime, 345678);
	assertEqualInt(pst->st_dev, 123);
	assertEqualInt(pst->st_gid, 34);
	assertEqualInt(pst->st_ino, 234);
	assertEqualInt(pst->st_mode, 012345);
	assertEqualInt(pst->st_mtime, 234567);
	assertEqualInt(pst->st_nlink, 345);
	assertEqualInt(pst->st_size, 123456789);
	assertEqualInt(pst->st_uid, 23);
#ifdef __FreeBSD__
	/* On FreeBSD, high-res timestamp data should come through. */
	assertEqualInt(pst->st_atimespec.tv_nsec, 321);
	assertEqualInt(pst->st_ctimespec.tv_nsec, 432);
	assertEqualInt(pst->st_mtimespec.tv_nsec, 543);
#endif

	/* Changing any one value should update struct stat. */
	archive_entry_set_atime(e, 456788, 0);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_atime, 456788);
	archive_entry_set_ctime(e, 345677, 431);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_ctime, 345677);
	archive_entry_set_dev(e, 122);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_dev, 122);
	archive_entry_set_gid(e, 33);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_gid, 33);
	archive_entry_set_ino(e, 233);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_ino, 233);
	archive_entry_set_mode(e, 012344);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_mode, 012344);
	archive_entry_set_mtime(e, 234566, 542);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_mtime, 234566);
	archive_entry_set_nlink(e, 344);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_nlink, 344);
	archive_entry_set_size(e, 123456788);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_size, 123456788);
	archive_entry_set_uid(e, 22);
	assert((pst = archive_entry_stat(e)) != NULL);
	assertEqualInt(pst->st_uid, 22);
	/* We don't need to check high-res fields here. */

	/*
	 * Test dev/major/minor interfaces.  Setting 'dev' or 'rdev'
	 * should change the corresponding major/minor values, and
	 * vice versa.
	 *
	 * The test here is system-specific because it assumes that
	 * makedev(), major(), and minor() are defined in sys/stat.h.
	 * I'm not too worried about it, though, because the code is
	 * simple.  If it works on FreeBSD, it's unlikely to be broken
	 * anywhere else.  Note: The functionality is present on every
	 * platform even if these tests only run some places;
	 * libarchive's more extensive configuration logic should find
	 * the necessary definitions on every platform.
	 */
#if __FreeBSD__
	archive_entry_set_dev(e, 0x12345678);
	assertEqualInt(archive_entry_devmajor(e), major(0x12345678));
	assertEqualInt(archive_entry_devminor(e), minor(0x12345678));
	assertEqualInt(archive_entry_dev(e), 0x12345678);
	archive_entry_set_devmajor(e, 0xfe);
	archive_entry_set_devminor(e, 0xdcba98);
	assertEqualInt(archive_entry_devmajor(e), 0xfe);
	assertEqualInt(archive_entry_devminor(e), 0xdcba98);
	assertEqualInt(archive_entry_dev(e), makedev(0xfe, 0xdcba98));
	archive_entry_set_rdev(e, 0x12345678);
	assertEqualInt(archive_entry_rdevmajor(e), major(0x12345678));
	assertEqualInt(archive_entry_rdevminor(e), minor(0x12345678));
	assertEqualInt(archive_entry_rdev(e), 0x12345678);
	archive_entry_set_rdevmajor(e, 0xfe);
	archive_entry_set_rdevminor(e, 0xdcba98);
	assertEqualInt(archive_entry_rdevmajor(e), 0xfe);
	assertEqualInt(archive_entry_rdevminor(e), 0xdcba98);
	assertEqualInt(archive_entry_rdev(e), makedev(0xfe, 0xdcba98));
#endif

	/* Release the experimental entry. */
	archive_entry_free(e);
}
