/*
 * Copyright (C) Angus J. C. Duggan 1991-1995
 * See file LICENSE for details.
 */
#define RELEASE 1
#define PATCHLEVEL 17
