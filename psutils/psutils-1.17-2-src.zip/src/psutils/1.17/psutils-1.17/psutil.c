/* psutil.c
 * Copyright (C) Angus J. C. Duggan 1991-1995
 * See file LICENSE for details.
 *
 * utilities for PS programs
 */

/*
 *  AJCD 6/4/93
 *    Changed to using ftell() and fseek() only (no length calculations)
 *  Hunter Goatley    31-MAY-1993 23:33
 *    Fixed VMS support.
 *  Hunter Goatley     2-MAR-1993 14:41
 *    Added VMS support.
 */
#include "psutil.h"
#include "pserror.h"
#include "patchlev.h"

#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef HAVE_LANGINFO_H
#  include <langinfo.h>
#  include <locale.h>
#endif

#define iscomment(x,y) (strncmp(x,y,strlen(y)) == 0)

extern char *program ;
extern int pages;
extern int verbose;
extern FILE *infile;
extern FILE *outfile;
extern char pagelabel[BUFSIZ];
extern int pageno;

#ifdef HAVE_LANGINFO_H
/* When using papertype _glibc we are comparing floating point values. Therefore
 * and because values in the papersize table are not exactly we are needing an
 * epsilon value. */
static float PT_EPSILON = 2.0;

/* The factor needed to convert lengths given in mm to length in pt.*/
static float MM_TO_PT_FACTOR = 72/25.4;
#endif /* HAVE_LANGINFO_H */

static char buffer[BUFSIZ];
static long bytes = 0;
static long pagescmt = 0;
static long headerpos = 0;
static long endsetup = 0;
static long beginprocset = 0;		/* start of pstops procset */
static long endprocset = 0;
static int outputpage = 0;
static int maxpages = 100;
static long *pageptr;

/* list of paper sizes supported */
/* sizes are points (72 * sizes in inch=2.54cm) */
static Paper papersizes[] = {
   { "a0", 2382, 3369 },    /* 84.1cm * 118.8cm */
   { "a1", 1684, 2382 },    /* 59.4cm * 84.1cm */
   { "a2", 1191, 1684 },    /* 42cm * 59.4cm */
   { "a3", 842, 1191 },		/* 29.7cm * 42cm */
   { "a4", 595, 842 },		/* 21cm * 29.7cm */
   { "a5",  421,  595 },    /* 14.85cm * 21cm */
   { "a6",  297,  420 },	/* 10.5cm * 14.85 cm */
   { "a7",  210,  297 },	/* 7.4cm * 10.5cm */
   { "a8",  148,  210 },	/* 5.2cm * 7.4cm */
   { "a9",  105,  148 },	/* 3.7cm * 5.2cm */
   { "a10",  73,  105 },	/* 2.6cm * 3.7cm */
   { "isob0", 2835, 4008 },
   { "b0",    2835, 4008 },	/* 100cm * 141.4cm */
   { "isob1", 2004, 2835 },
   { "b1",    2004, 2835 },	/* 70.7cm * 100cm */
   { "isob2", 1417, 2004 },
   { "b2",    1417, 2004 },	/* 50cm * 70.7cm */
   { "isob3", 1001, 1417 },
   { "b3",    1001, 1417 },	/* 35.3cm * 50cm */
   { "isob4",  709, 1001 },
   { "b4",     709, 1001 },	/* 25cm * 35.3cm */
   { "isob5",  499,  709 },
   { "b5",     499,  709 },	/* 17.6cm * 25cm */
   { "isob6",  354,  499 },
   { "b6",     354,  499 },	/* 12.5cm * 17.6cm */
   { "jisb0", 2920, 4127 }, /* 103.0cm * 145.6cm */
   { "jisb1", 2064, 2920 },	/* 72.8cm * 103.0cm */ 
   { "jisb2", 1460, 2064 },	/* 51.5cm * 72.8cm */  
   { "jisb3", 1032, 1460 },	/* 36.4cm * 51.5cm */  
   { "jisb4",  729, 1032 },	/* 25.7cm * 36.4cm */  
   { "jisb5",  516,  729 },	/* 18.2cm * 25.7cm */  
   { "jisb6",  363,  516 },	/* 12.8cm * 18.2cm */  
   { "c0", 2599, 3677 },	/* 91.7cm * 129.7cm */  
   { "c1", 1837, 2599 },	/* 64.8cm * 91.7cm */  
   { "c2", 1298, 1837 },	/* 45.8cm * 64.8cm */  
   { "c3",  918, 1298 },	/* 32.4cm * 45.8cm */  
   { "c4",  649, 918 },		/* 22.9cm * 32.4cm */  
   { "c5",  459, 649 },		/* 16.2cm * 22.9cm */  
   { "c6",  323, 459 },		/* 11.4cm * 16.2cm */  
   { "A0", 2382, 3369 },    /* 84cm * 118.8cm */
   { "A1", 1684, 2382 },    /* 59.4cm * 84cm */
   { "A2", 1191, 1684 },    /* 42cm * 59.4cm */
   { "A3", 842, 1191 },		/* 29.7cm * 42cm */
   { "A4", 595, 842 },		/* 21cm * 29.7cm */
   { "A5",  421,  595 },     /* 14.85cm * 21cm */
   { "A6",  297,  420 },	/* 10.5cm * 14.85 cm */
   { "A7",  210,  297 },	/* 7.4cm * 10.5cm */   
   { "A8",  148,  210 },	/* 5.2cm * 7.4cm */    
   { "A9",  105,  148 },	/* 3.7cm * 5.2cm */    
   { "A10",  73,  105 },	/* 2.6cm * 3.7cm */    
   { "ISOB0", 2835, 4008 },
   { "B0",    2835, 4008 },	/* 100cm * 141.4cm */
   { "ISOB1", 2004, 2835 },	                     
   { "B1",    2004, 2835 },	/* 70.7cm * 100cm */ 
   { "ISOB2", 1417, 2004 },	                     
   { "B2",    1417, 2004 },	/* 50cm * 70.7cm */  
   { "ISOB3", 1001, 1417 },	                     
   { "B3",    1001, 1417 },	/* 35.3cm * 50cm */  
   { "ISOB4",  709, 1001 },	                     
   { "B4",     709, 1001 },	/* 25cm * 35.3cm */  
   { "ISOB5",  499,  709 },	                     
   { "B5",     499,  709 },	/* 17.6cm * 25cm */  
   { "ISOB6",  354,  499 },	                     
   { "B6",     354,  499 },	/* 12.5cm * 17.6cm */
   { "JISB0", 2920, 4127 },	/* 103.0cm * 145.6cm */
   { "JISB1", 2064, 2920 },	/* 72.8cm * 103.0cm */
   { "JISB2", 1460, 2064 },	/* 51.5cm * 72.8cm */
   { "JISB3", 1032, 1460 },	/* 36.4cm * 51.5cm */
   { "JISB4",  729, 1032 },	/* 25.7cm * 36.4cm */
   { "JISB5",  516,  729 },	/* 18.2cm * 25.7cm */
   { "JISB6",  363,  516 },	/* 12.8cm * 18.2cm */
   { "C0", 2599, 3677 },	/* 91.7cm * 129.7cm */
   { "C1", 1837, 2599 },	/* 64.8cm * 91.7cm */
   { "C2", 1298, 1837 },	/* 45.8cm * 64.8cm */
   { "C3",  918, 1298 },	/* 32.4cm * 45.8cm */
   { "C4",  649, 918 },		/* 22.9cm * 32.4cm */
   { "C5",  459, 649 },		/* 16.2cm * 22.9cm */
   { "C6",  323, 459 },		/* 11.4cm * 16.2cm */
   { "letter", 612, 792 },	/* 8.5in * 11in */
   { "legal", 612, 1008 },	/* 8.5in * 14in */
   { "ledger", 1224, 792 },	/* 17in * 11in */
   { "tabloid", 792, 1224 },	/* 11in * 17in */
   { "statement", 396, 612 },	/* 5.5in * 8.5in */
   { "executive", 540, 720 },	/* 7.6in * 10in */
   { "folio", 612, 936 },	/* 8.5in * 13in */
   { "quarto", 610, 780 },	/* 8.5in * 10.83in */
   { "10x14", 720, 1008 },	/* 10in * 14in */
   { "archE", 2592, 3456 },	/* 34in * 44in */
   { "archD", 1728, 2592 },	/* 22in * 34in */
   { "archC", 1296, 1728 },	/* 17in * 22in */
   { "archB",  864, 1296 },	/* 11in * 17in */
   { "archA",  648,  864 },	/* 8.5in * 11in */
   { "flsa",   612,  936 },  /* U.S. foolscap: 8.5in * 13in */
   { "flse",   612,  936 },  /* European foolscap */
   { "halfletter", 396, 612 }, /* 5.5in * 8.5in */
   { NULL, 0, 0 }
};

void
printsizes (void)
{
	 Paper *pp;
	 for (pp = papersizes; PaperName(pp); pp++) 
	 	printf ("%-10s %5dpt %5dpt %5.1fin %5.1fin %5dmm %5dmm\n",
		PaperName(pp),
		PaperWidth(pp), PaperHeight(pp),
		(double) PaperWidth(pp) / 72, (double) PaperHeight(pp) / 72,
		(int) ((double) PaperWidth(pp) / 72 * 25.4), (int) ((double) PaperHeight(pp) / 72 * 25.4)
		);
	 exit (1);
}

#ifdef HAVE_LANGINFO_H
/* Called if papertype is '_glibc'. It uses the current locale to determine the
 * height and width of the current LC_PAPER and compares it with the items of
 * the 'papersizes' list. */
Paper* findpaperglibc()
{
   float	height, width;
   char		*old_locale = setlocale (LC_PAPER, "");
   Paper	*result = 0, *pp;
  
   height = MM_TO_PT_FACTOR * (unsigned int)(nl_langinfo(_NL_PAPER_HEIGHT));
   width  = MM_TO_PT_FACTOR * (unsigned int)(nl_langinfo(_NL_PAPER_WIDTH));

   for (pp = papersizes; PaperName(pp) && result==0; pp++) {
      if ( abs(PaperWidth(pp)-width)<PT_EPSILON &&
	   abs(PaperHeight(pp)-height)<PT_EPSILON )
	 result = pp;
   }

   setlocale(LC_PAPER, old_locale);

   return result;
}
#endif /* HAVE_LANGINFO_H */

/* return pointer to paper size struct or NULL */
Paper* findpaper(const char *name)
{
   Paper *pp = 0;

#ifdef HAVE_LANGINFO_H   
   if (strcmp(name, "_glibc") == 0) {
      pp = findpaperglibc();
      if (pp==0) name = "a4";	/* Paper in C locale */
   }
#endif /* HAVE_LANGINFO_H */
   
   if (pp==0) {
     for (pp = papersizes; PaperName(pp); pp++) {
       if (strncasecmp(PaperName(pp), name, strlen(PaperName(pp))) == 0) {
	 return pp;
       }
     }
   }

   return pp;
}

/* Make a file seekable, using temporary files if necessary */
FILE *seekable(FILE *fp)
{
#ifndef MSDOS
  FILE *ft;
  long r, w ;
#endif
  char *p;
  char buffer[BUFSIZ] ;
#if defined(WINNT)
  struct _stat fs ;
#else
  struct stat fs;
#endif

#if defined(WINNT)
  if (_fstat(fileno(fp), &fs) == 0 && (fs.st_mode&_S_IFREG) != 0)
    return (fp);
#else
  if (fstat(fileno(fp), &fs) == 0 && S_ISREG(fs.st_mode))
    return (fp);
#endif

#if defined(MSDOS)
  message(FATAL, "input is not seekable\n");
  return (NULL) ;
#else
  if ((ft = tmpfile()) == NULL)
    return (NULL);

  while ((r = fread(p = buffer, sizeof(char), BUFSIZ, fp)) > 0) {
    do {
      if ((w = fwrite(p, sizeof(char), r, ft)) == 0)
	return (NULL) ;
      p += w ;
      r -= w ;
    } while (r > 0) ;
  }

  if (!feof(fp))
    return (NULL) ;

  /* discard the input file, and rewind the temporary */
  (void) fclose(fp);
  if (fseek(ft, 0L, SEEK_SET) != 0)
    return (NULL) ;

  return (ft);
#endif
}


/* copy input file from current position upto new position to output file */
static int fcopy(long upto)
{
  long here = ftell(infile);
  long bytes_left = upto - here;

  while (bytes_left > 0) {
    size_t rw_result;
    const size_t numtocopy = (bytes_left > BUFSIZ) ? BUFSIZ : bytes_left;
    rw_result = fread(buffer, 1, numtocopy, infile);
    if (rw_result < numtocopy) return (0);
    rw_result = fwrite(buffer, 1, numtocopy, outfile);
    if (rw_result < numtocopy) return (0);
    bytes_left -= numtocopy;
    bytes += numtocopy;
  }    
  return (1);
}

/* build array of pointers to start/end of pages */
void scanpages(void)
{
   register char *comment = buffer+2;
   register int nesting = 0;
   register long int record;

   if ((pageptr = (long *)malloc(sizeof(long)*maxpages)) == NULL)
      message(FATAL, "out of memory\n");
   pages = 0;
   fseek(infile, 0L, SEEK_SET);
   while (record = ftell(infile), fgets(buffer, BUFSIZ, infile) != NULL)
      if (*buffer == '%') {
	 if (buffer[1] == '%') {
	    if (nesting == 0 && iscomment(comment, "Page:")) {
	       if (pages >= maxpages-1) {
		  maxpages *= 2;
		  if ((pageptr = (long *)realloc((char *)pageptr,
					     sizeof(long)*maxpages)) == NULL)
		     message(FATAL, "out of memory\n");
	       }
	       pageptr[pages++] = record;
	    } else if (headerpos == 0 && iscomment(comment, "Pages:"))
	       pagescmt = record;
	    else if (headerpos == 0 && iscomment(comment, "EndComments"))
	       headerpos = ftell(infile);
	    else if (iscomment(comment, "BeginDocument") ||
		     iscomment(comment, "BeginBinary") ||
		     iscomment(comment, "BeginFile"))
	       nesting++;
	    else if (iscomment(comment, "EndDocument") ||
		     iscomment(comment, "EndBinary") ||
		     iscomment(comment, "EndFile"))
	       nesting--;
	    else if (nesting == 0 && iscomment(comment, "EndSetup"))
	       endsetup = record;
	    else if (nesting == 0 && iscomment(comment, "BeginProlog"))
	       headerpos = ftell(infile);
	    else if (nesting == 0 &&
		       iscomment(comment, "BeginProcSet: PStoPS"))
	       beginprocset = record;
	    else if (beginprocset && !endprocset &&
		     iscomment(comment, "EndProcSet"))
	       endprocset = ftell(infile);
	    else if (nesting == 0 && (iscomment(comment, "Trailer") ||
				      iscomment(comment, "EOF"))) {
	       fseek(infile, record, SEEK_SET);
	       break;
	    }
	 } else if (headerpos == 0 && buffer[1] != '!')
	    headerpos = record;
      } else if (headerpos == 0)
	 headerpos = record;
   pageptr[pages] = ftell(infile);
   if (endsetup == 0 || endsetup > pageptr[0])
      endsetup = pageptr[0];
}

/* seek a particular page */
void seekpage(int p)
{
   fseek(infile, pageptr[p], SEEK_SET);
   if (fgets(buffer, BUFSIZ, infile) != NULL &&
       iscomment(buffer, "%%Page:")) {
      char *start, *end;
      for (start = buffer+7; isspace(*start); start++);
      if (*start == '(') {
	 int paren = 1;
	 for (end = start+1; paren > 0; end++)
	    switch (*end) {
	    case '\0':
	       message(FATAL, "Bad page label while seeking page %d\n", p);
	    case '(':
	       paren++;
	       break;
	    case ')':
	       paren--;
	       break;
	    }
      } else
	 for (end = start; !isspace(*end); end++);
      strncpy(pagelabel, start, end-start);
      pagelabel[end-start] = '\0';
      pageno = atoi(end);
   } else
      message(FATAL, "I/O error seeking page %d\n", p);
}

/* Output routines. These all update the global variable bytes with the number
 * of bytes written */
void writestring(char *s)
{
   fputs(s, outfile);
   bytes += strlen(s);
}

/* write page comment */
void writepageheader(char *label, int page)
{
   if (verbose)
      message(LOG, "[%d] ", page);
   sprintf(buffer, "%%%%Page: %s %d\n", label, ++outputpage);
   writestring(buffer);
}

/* search for page setup */
void writepagesetup(void)
{
   char buffer[BUFSIZ];
   if (beginprocset) {
      for (;;) {
	 if (fgets(buffer, BUFSIZ, infile) == NULL)
	    message(FATAL, "I/O error reading page setup %d\n", outputpage);
	 if (!strncmp(buffer, "PStoPSxform", 11))
	    break;
	 if (fputs(buffer, outfile) == EOF)
	    message(FATAL, "I/O error writing page setup %d\n", outputpage);
	 bytes += strlen(buffer);
      }
   }
}

/* write the body of a page */
void writepagebody(int p)
{
   if (!fcopy(pageptr[p+1]))
      message(FATAL, "I/O error writing page %d\n", outputpage);
}

/* write a whole page */
void writepage(int p)
{
   seekpage(p);
   writepageheader(pagelabel, p+1);
   writepagebody(p);
}

/* write from start of file to end of header comments */
void writeheader(int p)
{
   fseek(infile, 0L, SEEK_SET);
   if (pagescmt) {
      if (!fcopy(pagescmt) || fgets(buffer, BUFSIZ, infile) == NULL)
	 message(FATAL, "I/O error in header\n");
      sprintf(buffer, "%%%%Pages: %d 0\n", p);
      writestring(buffer);
   }
   if (!fcopy(headerpos))
      message(FATAL, "I/O error in header\n");
}

/* write prologue to end of setup section excluding PStoPS procset */
int writepartprolog(void)
{
   if (beginprocset && !fcopy(beginprocset))
      message(FATAL, "I/O error in prologue\n");
   if (endprocset)
      fseek(infile, endprocset, SEEK_SET);
   writeprolog();
   return !beginprocset;
}

/* write prologue up to end of setup section */
void writeprolog(void)
{
   if (!fcopy(endsetup))
      message(FATAL, "I/O error in prologue\n");
}

/* write from end of setup to start of pages */
void writesetup(void)
{
   if (!fcopy(pageptr[0]))
      message(FATAL, "I/O error in prologue\n");
}

/* write trailer */
void writetrailer(void)
{
   fseek(infile, pageptr[pages], SEEK_SET);
   while (fgets(buffer, BUFSIZ, infile) != NULL) {
      writestring(buffer);
   }
   if (verbose)
      message(LOG, "Wrote %d pages, %ld bytes\n", outputpage, bytes);
}

/* write a page with nothing on it */
void writeemptypage(void)
{
   if (verbose)
      message(LOG, "[*] ");
   sprintf(buffer, "%%%%Page: * %d\n", ++outputpage);
   writestring(buffer);
   if (beginprocset)
      writestring("PStoPSxform concat\n");
   writestring("showpage\n");
}

