#!/bin/sh

./.libs/pngtest ${srcdir}/pngtest.png
