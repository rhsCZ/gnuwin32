#ifndef _CYRIX_H
#define _CYRIX_H
void decode_Cyrix_TLB (int);
#endif /* _CYRIX_H */
