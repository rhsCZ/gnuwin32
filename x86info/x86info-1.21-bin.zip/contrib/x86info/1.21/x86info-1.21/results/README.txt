Add results of 'x86info -a -v' here.
Note, the runs should be done as root,
and with the MSR/CPUID modules loaded/built-in.

