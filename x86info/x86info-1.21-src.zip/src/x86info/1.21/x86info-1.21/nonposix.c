
#ifdef _WIN32
#include <errno.h>
#include <unistd.h>
#include <windows.h>

int getuid ()
{
	return 0;
}

static int
get_nprocs ()
{
	SYSTEM_INFO SysInfo;
	ZeroMemory(&SysInfo, sizeof(SYSTEM_INFO));
	GetSystemInfo(&SysInfo);
	return SysInfo.dwNumberOfProcessors;
}

int sysconf (int name)
{
	switch (name) {
	default:
		errno = EINVAL;
		return -1;
		break;

	case _SC_NPROCESSORS_ONLN:
		return get_nprocs ();
		break;
	}
}

#endif /* _WIN32 */

