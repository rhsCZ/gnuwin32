#ifndef _UNISTD_H
#define _UNISTD_H 1


#ifdef _WIN32

#define _SC_NPROCESSORS_ONLN 1

extern int getuid ();
extern int sysconf (int name);

#endif /* _WIN32 */

#endif /*  _UNISTD_H */
