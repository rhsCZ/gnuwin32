#
# Configuration file for using the LIBART library in GNOME applications
#
LIBART_LIBDIR="-Lc:/progra~1/LibArt/lib"
LIBART_LIBS="-lart_lgpl"
LIBART_INCLUDEDIR="-Ic:/progra~1/LibArt/include"
