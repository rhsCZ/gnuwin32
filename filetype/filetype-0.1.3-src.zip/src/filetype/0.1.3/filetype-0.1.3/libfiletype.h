/*
	Filetype Library headers - include this file into any programs
	which require to use the filetype library functions.

	Author: Paul L Daniels
	Original creation date: Jan 12, 2001
	Date of creation of libfiletype: 15 Jan 2003

	Licence of code : BSD

*/


// Special tokens and values used to deal with the parsing of
//		text form spec lists
#define FILETYPE_NOKEY_TOKEN '-'
#define FILETYPE_NOKEY_VALUE 0


// Special file type item for UNKNOWN files
// Type-testing routine test-choice types

#define _FILETYPE_TYPETEST_TOKENS 1
#define _FILETYPE_TYPETEST_BYTES 0
#define _FILETYPE_UNKNOWN -2

#define _FILETYPE_SPECIAL_ASCII_TEXT "ASCII Text"
#define _FILETYPE_SPECIAL_ID_ASCII_TEXT 30000

#define _FILETYPE_SPECIAL_BINARY_UNKNOWN "Unknown Binary"
#define _FILETYPE_SPECIAL_ID_BINARY_UNKNOWN 30001

#define _FILETYPE_SPECIAL_DIRECTORY "Directory"
#define _FILETYPE_SPECIAL_ID_DIRECTORY 30002

// String length maximums

#define _FILETYPE_STRLEN_MAX 1023
#define _FILETYPE_TT_STRLEN_MAX 128
#define _FILETYPE_TTG_STRLEN_MAX 20


	// This is a binary file record structure, so, please don't alter the
	//	ordering of the fields else this will result in the binary data being
	//	read back being turned into utter garbage ( well, some variables ).

struct FILETYPE_typerec {
	int key;		// Unique Key for this record
	int status;		//
	int use;		// Is this record active
	int offset;		// How far into the file do we go to start the test
	int testtype;	// Which test do we use ( for the byte pattern )
	int testlen;	// How long is the byte pattern
	int dummy1;	// Unused ( at this point )
	int dummy2; // Unused ( at this point )

	unsigned char testfor[_FILETYPE_TT_STRLEN_MAX+1];	// Byte pattern to search for

	char group1[_FILETYPE_TTG_STRLEN_MAX+1];	// Short string for a quick group name, ie, EXECUTABLES
	char group2[_FILETYPE_TTG_STRLEN_MAX+1];	// Short string for a quick group name, ie, EXECUTABLES
	char group3[_FILETYPE_TTG_STRLEN_MAX+1];	// Short string for a quick group name, ie, EXECUTABLES
	char name[_FILETYPE_TTG_STRLEN_MAX+1];		// Final unique name detailing the filetype
	char full[(_FILETYPE_TTG_STRLEN_MAX *4)+1]; // Precompiled descriptor
	char comment[_FILETYPE_TT_STRLEN_MAX+1];	// Any comments on this file type.
	};



	// Global variables structure
	//
	// They tell us never to have global variables, which I agree with,
	//	however, instead, I use a global structure packed with all the
	//	variables which I don't feel like passing between various functions.
	//
	// Ultimately, it's just simpler to pass a single pointer to a function
	//	knowing it'll always contain all the needed variables.  This means that
	//	should you ever wish to add another global, it's as simple as adding it
	//	into here, no need to break your API's or headers.

#define FILETYPE_TYPES_MAXIMUM 10000
#define FILETYPE_BLOCKS_MAXIMUM 100

struct FILETYPE_globals {

	int debug;				// Is debugging active, if so, what level
	int verbose;			// Talk as we walk
	int testblock_count;	// How many filetypes we have in the array
	int type_highestkey;	// The highest key value we have in the array ( the key is assigned by the user )
	int maxtestoffset;		// The maximum offset amongst all our filetypes - we use this to know how much to allocate in a file-read.

	struct FILETYPE_typerec *testblock[ FILETYPE_TYPES_MAXIMUM ];	// The filetype array - contains all the filetypes.

	int loaded_block_count;	// How many filetype list blocks have been loaded into memory
	struct FILETYPE_typerec *loaded_blocks[ FILETYPE_BLOCKS_MAXIMUM ]; // Contains the pointers as allocated by malloc for the filetypes
};






	// Constructors and destructors

int FILETYPE_init( void );
int FILETYPE_done( void );

	// Database IO calls

int FILETYPE_readb( char *fname );
int FILETYPE_writeb( char *fname );
int FILETYPE_import_list( char *fname );
int FILETYPE_clear( void );
int FILETYPE_sort_types( void );

	// Global information calls

int FILETYPE_get_typecount( void );

	// type information calls

struct FILETYPE_typerec *FILETYPE_get_details( int key );
int FILETYPE_get_key( int index );
int FILETYPE_get_name( char *buffer, int buffer_len, int key );
int FILETYPE_get_comment( char *buffer, int buffer_len, int key );
int FILETYPE_get_arrayindex( int key );
int FILETYPE_get_startindexbytypename( char *typename );


struct FILETYPE_typerec *FILETYPE_get_details_by_index( int index );
int FILETYPE_get_name_by_index( char *buffer, int buffer_len, int index );
int FILETYPE_get_comment_by_index( char *buffer, int buffer_len, int index );
int FILETYPE_get_fullclass_by_index( char *buffer, int buffer_len, int index );


	// Low-level testing calls

int FILETYPE_test_text(char *buffer, int bufsize, struct FILETYPE_typerec *test );
int FILETYPE_test_binary(unsigned char *buffer,  int bufsize, struct FILETYPE_typerec *test );
int FILETYPE_is_binary( char *filename );
int FILETYPE_is_filetype( char *filename, int typeindex );

	// This is our key function - returns the filetype key which represents what libfiletype thinks the file is
int FILETYPE_get_filetype( char *filename );

	// Tells us if the file is of the filetype we're looking for
	//		This call is slightly different than _is_filetype(), because it's a 
	//		more generic test against the filetype name, rather than actually 
	//		matching a single filetype.  Consequently, this function is slower
	//		to run than _is_filetype().
int FILETYPE_is_file_of_type( char *filename, char *filetype );


	// Custom output functions
int FILETYPE_generate_www_option_list( char *varname, char *whichkey );

	// Debugging calls.

int FILETYPE_set_verbose( int level );
int FILETYPE_set_debug( int level );
int FILETYPE_get_debug( void );
int FILETYPE_dump( void );




/*--------END*/

