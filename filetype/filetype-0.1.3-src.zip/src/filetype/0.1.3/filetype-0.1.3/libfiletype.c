#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef WIN32
#include <unistd.h>
#endif

#include "pldstr.h"
#include "logger.h"

#include "libfiletype.h"

//Win32 replacements for UNIX stat S_ISDIR/_ISREG() macros
//	05-03-03:Karl-Heinz Bussian
#ifndef S_ISREG
#  define S_ISDIR(x) (((x) & _S_IFDIR) == _S_IFDIR)
#  define S_ISREG(x) (((x) & _S_IFREG) == _S_IFREG)
#endif

#ifdef WIN32
#	define FOPEN_READ_BINARY "rb"
#	define FOPEN_WRITE_BINARY "wb"
#else
#	define FOPEN_READ_BINARY "r"
# 	define FOPEN_WRITE_BINARY "w"
#endif



/*------------------------------------------------------------------------
Module:        /extra/development/xamime/xamime_working/libfiletype/libfiletype.c
Author:        Paul L Daniels
Project:       Xamime
State:         Beta
Creation Date: 10-01-2003
Description:   libfiletype is a core library in the Xamime application.
Its purpose is to identify the 'type' of a given file ( or set of files ).
libfiletype does this by comparing a user defined list of signatures against the
required file until it [possibly] finds a match.
------------------------------------------------------------------------*/





#ifndef FL
#define FL __FILE__,__LINE__
#endif
#define FILETYPE_DEBUG (glb->debug > 0)
#define FILETYPE_VERBOSE (glb->verbose > 0)


/* FILETYPE_hexconv is used to provide direct hex->decimal conversions.  While this could also
	have been done using a cute little bit of math and bit twisting, I suspect it'd take more
	than 256bytes overall to have such a function call or macro implemented.  Instead, we'll
	just use  foo = FILETYPE_hexconv[ highbyte ]*16 +FILETYPE_hexconv[ lowbyte ];
 */

static unsigned char FILETYPE_hexconv[256]={
	0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    0,    0,    0,    0,    0,    0,\
		0,   10,   11,   12,   13,   14,   15,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,   10,   11,   12,   13,   14,   15,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,\
		0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0 \
};


static struct FILETYPE_globals _glb, *glb = &_glb;



/*------------------------------------------------------------------------
Procedure:     FILETYPE_set_verbose ID:1
Purpose:       Set the filetype level of verbosity
Input:         int level: How verbose to be ( 0 == silent, > 0 == verbose )
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_set_verbose( int level )
{
	if ( level < 0 ) level = 0;

	glb->verbose = level;

	return 0;
}


/*------------------------------------------------------------------------
Procedure:     FILETYPE_set_debug ID:1
Purpose:       Set the internal debug level
Input:         int level: positive integer from 0..N
Output:        none
Errors:        Input value cannot be negative.  Values < 0 will be set to 0.
------------------------------------------------------------------------*/
int FILETYPE_set_debug( int level )
{
	if ( level < 0 ) level = 0;

	glb->debug = level;

	LOGGER_log("%s:%d:FILETYPE_set_debug: Debugging set to '%d'", FL, level );

	return 0;
}


/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_debug ID:1
Purpose:       Get the current debug level
Input:         none
Output:        Returns the current debug level. Value is of range 0..N
Errors:        none
------------------------------------------------------------------------*/
int FILETYPE_get_debug( void )
{
	return glb->debug;
}


/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_typecount ID:1
Purpose:       Get the number of types currently in memory
Input:         none
Output:        returns the number of types currently in memory. Range of 0..N
Errors:        none
------------------------------------------------------------------------*/
int FILETYPE_get_typecount( void )
{
	return glb->testblock_count;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_arrayindex ID:1
Purpose:       Get the internal array index representing the location of the type with the supplied key
Input:         int key : Positive integer
Output:        returns the internal array index of the type. Range of 0..testblock_count-1
Errors:        If key is not found, -1 is returned.
------------------------------------------------------------------------*/
int FILETYPE_get_arrayindex( int key )
{

	int i;
	int rv = -1;

	for (i = 0; i < glb->testblock_count; i++)
	{
		if ( glb->testblock[i]->key == key )
		{
			rv = i;
			break;
		}
	}

	return rv;
}




/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_key ID:1
Purpose:       Get the key value of a type based on its array index
Input:         int index : internal type array index value
Output:        returns a positive integer representing the key value of the type
Errors:        returns -1 if the index was out of range
------------------------------------------------------------------------*/
int FILETYPE_get_key( int index )
{
	if (( index < glb->testblock_count )&&(index >= 0))
	{
		return glb->testblock[index]->key;
	} else {
		return -1;
	}
}





/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_startindexbytypename ID:1
Purpose:       Returns the index in the type array of the first entry matching the full description
as given by the parameter typename.
Input:         char *typename : prefix of the full type name ( as created by combining all the
heirachial names together into a long string )
Output:        returns the array index of the type array of the first item which matched.
Errors:
------------------------------------------------------------------------*/
int FILETYPE_get_startindexbytypename( char *typename )
{
	int i;
	int return_value = -1;
	int slen = strlen( typename );

	/* For every filetype we have in the array, compare its fully composed
		description ( G1:G2:G3:Name ) with the name supplied.  If we have
		a partial match, then we consider it to be a 'hit'
	 */

	for (i = 0; i < glb->testblock_count; i++)
	{
		if (strncmp( typename, glb->testblock[i]->full, slen)==0)
		{
			return_value = i;
			break;
		}
	}

	return return_value;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_finishindexbytypename ID:1
Purpose:       returns the index of the last type in the array which still matches the filetype name critera supplied
Input:         char *typename : full or partial type name to search for
int start : Index to start searching from within the type array ( usually obtained from FILETYPE_get_startindexbytypename() )
Output:        Returns the index representing the last array item matching the typename
Errors:
------------------------------------------------------------------------*/
int FILETYPE_get_finishindexbytypename( char *typename, int start )
{
	int i;
	int slen = strlen( typename );

	i = start;
	while ((i < glb->testblock_count)&&(strncmp(typename,glb->testblock[i]->full,slen)==0)) i++;

	return i;
}






/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_name_by_index ID:1
Purpose:       Copy the filetype name of the type located at filetype
array index 'index' into the string buffer 'buffer'

Input:         char *buffer: preallocated character array
int buffer_len: available space in buffer
int index: filetype array index

Output:        Copies up to buffer_len characters of the filetype's 'name'
as located in the array at index 'index'.

Errors:        If either the index is out of range or the filetype array
location at 'index' is NULL, this function will return -1
------------------------------------------------------------------------*/
int FILETYPE_get_name_by_index( char *buffer, int buffer_len, int index )
{
	int return_code = 0;

	// First check that index is within the valid ranges of
	//		our filetype array

	if (( index >= 0 )&&( index < glb->testblock_count ))
	{
		// Now check to see that the actual record at this location
		//		is valid, if so, then we can copy the name to the buffer

		if ( glb->testblock[ index ] != NULL )
		{
			PLD_strncpy( buffer, glb->testblock[index]->name, buffer_len );
		} else {
			LOGGER_log("FILETYPE_get_name_by_index: WARNING: Filetype array index '%d' is empty", index );
			return_code = -1;
		}
	} else {
		LOGGER_log("FILETYPE_get_name_by_index: WARNING: Index '%d' is out of range 0..%d", index, glb->testblock_count );
		return_code = -1;
	}

	return return_code;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_comment_by_index ID:1
Purpose:       Copy the filetype comment of the type located at filetype array
index 'index' into the string buffer 'buffer'

Input:         char *buffer: preallocated character array
int buffer_len: available space in buffer
int index: filetype array index

Output:        Copies up to buffer_len characters of the filetype's 'comment'
as located in the array at index 'index'.

Errors:        If either the index is out of range or the filetype array location
at 'index' is NULL, this function will return -1
------------------------------------------------------------------------*/
int FILETYPE_get_comment_by_index( char *buffer, int buffer_len, int index )
{

	int return_code = 0;

	// First check to see the index is within the valid range for our
	//		file type array.

	if (( index >= 0 )&&( index < glb->testblock_count ))
	{
		// Next check to see that the record at the array point
		//		is valid, if so, we can proceed to copy the data
		//		into the buffer

		if ( glb->testblock[ index ] != NULL )
		{
			PLD_strncpy( buffer, glb->testblock[index]->comment, buffer_len );
		} else {
			LOGGER_log("FILETYPE_get_comment_by_index: WARNING: Filetype array index '%d' is empty", index );
			return_code = -1;
		}
	} else {
		LOGGER_log("FILETYPE_get_comment_by_index: WARNING: Index '%d' is out of range 0..%d", index, glb->testblock_count );
		return_code = -1;
	}

	return return_code;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_fullclass_by_index ID:1
Purpose:       Copy the filetype fullclass of the type located at filetype array
index 'index' into the string buffer 'buffer'

Input:         char *buffer: preallocated character array
int buffer_len: available space in buffer
int index: filetype array index

Output:        Copies up to buffer_len characters of the filetype's 'comment'
as located in the array at index 'index'.

Errors:        If either the index is out of range or the filetype array location
at 'index' is NULL, this function will return -1
------------------------------------------------------------------------*/
int FILETYPE_get_fullclass_by_index( char *buffer, int buffer_len, int index )
{

	int return_code = 0;

	// First check to see the index is within the valid range for our
	//		file type array.

	if (( index >= 0 )&&( index < glb->testblock_count ))
	{
		// Next check to see that the record at the array point
		//		is valid, if so, we can proceed to copy the data
		//		into the buffer

		if ( glb->testblock[ index ] != NULL )
		{
			PLD_strncpy( buffer, glb->testblock[index]->full, buffer_len );
		} else {
			LOGGER_log("FILETYPE_get_fullclass_by_index: WARNING: Filetype array index '%d' is empty", index );
			return_code = -1;
		}
	} else {
		LOGGER_log("FILETYPE_get_fullclass_by_index: WARNING: Index '%d' is out of range 0..%d", index, glb->testblock_count );
		return_code = -1;
	}

	return return_code;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_typerec
  Returns Type	: struct
  ----Parameter List
  1. *FILETYPE_get_details_by_index( int index , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
struct FILETYPE_typerec *FILETYPE_get_details_by_index( int index )
{

	// First check to see the index is within the valid range for our
	//		file type array.

	if (( index >= 0 )&&( index < glb->testblock_count ))
	{
		// Next check to see that the record at the array point
		//		is valid, if so, we can return the pointer.

		if ( glb->testblock[ index ] != NULL )
		{
			return glb->testblock[index];
		} else {
			LOGGER_log("FILETYPE_get_details_by_index: WARNING: Filetype array index '%d' is empty", index );
			return NULL;
		}
	} else {
		LOGGER_log("FILETYPE_get_fullclass_by_index: WARNING: Index '%d' is out of range 0..%d", index, glb->testblock_count );
		return NULL;
	}

	return NULL;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_get_comment
  Returns Type	: int
  ----Parameter List
  1. char *buffer, 
  2.  int buffer_len, 
  3.  int key , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_get_comment( char *buffer, int buffer_len, int key )
{
	static char ukt[]="Unknown Type";
	int i;

	// If the key is not in range, then mark the comment as
	//		an UNKNOWN type.

	if (key < 0)
	{
		PLD_strncpy( buffer, ukt, buffer_len );
		return -1;
	}

	// If the key is in range, we have to cycle through each filetype
	//		item looking for the one which has the same key.  Unfortunately
	//		this is rather slow and could perhaps be improved upon, fortunately
	//		given the small number of filetypes ( less than 1000 typically )
	//		and infrequent calling ( less than 10 times/second ) it does not
	//		impose a massive load as we're only doing integer comparisons
	//
	// Another possible way out is to create an additional 'array' which is
	//		ordered according to the key, then you could do something like:
	//			comment = filetype_by_key[key]->comment --- for the TODO list.

	for (i = 0; i < glb->testblock_count; i++)
	{
		if ( glb->testblock[i]->key == key )
		{
			PLD_strncpy( buffer, glb->testblock[i]->comment, buffer_len );
			break;
		}
	}

	return 0;
}



/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_get_name
  Returns Type	: int
  ----Parameter List
  1. char *buffer, 
  2.  int buffer_len, 
  3.  int key , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_get_name( char *buffer, int buffer_len, int key )
{
	int i;

	for (i = 0; i < glb->testblock_count; i++)
	{
		if ( glb->testblock[i]->key == key )
		{
			PLD_strncpy( buffer, glb->testblock[i]->name, buffer_len );
			break;
		}
	}

	return 0;
}


/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_typerec
  Returns Type	: struct
  ----Parameter List
  1. *FILETYPE_get_details( int key , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
struct FILETYPE_typerec *FILETYPE_get_details( int key )
{
	int i;
	struct FILETYPE_typerec *p = NULL;

	for (i = 0; i < glb->testblock_count; i++)
	{
		if ( glb->testblock[i]->key == key )
		{
			p = (glb->testblock[i]);
			break;
		}
	}

	return p;
}



/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_readb
  Returns Type	: int
  ----Parameter List
  1. char *fname , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_readb( char *fname )
{
	int result = 0;
	int readcount;
	int i;
	int local_testblock_count;
	int local_max_offset;

	FILE *f;
	struct FILETYPE_typerec t, *p;

	/* Delegated to be in FILETYPE_init() - this is so that we can
		call this function multiple times and 'append' the newly read
		data to the end of the current block

		glb->testblock_count = 0;
		glb->type_highestkey = 0;
	 */

	if ( glb->debug > 0 ) LOGGER_log("%s:%d:FILETYPE_readb: Reading specfile '%s'", FL, fname);
	f = fopen(fname, FOPEN_READ_BINARY);

	if (!f)
	{
		LOGGER_log("%s:%d:FILETYPE_readb: Error: Could not open filetype-spec file '%s' for reading (%s)",FL,fname,strerror(errno));
		return -1;
	}

	// Try to read in the key index
	// 	The key index ( first record ) will tell us how many records
	//		there are in the file ( we hope it's accurate, though we will
	//		check later.

	readcount = fread(&t, sizeof(struct FILETYPE_typerec), 1, f);
	if (readcount != 1)
	{
		LOGGER_log("FILETYPE_readb: Error: Attempted to read 1 record from '%s', but instead got '%d'",fname, readcount);
		fclose(f);
		return -1;
	}

	//	glb->testblock_count = t.key;
	local_testblock_count = t.key;
	//	glb->maxtestoffset = t.offset;
	local_max_offset = t.offset;

	//	LOGGER_log("FILETYPE_readb:%s:%d: Testblock count = %d",__FILE__,__LINE__,testblock_count);

	// Allocate memory for the block
	// and store the location to the loadedblock array so that we can later
	//	free the memory cleanly.

	glb->loaded_blocks[glb->loaded_block_count] = p = malloc( sizeof(struct FILETYPE_typerec) *local_testblock_count );
	if (!p)
	{
		LOGGER_log("FILETYPE_readb: Error: Cannot allocate %d bytes of memory for filetype database",sizeof(struct FILETYPE_typerec) *t.key);
		return -1;
	}

	// Indicate that we've allocated an additional block of memory for filetypes.

	glb->loaded_block_count++;



	// Read in the whole block
	//
	readcount = fread(p, sizeof(struct FILETYPE_typerec), local_testblock_count, f);
	if (readcount != local_testblock_count)
	{
		LOGGER_log("FILETYPE_readb: Error: Attempted to read %d records from '%s', but received %d", local_testblock_count, fname, readcount);
		fclose(f);
		return -1;
	}
	fclose(f);


	// Setup the pointers in the testblock array to point to the items
	// in the newly read in block
	//
	// We offset this from the end of the last [if any] spec file _readb()

	for (i = glb->testblock_count; i < (glb->testblock_count +readcount); i++ )
	{
		glb->testblock[i] = p;
		if (FILETYPE_DEBUG) LOGGER_log("%s:%d:FILETYPE_readb: read type[%d] '%s'", FL, i, p->full);
		p++;
	}

	// Now that we've managed to safely get through the entire load/read process
	//		we can update our global variables to indicate the new limits.

	glb->testblock_count += readcount;
	if (local_max_offset > glb->maxtestoffset) glb->maxtestoffset = local_max_offset;

	//	if (FILETYPE_DEBUG) FILETYPE_dump();
	return result;
}






/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_writeb
  Returns Type	: int
  ----Parameter List
  1. char *fname , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_writeb( char *fname )
{
	int result = 0;
	int i;
	int writecount;
	struct FILETYPE_typerec t;
	FILE *f;

	f = fopen(fname, FOPEN_WRITE_BINARY);

	if (!f)
	{
		LOGGER_log("FILETYPE_writeb: Error: Could not open filetype-spec file '%s' for writing (%s)",fname,strerror(errno));
		return -1;
	}

	// Set and write the index/count keeper record, this makes writing fractionally
	//		slower, but, as an immediate improvement, makes reading substantially faster
	//		as the read operation can read in precisely the required number of
	//		records, rather than having to repeatedly malloc and read

	t.key = glb->testblock_count;
	t.offset = glb->maxtestoffset;
	writecount = fwrite(&t,sizeof(struct FILETYPE_typerec), 1, f);
	if (writecount != 1)
	{
		LOGGER_log("FILETYPE_writeb: Error: Attempted to write 1 record[s], but was only able to write %d", writecount);
		fclose(f);
		return -1;
	}

	// Write the filetype records, one at a time to the filetype file.

	for (i = 0; i < glb->testblock_count; i++)
	{
		writecount = fwrite( glb->testblock[i],sizeof(struct FILETYPE_typerec), 1, f);

		if (writecount != 1)
		{
			LOGGER_log("FILETYPE_writeb: Error: Attempted to write %d records, but was only able to write %d",1, writecount);
			result = -1;
			break;
		}
	}

	fclose(f);

	return result;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_sort_fn
  Returns Type	: int
  ----Parameter List
  1. struct FILETYPE_typerec  **pa, 
  2.  struct FILETYPE_typerec **pb , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_sort_fn( struct FILETYPE_typerec  **pa, struct FILETYPE_typerec **pb )
{
	struct FILETYPE_typerec *a, *b;
	char sa[1024], sb[1024];

	a = *pa;
	b = *pb;

#ifdef NO_SNPRINTF
	sprintf(sa,"%s:%s:%s:%s",a->group1, a->group2, a->group3, a->name);
	sprintf(sb,"%s:%s:%s:%s",b->group1, b->group2, b->group3, b->name);
#else
	// 05-03-03:Karl-Heinz Bussian
	snprintf(sa,sizeof(sa),"%s:%s:%s:%s",a->group1, a->group2, a->group3, a->name);
	snprintf(sb,sizeof(sb),"%s:%s:%s:%s",b->group1, b->group2, b->group3, b->name);
#endif

	return strncmp(sa,sb,sizeof(sa));
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_sort_types
  Returns Type	: int
  ----Parameter List
  1. void , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_sort_types( void )
{
	int result = 0;

	qsort( glb->testblock, glb->testblock_count, sizeof(glb->testblock[0]), (void *)FILETYPE_sort_fn);

	return result;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_import_list
  Returns Type	: int
  ----Parameter List
  1. char *fname , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_import_list( char *fname )
{

	int digitcount;
	char *pin, *gin;
	char *testfor;
	char *sp;
	char ascii[4];
	char line[1025];
	struct PLD_strtok tx;
	struct FILETYPE_typerec *atest;
	FILE *f;

	glb->testblock_count = 0;
	glb->type_highestkey = 0;

	f = fopen(fname,"r");
	if (!f)
	{
		LOGGER_log("FILETYPE_import_list: ERROR: Could not open filetype-spec file '%s'(%s)",fname, strerror(errno));
	}
	else {

		// whilst we still have more types to read in...

		while ( fgets(line, sizeof(line), f) )
		{

			// if the line is not a comment, and it's got more than noise in
			// the line contents

			if ((line[0] != '#') && (strlen(line) > 2))
			{


				// allocate memory for the new name block
				// -NOTE- we assign two pointers at once here
				// bcause it's quicker to type 'atest' rather than
				// testblock[....]

				glb->testblock[glb->testblock_count] = atest = malloc(sizeof(struct FILETYPE_typerec));

				// scan in the details from the file

				// The first field is supposed to be a place
				//		that you can specify an integer-key, however
				//		if you don't want to worry about that, given that
				//		keys will probably be later depricated, we can just
				//		insert a '-' character at the start, so, if we
				//		detect this '-' char, we know to just set the key to
				//		FILETYPE_TYPEREC_NOKEY_VALUE.

				sp = PLD_strtok(&tx, line,":");
				if (sp) {
					if ( *sp == FILETYPE_NOKEY_TOKEN )
					{
						atest->key = FILETYPE_NOKEY_VALUE;
					} else {
						atest->key = atoi(sp);
					}

					sp = PLD_strtok(&tx, NULL,":");
				}

				if (sp) {
					atest->offset = atoi(sp);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					atest->testtype = atoi(sp);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					atest->testlen = atoi(sp);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					PLD_strncpy(atest->group1, sp, _FILETYPE_TTG_STRLEN_MAX+1);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					PLD_strncpy(atest->group2, sp, _FILETYPE_TTG_STRLEN_MAX+1);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					PLD_strncpy(atest->group3, sp, _FILETYPE_TTG_STRLEN_MAX+1);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					PLD_strncpy(atest->name, sp, _FILETYPE_TTG_STRLEN_MAX+1);
					sp = PLD_strtok(&tx, NULL,":");
				}
				if (sp) {
					PLD_strncpy(atest->testfor, sp, _FILETYPE_TT_STRLEN_MAX+1);

					// If we're testing for token sequences, then reduce to lowercase
					//
					if (atest->testtype == _FILETYPE_TYPETEST_TOKENS)
					{
						PLD_strlower(atest->testfor);
					}
					sp = PLD_strtok(&tx, NULL,":\n\r");
				}
				if (sp)
				{
					PLD_strncpy(atest->comment, sp, _FILETYPE_TT_STRLEN_MAX+1);
				}



				// Precompile a full descriptor string.
				//
#ifdef NO_SNPRINTF
				sprintf(atest->full,"%s:%s:%s:%s:%d",atest->group1, atest->group2, atest->group3, atest->name, atest->key);
#else
				snprintf(atest->full,_FILETYPE_TTG_STRLEN_MAX*4,"%s:%s:%s:%s:%d",atest->group1, atest->group2, atest->group3, atest->name, atest->key);
#endif
				// Check to see what our highest Key ID is
				//
				if ((atest->key) > glb->type_highestkey) glb->type_highestkey = (int)((atest->key));


				if (atest->testtype == _FILETYPE_TYPETEST_TOKENS)
				{

					// We dont do anything to the testfor string
					//		with a tokens test
					//

				}
				else
				{

					// now, on a string search, we often have encoded sequences
					// these me must recode back into single-chars
					//

					testfor = atest->testfor;
					atest->testlen = 0;
					gin = pin = testfor;

					while (*gin != '\0')
					{

						if (*gin == '\\')
						{

							// If the next bit is a digit, then we have a decimal
							//	entry which we must decode
							//

							if (isdigit(*(gin+1)))
							{
								if (*(gin+2) == '\\') digitcount = 1;
								else if (*(gin+3) == '\\') digitcount = 2;
								else digitcount = 3;
								memcpy(ascii, gin+1, digitcount);
								// PLD_strncpy(ascii,gin+1,digitcount); - Use memcpy here.
								*pin = (unsigned char)atoi(ascii);
								gin += digitcount+1;
								pin += 1;
							}

							// Else, if we get an 'x' as our next byte, then we
							// have a hexadecimal number to accept in
							//

							else
								if (*(gin+1) == 'x')
								{

									// Hex mode byte

									if ( (isxdigit(*(gin+2))) && (isxdigit(*(gin+3))) )
									{
										*pin = (unsigned char) (((unsigned char)FILETYPE_hexconv[(int)*(gin+2)]<<4) +((unsigned char)FILETYPE_hexconv[(int)*(gin+3)]) );
									}
									else
									{
										*pin = 'x';
										LOGGER_log("FILETYPE_load: Error - Expecting hex digits for input, but instead got %c %c",*(gin+2),*(gin+3));
									}
									gin += 4;
									pin += 1;
								}

							// Else, it's just a desire to escape the next char so that it doesn
							// get interpreted as something specific
							//

								else
								{
									*pin = (unsigned char)*(gin+1);
									gin += 2;
									pin += 1;
								}
						}

						// Else if we had a normal character/digit,then just put it in as well
						//

						else
						{
							*pin = *gin;
							gin += 1;
							pin += 1;
						} // else

						atest->testlen++;
					} // while

					*pin = '\0';

					// Commit file type

					atest->use = 1;

					if ((atest->offset +atest->testlen) > glb->maxtestoffset)
					{
						glb->maxtestoffset = atest->offset +atest->testlen;
					}

				} // If the test-type was BINARY


				// we have to always increment the test-block list counter
				// even if we're not using the particular test
				// this is because we need to refer to the unused items
				// in various programs such as xmadmin
				//

				glb->testblock_count++;

			} // if line wasn't a comment

		} // while

		fclose(f);

	} // if (f)

	//DBG	fprintf(stderr,"MAX_TEST_OFFSET = %d\n",maxtestoffset);

	return 0;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_dump
  Returns Type	: int
  ----Parameter List
  1. void , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_dump( void )
{

	int i;

	for (i = 0; i < glb->testblock_count; i++)
	{
		LOGGER_log("%d:%d:%s:%s:%s:%s - %s",i, glb->testblock[i]->key, glb->testblock[i]->group1, glb->testblock[i]->group2, glb->testblock[i]->group3, glb->testblock[i]->name, glb->testblock[i]->comment);

		if ( glb->testblock[i]->testtype == _FILETYPE_TYPETEST_TOKENS)
		{
			LOGGER_log("TOKENS: %s", glb->testblock[i]->testfor);
		}
	}

	return 0;
}




/*------------------------------------------------------------------------
Procedure:     CLEAR_testblock ID:1
Purpose:       Clears memory used by testblock array
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_clear( void )
{
	int i;

	// To free up all the blocks, we need to cycle through the
	//		loadedblocks pointer array, NOT the testblock array.
	//	This is because the loadedblock array indicates/stores the
	//		memory locations actually allocated by malloc()

	for ( i = 0; i < glb->loaded_block_count; i++ )
	{
		if ( glb->loaded_blocks[i] != NULL )
		{
			free( glb->loaded_blocks[i] );
		}
	}

	return 0;
}









/*------------------------------------------------------------------------
Procedure:     FILETYPE_test_text ID:1
Purpose:       Performs a token-sequence text file detection system.
This is useful for determining if a file is HTML or other
such loose format files. Each sequence is seperated by a
non-escaped caret ^.  The caret is so rarely used that
it can be considerd safe to use as a seperator
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_test_text(char *buffer, int bufsize, struct FILETYPE_typerec *test )
{
	int result = 0;
	int optional = 0;
	int invert = 0;
	struct PLD_strtok x;
	char *p;
	char *t1=buffer;
	char *limit;
	char tft[_FILETYPE_STRLEN_MAX+1];
	char tmpc;

	//	if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: Starting...");

	// If the filetype list says we only need to test
	// 	the first N bytes, then make that our buffer
	//		limit
	//
	if ((test->testlen > 0)&&(test->testlen < bufsize))
	{
		bufsize = test->testlen;
	}

	sprintf(tft, "%s",test->testfor);
	limit = buffer +bufsize;
	tmpc = *limit;
	*limit = '\0';

	//	if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: Looking for %s",tft);

	p = PLD_strtok(&x, tft, "\n\r^");

	result = 1;

	// While there are tags to search...
	while ((p)&&(t1 < limit))
	{
		if (*p == '~') {
			optional=1;
			p++;
		}
		else optional = 0;
		if (*p == '!') {
			invert=1;
			p++;
		}
		else invert = 0;

		//		if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: %s Testing token %s",test->comment,p);
		t1 = strstr(buffer,p);

		if (t1 < limit)
		{
			if ((!t1)||(t1 && invert))
			{
				if (!optional)
				{
					// Tag not found - quit out
					//
					result = -1;
					//					if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: %s Token %s miss :(",test->comment,p);
					break;
				}
				//				else if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: %s Optional token %s missed :\\ ",test->comment,p);
			}
			else
			{
				//				if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: Token %s hit :)",p);
				// Move the start of buffer search space to where t1 is (plus 1)
				//
				buffer = ++t1;
			}

			p = PLD_strtok(&x, NULL, "\n\r^");
		}
	}

	*limit = tmpc;

	//	if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_test_text: __finish.");
	return result;
}





/*------------------------------------------------------------------------
Procedure:     FILETYPE_test_binary ID:1
Purpose:       Tests a given data block to see if the type supplied matches
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_test_binary(unsigned char *buffer,  int bufsize, struct FILETYPE_typerec *test )
{
	int result = 1;
	int offset = test->offset;
	int testlen = test->testlen;
	int stopat = offset +testlen;
	int i, j;
	unsigned char xres;

	if (stopat > bufsize)
	{
		//LOGGER_log("DEBUG:FILETYPE_test_binary:%d: StopAt = %d, Bufsize = %d, Returning",__LINE__,stopat,bufsize);
		return 0;
	}


	for (i = offset, j = 0; i < stopat; i++, j++)
	{

		// if we don't get a match exit immediately, this is
		// not a fuzzy test situation
		//

		// Test to see if we have a AND test to perform...
		//
		if (test->testfor[j] == '&')
		{
			j++;
			stopat--;	// If we have a & char, because it's actually a control char

			// and not a char which is used in the test, we much actually
			// shorten the anticipiated test length by 1 byte

			xres = (unsigned char)( (unsigned char)buffer[i] & (unsigned char)test->testfor[j] );
			//DBG			fprintf(stderr,"FILETYPE_test_binary (%d): AND testing %x AND %x = %x\n",__LINE__,buffer[i],test->testfor[j],xres);

			if (xres != test->testfor[j])
			{
				result = 0;
				break;
			}
		}
		// Else do a normal bit-for-bit test
		///
		else
			if ((unsigned char)buffer[i] != (unsigned char)test->testfor[j])
			{
				result = 0;
				break;
			} // if  testwindow

	} // for i,j

	//DBG	if (result) fprintf(stderr,"FILETYPE_test_binary: Hit for %s\n",test->full);

	return result;
}






/*------------------------------------------------------------------------
Procedure:     FILETYPE_isbinary ID:1
Purpose:       Determines if a file is binary by looking for \0 sequences within the first 10k of a given file.
Input:         char *filename : Name of file to test.
Output:        0 = file was not binary
1 = file is binary
-1 = Error occured in either opening the file, or memory allocation
Errors:
------------------------------------------------------------------------*/
int FILETYPE_is_binary( char *filename )
{
	unsigned char *buffer, *bp;
	int result = 0;
	int bufsize=10240;
	int isbinary=0;
	FILE *f;

	f = fopen(filename, FOPEN_READ_BINARY);
	if (!f)
	{
		LOGGER_log("FILETYPE_isbinary:%d: Cannot open filename '%s' for reading",__LINE__,filename);
		return -1;
	}

	bp = buffer = malloc(bufsize *sizeof(unsigned char));
	if (!buffer)
	{
		LOGGER_log("FILETYPE_isbinary:%d: Cannot allocate %d bytes of memory for file read",__LINE__,bufsize);
		return -1;
	}

	// Read in the first 10k of the file

	result = fread(buffer,1,bufsize,f);

	// While we've not confirmed that this is a binary, keep on
	// searching through the characters.
	//
	// Note - we remove 1 from the file length, this is so that we dont
	// mark a 0-terminated ASCII file as being a binary. This happens with
	// MAPI messages from MS programs (another case of MS stuffing us around
	//

	result--;

	while (result >= 0)
	{
		switch (*bp) {
			case 0:
				isbinary=1;
				break;
				// "Why?" you may ask is there no other case statements in here
				//		well, it's because for now, we're not aware of any other
				//		specific characters which imply a 'binary file'.  However
				//		we want to leave the option of there being other characters
				//		...just incase.
		}
		bp++;
		result--;
	}

	fclose(f);

	if (buffer) free(buffer);
	else LOGGER_log("FILETYPE_isbinary:%d: ERROR, attempting to free buffer, but it's NULL!",__LINE__);

	return isbinary;
}





/*------------------------------------------------------------------------
Procedure:     FILETYPE_is_filetype ID:1
Purpose:       Checks if a filename is of type [typeindex]
filelist.

03 Mar 2003:PLD
This function is no longer really used because of the fact
that the filetype 'typeindex' is not a reliable way of referencing
a given filetype record between processes.  Instead, a replacement
function FILETYPE_isoffiletype() which will use the filetype heirrachy
class to match filetypes.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_is_filetype( char *filename, int typeindex )
{

	int errcode=0;
	int result=0;
	int byteitemsread=0, textitemsread=0;
	unsigned char *testwindow;
	struct FILETYPE_typerec *t;
	char *textbuffer, *p;
	int ftype = -1;
	FILE *f;


	if (FILETYPE_DEBUG) LOGGER_log("FILETYPE_isfiletype: start, Filename = %s filelist, Windowsize = %d",strrchr(filename,'/'), glb->maxtestoffset);

	// allocate memory for our filetype testing

	testwindow = malloc( glb->maxtestoffset+1 );
	if (!testwindow)
	{
		LOGGER_log("FILETYPE_isfiletype: Error: cannot allocate %d bytes for file-type test : %s", glb->maxtestoffset, strerror(errno));
		return -1;
	}

	memset(testwindow,0, glb->maxtestoffset+1);




	// Allocate 10k to a text search buffer space

	textbuffer = malloc( 10240 +1 );
	if (!textbuffer)
	{
		LOGGER_log("FILETYPE_isfiletype: Error: cannot allocate 10240 bytes for file-type test");
		return -1;
	}
	memset(textbuffer,0,10240 +1);


	// get the file name, and open up the file

	f = fopen(filename, FOPEN_READ_BINARY);

	// if the file opened okay, then lets get to work on it
	if (!f)
	{
		LOGGER_log("FILETYPE_isfiletype: Could not open file '%s' for type testing. : %s", filename, strerror(errno));
		return -1;
	}


	// read in the required window-data size
	//

	byteitemsread = fread(testwindow,1, glb->maxtestoffset,f);

	//	LOGGER_log("DEBUG:FILETYPE_isfiletype:%d: Bytes read for binary: %d",__LINE__,byteitemsread);

	if (byteitemsread < 1)
	{
		if (!feof(f))
		{
			errcode = ferror(f);
			LOGGER_log("FILETYPE_isfiletype: Binary Read - Error reading with fread(). Error code returned is %d. We read %d bytes",errcode,byteitemsread);
			return -1;
		}
	}


	// Go back to the start of the file

	rewind(f);



	// Read in the text buffer
	//		NOTE- we had some problems with this code before when setup as
	//		1,10240... so, I'm not sure what happened, but, I've set this
	//		now to 10x 1024 blocks.... it seems to be working good with this
	//		setup.  Just be aware if people start getting "No such file or
	//		directory errors on file reads for type testing in their syslogs
	//

	textitemsread = fread(textbuffer,1,10240,f);
	if (textitemsread < 1)
	{
		if (!feof(f))
		{
			errcode = ferror(f);
			LOGGER_log("FILETYPE_isfiletype: Text read - Error reading with fread(). Error code returned is %d. We read %d bytes",errcode,textitemsread);
			return -1;
		}
	}

	// With some files, we have a hybrid text/binary mix, which plays havoc with
	//		with the strstr() search routines.  So, we quickly go through and
	//		eleminate those.  NOTE - we only start from 1 because we want the
	//		last byte to ALWAYS be \0, so that we dont strstr() beyond the bounds.
	//

	p = textbuffer;
	for (ftype = 1; ftype < textitemsread; ftype++, p++) if (*p == 0) *p=1;
	PLD_strlower(textbuffer);
	ftype = -1;


	fclose(f);


	// Now, lets test to see if the type we asked for is a match.

	t = glb->testblock[typeindex];

	if (!t)
	{
		LOGGER_log("FILETYPE_isfiletype(): Index %d not available for array testblock[]",typeindex);
		return 0;
	}


	// If we have a token-sequence test requirement
	//

	if (t->testtype == _FILETYPE_TYPETEST_TOKENS)
	{
		result = FILETYPE_test_text(textbuffer, textitemsread, t );
	}
	else
	{
		result = FILETYPE_test_binary(testwindow, byteitemsread, t );
	}

	// If we got a positive hit from our tests, then it means we've
	//	found our file type! rejoice by breaking out.
	//

	if (result > 0)
	{
		ftype = typeindex;
		LOGGER_log("DEBUG:%d: Filetype look resulted in a HIT, index = %d",__LINE__,typeindex);
	}


	if (testwindow) free(testwindow);
	if (textbuffer) free(textbuffer);

	return ftype;
}











/*------------------------------------------------------------------------
Procedure:     FILETYPE_isfile ID:1
Purpose:       Determines if the filename given points to a normal file
Input:         char *filename - nul terminated string containing the filename to test normality of.
Output:        returns 0 == Not a normal file,  1 == Is a normal file ( as defined by S_ISREG() in man stat )
Errors:
------------------------------------------------------------------------*/
int FILETYPE_isfile( char *filename )
{
	struct stat st = {1}; // This is really dumb, but valgrind complains if I don't initialize this
	int stat_result = 0;
	int isreg = 0;

	stat_result = stat( filename, &st );

	isreg = S_ISREG(st.st_mode);

	if (isreg != 0)
	{
		stat_result = 1;
	}	else {
	  	stat_result = 0;
	}

	return stat_result;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPE_get_filetype ID:1
Purpose:       Determine the filetype of the file located by the filename supplied
Input:         char *filename: Pointer to a nul terminated char array containing the path to the required file
Output:        returns a signed integer either having a value >= 0 [ implying a filetype match was located
and its information can be located at the filetype array index of the returned value,
ie, filetype[return_value] ].
A return value of -1 indicates that no filetype could be determined.
Errors:
------------------------------------------------------------------------*/
int FILETYPE_get_filetype( char *filename )
{

	int errcode=0;
	int result=0;
	int typeindex=0;
	int byteitemsread=0, textitemsread=0;
	unsigned char *testwindow;
	struct FILETYPE_typerec *t;
	char *textbuffer, *p;
	int ftype = -1;
	FILE *f;

	if (FILETYPE_DEBUG) LOGGER_log("%s:%d:FILETYPE_get_filetype: start, Filename = '%s' filelist, Windowsize = %d", FL, filename, glb->maxtestoffset);

	if ( FILETYPE_isfile( filename ) == 0 )
	{
		if (FILETYPE_VERBOSE) LOGGER_log("%s is not a normal file",filename);
		return -1;
	}

	// allocate memory for our filetype testing
	//		This memory is used for loading in the file data
	//		which we're going to use to check against the array of
	//		filetype signatures we have

	testwindow = malloc( glb->maxtestoffset+1 );
	if (!testwindow)
	{
		LOGGER_log("FILETYPE_get_filetype: ERROR: cannot allocate %d bytes for file-type test : %s", glb->maxtestoffset, strerror(errno));
		return -1;
	}
	memset(testwindow, 0, glb->maxtestoffset+1 );


	// Allocate 10k to a text search buffer space
	//
	// This text search buffer is used to do things like
	//		look for binary character occurances ( '\0' )
	//		and look for string sequences as required by
	//		our filetype array -  This 10K hard limit should
	//		be replaced by something wihch is a little more
	//		'dynamic' otherwise we will run the risk of either
	//		having too much data ( not likely ) or too little
	//		( quite likely, ie, the string we're after occurs
	//		at 11K point in the file ). -- a TODO item.

	textbuffer = malloc( 10240 +1 );
	if (!textbuffer)
	{
		LOGGER_log("FILETYPE_get_filetype: ERROR: cannot allocate 10240 bytes for file-type test");
		return -1;
	}
	memset(textbuffer,0,10240 +1);

	// get the file name, and open up the file
	f = fopen(filename, FOPEN_READ_BINARY);

	// if the file opened okay, then lets get to work on it
	if (!f)
	{
		LOGGER_log("FILETYPE_get_filetype: ERROR: Could not open file '%s' for type testing. : %s", filename, strerror(errno));
		return -1;
	}


	// read in the required window-data size
	//

	byteitemsread = fread(testwindow,1, glb->maxtestoffset,f);

	//	LOGGER_log("DEBUG:FILETYPE_get_filetype:%d: Bytes read for binary: %d",__LINE__,byteitemsread);

	if (byteitemsread < 1)
	{
		if (!feof(f))
		{
			errcode = ferror(f);
			LOGGER_log("FILETYPE_get_filetype: ERROR: Binary Read - Error attempting to read from '%s'. Error code returned is %d. We read %d bytes", filename, errcode, byteitemsread);
			return -1;
		}
	}


	// Go back to the start of the file

	rewind(f);



	// Read in the text buffer
	//		NOTE- we had some problems with this code before when setup as
	//		1,10240... so, I'm not sure what happened, but, I've set this
	//		now to 10x 1024 blocks.... it seems to be working good with this
	//		setup.  Just be aware if people start getting "No such file or
	//		directory errors on file reads for type testing in their syslogs
	//
	//		Eratta: Problem has been solved - the issue was that we were
	//			attempting to load ONE 10K block, rather than 10K of 1byte
	//			blocks.  So, if the file was smaller than 10K the whole read
	//			would fail because fread() cannot read in a fraction of a block.
	//			Thus, by simple swapping the 1 and 10240 around, we solved the
	//			problem.

	textitemsread = fread(textbuffer,1,10240,f);
	if (textitemsread < 1)
	{
		if (!feof(f))
		{
			errcode = ferror(f);
			LOGGER_log("FILETYPE_get_filetype: ERROR: Unable to read data from '%s' Error code returned is %d", filename, errcode);
			return -1;
		}
	}

	// With some files, we have a hybrid text/binary mix, which plays havoc with
	//		with the strstr() search routines.  So, we quickly go through and
	//		eleminate those.  NOTE - we only start from 1 because we want the
	//		last byte to ALWAYS be \0, so that we dont strstr() beyond the bounds.
	//

	p = textbuffer;
	for (typeindex = 1; typeindex < textitemsread; typeindex++, p++) if (*p == 0) *p=1;
	PLD_strlower(textbuffer);


	fclose(f);


	// for every type that we know about...

	//	LOGGER_log("FILETYPE_get_filetype:%s:%d: Max type index = %d",__FILE__,__LINE__,testblock_count);

	for(typeindex = 0;
			typeindex < glb->testblock_count;
			typeindex++)
	{

		t = glb->testblock[typeindex];

		if (!t)
		{
			LOGGER_log("BLOCKS_get_filetype: WARNING: Index %d not available for array testblock[] (max = %d)",typeindex, glb->testblock_count );
			continue;
		}


		// If we have a token-sequence test requirement

		if (t->testtype == _FILETYPE_TYPETEST_TOKENS)
		{
			result = FILETYPE_test_text(textbuffer, textitemsread, t );
		}
		else
		{
			result = FILETYPE_test_binary(testwindow, byteitemsread, t );
		}

		// If we got a positive hit from our tests, then it means we've
		//	found our file type! rejoice by breaking out.

		if (result > 0)
		{
			if (FILETYPE_DEBUG) LOGGER_log("%s:%d:FILETYPE_get_filetype: Filetype look resulted in a HIT, index = %d", FL, typeindex );

			ftype = typeindex;
			break;
		}
		else ftype = -1;


	} // for each filetype in the list


	if (testwindow) free(testwindow);
	if (textbuffer) free(textbuffer);

	return ftype;
}



/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_is_file_of_type
  Returns Type	: int
  ----Parameter List
  1. char *filename, 
  2.  char *filetype , 
  ------------------
  Exit Codes	: 
  0 = no match
  1 = match located

  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_is_file_of_type( char *filename, char *filetype )
{
	int result=0;
	int typeindex;

	// for every type that we know about...

	for (typeindex = 0; typeindex < glb->testblock_count; typeindex++)
	{

		struct FILETYPE_typerec *t;

		t = glb->testblock[typeindex];

		// Does the filetype name match (in part or whole) with what we're looking for?
		// If so, then proceed to test the file given, with the current filetype

		if (strncmp(filetype, t->full, strlen(filetype))==0)
		{
			result = FILETYPE_is_filetype( filename, typeindex );
			if (result == 1) break;

		} // If the current file type matches the one we're wanting to test for

	} // For every file type

	return result;
}

/*------------------------------------------------------------------------
Procedure:     ACL_www_build_typelist ID:1
Purpose:       Builds a list of file-type items for use in the ACL_www_aclitemview page
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPE_generate_www_option_list( char *varname, char *whichkey )
{

	char *g1, *g2, *g3, *gn;
	char sel[]="";
	char keystring[1024];
	int i;

	g1 = g2 = g3 = gn = NULL;

	fprintf(stdout,"\n<SELECT name=\"%s\" id=\"id%s\">\n", varname, varname);

	fprintf(stdout,"<OPTION value=\"unknown\">-:Unknown:-\n");
	fprintf(stdout,"<OPTION value=\"%s\">-:%s:-\n",_FILETYPE_SPECIAL_ASCII_TEXT,_FILETYPE_SPECIAL_ASCII_TEXT);
	fprintf(stdout,"<OPTION value=\"%s\">-:%s:-\n",_FILETYPE_SPECIAL_BINARY_UNKNOWN,_FILETYPE_SPECIAL_BINARY_UNKNOWN);

	for ( i = 0; i < glb->testblock_count; i++ )
	{
		struct FILETYPE_typerec *t;

		t = glb->testblock[i];

		/* If our Group 1 name has changed, we better display the new group 1 Name */
		if ((!g1)||(strcmp(g1,t->group1)))
		{
			g1 = t->group1;
			snprintf(keystring,1023,"%s",g1);
			fprintf(stdout,"<OPTION %s value=\"%s\">%s\n",sel,keystring,g1);
		}

		/* If our Group 2 name has changed, we better display the new group 2 Name */
		if ((!g2)||(strcmp(g2,t->group2)))
		{
			g2 = t->group2;
			snprintf(keystring,1023,"%s:%s",g1,g2);
			fprintf(stdout,"<OPTION %s value=\"%s\">&nbsp;&nbsp;\\%s\n",sel,keystring,g2);
		}

		/* If our Group 3 name has changed, we better display the new group 3 Name */
		if ((!g3)||(strcmp(g3,t->group3)))
		{
			g3 = t->group3;
			snprintf(keystring,1023,"%s:%s:%s",g1,g2,g3);
			fprintf(stdout,"<OPTION %s value=\"%s\">&nbsp;&nbsp;|&nbsp;&nbsp;\\%s\n",sel,keystring,g3);
		}

		if ((!gn)||(strcmp(gn,t->name)))
		{
			/* Now we can print the whole string */
			gn = t->name;
			snprintf(keystring,1023,"%s:%s:%s:%s",g1,g2,g3,t->name);
			fprintf(stdout,"<OPTION %s value=\"%s\">&nbsp;&nbsp;|&nbsp;&nbsp;|&nbsp;&nbsp;\\%s\n",sel,keystring,t->name);
		}


		fflush(stdout);
	}

	fprintf(stdout,"</select>\n");
	fflush(stdout);

	return 0;
}




/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_init
  Returns Type	: int
  ----Parameter List
  1. void , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_init( void )
{
	glb->debug = 0;
	glb->testblock_count = 0;
	glb->type_highestkey = 0;
	glb->maxtestoffset = 0;
	glb->loaded_block_count = 0;

	return 0;
}



/*-----------------------------------------------------------------\
  Function Name	: FILETYPE_done
  Returns Type	: int
  ----Parameter List
  1. void , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int FILETYPE_done( void )
{
	FILETYPE_clear();

	return 0;
}
