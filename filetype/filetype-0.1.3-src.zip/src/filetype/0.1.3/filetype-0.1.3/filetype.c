/*------------------------------------------------------------------------
Module:        /extra/development/xamime-2.0.0/typetest.c
Author:        PLD
Project:       Xamime
State:         Alpha
Creation Date: 30/10/2001
Description:   Returns to stdout the file-type which Xamime -thinks- the specificed file is.
------------------------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#ifndef WIN32
#include <unistd.h>
#include <syslog.h>
#else
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef WIN32_LEAN_AND_MEAN
#endif
#include <errno.h>

#include "logger.h"
#include "libfiletype.h"

#define FILETYPEAPP_SPECFILE_COUNT_MAXIMUM 100
#define FILETYPEAPP_FILELIST_COUNT_MAXIMUM 100
#define FILETYPEAPP_SPEC_FILEPATH_SIZE 1024

#ifdef WIN32
#define DIRECTORY_SEPERATOR '\\'
#define SEARCHLIST_SEPARATOR ';'
#else
#define DIRECTORY_SEPERATOR '/'
#define SEARCHLIST_SEPARATOR ':'
#endif

char *spec_locations[]= {
	"$FILESPECPATH",
	"/etc/filetype.spec",
	"~/.filetypespec",
	"filetype.spec",
	".",
	NULL
};

char version[]="v0.1.3 - 06-April-2004 (C) PLDaniels http://www.pldaniels.com/filetype";
char help[]="Usage:\n"
"\tfiletype [ -s filetype-spec file ] [-h|--help] [-v|--version] [-d|--debug] [--log-stdin|--log-stderr|--log-syslog] [-f <filename|->] <file> [file...]\n"
"\tOptions available :\n"
"\t-f : Specify a file containing a list of files to test,\n"
"\t\tmultiple file lists can be used by specifying each one as\n"
"\t\ta seperate '-f filelist' paramter. Additionally, use '-f -'\n"
"\t\tif you wish to read the file list from STDIN\n"
"\t-s : Specify the location of a filetype spec file,\n"
"\t\tmultiple spec files can be used by specifying each one as\n"
"\t\ta seperate '-s specfile' parameter.\n"
"\t-h, --help : This help message\n"
"\t-v, --version : Give version information\n"
"\t-d, --debug : Turn on debugging\n"
"\t--verbose : Display additional runtime information\n"
"\t--log-stdout : Send verbose/debug output to stdout\n"
"\t--log-stderr : Send verbose/debug output to stderr\n"
"\t--log-syslog : Send verbose/debug output to syslog (if available)\n";



struct FILETYPEAPP_globals {
	char *specfiles[ FILETYPEAPP_SPECFILE_COUNT_MAXIMUM ];
	int specfile_count;

	char *filelists[ FILETYPEAPP_FILELIST_COUNT_MAXIMUM ];
	int filelist_count;

	char *programdir;

	int first_file_index;
	int no_parameter_flags;

	int verbose;
	int debug;
};



/*------------------------------------------------------------------------
Procedure:     FILETYPEAPP_parse_parameters ID:1
Purpose:       Determine the required operational settings from the command line parameters
Input:         struct FILETYPEAPP_globals *glb: Pointer to the global struct
int argc: Number of parameters in array
char **argv: pointer to an array of parameters which are char * strings
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPEAPP_parse_parameters( struct FILETYPEAPP_globals *glb, int argc, char **argv )
{
	int i;
	int result = 0;
	struct stat buf;
	char *p;

	// If there are insufficient parameters passed to the filetype application
	//		then let the caller know what we're expecting.

	if ( argc < 2 )
	{
		fprintf(stdout,"%s\n",version);
		fprintf(stderr,"%s\n",help);
		exit(1);
	}

	// Set our application calling parameter.
	//		This is used in the searching of the filetype.spec
	//		files in FILETYPEAPP_locate_specfile()
	glb->programdir = argv[0];

#ifdef WIN32
	if ( strrchr(argv[0], '\\') == NULL )
	{
		// not a fully qualified pathname, retrieve it
		char  szTemp[1024];
		if ( GetModuleFileName(NULL, szTemp, sizeof(szTemp)) ) {
			glb->programdir = strdup(szTemp);
		}
		if ( glb->programdir == NULL ) {
			glb->programdir = argv[0];
		}
	}
#endif

	// So far we have not encountered any parameters with the '-'
	//		prefix ( because we've just started )
	//
	// We use this so that we can determine if the command line
	//		parameters was entirely filenames and take appropriate
	//		steps to ensure that filetype starts testing the files
	//		from the correct command parameter index.

	glb->no_parameter_flags = 1;

	// Cycle through every parameter, looking for any which start with
	//		a hyphen '-', then check to see if there's a letter or
	//		additional hypen there after... then process the chosen
	//		flag and look for any addtional required params.

	for (i = 1; i < argc; i++)
	{
		// If we don't have a leading '-' on our parameter, then we take this
		//		to mean that there are no more flags to follow, thus, anything
		//		additional parameters left will [ should ] be the files we're
		//		wanting to test.  We set the 'first_file_index' to indicate this
		//		as it is used later as the 'start off' point for the filenames we
		//		need to test.

		if (argv[i][0] != '-')
		{
			glb->first_file_index = i;
			break;

		} else {


			// Otherwise... if the first character is a hyphen '-', we
			//		will need to process the parameter as a flag.

			glb->no_parameter_flags = 0;

			switch (argv[i][1])
			{

				case 'd': FILETYPE_set_debug(1); glb->debug=1; break;
				case 'v': fprintf(stdout,"%s\n",version); exit(1); break;
				case 'h': fprintf(stderr,"%s\n",help); exit(1); break;
				case 's':
							 i++;
							 result = stat( argv[i], &buf );
							 if ( result != 0 )
							 {
								 fprintf(stderr,"%s:%d: ERROR - Cannot locate specfile '%s' (%s)\n", __FILE__, __LINE__, argv[i], strerror(errno) );
								 exit(1);
							 } else {
								 glb->specfiles[glb->specfile_count] = strdup( argv[i] );
								 glb->specfile_count++;
							 }
							 break;

				case 'f':
							 i++;

							 // If the filelist filename is a single '-', then we
							 //		are reading from STDIN, thus we do not attempt
							 //		to stat the file.

							 if ( strcmp( argv[i], "-" ) == 0 ) result = 0;
							 else result = stat( argv[i], &buf );

							 if ( result != 0 )
							 {
								 fprintf(stderr,"%s:%d: ERROR - Cannot locate filelist '%s' (%s)\n", __FILE__, __LINE__, argv[i], strerror(errno) );
								 exit(1);
							 } else {
								 glb->filelists[glb->filelist_count] = strdup( argv[i] );
								 glb->filelist_count++;
							 }
							 break;


							 // if we get ANOTHER hyphen '-' symbol, then we have an extended flag

				case '-':
							 p = &(argv[i][2]);
							 if (strncmp(p,"debug",strlen("debug")) == 0 ) { FILETYPE_set_debug(1); break; }
							 else if (strncmp(p,"help",strlen("help")) == 0 ) { fprintf(stderr,"%s\n",help); exit(1); break;  }
							 else if (strncmp(&(argv[i][2]),"version", strlen("version")) == 0 ) { fprintf(stdout,"%s\n", version ); exit(1); }
							 else if (strncmp(p, "verbose", strlen("verbose"))==0) { glb->verbose=1; FILETYPE_set_verbose(1); }
							 else if (strncmp(p, "log-stdout",strlen("log-stdout"))==0) { LOGGER_set_output_mode(_LOGGER_STDOUT); }
							 else if (strncmp(p, "log-stderr",strlen("log-stderr"))==0) { LOGGER_set_output_mode(_LOGGER_STDERR); }
#ifndef WIN32
							 else if (strncmp(p, "log-syslog",strlen("log-syslog"))==0) { LOGGER_set_output_mode(_LOGGER_SYSLOG); LOGGER_set_syslog_mode( LOG_MAIL|LOG_INFO ); }
#endif
							 else {
								 fprintf(stderr, "Cannot interpret option \"%s\"\n%s\n",argv[i],help);exit(1);break;
							 }
							 break;

							 // else, just dump out the help message

				default : fprintf(stderr, "Cannot interpret option \"%s\"\n%s\n",argv[i],help);exit(1);break;

			} // Switch argv[i][1]
		} // if argv[i][0] == -
	} // for

	return result;
}


int FILETYPEAPP_locate_specfile_home( struct FILETYPEAPP_globals *glb )
{
	return 0;
}

int FILETYPEAPP_locate_specfile_cwd( struct FILETYPEAPP_globals *glb )
{
	return 0;
}

int FILETYPEAPP_locate_specfile_envvar( struct FILETYPEAPP_globals *glb )
{
	return 0;
}

/*------------------------------------------------------------------------
Procedure:     FILETYPEAPP_locate_specfile ID:1
Purpose:       Attempts to locate default specfiles
Input:         struct FILETYPEAPP_globals *glb: Pointer to global structure
Output:        Appends any located specfiles to the globals specfiles[] array
Errors:
------------------------------------------------------------------------*/
int FILETYPEAPP_locate_specfile( struct FILETYPEAPP_globals *glb )
{
	int j, i = 0;
	int result = 0;
	struct stat buf;
	char filepath[1024];
	char *env_home;
	char *p;

	// Go through each filetype.spec potential location, making sure that
	//		we put the most 'specific' location _LAST_, this way, if there
	//		are multiple potential spec files, we ensure that the most specific
	//		gets used.

	while ( spec_locations[i] != NULL )
	{
		// Test the spec location, if it has a leading ~/ combination
		//		this means that we have a 'home directory' specifier and
		//		thus should test for the presence of the home directory
		//		environment variable.  If the $HOME exists, we will
		//		proceed to use it in our specfile location test, if it
		//		doesn't exist that's okay, we just carry on and if at the
		//		end of all the testing no specfile has been found the
		//		higher level operations will report an error.

		if ((spec_locations[i][0] == '~')&&(spec_locations[i][1] == '/'))
		{
			env_home = getenv("HOME");
#ifdef WIN32
			if ( env_home == NULL )
				env_home = getenv("HOMEPATH");
#endif
			if ( env_home != NULL )
			{

#ifdef NO_SNPRINTF
				sprintf( filepath, "%s%s", env_home, &spec_locations[i][1] );
#else
				snprintf( filepath, sizeof(filepath), "%s%s", env_home, &spec_locations[i][1] );
#endif
			}

		}
		else if ((spec_locations[i][0] == '.')&&(spec_locations[i][1] == '\0'))
		{
			// Path of invoked program test, that is, if we write
			//		"/usr/local/bin/filetype foo", this will check to
			//		see if there's a /usr/local/bin/filetype.spec

			p = strrchr(glb->programdir, DIRECTORY_SEPERATOR);
			if (p != NULL)
			{
				*p = '\0';
#ifdef NO_SNPRINTF
				sprintf( filepath, "%s%cfiletype.spec", glb->programdir, DIRECTORY_SEPERATOR);
#else
				snprintf( filepath, sizeof(filepath), "%s%cfiletype.spec", glb->programdir, DIRECTORY_SEPERATOR);
#endif
				*p = DIRECTORY_SEPERATOR;
			}

		}
		else if (spec_locations[i][0] == '$')
		{
			char searchentry[1024];

			// Environmentvariable with path definition
			env_home = getenv( &spec_locations[i][1] );
			if (env_home == NULL)
			{
				i++;
				continue;		// not defined, skip
			}


			// we assume the variable contains a search path
			for ( j=0, p=env_home;   ; p++ )
			{
				searchentry[j++] = *p;
				if ( (*p == '\0') || (*p == SEARCHLIST_SEPARATOR) )
				{
					// found entry, add spec and check
					searchentry[j-1] = '\0';
#ifdef NO_SNPRINTF
					sprintf( filepath, "%s%cfiletype.spec", searchentry, DIRECTORY_SEPERATOR);
#else
					snprintf( filepath, sizeof(filepath), "%s%cfiletype.spec", searchentry, DIRECTORY_SEPERATOR);
#endif

#ifdef WIN32
					// make sure any remaining separators are conformant
					for ( j=0; filepath[j]; j++)
					{
						if (filepath[j] == '/')
						{
							filepath[j] = '\\';
						}
					}
#endif

					result = stat( filepath, &buf );
					if ( result == 0 )
					{
						// only the very first one is used
						break;
					}

					// reset due to new search entry
					j = 0;
				}

				// break at end of search string
				if (*p == '\0')
				{
					break;
				}
			}
#ifdef WIN32
		} else if (spec_locations[i][0] == '/') {

			// prefix it with the parent of the programdir

			p = strrchr(glb->programdir, DIRECTORY_SEPERATOR);
			if (p != NULL)
			{
				*p = '\0';
#ifdef NO_SNPRINTF
				sprintf( filepath, "%s%c..%c%s", glb->programdir, DIRECTORY_SEPERATOR, DIRECTORY_SEPERATOR, spec_locations[i]);
#else
				snprintf( filepath, sizeof(filepath), "%s%c..%c%s", glb->programdir, DIRECTORY_SEPERATOR, DIRECTORY_SEPERATOR, spec_locations[i]);
#endif
				*p = DIRECTORY_SEPERATOR;
			}
#endif /* WIN32 */
		} else {

			// If we have a 'normal' potential specfile location
			//		then just copy it directly into the filepath

#ifdef NO_SNPRINTF
			sprintf( filepath, "%s", spec_locations[i] );
#else
			snprintf( filepath, sizeof(filepath), "%s", spec_locations[i] );
#endif
		}

#ifdef WIN32
		// make sure any remaining separators are conformant
		for ( j=0; filepath[j]; j++)
		{
			if (filepath[j] == '/')
			{
				filepath[j] = '\\';
			}
		}
#endif

		result = stat( filepath, &buf );
		if ( result == 0 )
		{
			glb->specfiles[glb->specfile_count] = strdup( filepath );
			glb->specfile_count++;
		}

		i++;
	}

	return 0;
}




/*------------------------------------------------------------------------
Procedure:     FILETYPEAPP_init ID:1
Purpose:       Initializses global parameters to ensure sane operations.
Input:         struct FILETYPEAPP_globals *glb:  Pointer to our global struct
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPEAPP_init( struct FILETYPEAPP_globals *glb )
{
	glb->verbose = 0;
	glb->debug = 0;
	glb->specfile_count = 0;
	glb->specfiles[0] = NULL;
	glb->first_file_index = 0;
	glb->filelist_count = 0;
	glb->filelists[0] = NULL;
	glb->programdir = NULL;

	FILETYPE_init();

	return 0;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPEAPP_filetype_test ID:1
Purpose:       Test all the files required
Input:         struct FILETYPEAPP_globals *glb: pointer to the global variables structure
int argc: number of parameters on the command line
char **argv: pointer to the array of strings consisting of the command line parameters
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPEAPP_filetype_test( struct FILETYPEAPP_globals *glb, int argc, char **argv )
{
	int i;
	char *p;
	char buffer[1024];
	char name[128];
	char comment[128];
	int blen;
	int type_index;
	FILE *f;



	// We have to go through every file as given on the command line
	//		and test its type.  First we have to actually ask libfiletype
	//		to test each file uniquely, _get_filetype() will return to us
	//		an integer representing if the test was successful or not
	//		( >= 0 is success ).  If the search is successful, we can then
	//		request information about the filetype by firstly converting the
	//		return code into a 'key' ( string detailing the filetype uniquely )
	//		and additionally getting a comment for that filetype ( arbitary string )
	//
	// If the return code < 0, then libfiletype did not know what the filetype is.

	for (i = 0 ; i < glb->filelist_count; i++)
	{
		// Check to see if the filename we're attempting to
		//		use is the STDIN one ( single hyphen, '-' ), if so
		//		we just assign f to be 'stdin', otherwise we attempt
		//		to open the file using the normal fopen() call.

		if ( strcmp( glb->filelists[i], "-" ) == 0 )
		{
			f = stdin;
		} else {
			f = fopen( glb->filelists[i], "r" );
		}

		if ( f == NULL )
		{
			LOGGER_log("FILETYPEAPP_filetype_test: WARNING: Could not open filelist '%s' (%s)", glb->filelists[i], strerror(errno));
		} else {

			// If our source of the files opened up okay, then we can proceed
			//		to read off our file list, one filename per line

			while (fgets( buffer, sizeof(buffer), f))
			{

				// Test the buffer for trailing \n and remove it because
				//		otherwise this can/will affect the operation of the
				//		FILETYPE_get_filetype() calls.
				//
				// Make sure we have a sane filename before sending it to
				//		FILETYPE_get_filetype(), even though it should protect
				//		itself from dodgy input.
				
				blen = strlen(buffer);
				if (blen > 0)
				{
					if (buffer[blen -1] == '\n') { buffer[blen -1] = '\0'; blen--; }
					if (blen > 0)
					{
						type_index = FILETYPE_get_filetype( buffer );
						if (type_index >= 0)
						{
							FILETYPE_get_name_by_index( name , sizeof(name), type_index );
							FILETYPE_get_comment_by_index( comment, sizeof(comment), type_index );
							fprintf( stdout,"%s\t\t\t\"%s\" (%s)\n", buffer, name, comment);
						}
						else if (type_index == -2)
						{
							fprintf(stdout,"%s\t\t\t\tDirectory.\n", buffer);
						}
						else
						{
							fprintf( stdout,"%s\t\t\t\tUnknown.\n", buffer);
						}
					} // if blen > 0 (after \n removal )
				} // if blen > 0 (before \n removal )
			} // while fgets()

			fclose(f);

		} // If fopen() wasn't NULL
	}

	// Test the filetypes as given on the command line parameters
	//
	// Note - It's quite possible for first_file_index to not be set
	//		due to if filetype was called without any filename's on its
	//		parameter list, ie:
	//
	//		./filetype -f foobar
	//
	// Additionally, it's possible to have a parameter list where there
	//		was no flags, but there are paramters, this is indicated if
	//		the glb->no_parameter_flags is set ( to 1 ), we must test
	//		the other command line parameters as files in this case.

	if (( glb->first_file_index > 1 )||( glb->no_parameter_flags == 1 ))
	{
		for (i = glb->first_file_index ; i < argc; i++)
		{
			type_index = FILETYPE_get_filetype(argv[i]);
			p = argv[i];
			if (type_index >= 0)
			{
				FILETYPE_get_name_by_index( name , sizeof(name), type_index );
				FILETYPE_get_comment_by_index( comment, sizeof(comment), type_index );
				fprintf( stdout,"%s\t\t\t\"%s\" (%s)\n",p, name, comment);
			}
			else if (type_index == -2)
			{
				fprintf(stdout,"%s\t\t\t\tDirectory.\n", p);
			}
			else
			{
				fprintf( stdout,"%s\t\t\t\tUnknown.\n",p);
			}
		}
	}

	return 0;
}



/*------------------------------------------------------------------------
Procedure:     FILETYPEAPP_done ID:1
Purpose:       Perform any cleanup routines needed to ensure good resource management and sanity
Input:         struct FILETYPEAPP_globals *glb: Global parameters structure
Output:
Errors:
------------------------------------------------------------------------*/
int FILETYPEAPP_done( struct FILETYPEAPP_globals *glb )
{
	int i;

	// Free all the strings strdup'd for the specfiles.
	for ( i = 0; i < glb->specfile_count; i++ )
	{
		if ( glb->specfiles[i] ) free( glb->specfiles[i] );
	}
	glb->specfile_count = 0;


	// Free all the strings strdup'd for the listfiles.
	for ( i = 0; i < glb->filelist_count; i++ )
	{
		if ( glb->filelists[i] ) free( glb->filelists[i] );
	}
	glb->filelist_count = 0;

	return 0;
}


/*-----------------------------------------------------------------\
  Function Name	: main
  Returns Type	: int
  ----Parameter List
  1. int argc, 
  2.  char **argv , 
  ------------------
  Exit Codes	: 
  Side Effects	: 
  --------------------------------------------------------------------
Comments:

--------------------------------------------------------------------
Changes:

\------------------------------------------------------------------*/
int main( int argc, char **argv )
{

	int i;
	struct FILETYPEAPP_globals glb;

	FILETYPEAPP_init( &glb );

	LOGGER_set_output_mode(_LOGGER_STDOUT);


	// Step 1 - perform local application configurations, this isn't really required
	//		if you're using libfiletype from within your own application [ ie a constrained
	//		environment.  For the filetype application however we need to provide a set of
	//		options for the user to use.

	FILETYPEAPP_parse_parameters( &glb, argc, argv );

	// A very important part of setting up libfiletype is to be able to specify
	//		the location of the filetype.spec file.  Without the filetype.spec file
	//		everything else is useless.
	//
	//	Here we're testing to see if the user hasn't given us a location. If there's
	//		no explicit location, we have to try and find the filetype.spec file on our
	//		own, hopefully in one of the predefined locations.

	if ( glb.specfile_count == 0 )
	{
		FILETYPEAPP_locate_specfile( &glb );
		if ( glb.specfiles[0]=='\0' )
		{
			LOGGER_log("\
					No specfile was specified or was able to be located.\n\
					Please check to see you have a specfile located at /etc/filetype.spec or $HOME/.filetypespec\n\
					or you have specified a specfile using the -s parameter\n\
					\n");
			exit(1);
		}

		if (glb.verbose) LOGGER_log("Specfile located at %s",glb.specfiles[0]);
	}


	// Okay, now we're into the actual libfiletype routines, first up
	//		we run the _init() call ( Object Orientated code ;-), after
	//		that we read the BINARY spec file in using _readb()
	//
	//	We should really check the return codes of the _readb(), but, for
	//		now we'll assume all went well.

	if (glb.verbose) LOGGER_log("Reading database");
	for ( i = 0; i < glb.specfile_count; i++ )
	{
		FILETYPE_readb( glb.specfiles[i] );
		if (glb.verbose) LOGGER_log("Types loaded from database '%s'", glb.specfiles[i]);
	}
	if (glb.verbose) LOGGER_log("%d file types loaded.", FILETYPE_get_typecount());


	// Test the filetypes

	FILETYPEAPP_filetype_test( &glb, argc, argv );

	// Clean up anything which needs to be done once we've finished

	FILETYPE_done();
	FILETYPEAPP_done( &glb );


	return 0;
}

/*--------------------------------------END. */
