#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "libfiletype.h"
#include "logger.h"




/*-----------------------------------------------------------------\
 Function Name	: main
 Returns Type	: int
 	----Parameter List
	1. int argc, 
	2.  char **argv , 
 	------------------
 Exit Codes	: 
 Side Effects	: 
--------------------------------------------------------------------
 Comments:
 
--------------------------------------------------------------------
 Changes:
 
\------------------------------------------------------------------*/
int main( int argc, char **argv )
{
	int result = 0;
	int count1, count2, count3;
	char *input_fname, *output_fname, *bname;

	if (argc != 3)
	{
		fprintf(stderr,"buildtypes usage\n"
				"\tbuildtypes <text form type list filename> <output filename>\n\n");
		exit(1);
	}

	bname = argv[0];
	input_fname = argv[1];
	output_fname = argv[2];

	FILETYPE_init();

	fprintf(stdout, "Reading in text database...\n");
	FILETYPE_import_list( input_fname );

	count1 = FILETYPE_get_typecount();
	fprintf(stdout, "%d types read in...\n", count1);

	FILETYPE_writeb( output_fname );
	count2 = FILETYPE_get_typecount();

	fprintf(stdout,"Clearing database...\n");
	FILETYPE_clear();

	// We need to re-init the FILETYPE specs again, because we
	//		are now able to read in multiple filetype specfiles.
	//		which would cause the verification to fail because in
	//		effect, we'd be loading the same DB twice and thus it'll
	//		return a typecount 2x the real size.

	FILETYPE_init();
	fprintf(stdout,"Reading in binary database...\n");
	FILETYPE_readb( output_fname );

	count3 = FILETYPE_get_typecount();
	fprintf(stdout,"%d types read in from binary database\n", count3);

	FILETYPE_sort_types();
	FILETYPE_writeb( output_fname );

	if ((count1 == count2)&&(count2 == count3))
	{
		fprintf(stdout,"Types database verified.\n");
	} else {
		fprintf(stdout,"ERROR - the databases differed in counts (%d:%d:%d)\n", count1, count2, count3 );
	}

	FILETYPE_clear();

	return result;
}
