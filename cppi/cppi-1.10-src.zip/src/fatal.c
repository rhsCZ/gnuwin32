/* Generate fatal and warn functions from a common base definition.  */
#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdio.h>

/* I'm not going to worry about SunOS's /bin/cc (which doesn't have this file)
   for now.  If some significant system fails to compile this file, then
   maybe I'll consider pulling in all the cruft that's in error.c.  */
#include <stdarg.h>

#include <errno.h>
#ifndef errno
extern int errno;
#endif

#include <stdlib.h>

extern char *strerror (int);

#if HAVE_STRERROR
# ifndef strerror		/* On some systems, strerror is a macro */
char *strerror ();
# endif
#else
static char *
private_strerror (int errnum)
{
  extern char *sys_errlist[];
  extern int sys_nerr;

  if (errnum > 0 && errnum <= sys_nerr)
    return sys_errlist[errnum];
  return "Unknown system error";
}
# define strerror private_strerror
#endif	/* HAVE_STRERROR */

/* Format an error message and print it on stderr.  Then, the `fatal'
   incarnation of this macro exits; `warn' just returns.  */

#define FW_DECL(Name)							\
void									\
Name (EXIT_STATUS_DCL int errnum, const char *format, ...)		\
{									\
  va_list arg;								\
									\
  va_start (arg, format);						\
  vfprintf (stderr, format, arg);					\
  va_end (arg);								\
									\
  if (errnum)								\
    fprintf (stderr, ": %s", strerror (errnum));			\
  putc ('\n', stderr);							\
  EXIT_WITH_STATUS;							\
}

#define EXIT_STATUS_DCL /* empty */
#define EXIT_WITH_STATUS /* empty */
FW_DECL(warn)

#undef EXIT_STATUS_DCL
#undef EXIT_WITH_STATUS
#define EXIT_STATUS_DCL int exit_status,
#define EXIT_WITH_STATUS exit (exit_status)
FW_DECL(fatal)
