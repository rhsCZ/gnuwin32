#ifndef FATAL_H_
# define FATAL_H_

# ifndef __attribute__
#  if __GNUC__ < 2 || (__GNUC__ == 2 && __GNUC_MINOR__ < 5) || __STRICT_ANSI__
#   define __attribute__(Spec) /* empty */
#  endif
# endif

# if __STDC__
void fatal (int, int, const char *, ...) \
  __attribute__ ((__format__ (__printf__, 3, 4), __noreturn__));
# else
void fatal ();
# endif

# if __STDC__
void warn (int, const char *, ...) \
  __attribute__ ((__format__ (__printf__, 2, 3)));
# else
void warn ();
# endif

#endif /* FATAL_H_ */
