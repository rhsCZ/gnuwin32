/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 | Copyright (c) 1997-2004 Thomas Merz and PDFlib GmbH. All rights reserved. |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 |                                                                           |
 *---------------------------------------------------------------------------*/

/* $Id: pc_ebcdic.c,v 1.16.2.6 2004/09/28 16:22:00 kurt Exp $
 *
 * EBCDIC conversion routines
 *
 */

#include "pc_util.h"

/* ANSI C forbids an empty source file */
void pdc_dummy_ebcdic_c(void);
void pdc_dummy_ebcdic_c() {}

