/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 | Copyright (c) 1997-2005 Thomas Merz and PDFlib GmbH. All rights reserved. |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 *---------------------------------------------------------------------------*/

/* $Id: p_layer.c,v 1.65.2.9 2005/06/08 19:59:02 tm Exp $
 *
 * PDFlib optional content routines
 *
 */

#define P_LAYER_C

#include "p_intern.h"
#include "p_layer.h"
#include "p_tagged.h"











