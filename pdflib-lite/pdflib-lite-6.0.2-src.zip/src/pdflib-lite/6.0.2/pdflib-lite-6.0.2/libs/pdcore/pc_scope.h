/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 | Copyright (c) 1997-2005 Thomas Merz and PDFlib GmbH. All rights reserved. |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 |                                                                           |
 *---------------------------------------------------------------------------*/

/* $Id: pc_scope.h,v 1.25.2.1 2005/06/08 19:59:02 tm Exp $
 *
 * Scoping routines and macros
 *
 */

#ifndef PC_SCOPE_H
#define PC_SCOPE_H


#endif	/* PC_SCOPE_H */
