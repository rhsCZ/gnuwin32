Notes on the PDFlib C binding:

- On Linux systems gcc 3 or above is strongly recommended.
