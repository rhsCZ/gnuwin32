===================================
Notes on the PDFlib binding for PHP
===================================

This file has been superceded by the PDFlib-in-PHP-HowTo
document which is contained in all PDFlib for PHP distribution
packages as PDF (in the doc directory).
