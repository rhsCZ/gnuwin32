/* $Id: tiffvers.h,v 1.3 2001/03/21 10:41:18 rjs Exp $ */

#define TIFFLIB_VERSION_STR \
"LIBTIFF, Version 3.5.6 beta\nCopyright (c) 1988-1996 Sam Leffler\n\
Copyright (c) 1991-1996 Silicon Graphics, Inc."
/*
 * This define can be used in code that requires
 * compilation-related definitions specific to a
 * version or versions of the library.  Runtime
 * version checking should be done based on the
 * string returned by TIFFGetVersion.
 */
#define TIFFLIB_VERSION 20012401
