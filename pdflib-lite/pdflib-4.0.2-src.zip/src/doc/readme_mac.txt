Building PDFlib on Mac OS 9
===========================

To compile PDFlib with Metrowerks CodeWarrior, open the supplied
project file PDFlib.mcp with the Metrowerks IDE. The project file
contains a target for building a static PDFlib library, and a
target for building the pdftest sample program which uses this
static PDFlib library. pdftest is a simple command-line application
which demonstrates the use of PDFlib, but doesn't make any attempt
at doing fancy Mac GUI stuff.

Note: PDFlib does not need the Carbon library, and will therefore
not change the "Carbonized" status of your application.


Compiling the language wrappers
===============================

In order to compile the C wrappers for the supported languages you
will have to install the relevant source code package, and adjust the
include paths for these packages in the project file.
Since we supply prebuilt binaries for all supported languages this will
generally not be required.

Note: Mac OS X is fully supported as a Unix platform.
