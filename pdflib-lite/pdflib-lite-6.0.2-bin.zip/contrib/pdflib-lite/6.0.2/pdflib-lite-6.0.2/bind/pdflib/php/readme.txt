===================================
Notes on the PDFlib binding for PHP
===================================

This file has been superceded by the PDFlib-in-PHP-HowTo.pdf
document which is contained in all PDFlib for PHP distribution
packages as PDF (in the doc directory).

Or at http://www.pdflib.com/products/pdflib/info/PDFlib-in-PHP-HowTo.pdf
on our website.
