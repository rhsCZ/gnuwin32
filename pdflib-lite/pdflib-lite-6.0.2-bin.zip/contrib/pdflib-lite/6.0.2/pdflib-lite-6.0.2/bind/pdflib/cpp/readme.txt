Notes on the PDFlib C++ binding:

(none)
