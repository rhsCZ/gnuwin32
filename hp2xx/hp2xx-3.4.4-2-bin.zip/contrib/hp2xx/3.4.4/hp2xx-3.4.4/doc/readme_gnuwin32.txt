The Windows binary provided by the GnuWin32 project on http://sourceforge.net
apparently expects a writable TEMP directory in the root of the drive from which
it is started.
