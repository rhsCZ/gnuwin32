#include "hp2xx.h"
#include "bresnham.h"

void plot_PicBuf(PicBuf *pb, DevPt *pt, PEN_C color_index);
void polygon_PicBuf(DevPt, DevPt, DevPt, DevPt, PEN_C, PicBuf *);

