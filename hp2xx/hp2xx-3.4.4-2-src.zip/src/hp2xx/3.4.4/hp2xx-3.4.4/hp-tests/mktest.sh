for f in *.hp *.hpg *.plt ; do
	for mf in cad dxf em emf epic eps esc2 fig gpt hpgl img jpg mf nc pbm pcl pcx pac pic pdf png  rgip svg tiff; do
# pre
		echo $f $mf
		rm -f $f.err
		../sources/hp2xx.exe -m $mf -f $f.$mf $f 2>>$f.err
		if [ "$mf" = "eps" ]; then
			eps2pdf.cmd $f.eps
			mv -f $f.pdf $f.0.pdf
		fi
	done
done
