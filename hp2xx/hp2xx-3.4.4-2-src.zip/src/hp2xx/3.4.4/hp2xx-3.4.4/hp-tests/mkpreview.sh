for f in *.hp *.hpg *.plt ; do
	for mf in pre; do
		echo $f $mf
		../sources/hp2xx.exe -m $mf -f $f.$mf $f 2>$f.err
	done
done
