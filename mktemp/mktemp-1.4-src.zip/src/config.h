/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

#ifndef _MKTEMP_CONFIG_H
#define _MKTEMP_CONFIG_H

/* Define if you have the <inttypes.h> header file. */
/* #undef HAVE_INTTYPES_H */

/* Define if you have the `lrand48' function. */
/* #undef HAVE_LRAND48 */

/* Define if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define if you have the `mkdtemp' function. */
/* #undef HAVE_MKDTEMP */

/* Define if you have the <paths.h> header file. */
#define HAVE_PATHS_H 1

/* Define if your crt0.o defines the __progname symbol for you. */
/* #undef HAVE_PROGNAME */

/* Define if you have the `random' function. */
#define HAVE_RANDOM 1

/* Define if you have the `srandomdev' function. */
/* #undef HAVE_SRANDOMDEV */

/* Define if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Use the system or private version of mkdtemp? */
#define MKDTEMP priv_mkdtemp

/* Use the system or private version of mkstemp? */
#define MKSTEMP mkstemps

/* Define if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>. */
#define TIME_WITH_SYS_TIME 1

/* Location of random device/stream if you have one. */
// #undef _PATH_RANDOM "/dev/urandom"

/* Deal with ANSI stuff reasonably.  */
/* XXX */
/* #undef  __P */
#if defined (__cplusplus) || defined (__STDC__)
# define __P(args)		args
#else
# define __P(args)		()
#endif

/* Ignore __attribute__ if non-gcc or gcc < 2.5 */
#if !defined(__GNUC__) || __GNUC__ < 2 ||  (__GNUC__ == 2 && __GNUC_MINOR__ < 5)
#define __attribute__(args)
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `int' if <sys/types.h> does not define. */
#define ssize_t int

#endif /* _MKTEMP_CONFIG_H */
