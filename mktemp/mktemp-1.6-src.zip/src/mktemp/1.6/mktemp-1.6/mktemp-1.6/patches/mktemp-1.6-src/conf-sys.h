#ifndef _CONF_SYS_H
#define _CONF_SYS_H 1

#ifdef _WIN32

#  include <io.h>
#  include <sys/stat.h>

#  define mkdir(d,m)	_mkdir(d)
#  define lstat		stat

#  ifdef _PATH_TMP
#    undef _PATH_TMP
#  endif /* _PATH_TMP */
#  define _PATH_TMP "./"

int mkstemp(char *template);

#endif

#endif /* _CONF_SYS_H */
