/* Character which is used to separate path components. */
#undef PATH_SEPARATOR
#undef PATH_SEPARATOR_STR

/* Package name. */
#undef PACKAGE

/* Version number. */
#undef VERSION

/* Have strerror() function. */
#undef HAVE_STRERROR

/* Have memmove() function. */
#undef HAVE_MEMMOVE

/* Have memcpy() function. */
#undef HAVE_MEMCPY

/* Have strtoul() function. */
#undef HAVE_STRTOUL

/* How to retrieve the current working directory? */
#undef HAVE_GETCWD
#undef HAVE_GETWD

/*
 * Internationalization stuffs.
 */

#undef ENABLE_NLS

#undef HAVE_CATGETS

#undef HAVE_GETTEXT

#undef HAVE_LC_MESSAGES

#undef HAVE_STPCPY

#undef PROTOTYPES
