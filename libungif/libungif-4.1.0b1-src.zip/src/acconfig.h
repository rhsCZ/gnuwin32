/* Define if you have the gl_s library (SGI GL library). */
#undef HAVE_LIBGL_S

/* Define if you have the X11 library. */
#undef HAVE_LIBX11
