/* Provide relocatable packages.
   Copyright (C) 2003 Free Software Foundation, Inc.
   Written by Bruno Haible <bruno@clisp.org>, 2003.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU Library General Public License as published
   by the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA.  */


/* Specification.  */
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>

#if defined _WIN32 || defined __WIN32__
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
#endif

#include "file-nonposix.h"

#define ISSLASH(C)					((C) == '/' || (C) == '\\')
#define ISDIRSEP(C)					ISSLASH(C)

/* Original installation prefix.  */
static char *orig_prefix = NULL;
static size_t orig_prefix_len = 0;
/* Current installation prefix.  */
static char *curr_prefix = NULL;
static size_t curr_prefix_len = 0;
/* These prefixes do not end in a slash.  Anything that will be concatenated
   to them must start with a slash.  */
   
char *getshortpath (const char *longpath)
{
     char *shortpath = NULL;
     DWORD len, res;
     
     len = GetShortPathName(longpath, shortpath, 0);
     if (!len) {
//          set_werrno;
          return (char *) longpath;
     }
     shortpath = (char *) malloc (len + 1);
     if (!shortpath) {
//          set_werrno;
          return (char *) longpath;
     }
     res = GetShortPathName(longpath, shortpath, len);
     if (!res) {
          free (shortpath);
//          set_werrno;
          return (char *) longpath;
     }
     return shortpath;
}

int 
set_orig_prefix (const char *orig_prefix_arg)
{
	orig_prefix_len = strlen (orig_prefix_arg);
	return orig_prefix_len;
}

static char *
set_current_prefix ()
{
	LPTSTR curr_prefix_arg, q, lpFilePart;
	DWORD len;
	int nDIRSEP = 0;

	if (curr_prefix)
		free (curr_prefix);
	curr_prefix_arg = malloc (MAX_PATH * sizeof (TCHAR));
	if (!curr_prefix_arg) {
//		set_werrno;
		curr_prefix = NULL;
		curr_prefix_len = 0;
		return NULL;
	}		
	
	len = GetModuleFileName (NULL, curr_prefix_arg, MAX_PATH);
	if (!len) {
//		set_werrno;
		curr_prefix = NULL;
		curr_prefix_len = 0;
		return NULL;
	}
//	strncpy (curr_prefix_arg, ModuleName, MAX_PATH);
//	printf ("curr_prefix_arg: %s\n", curr_prefix_arg);
//	win2posixpath (curr_prefix_arg, curr_prefix_arg);
	curr_prefix = curr_prefix_arg;
	q = curr_prefix_arg + len - 1;
	/* strip name of executable and its directory */
	while (!ISDIRSEP (*q) && (q > curr_prefix_arg) && nDIRSEP < 2) {
		q--;
		if (ISDIRSEP (*q)) {
			*q = '\0';
			nDIRSEP++;
		}
	}
	curr_prefix_len = q - curr_prefix_arg; 
//	printf ("curr_prefix: %s\n", curr_prefix);
//	printf ("curr_prefix_len: %d\n", curr_prefix_len);
	return curr_prefix;
}

char *relocaten (const char *path)
{
	char *relative_path, *relocated_path, *relocated_short_path;
	int relative_path_len;
	
	if (!curr_prefix)
		set_current_prefix ();
//	printf ("path:                 %s\n", path);
//	printf ("orig_prefix:          %s\n", orig_prefix);
//	printf ("curr_prefix:          %s\n", curr_prefix);
//	if (strncmp (orig_prefix, path, orig_prefix_len))
//	if (strcmp (orig_prefix, path))
//		return (char *) path;
	relative_path = (char *) path + orig_prefix_len;
//	printf ("relative_path:        %s\n", relative_path);
	relative_path_len = strlen (relative_path);
	relocated_path = malloc (curr_prefix_len + relative_path_len + 1);
	strcpy (relocated_path, curr_prefix);
	strcat (relocated_path, relative_path);
//	printf ("relocated_path:       %s\n", relocated_path);
	relocated_short_path = getshortpath (relocated_path);
//	printf ("relocated_short_path: %s\n", relocated_short_path);
	if (relocated_short_path) {
		if (relocated_short_path != relocated_path)
			free (relocated_path);
		return relocated_short_path;
	} else
		return relocated_path;
}


char *relocatex (const char *installdir, const char *path)
{
	char *p;

	set_orig_prefix (installdir);
	if (access (path, R_OK))
		p = relocaten (path);
	else
		p = (char *) path;
//	printf ("relocatenx: %s\n", p);
	return p;
}

