#ifndef _NONPOSIX_H
#define _NONPOSIX_H 1

#include <fcntl.h>
#include <process.h>

#ifndef PIPE_BUF
#define PIPE_BUF 0
#endif /* PIPE_BUF  */

#define __set_errno(val)  errno = val

#define _stat  _stati64
#define stat   _stati64
#define _fstat _fstati64
#define fstat  _fstati64
#define off_t  __int64

#define lseek _lseeki64

extern inline int pipe (int pipedes[2])
{
     return _pipe(pipedes, 0, _O_BINARY | _O_NOINHERIT);
}


extern inline pid_t
wait (int *stat_loc)
{
     return _cwait (stat_loc, 0, 0);
}

extern inline int
fork ()
{
  __set_errno (ENOSYS);
  return -1;
}

#ifdef ENABLE_RELOCATABLE
# include <magic.h>
MAGIC_DLL_IMPEXP char *relocatex (const char *installdir, const char *path);
#else
# define relocatex(path,dir) (path)
#endif /* ENABLE_RELOCATABLE */

#endif /* _NONPOSIX_H */
