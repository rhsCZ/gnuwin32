void foo()
{
    /* first comment */

    /* second comment */ /* third comment */

 /*
       * fourth comment
    */

  /*
   ** fifth comment *
   */

/*
* sixth comment *
*/
}
