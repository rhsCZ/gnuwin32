static void
bar (char *foo)
{
  long whizzo;
  short spazzo;

  if (*foo == gibberish ())
    whizzo = spazzo;
}

char *
nevermind (char harrumph)
{
  char buf[1024];

  buf[3] = harrumph;
}
