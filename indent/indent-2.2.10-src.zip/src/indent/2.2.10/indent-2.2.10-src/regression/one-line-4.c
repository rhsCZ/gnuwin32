main (){ if (foo) { bar (33); grop (); } else foo (); return -1; }
