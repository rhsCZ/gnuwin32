main ()
{
  int size_;

  for (size_ = 32; size_ < n; size_ <<= 1);
}
