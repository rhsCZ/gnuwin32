void count_memory()
{
  int lc = 0,                   /* local clients */
    ch = 0,                     /* channels */
    co = 0; /* conf lines */
}
