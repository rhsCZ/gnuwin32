int foo (void)
{
  p = qsort (*aasdfagddsdf, *afasdfsdafasd, sizeof (struct foo),
             comparisonFunction);
}

