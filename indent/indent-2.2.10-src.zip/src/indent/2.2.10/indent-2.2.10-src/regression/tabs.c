

/* Here is a column 1 comment with	tab	tab and	tab
   In the columns:                ^        ^           ^ those */

main ()
{
  int i = 33;

     /* Here	there	everywhere	here..	and that's it
	tab ^--------^------------^-----------^------------- */

  foo (i);
}
