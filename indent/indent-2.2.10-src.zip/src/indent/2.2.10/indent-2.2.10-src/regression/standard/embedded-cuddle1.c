void foo()
{
#ifdef foo
    if (1) {
    }				/* if */
    {
	a++;
    }
#endif
}
