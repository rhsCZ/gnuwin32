void
main (void)
{
  if ((foofoofoo.barbarbar.
       bazbazbazbaz->foobar.foobaz.
       bazzbar->foobar.barbaz.bazfoo))
    a = 1;
}
