
int
foo()
{
    bar();
    /*
     * A comment 
     */
}
