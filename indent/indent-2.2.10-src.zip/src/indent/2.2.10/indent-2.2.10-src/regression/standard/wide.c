extern char *s = L"long string";

void
main (int argc, char *argv[])
{
  char *s1, *s2;
  char c;

  s1 = "foobar";
  if (x)
    foo ();

  s2 = L"barfoo";

  c = L'\0';
}
