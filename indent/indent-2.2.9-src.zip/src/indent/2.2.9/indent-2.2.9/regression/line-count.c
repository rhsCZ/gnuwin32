/* 1
 * 2
 * 3
 * 4

  

 * 5
 * 6
 * 7
 * 8
 */

 
  

func()
{
  /* Hello world
   * this is an
   * extra long

   *
   * multi-line
   * comment
   */
 

/*
*/

}
} /* deliberate mistake to provoke error */
