void foo()
{
  if (0)
  ;
  else if (acptr->from == one ||   /* ...was the one I should skip */
      (lp->flags & CHFL_ZOMBIE) || IsDeaf(acptr))
    continue;
}
