/* Try indent -st -ncs -TUNCH on this file */

void
foo ()
{
  char c = (UNCH)1;
}
