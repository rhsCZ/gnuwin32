int
foo (void)
{
     if (0)
	     {
		  ++i;
	     }
     {
	  ++i;
     }
}
