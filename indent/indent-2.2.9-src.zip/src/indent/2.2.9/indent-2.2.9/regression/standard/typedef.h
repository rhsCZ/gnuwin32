
typedef boolean (*PFB) ();

/* system defined globals */
extern int errno;
extern int sys_nerr;
extern char *sys_errlist[];
