void dblptr_main(void)
{
  double (*valfnc) (const char *);
}
