/*********************************************************************\
                        This is a test
                        of my style of block comment

Sometimes I like to do something like this.
\*********************************************************************/
void
Hello (void)
{
  printf ("Hello world.\n");
}
