void
foo ()
{
  if (1)
    if (1)
      if (else_chptr->creationtime && chanTS > chptr->creationtime
	  && chptr->creationtime != MAGIC_REMOTE_JOIN_TS)
      {
	int i;
      }
      else if (chptr->creationtime && chanTS > chptr->creationtime
	  && chptr->creationtime != MAGIC_REMOTE_JOIN_TS)
	;
      else if (chptr->creationtime && chanTS > chptr->creationtime
	  && chptr->creationtime != MAGIC_REMOTE_JOIN_TS)
      {
	j = 1;
	i = 2;
      }

  if (0)
    i = 0;
  else
    /* Seperate banmasks with a space because
       they can contain commas themselfs: */
  {
    j = 0;
  }
}
