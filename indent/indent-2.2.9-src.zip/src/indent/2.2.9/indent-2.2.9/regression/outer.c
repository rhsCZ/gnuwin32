/* Redistribution and use in source and binary forms are permitted
   permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
   IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
   OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */

/* Redistribution and use in source and binary forms are permitted
   permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
   IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
   OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */

int some_global;

  /* Redistribution and use in source and binary forms are permitted
     permission. THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
     IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
     OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE. */

				/* Here's a multi-line cooment where the
				   closing delimiter ends on a line by itself
				   */

main ()
{
  var1 = 33;
  while (grop ())
    {
      foob ();
      turds ();
    }

  exit ();
}
