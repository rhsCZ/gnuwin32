int foo()
{
  return (int)n;
}
