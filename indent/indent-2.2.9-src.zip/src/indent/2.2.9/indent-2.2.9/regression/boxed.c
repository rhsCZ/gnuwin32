/******************************************************************
 *                                                                *
 *  Here is a nice big boxed comment.  Enjoy it!!   file fill fil *
 *                                                                *
 ******************************************************************/

/*-------------------------------------------------------------------------.
| For a given SIDE, turn original input file in another one, in which each |
| word is on one line.                                                     |
`-------------------------------------------------------------------------*/

int global;

    /******************************************************************
     *                                                                *
     *  Here is a nice big boxed comment.  Enjoy it!!   file fill fil *
     *                                                                *
     ******************************************************************/

int barof;

/******************************************************************
 *                                                                *
 *  Here is a nice big boxed comment.  Enjoy it!!   file fill fil *
 *                                                                *
 ******************************************************************/

main ()
{
  printf ("Eat me\n");
}


/* Les boites de Francois */


/*====================================================================\
| Note that Standard Input must be associated to a virtual terminal.  |
| Further, it must be currently displayed for any sound to occur.     |
\====================================================================*/


/* Note that Standard Input must be associated to a virtual terminal.  */
/* Further, it must be currently displayed for any sound to occur.     */
/* ------------------------------------------------------------------- */


sfou ()
{
  while (foo)
    {
      printf ("Save me from indent");
      printf ("What idiot wrote this program?");
    }  /**************************************
	* Another woeird boxed comment       *
	*                                    *
	**************************************/


  i = 33;
  while (foo)
    {
      printf ("Save me from indent");
      printf ("What idiot wrote this program?");
    }
}
