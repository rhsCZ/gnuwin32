enum foo
bar ()
{
  if (1)
    {
      func (1);
    }
  return SUCCESSFUL;
}

void
bar (enum foo)
{
  if (1)
  {
    func (1); 
  }
}
