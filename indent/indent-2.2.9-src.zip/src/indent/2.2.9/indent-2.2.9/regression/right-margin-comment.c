int i;				/* this comment is just too long for one line 
				 */
