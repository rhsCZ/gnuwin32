/* Testing *INDENT-ON* and *INDENT-OFF* controls comments */

// *INDENT-ON*
// *INDENT-OFF*

main(int argc, char **argv)
{  char *foo;
  puts(foo);
}

grunt(int argc,
      char **argv
{     char *foo;
    puts(foo);
}
    /*   *INDENT-ON* */


/* shouldn *INDENT-ON* */

frobp (int argc, char **argv)
{
  char *foo;
      while (barl) { printf ("marglefrosh"); }
  puts(foo);
}

