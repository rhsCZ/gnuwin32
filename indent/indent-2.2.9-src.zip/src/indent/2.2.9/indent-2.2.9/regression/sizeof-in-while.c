f ()
{
  do
    g ();
  while (sizeof (char));
}
